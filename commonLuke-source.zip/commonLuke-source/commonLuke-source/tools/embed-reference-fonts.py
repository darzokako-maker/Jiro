import json
import sys
from pathlib import Path

source, destination = map(Path, sys.argv[1:])
faces = json.loads((source / 'metrics.json').read_text())
out = ['#pragma once', '#include <cstddef>', 'namespace client::ui::reference_fonts {',
       'struct Glyph {int x,y,width,height;};',
       'struct Face {int size,weight,width,height;float fontHeight;const unsigned char* png;std::size_t bytes;const Glyph* glyphs;};']
for i, face in enumerate(faces):
    data = (source / face['file']).read_bytes()
    out.append(f'inline constexpr unsigned char png{i}[] = {{' + ','.join(map(str, data)) + '};')
    out.append(f'inline constexpr Glyph glyphs{i}[] = {{' + ','.join('{' + ','.join(map(str, g)) + '}' for g in face['glyphs']) + '};')
out.append('inline constexpr Face faces[] = {')
for i, face in enumerate(faces):
    out.append('{' + ','.join(map(str, [face['size'], face['weight'], face['width'], face['height']])) +
               f',{face["fontHeight"]}f,png{i},sizeof(png{i}),glyphs{i}' + '},')
out.extend(['};', '}'])
destination.write_text('\n'.join(out), encoding='utf-8')
