#!/usr/bin/env python3
"""Verify the native, fileless distribution payload.

The DLL owns its generated packet-hook payload.  Distribution verification
therefore only needs to prove that the exact DLL (encrypted when configured)
is embedded in the loader and that no external payload path leaked into either
binary.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import struct
from pathlib import Path


LOG_LITERAL = re.compile(r'AOKI_LOG\s*\(\s*"((?:\\.|[^"\\])*)"')
SOURCE_SUFFIXES = {".cpp", ".cxx", ".cc", ".hpp", ".hxx", ".hh", ".h"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded_forms(text: str) -> tuple[bytes, bytes]:
    return text.encode("utf-8"), text.encode("utf-16-le")


def source_log_literals(source_root: Path) -> set[str]:
    literals: set[str] = set()
    for path in source_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in SOURCE_SUFFIXES:
            continue
        contents = path.read_text(encoding="utf-8", errors="ignore")
        for match in LOG_LITERAL.finditer(contents):
            try:
                value = ast.literal_eval('"' + match.group(1) + '"')
            except (SyntaxError, ValueError):
                value = match.group(1)
            if len(value) >= 8:
                literals.add(value)
    return literals


def require_nested(parent_name: str, parent: bytes, child_name: str, child: bytes) -> int:
    offset = parent.find(child)
    if offset < 0:
        raise SystemExit(f"{child_name} is not embedded byte-for-byte in {parent_name}")
    return offset


def rotate_left(value: int, amount: int) -> int:
    return ((value << amount) | (value >> (32 - amount))) & 0xFFFFFFFF


def quarter_round(state: list[int], a: int, b: int, c: int, d: int) -> None:
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = rotate_left(state[d] ^ state[a], 16)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotate_left(state[b] ^ state[c], 12)
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = rotate_left(state[d] ^ state[a], 8)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotate_left(state[b] ^ state[c], 7)


def chacha20(data: bytes, key: bytes, nonce: bytes) -> bytes:
    constants = (0x61707865, 0x3320646E, 0x79622D32, 0x6B206574)
    key_words = struct.unpack("<8I", key)
    nonce_words = struct.unpack("<3I", nonce)
    output = bytearray(len(data))
    for offset in range(0, len(data), 64):
        initial = list(constants + key_words + (1 + offset // 64,) + nonce_words)
        state = initial.copy()
        for _ in range(10):
            quarter_round(state, 0, 4, 8, 12); quarter_round(state, 1, 5, 9, 13)
            quarter_round(state, 2, 6, 10, 14); quarter_round(state, 3, 7, 11, 15)
            quarter_round(state, 0, 5, 10, 15); quarter_round(state, 1, 6, 11, 12)
            quarter_round(state, 2, 7, 8, 13); quarter_round(state, 3, 4, 9, 14)
        stream = struct.pack("<16I", *((state[i] + initial[i]) & 0xFFFFFFFF for i in range(16)))
        block = data[offset:offset + 64]
        output[offset:offset + len(block)] = bytes(a ^ b for a, b in zip(block, stream))
    return bytes(output)


def encrypted_payload(data: bytes, config_path: Path) -> bytes:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    password_digest = bytes.fromhex(config["password_sha256"])
    salt = bytes.fromhex(config["salt"])
    nonce = bytes.fromhex(config["nonce"])
    key = hashlib.pbkdf2_hmac("sha256", password_digest, salt, int(config["iterations"]), 32)
    return chacha20(data, key, nonce)


def reject_tokens(name: str, data: bytes, tokens: set[str]) -> None:
    for token in sorted(tokens):
        for encoded in encoded_forms(token):
            if encoded and encoded in data:
                raise SystemExit(f"{name} contains forbidden distribution token: {token!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dll", type=Path)
    parser.add_argument("loader", type=Path)
    parser.add_argument("native_source", type=Path)
    parser.add_argument("--cipher-config", type=Path)
    parser.add_argument("--allow-native-logs", action="store_true",
                        help="Diagnostic builds only: keep native log strings; still verify embedded payloads")
    args = parser.parse_args()

    dll = args.dll.read_bytes()
    loader = args.loader.read_bytes()

    embedded_dll = encrypted_payload(dll, args.cipher_config) if args.cipher_config else dll
    dll_offset = require_nested(
        args.loader.name,
        loader,
        "encrypted " + args.dll.name if args.cipher_config else args.dll.name,
        embedded_dll,
    )
    if args.cipher_config and dll in loader:
        raise SystemExit("plaintext commonLuke.dll must not be embedded in commonLukeLoader.exe")

    external_payload_tokens = {
        "C:\\Saori\\logs",
        "packet-hook.jar",
        "commonLuke.dll loader'in yaninda",
    }
    # Java diagnostic/dump constants are checked by the dedicated JAR verifier.
    # The same short words may legitimately occur in unrelated native UI code.
    log_tokens = set() if args.allow_native_logs else source_log_literals(args.native_source)
    reject_tokens("commonLuke.dll", dll, external_payload_tokens | log_tokens)
    reject_tokens("commonLukeLoader.exe", loader, external_payload_tokens | log_tokens)

    print("verified native-only DLL: no external Java payload requested")
    print(
        f"verified {'encrypted dll' if args.cipher_config else 'dll'}"
        f"@{dll_offset:,} in loader"
    )
    print(f"commonLuke.dll       sha256={digest(dll)} size={len(dll):,}")
    print(f"commonLukeLoader.exe sha256={digest(loader)} size={len(loader):,}")
    print("verified distribution: no external payload path or plaintext DLL; " +
          ("native diagnostic logging enabled" if args.allow_native_logs else "no compiled log literals"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
