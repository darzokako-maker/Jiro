"""Audited additions for the supplied dusunurum game; validates every descriptor."""
import json
from pathlib import Path
index=json.loads(Path('build/aura-game-index.json').read_text())
base=json.loads(Path('native/mappings/client.json').read_text())
aliases={**base['classes'],**base['autoMapper']['classes']}
extra={
 'AuraMovementPacket':'net/minecraft/AZ','AuraLookPacket':'net/minecraft/A_',
 'AuraPositionLookPacket':'net/minecraft/AF','AuraPositionPacket':'net/minecraft/A5',
 'AuraAttackPacket':'net/minecraft/AD','AuraAttackAction':'net/minecraft/zn',
 'AuraAnimationPacket':'net/minecraft/I3','AuraSlotPacket':'net/minecraft/gu',
 'AuraPlacePacket':'net/minecraft/Ow','AuraDigPacket':'net/minecraft/Ah','AuraDigAction':'net/minecraft/q8',
 'AuraFace':'net/minecraft/Bh','AuraInputPacket':'net/minecraft/AQ','AuraClosePacket':'net/minecraft/XG',
 'AuraClickWindowPacket':'net/minecraft/LW','AuraStatusPacket':'net/minecraft/Ie',
 'AuraEntityActionPacket':'net/minecraft/jF','AuraArmorStand':'net/minecraft/sw',
 'AuraHostile':'net/minecraft/Fl','AuraAmbient':'net/minecraft/sq','ItemHoe':'net/minecraft/fL',
 'ToolMaterial':'net/minecraft/Gu','AuraMovementInput':'net/minecraft/VB','Potion':'net/minecraft/zY',
 'AuraTeam':'net/minecraft/k4','AuraWaterMob':'net/minecraft/sU','AuraKeepAlivePacket':'net/minecraft/Gy',
 'AuraTransactionPacket':'net/minecraft/VT','AuraPayloadPacket':'net/minecraft/j',
 'AuraResourcePacket':'net/minecraft/Xo','AuraAbilitiesPacket':'net/minecraft/nP',
 'AuraSettingsPacket':'net/minecraft/OE','AuraSpectatePacket':'net/minecraft/FD',
 'AuraVelocityPacket':'net/minecraft/kh','AuraExplosionPacket':'net/minecraft/nw'
}
aliases.update(extra)
fields={};methods={}
def field(key,name,desc,static=False):fields[key]=dict(name=name,descriptor=desc,static=static,offset=0)
def method(key,name,desc):methods[key]=dict(name=name,descriptor=desc)
for key,name,desc in [
 ('Entity.ticksExisted','MT','I'),('Entity.motionX','MV','D'),('Entity.motionZ','z','D'),
 ('Entity.fallDistance','MW','F'),('Entity.ridingEntity','Mq','Lnet/minecraft/Oj;'),
 ('Entity.prevPosX','X','D'),('Entity.prevPosY','p','D'),('Entity.prevPosZ','U','D'),
 ('EntityPlayer.itemInUse','fA','Lnet/minecraft/n1;'),('EntityPlayer.itemInUseCount','fL','I'),
 ('Entity.prevRotationYaw','Y9','F'), # Actual previous yaw is declared on OQ; moved below.
 ('EntityLivingBase.hurtTime','Y6','I'),('EntityLivingBase.isSwingInProgress','_Q','Z'),
 ('EntityLivingBase.swingProgressInt','_A','I'),
 ('AuraVelocityPacket.entityId','P','I'),
 ('EntityLivingBase.rotationYawHead','_o','F'),('EntityLivingBase.prevRotationYawHead','Yx','F'),
 ('GameSettings.mouseSensitivity','uy','F'),('ClientPlayer.movementInput','mf','Lnet/minecraft/VB;'),
 ('AuraMovementInput.forward','J','F'),('AuraMovementInput.strafe','M','F'),
 ('AuraMovementInput.jump','W','Z'),('AuraMovementInput.sneak','w','Z'),
 ('AuraMovementPacket.yaw','K','F'),('AuraMovementPacket.pitch','N','F'),
 ('AuraMovementPacket.extra','L','F'),('AuraMovementPacket.onGround','o','Z'),
 ('AuraMovementPacket.moving','l','Z'),('AuraMovementPacket.rotating','D','Z'),
 ('AuraMovementPacket.x','B','D'),('AuraMovementPacket.y','s','D'),('AuraMovementPacket.z','X','D'),
 ('ItemHoe.toolMaterial','T','Lnet/minecraft/Gu;'),('PlayerControllerMP.currentPlayerItem','e','I')]:field(key,name,desc)
del fields['Entity.prevRotationYaw']
for key,name,desc in [
 ('AuraDigAction.release','RELEASE_USE_ITEM','Lnet/minecraft/q8;'),
 ('AuraFace.down','DOWN','Lnet/minecraft/Bh;'),('BlockPos.origin','ORIGIN','Lnet/minecraft/BlockPos;'),
 ('Potion.blindness','e','Lnet/minecraft/zY;')]:field(key,name,desc,True)
for key,name,desc in [
 ('World.getEntityByID','Z','(I)Lnet/minecraft/Oj;'),
 ('Entity.onGround','v','()Z'),('Entity.isSprinting','z','()Z'),('Entity.setSprinting','H','(Z)V'),
 ('Entity.isInWater','w','()Z'),
 ('Entity.getBounds','J','()Lnet/minecraft/kb;'),('Entity.border','z','()F'),
 ('Entity.canBeCollidedWith','A','()Z'),('EntityLivingBase.isOnLadder','U','()Z'),
 ('EntityLivingBase.getTeam','U','()Lnet/minecraft/k4;'),
 ('EntityLivingBase.swingItem','O','()V'),('EntityLivingBase.isPotionActive','X','(Lnet/minecraft/zY;)Z'),
 ('EntityLivingBase.armSwingEnd','C','()I'),
 ('EntityPlayer.attackLocal','B','(Lnet/minecraft/Oj;)V'),('EntityPlayer.critical','g','(Lnet/minecraft/Oj;)V'),
 ('EntityPlayer.isUsingItem','T','()Z'),
 ('PlayerControllerMP.syncCurrentItem','h','()V'),
 ('PlayerControllerMP.interactAt','i','(Lnet/minecraft/sI;Lnet/minecraft/Oj;Lnet/minecraft/B8;)Z'),
 ('PlayerControllerMP.interact','t','(Lnet/minecraft/sI;Lnet/minecraft/Oj;)Z'),
 ('AuraLookPacket.constructor','<init>','(FFZ)V'),
 ('AuraPositionLookPacket.constructor','<init>','(DDDFFZF)V'),
 ('AuraSlotPacket.constructor','<init>','(I)V'),('AuraPlacePacket.constructor','<init>','(Lnet/minecraft/n1;)V'),
 ('AuraDigPacket.constructor','<init>','(Lnet/minecraft/q8;Lnet/minecraft/BlockPos;Lnet/minecraft/Bh;)V'),
 ('MovingObjectPosition.entityConstructor','<init>','(Lnet/minecraft/Oj;Lnet/minecraft/Gw;)V')]:method(key,name,desc)
# WorldClient owns Z(I); use that owner explicitly (World's overload differs).
methods['ClientWorld.getEntityByID']=methods.pop('World.getEntityByID')
extra['AuraNpc']=index['net/minecraft/sr']['interfaces'][-1]
aliases.update(extra)
for n,c in index.items():
    if any(m['name']=='<init>' and m['descriptor']=='(ILnet/minecraft/F9;Z)V' for m in c['methods']):
        extra['AuraMetadataPacket']=n
aliases.update(extra)
def find(owner,section,name,desc):
    if owner is None:return None
    c=index[owner]
    for m in c[section]:
        if m['name']==name and m['descriptor']==desc:return m
    return find(c['superName'],section,name,desc) if c['superName'] in index else None
for section,entries in [('fields',fields),('methods',methods)]:
    for key,spec in entries.items():
        owner=aliases[key.split('.')[0]];actual=find(owner,section,spec['name'],spec['descriptor'])
        if not actual:raise RuntimeError((section,key,owner,spec))
        if section=='fields' and bool(actual['accessFlags']&8)!=spec['static']:raise RuntimeError(('static',key))
result={'artifact':base.get('verification',{}),'classes':extra,'fields':fields,'methods':methods}
print(json.dumps(result,indent=2))
