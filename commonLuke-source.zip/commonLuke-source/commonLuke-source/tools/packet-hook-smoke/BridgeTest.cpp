#include "client/PacketBridge.hpp"
#include "client/ClassRepository.hpp"
#include "client/MethodManager.hpp"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <thread>
#include <atomic>

std::array<JNINativeMethod,3> registered{};
void Check(bool ok) { if(!ok)std::exit(1); }
jint JNICALL Register(JNIEnv*,jclass,const JNINativeMethod* methods,jint count) {
    Check(count==3);for(int i=0;i<count;++i)registered[i]=methods[i];return JNI_OK;
}
std::atomic<bool> pendingException{false};
jboolean JNICALL NoException(JNIEnv*) { return pendingException ? JNI_TRUE : JNI_FALSE; }
jobject Cancel(JNIEnv*,jobject) { return nullptr; }
jobject Replace(JNIEnv*,jobject) { return reinterpret_cast<jobject>(2); }
bool CancelReceive(JNIEnv*,jobject) { return false; }
jobject ThrowSend(JNIEnv*,jobject) { throw 1; }
bool ThrowReceive(JNIEnv*,jobject) { throw 1; }
std::vector<int> order;
jobject First(JNIEnv*,jobject packet) { order.push_back(1); return packet; }
jobject Third(JNIEnv*,jobject packet) { order.push_back(3); return packet; }
jobject Second(JNIEnv*,jobject packet) { order.push_back(2); Check(packet==reinterpret_cast<jobject>(2)); return packet; }
bool ReceiveFirst(JNIEnv*,jobject) { order.push_back(1); return false; }
bool ReceiveSecond(JNIEnv*,jobject) { order.push_back(2); return true; }
jobject Reconfigure(JNIEnv*,jobject packet) {
    order.push_back(1);
    client::packets::RemoveFilter("second");
    return packet;
}
std::atomic<unsigned> concurrentCalls{0};
jobject Concurrent(JNIEnv*,jobject packet) { ++concurrentCalls; return packet; }
jobject JavaFailure(JNIEnv*,jobject packet) { pendingException=true;return packet; }
jobject JNICALL CopyRef(JNIEnv*,jobject object) { return object; }
void JNICALL DropRef(JNIEnv*,jobject) {}
unsigned closed=0;
jboolean JNICALL Same(JNIEnv*,jobject a,jobject b) { return a==b?JNI_TRUE:JNI_FALSE; }

namespace client::methods {
Result Invoke(JNIEnv*,jobject receiver,const classes::ClassRecord&,const std::string& name,const std::string& descriptor,
    const std::vector<Argument>& arguments,bool,bool) {
    Check(receiver==reinterpret_cast<jobject>(2));Result result;result.ok=true;
    if(name=="send") {
        Check(descriptor=="(Ljava/lang/Object;)Ljava/lang/Object;"&&arguments.size()==1&&arguments[0].value.l==reinterpret_cast<jobject>(1));
        result.type=Type::Object;result.value.l=reinterpret_cast<jobject>(4);
    } else if(name=="receive") {
        Check(descriptor=="(Ljava/lang/Object;)V"&&arguments.size()==1&&arguments[0].value.l==reinterpret_cast<jobject>(1));
    } else if(name=="isInstalled") {
        Check(descriptor=="()Z"&&arguments.empty());result.type=Type::Boolean;result.value.z=JNI_TRUE;
    } else if(name=="close") {
        Check(descriptor=="()V"&&arguments.empty());++closed;
    } else Check(false);
    return result;
}
}
int main() {
    JNINativeInterface_ table{};table.RegisterNatives=&Register;table.ExceptionCheck=&NoException;
    JNIEnv_ env{&table};
    Check(client::packets::BindNativeCallbacks(&env,reinterpret_cast<jclass>(1)));
    Check(std::strcmp(registered[0].name,"nativeBridgeVersion")==0);
    auto version=reinterpret_cast<jint(JNICALL*)(JNIEnv*,jclass)>(registered[0].fnPtr);
    auto send=reinterpret_cast<jobject(JNICALL*)(JNIEnv*,jclass,jobject)>(registered[1].fnPtr);
    auto receive=reinterpret_cast<jboolean(JNICALL*)(JNIEnv*,jclass,jobject)>(registered[2].fnPtr);
    auto packet=reinterpret_cast<jobject>(1);
    Check(version(&env,nullptr)==1);
    Check(send(&env,nullptr,packet)==packet && receive(&env,nullptr,packet)==JNI_TRUE);
    client::packets::SetFilter("test",&Cancel,nullptr);Check(send(&env,nullptr,packet)==nullptr);
    client::packets::SetFilter("test",&Replace,nullptr);Check(send(&env,nullptr,packet)==reinterpret_cast<jobject>(2));
    client::packets::SetFilter("test",&ThrowSend,nullptr);Check(send(&env,nullptr,packet)==nullptr);
    client::packets::SetFilter("test",nullptr,&CancelReceive);Check(receive(&env,nullptr,packet)==JNI_FALSE);
    client::packets::SetFilter("test",nullptr,&ThrowReceive);Check(receive(&env,nullptr,packet)==JNI_FALSE);
    const auto counters=client::packets::GetCounters();
    Check(counters.sent==4 && counters.received==3 && counters.cancelledSend==2 && counters.cancelledReceive==2);
    Check(client::packets::RemoveFilter("test"));
    Check(!client::packets::RemoveFilter("test"));
    client::packets::SetFilter("second",&Second,&ReceiveSecond,20);
    client::packets::SetFilter("first",&Replace,&ReceiveFirst,10);
    Check(send(&env,nullptr,packet)==reinterpret_cast<jobject>(2));Check(order==std::vector<int>{2});order.clear();
    Check(receive(&env,nullptr,packet)==JNI_FALSE);Check(order==std::vector<int>{1});order.clear();
    client::packets::SetFilter("first",&Cancel,nullptr,10);
    Check(send(&env,nullptr,packet)==nullptr&&order.empty());
    client::packets::SetFilter("first",&Reconfigure,nullptr,10);
    client::packets::SetFilter("second",&First,nullptr,20);
    Check(send(&env,nullptr,packet)==packet);Check(order==std::vector<int>({1,1}));order.clear();
    Check(send(&env,nullptr,packet)==packet);Check(order==std::vector<int>{1});order.clear();
    client::packets::RemoveFilter("first");
    // Equal priorities retain original registration order after priority changes.
    client::packets::SetFilter("a",&First,nullptr,10);
    client::packets::SetFilter("b",&Third,nullptr,10);
    client::packets::SetFilter("a",&First,nullptr,30);
    client::packets::SetFilter("a",&First,nullptr,10);
    Check(send(&env,nullptr,packet)==packet&&order==std::vector<int>({1,3}));order.clear();
    client::packets::RemoveFilter("a");client::packets::RemoveFilter("b");
    client::packets::SetFilter("java-exception",&JavaFailure,nullptr,0);
    client::packets::SetFilter("unreachable",&First,nullptr,1);
    Check(send(&env,nullptr,packet)==nullptr&&order.empty());pendingException=false;
    client::packets::RemoveFilter("java-exception");client::packets::RemoveFilter("unreachable");
    client::packets::SetFilter("concurrent",&Concurrent,nullptr);
    std::thread worker([&]{for(int i=0;i<2000;++i)Check(send(&env,nullptr,packet)==packet);});
    for(int i=0;i<2000;++i){client::packets::SetFilter("optional",&Concurrent,nullptr);client::packets::RemoveFilter("optional");}
    worker.join();Check(concurrentCalls>=2000);client::packets::RemoveFilter("concurrent");
    Check(client::packets::Send(&env,packet)==nullptr);
    table.NewLocalRef=&CopyRef;table.NewGlobalRef=&CopyRef;
    table.DeleteLocalRef=&DropRef;table.DeleteGlobalRef=&DropRef;
    table.IsSameObject=&Same;
    client::classes::ClassRecord owner;owner.name="client/packethook/PacketHook";
    Check(client::packets::SetHook(&env,reinterpret_cast<jobject>(2),owner));
    Check(client::packets::IsInstalled(&env));
    Check(client::packets::Send(&env,packet)==reinterpret_cast<jobject>(4));
    Check(client::packets::Receive(&env,packet));
    Check(client::packets::GetCounters().directSend==1);
    Check(client::packets::Uninstall(&env)&&closed==1);
    Check(client::packets::Send(&env,packet)==nullptr);
    std::puts("PASS: subscriber priority/replacement/cancellation, snapshot reentrancy/concurrency, exceptions, counters, direct send/replay and detach");
}
