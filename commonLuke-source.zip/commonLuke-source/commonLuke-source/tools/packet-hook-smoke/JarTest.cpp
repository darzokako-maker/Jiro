#include "client/JarReader.hpp"
#include "client/PayloadClosure.hpp"
#include <cstdio>
#include <set>
namespace client::log { void Write(const char*, ...) {} }
int main(int argc,char** argv) {
    if(argc!=2)return 1;
    if(!client::jar::Read(argv[1]).empty())return 2; // Native declarations require explicit policy.
    auto classes=client::jar::Read(argv[1],true);
    if(classes.size()!=5)return 3;
    std::set<std::string> names;unsigned natives=0;
    for(const auto& c:classes) {
        if(c.bytecode.size()<8 || c.bytecode[6]!=0 || c.bytecode[7]!=52)return 4;
        names.insert(c.name);
        for(const auto& m:c.class_file.methods)if(m.access_flags&0x100)++natives;
    }
    if(names.size()!=5 || natives!=4 || !names.contains("client/packethook/MovementInput.class") || !names.contains("client/packethook/PacketHook$NativeListener.class") )return 5;
    for(const auto& name:names) {
        const bool payload=name.starts_with("client/packethook/");
        if(!payload)return 8; // Never package compile-only game stubs.
    }
    std::string missing;
    if(!client::payload::ValidatePayloadClosure(classes,missing))return 6;
    bool changed=false;
    for(auto& item:classes) {
        auto& cp=item.class_file.constant_pool;
        for(jcfp::u2 i=1;i<cp.count()&&!changed;++i) {
            if(cp.get_tag(i)!=jcfp::ConstantPoolEntry::Tag::Utf8)continue;
            auto& text=cp.get_entry(i).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
            if(text=="()V") {text="(Lclient/packethook/PacketHook$1;)V";changed=true;}
        }
    }
    if(!changed || client::payload::ValidatePayloadClosure(classes,missing)
        || missing!="client/packethook/PacketHook$1")return 7;
    std::puts("PASS: Java8/native policy, packaged class closure, missing synthetic descriptor dependency rejected");
}
