#include "features/utility/seed_dumper/SeedDump.hpp"
#include <filesystem>
#include <iostream>
#include <stdexcept>

using namespace client::features::seeddumper;
void Require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main(){try{
 Snapshot s;s.x=-17;s.z=32;s.dimension=-1;s.capturedMs=123456789;s.sections=5;
 s.biomes.fill(255);s.biomes[17]=4;s.states[0]=56<<4;s.states[65535]=(35<<4)|14;
 auto bytes=Encode(s);Snapshot decoded;std::string error;
 Require(Decode(bytes,decoded,error),"decode valid snapshot");
 Require(decoded==s,"round trip coordinates, time, biomes and metadata");
 auto truncated=bytes;truncated.pop_back();Require(!Decode(truncated,decoded,error),"reject truncated record");
 auto trailing=bytes;trailing.push_back(0);Require(!Decode(trailing,decoded,error),"reject trailing bytes");
 auto bad=bytes;bad[0]=0;Require(!Decode(bad,decoded,error),"reject bad magic");
 auto zeroRun=bytes;for(int i=294;i<298;++i)zeroRun[i]=0;Require(!Decode(zeroRun,decoded,error),"reject zero run");
 auto hugeRun=bytes;for(int i=294;i<298;++i)hugeRun[i]=255;Require(!Decode(hugeRun,decoded,error),"reject oversized run");
 Snapshot empty;Require(Decode(Encode(empty),decoded,error)&&decoded==empty,"empty chunk round trip");
 const auto root=std::filesystem::temp_directory_path()/"aoki-seed-codec-test";
 std::filesystem::create_directories(root);
 const auto path=root/"snapshot.aokisd";std::filesystem::remove(path);
 Require(WriteSnapshot(path,s,error),"write snapshot");
 Require(!WriteSnapshot(path,s,error),"immutable snapshot must not overwrite");
 Require(!WriteSnapshot(path/"invalid",s,error),"report IO error");
 std::filesystem::remove(path);std::filesystem::remove(root);
 std::cout<<"PASS SeedDump codec, immutable writes and IO errors\n";return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
