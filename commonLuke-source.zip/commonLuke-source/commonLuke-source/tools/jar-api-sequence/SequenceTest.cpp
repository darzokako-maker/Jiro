#include "client/ApiTestSequence.hpp"
#include <cstdio>
#include <cstdlib>
using client::jar_vm::ApiTestSequence;
void Check(bool ok) { if (!ok) { std::fputs("FAIL\n", stderr); std::exit(1); } }
int main() {
    ApiTestSequence sequence;
    Check(sequence.CanRun(0) && !sequence.CanRun(1));
    std::array<bool, ApiTestSequence::Count> keys{};
    Check(sequence.Pressed(keys) == -1);
    keys[0] = true;
    Check(sequence.Pressed(keys) == 0);
    Check(sequence.Pressed(keys) == -1);
    sequence.Complete(true);
    Check(!sequence.CanRun(0) && sequence.CanRun(1));
    keys = {};
    Check(sequence.Pressed(keys) == -1);
    keys[1] = keys[2] = true;
    Check(sequence.Pressed(keys) == -1);
    Check(sequence.Pressed(keys) == -1);
    sequence.Complete(false);
    for (unsigned i = 0; i <= ApiTestSequence::Count; ++i) Check(!sequence.CanRun(i));
    Check(sequence.Failed() && sequence.Next() == 1);
    ApiTestSequence stopped;
    stopped.Stop();
    Check(!stopped.Enabled() && !stopped.CanRun(0));
    ApiTestSequence all;
    for (unsigned i = 0; i < ApiTestSequence::Count; ++i) {
        Check(all.CanRun(i)); all.Complete(true); Check(!all.CanRun(i));
    }
    Check(!all.CanRun(ApiTestSequence::Count));
    std::puts("PASS: no automatic trigger, key hold, simultaneous keys, ordering, no replay, failure/stop gates, completion");
}
