from pathlib import Path
import hashlib
import json
import struct
import sys


source, header, implementation = map(Path, sys.argv[1:4])
symbol = sys.argv[4]
data = source.read_bytes()
cipher_config = None
if len(sys.argv) == 7 and sys.argv[5] == "--cipher-config":
    cipher_config = json.loads(Path(sys.argv[6]).read_text(encoding="utf-8"))
elif len(sys.argv) != 5:
    raise SystemExit("usage: embed-binary.py input header cpp symbol [--cipher-config config.json]")


def rotate_left(value: int, amount: int) -> int:
    return ((value << amount) | (value >> (32 - amount))) & 0xFFFFFFFF


def quarter_round(state: list[int], a: int, b: int, c: int, d: int) -> None:
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = rotate_left(state[d] ^ state[a], 16)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotate_left(state[b] ^ state[c], 12)
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = rotate_left(state[d] ^ state[a], 8)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = rotate_left(state[b] ^ state[c], 7)


def chacha20(data: bytes, key: bytes, nonce: bytes) -> bytes:
    constants = (0x61707865, 0x3320646E, 0x79622D32, 0x6B206574)
    key_words = struct.unpack("<8I", key)
    nonce_words = struct.unpack("<3I", nonce)
    output = bytearray(len(data))
    for offset in range(0, len(data), 64):
        counter = 1 + offset // 64
        initial = list(constants + key_words + (counter,) + nonce_words)
        state = initial.copy()
        for _ in range(10):
            quarter_round(state, 0, 4, 8, 12)
            quarter_round(state, 1, 5, 9, 13)
            quarter_round(state, 2, 6, 10, 14)
            quarter_round(state, 3, 7, 11, 15)
            quarter_round(state, 0, 5, 10, 15)
            quarter_round(state, 1, 6, 11, 12)
            quarter_round(state, 2, 7, 8, 13)
            quarter_round(state, 3, 4, 9, 14)
        stream = struct.pack("<16I", *((state[i] + initial[i]) & 0xFFFFFFFF for i in range(16)))
        block = data[offset:offset + 64]
        output[offset:offset + len(block)] = bytes(a ^ b for a, b in zip(block, stream))
    return bytes(output)


salt = nonce = b""
iterations = 0
if cipher_config is not None:
    password_digest = bytes.fromhex(cipher_config["password_sha256"])
    salt = bytes.fromhex(cipher_config["salt"])
    nonce = bytes.fromhex(cipher_config["nonce"])
    iterations = int(cipher_config["iterations"])
    if len(password_digest) != 32 or len(salt) != 16 or len(nonce) != 12 or iterations < 10000:
        raise SystemExit("invalid payload cipher configuration")
    derived_key = hashlib.pbkdf2_hmac("sha256", password_digest, salt, iterations, 32)
    data = chacha20(data, derived_key, nonce)
header.parent.mkdir(parents=True, exist_ok=True)
implementation.parent.mkdir(parents=True, exist_ok=True)

header.write_text(
    "#pragma once\n#include <cstddef>\n"
    f"extern const unsigned char {symbol}[];\n"
    f"extern const std::size_t {symbol}Size;\n"
    + (f"extern const unsigned char {symbol}Salt[16];\n"
       f"extern const unsigned char {symbol}Nonce[12];\n"
       f"extern const unsigned long long {symbol}Iterations;\n" if cipher_config is not None else ""),
    encoding="utf-8",
    newline="\n",
)

with implementation.open("w", encoding="utf-8", newline="\n") as output:
    output.write(f'#include "{header.name}"\n')
    output.write(f"const unsigned char {symbol}[] = {{\n")
    for offset in range(0, len(data), 20):
        output.write("    " + ",".join(f"0x{value:02x}" for value in data[offset:offset + 20]) + ",\n")
    output.write("};\n")
    output.write(f"const std::size_t {symbol}Size = sizeof({symbol});\n")
    if cipher_config is not None:
        output.write(f"const unsigned char {symbol}Salt[16] = {{" + ",".join(f"0x{x:02x}" for x in salt) + "};\n")
        output.write(f"const unsigned char {symbol}Nonce[12] = {{" + ",".join(f"0x{x:02x}" for x in nonce) + "};\n")
        output.write(f"const unsigned long long {symbol}Iterations = {iterations}ULL;\n")
