import json,sys
from pathlib import Path
source,dest,*audit_paths=map(Path,sys.argv[1:])
d=json.loads(source.read_text(encoding='utf8'))
manual_required={'members':[],'rvas':[]}
if audit_paths:
 audit=json.loads(audit_paths[0].read_text(encoding='utf8'))
 if audit['profile']!=d['jvmProfile']['id']:
  raise ValueError('Manual bridge and client JVM profiles differ')
 for section,entries in audit.get('runtime',{}).items():
  for key,value in entries.items():
   existing=d['jvmProfile'][section].get(key,value)
   if existing!=value:
    raise ValueError(f'Conflicting JVM mapping: {section}.{key}')
   d['jvmProfile'][section][key]=value
 manual_required=audit.get('required_profile_keys',manual_required)
 for section,keys in manual_required.items():
  missing=[key for key in keys if key not in d['jvmProfile'][section]]
  if missing:
   raise ValueError(f'Manual JVM profile missing {section}: '+', '.join(missing))
def quote(s): return json.dumps(s,ensure_ascii=True)
out=['#pragma once','namespace client::mapping::generated {','struct Symbol { const char* key; const char* name; const char* descriptor; };','struct Number { const char* key; unsigned long long value; };']
out+=['inline constexpr Symbol classes[] = {']
classes={**d['classes'],**d['autoMapper']['classes']}
out += ['{'+quote(k)+','+quote(v)+',""},' for k,v in sorted(classes.items())]
out += ['};']
for section in ['fields','methods']:
 out+=['inline constexpr Symbol '+section+'[] = {']
 out+=['{'+quote(k)+','+quote(v['name'])+','+quote(v['descriptor'])+'},' for k,v in sorted(d['autoMapper'][section].items())]
 out+=['};']
out+=['struct Packet { const char* key; const char* className; int id; bool inbound; };']
out+=['inline constexpr Packet packets[] = {']
for p in d.get('nativePackets',[]):
 inbound='true' if p['direction']=='inbound' else 'false'
 out+=['{'+quote(p['key'])+','+quote(p['class'])+','+str(p['id'])+','+inbound+'},']
out+=['};']
out+=['inline constexpr char profileId[]='+quote(d['jvmProfile']['id'])+';']
for section in ['rvas','members']:
 out+=['inline constexpr Number '+section+'[] = {']
 out+=['{'+quote(k)+','+str(v)+'ULL},' for k,v in d['jvmProfile'][section].items()]
 out+=['};']
out+=['}']
dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text('\n'.join(out),encoding='utf8')
