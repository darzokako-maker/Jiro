#include "features/utility/extra_modules/ExtraModuleRules.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <cstdio>
#include <cstdlib>
#include <limits>
namespace client::features::modules {void StateChanged(Id,bool,bool){}}
using namespace client::features::extras;
void Check(bool value,const char* message){if(!value){std::printf("FAIL %s\n",message);std::exit(1);}}
bool Near(double a,double b){return std::abs(a-b)<.00001;}
int main(){
 Check(!NeedsInput(),"all new modules default disabled");
 Check(!Defaults(Kind::Breaker).bloom&&Near(Defaults(Kind::Breaker).boxAlpha,.18)&&Defaults(Kind::Breaker).layerCount==4,"performant Breaker visual defaults");
 auto s=Defaults(Kind::AutoClicker);s.enabled=true;s.cps=99;s.history=100;s.boxAlpha=std::numeric_limits<float>::quiet_NaN();SetOptions(Kind::AutoClicker,s);s=Options(Kind::AutoClicker);
 Check(NeedsInput()&&s.cps==20&&s.history==20&&Near(s.boxAlpha,.18),"input ownership and settings bounds");DisableInputFeatures();Check(!NeedsInput(),"disable releases input need");
 Check(rules::Block({-.01,1.99,-1.01})==rules::Pos{-1,1,-2},"negative block coordinates");
 Check(Near(rules::Wrap(181),-179)&&Near(rules::Wrap(-181),179),"shortest yaw path");
 const auto angle=rules::Aim({1,2,3},{4,6,8});const auto direction=rules::Direction(angle);const auto distance=rules::Distance({1,2,3},{4,6,8});
 Check(Near(direction.x,3/distance)&&Near(direction.y,4/distance)&&Near(direction.z,5/distance),"aim ray roundtrip");
 Check(rules::AimbotCandidate(20,10,25)&&!rules::AimbotCandidate(20,20,25),"Aimbot combined yaw/pitch FOV");
 const auto axes=rules::InventoryAxes(true,false,true,false);Check(Near(axes[0],1)&&Near(axes[1],1),"InventoryMove forward/strafe axes");
 Check(rules::InventoryMoveAllowed(true,true,false,false)&&!rules::InventoryMoveAllowed(true,true,true,false)&&!rules::InventoryMoveAllowed(true,true,false,true),"InventoryMove screen/chat/ClickGUI gate");
 Check(rules::RayBox({0,0,0},{0,0,1},{-1,-1,2},{1,1,3},3)==2,"ray enters target");
 Check(!rules::RayBox({2,0,0},{0,0,1},{-1,-1,2},{1,1,3},3),"parallel ray outside target");
 Check(!rules::RayBox({0,0,0},{0,0,1},{-1,-1,2},{1,1,3},1.9),"ray respects attack range");
 Check(rules::RayBox({0,0,2.5},{0,0,1},{-1,-1,2},{1,1,3},3)==0,"eye inside target");
 Check(!rules::CriticalReady(true,true,2,500,500)&&!rules::CriticalReady(true,false,3,500,500)&&!rules::CriticalReady(true,true,3,499,500)&&rules::CriticalReady(true,true,3,500,500),"critical ground and delay boundaries");
 Check(rules::ClickDelay(8)==125&&rules::ClickDelay(14)==71,"direct CPS click timing");
 Check(Near(rules::Remaining(3000,.25f),2250)&&Near(rules::Remaining(3000,1),0),"Breaker countdown progress");
 Check(rules::EagleAllowed(false,false)&&!rules::EagleAllowed(true,false)&&rules::EagleAllowed(true,true),"Eagle block-only gate");
 const auto eagleForward=rules::EagleDirection(1,0,0),eagleBack=rules::EagleDirection(-1,0,0),eagleLeft=rules::EagleDirection(0,1,0);
 Check(Near(eagleForward.x,0)&&Near(eagleForward.z,1)&&Near(eagleBack.z,-1)&&Near(eagleLeft.x,1),"Eagle follows actual movement direction");
 const auto probes=rules::EagleSamples({-.3,64,-.3},{.3,65.8,.3},eagleForward,.1);
 Check(Near(probes[0].x,0)&&Near(probes[0].z,.4)&&Near(probes[0].y,63.95)&&probes[1].x<0&&probes[2].x>0,"Eagle probes leading foot edge");
 Check(rules::EagleUnsupported({true,true,false})&&!rules::EagleUnsupported({true,false,false}),"Eagle requires majority unsupported probes");
 bool owned=false;int until=-1;Check(rules::EagleState(true,true,true,10,4,owned,until)&&owned&&until==14,"Eagle begins minimum sneak hold");
 Check(rules::EagleState(false,true,true,11,4,owned,until)&&rules::EagleState(false,true,true,13,4,owned,until),"Eagle rejects one-tick release");
 Check(!rules::EagleState(false,true,true,14,4,owned,until)&&!owned,"Eagle releases after minimum hold");
 owned=true;until=99;Check(!rules::EagleState(true,true,false,20,6,owned,until)&&!owned,"Eagle releases while airborne");
 std::puts("PASS extra modules: bounds, Aimbot targeting, InventoryMove gates/axes, raycast, critical delay and click timing");
}

