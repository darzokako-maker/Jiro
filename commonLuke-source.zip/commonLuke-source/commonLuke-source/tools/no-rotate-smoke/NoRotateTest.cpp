#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "game/MappingRepository.hpp"
#include "ClientMappings.hpp"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
namespace {
enum Kind {Teleport,PosLook,Other};
struct Packet {Kind kind=Teleport;std::array<float,2> angles{150,70};double x=12,y=64,z=-9;int flags=31;};
struct Player {float yaw=25,pitch=-10;} player;
int minecraft,frames=0;bool exception=false,missing=false,hasPlayer=true;
void Check(bool ok,const char* msg){if(!ok){std::printf("FAIL %s\n",msg);std::exit(1);}}
jboolean JNICALL Exception(JNIEnv*){return exception;}
void JNICALL Clear(JNIEnv*){exception=false;}
jint JNICALL Push(JNIEnv*,jint){++frames;return JNI_OK;}
jobject JNICALL Pop(JNIEnv*,jobject value){--frames;return value;}
jclass JNICALL Class(JNIEnv*,jobject value){return reinterpret_cast<jclass>(value);}
jfieldID JNICALL Field(JNIEnv*,jclass cls,const char* name,const char* desc){
 Check(std::strcmp(desc,"F")==0,"float descriptor");
 const bool teleport=reinterpret_cast<Packet*>(cls)->kind==Teleport;
 const char* names[]={teleport?"M":"N",teleport?"w":"d"};
 // Outgoing names are resolved from the generated, independently verified table.
 if(!teleport){for(auto s:client::mapping::generated::fields){if(std::strcmp(s.key,"AuraMovementPacket.yaw")==0)names[0]=s.name;if(std::strcmp(s.key,"AuraMovementPacket.pitch")==0)names[1]=s.name;}}
 if(missing&&std::strcmp(name,names[1])==0){exception=true;return nullptr;}
 for(int i=0;i<2;++i)if(std::strcmp(name,names[i])==0)return reinterpret_cast<jfieldID>(i+1);
 Check(false,"mapped angle name");return nullptr;
}
jfloat JNICALL Get(JNIEnv*,jobject p,jfieldID f){return reinterpret_cast<Packet*>(p)->angles[reinterpret_cast<std::uintptr_t>(f)-1];}
void JNICALL Set(JNIEnv*,jobject p,jfieldID f,jfloat value){reinterpret_cast<Packet*>(p)->angles[reinterpret_cast<std::uintptr_t>(f)-1]=value;}
}
namespace client::features::modules {void StateChanged(Id,bool,bool){}}
namespace client::mapping {
std::optional<Symbol> Field(std::string_view key){for(auto s:generated::fields)if(key==s.key)return Symbol{s.name,s.descriptor};return {};}
std::optional<FieldInfo> ResolveField(std::string_view key){FieldInfo f{};if(key=="Entity.rotationYaw")f.offset=0;else if(key=="Entity.rotationPitch")f.offset=4;else return {};return f;}
std::uintptr_t Oop(jobject object){return reinterpret_cast<std::uintptr_t>(object);}
jobject StaticObject(JNIEnv*,std::string_view){return reinterpret_cast<jobject>(&minecraft);}
jobject Object(JNIEnv*,jobject,std::string_view){return hasPlayer?reinterpret_cast<jobject>(&player):nullptr;}
bool Instance(jobject p,std::string_view alias){const auto kind=reinterpret_cast<Packet*>(p)->kind;return (alias=="NoRotateTeleportPacket"&&kind==Teleport)||(alias=="AuraPositionLookPacket"&&kind==PosLook);}
}
namespace client::hotspot {bool ReadMemory(std::uintptr_t address,void* out,std::size_t size){std::memcpy(out,reinterpret_cast<void*>(address),size);return true;}}
int main(){
 namespace nr=client::features::norotate;
 JNINativeInterface_ t{};t.ExceptionCheck=Exception;t.ExceptionClear=Clear;t.PushLocalFrame=Push;t.PopLocalFrame=Pop;t.GetObjectClass=Class;t.GetFieldID=Field;t.GetFloatField=Get;t.SetFloatField=Set;JNIEnv_ env{&t};
 auto receive=[&](Packet& p){Check(nr::BeforeReceive(&env,reinterpret_cast<jobject>(&p)),"teleport always forwarded");Check(frames==0,"receive frames balanced");};
 auto send=[&](Packet& p){Check(nr::BeforeSend(&env,reinterpret_cast<jobject>(&p))==reinterpret_cast<jobject>(&p),"send identity");Check(frames==0,"send frames balanced");};
 Packet p;receive(p);Check(p.angles==std::array<float,2>{150,70},"disabled passthrough");
 auto s=nr::Options();Check(s.mode==nr::Mode::Edit,"reference default Edit");s.enabled=true;nr::SetOptions(s);
 receive(p);Check(p.angles==std::array<float,2>{25,-10},"incoming camera angles replaced");Check(p.x==12&&p.y==64&&p.z==-9&&p.flags==31,"position and relative flags unchanged");
 Check(player.yaw==25&&player.pitch==-10,"player fields untouched");
 Packet other;other.kind=Other;send(other);Check(other.angles==std::array<float,2>{150,70},"other sends do not consume acknowledgement");
 Packet ack;ack.kind=PosLook;ack.angles={0,0};send(ack);Check(ack.angles==std::array<float,2>{150,70},"Edit restores original server angles once");ack.angles={3,4};send(ack);Check(ack.angles==std::array<float,2>{3,4},"second C06 untouched");
 s.mode=nr::Mode::Cancel;nr::SetOptions(s);p={};receive(p);ack.angles={3,4};send(ack);Check(p.angles==std::array<float,2>{25,-10}&&ack.angles==std::array<float,2>{3,4},"Cancel only changes incoming angles");
 s.mode=nr::Mode::Edit;nr::SetOptions(s);p={};receive(p);s.enabled=false;nr::SetOptions(s);s.enabled=true;nr::SetOptions(s);send(ack);Check(ack.angles==std::array<float,2>{3,4},"disable/re-enable clears stale acknowledgement");
 p={};missing=true;receive(p);Check(!exception&&p.angles==std::array<float,2>{150,70},"missing field fails open before any writes");missing=false;
 exception=true;receive(p);Check(exception,"preexisting exception preserved");exception=false;
 hasPlayer=false;receive(p);Check(p.angles==std::array<float,2>{150,70},"no player passthrough");
 std::puts("PASS NoRotate: production Cancel/Edit callbacks, default, one-shot acknowledgement, untouched position/flags/player, disable reset, failures and JNI frames");
}
