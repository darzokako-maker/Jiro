#include "features/visual/spotify_widget/SpotifySession.hpp"
#include <Windows.h>
#include <roapi.h>
#include <cstdio>

int main() {
 const HRESULT apartment=RoInitialize(RO_INIT_MULTITHREADED);
 const auto media=client::features::spotify::session::Query();
 if(!media){std::puts("FAIL GSMTC query");return 1;}
 if(!media->available){std::puts("SKIP no active Windows media session");return 0;}
 std::printf("PASS title=%s artist=%s playing=%d position=%lld duration=%lld artwork=%zu source=%s\n",
  media->title.c_str(),media->artist.c_str(),media->playing?1:0,
  static_cast<long long>(media->positionMs),static_cast<long long>(media->durationMs),media->artwork.size(),media->source.c_str());
 return media->title.empty()||media->durationMs<0?2:0;
}
