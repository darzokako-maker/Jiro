#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <Windows.h>
#include <cstdarg>
#include <cstdio>

namespace client::features::modules {void StateChanged(Id,bool,bool) {}}
namespace client::log {void Write(const char* format,...){va_list args;va_start(args,format);std::vprintf(format,args);va_end(args);std::puts("");}}

int main() {
 auto options=client::features::spotify::Options();options.enabled=true;client::features::spotify::SetOptions(options);
 client::features::spotify::PollRuntime();
 for(int attempt=0;attempt<20;++attempt) {
  Sleep(250);const auto media=client::features::spotify::Snapshot();
  if(media&&media->available) {
   std::printf("PASS worker title=%s artist=%s playing=%d artwork=%zu\n",media->title.c_str(),media->artist.c_str(),media->playing?1:0,media->artwork.size());return 0;
  }
 }
 std::puts("SKIP worker started but no active Windows media session");return 0;
}
