import json, re, sys
from pathlib import Path

root, output = map(Path, sys.argv[1:])
mapping = json.loads((root/'native/mappings/client.json').read_text(encoding='utf-8'))
layout = mapping['injectionLayout']
packet = mapping['packetHook']
header = (root/'referans/dll/src/core/JvmMapper.hpp').read_text(encoding='utf-8-sig')
declared = set()
for group, body in re.findall(r'struct (\w+)\s*\{(.*?)\n    \};', header, re.S):
    declared.update(group+'.'+name for name in re.findall(r'static inline std::ptrdiff_t (\w+)\s*=', body))
members = {k:v for k,v in layout['members'].items() if k in declared}
optional = set(layout.get('missing', []))
if any(not k.startswith('InstanceKlass.') for k in optional):
    raise SystemExit('Required injection layout still unresolved: '+str(optional))
out = ['#pragma once', '#include "JvmMapper.hpp"', 'namespace client::payload::fixed {',
       'inline void BindLayout() {']
out += [f'JvmMapper::{k.replace(".", "::")} = {v};' for k,v in sorted(members.items())]
out += ['}', 'struct Rva {const char* name; unsigned long long value;};', 'inline constexpr Rva rvas[] = {']
out += ['{'+json.dumps(k)+','+str(v)+'ULL},' for k,v in layout['rvas'].items()]
out += ['};', 'struct Field {const char* key; const char* owner; const char* name; const char* descriptor; bool isStatic;};',
        'inline constexpr Field fields[] = {']
out += ['{'+','.join(json.dumps(v) for v in (key,f['owner'],f['name'],f['descriptor']))+','+str(f['static']).lower()+'},' for key,f in packet['fields'].items()]
out += ['};', 'struct Class {const char* key; const char* name;};', 'inline constexpr Class classes[] = {']
out += ['{'+json.dumps(k)+','+json.dumps(v)+'},' for k,v in packet['classes'].items()]
out += ['};','}']
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text('\n'.join(out)+'\n', encoding='utf-8')
