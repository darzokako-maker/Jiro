from pathlib import Path
import shutil
import sys

source_root, destination_root = map(Path, sys.argv[1:])
for name in ("PacketHook.java",):
    relative = Path("client/packethook") / name
    destination = destination_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source_root / relative, destination)
