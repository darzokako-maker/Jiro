#include "loader/PayloadCipher.hpp"

#include <fstream>
#include <iterator>
#include <string>
#include <vector>
#include <cstdio>

int main(int argc,char** argv)
{
    if(argc!=3){std::fprintf(stderr,"usage: payload_cipher_test <key> <dll>\n");return 2;}
    std::ifstream input(argv[2],std::ios::binary);
    const std::vector<unsigned char> expected{
        std::istreambuf_iterator<char>(input),std::istreambuf_iterator<char>()};
    std::vector<unsigned char> decrypted;
    if(expected.empty()||!loader::DecryptEmbeddedPayload(argv[1],decrypted)||decrypted!=expected){
        std::fprintf(stderr,"FAIL correct key did not reproduce embedded DLL\n");return 1;
    }
    std::string wrong=argv[1];wrong.push_back('x');
    if(loader::DecryptEmbeddedPayload(wrong,decrypted)){
        std::fprintf(stderr,"FAIL incorrect key produced a valid payload\n");return 1;
    }
    std::puts("PASS payload cipher: correct key reproduces DLL; incorrect key is rejected");
    return 0;
}
