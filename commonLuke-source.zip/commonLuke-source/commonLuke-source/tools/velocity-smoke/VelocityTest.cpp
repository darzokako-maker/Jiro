#include "features/combat/velocity/Velocity.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "game/MappingRepository.hpp"
#include "ClientMappings.hpp"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>

namespace {
using namespace client;
enum class Kind { Velocity, Explosion, Other };
struct Packet {
    int id = 42;
    Kind kind = Kind::Velocity;
    std::array<jint, 3> ints{8000, 4000, -8000};
    std::array<jfloat, 3> floats{1.f, .5f, -1.f};
};
struct Player { int id = 42; } player;
int minecraft, world;
bool connected = true, hasPlayer = true, pending = false, missingField = false, badFrame = false;
int frames = 0;
void Check(bool condition, const char* message) {
    if (!condition) { std::printf("FAIL: %s\n", message); std::exit(1); }
}
jboolean JNICALL ExceptionCheck(JNIEnv*) { return pending ? JNI_TRUE : JNI_FALSE; }
void JNICALL ExceptionClear(JNIEnv*) { pending = false; }
jint JNICALL PushFrame(JNIEnv*, jint) { if (badFrame) { pending=true; return JNI_ERR; } ++frames;return JNI_OK; }
jobject JNICALL PopFrame(JNIEnv*, jobject result) { --frames;return result; }
jclass JNICALL GetClass(JNIEnv*, jobject object) { return reinterpret_cast<jclass>(object); }
jfieldID JNICALL GetField(JNIEnv*, jclass cls, const char* name, const char* descriptor) {
    const auto* packet = reinterpret_cast<Packet*>(cls);
    const bool velocity = packet->kind == Kind::Velocity;
    const char* names[] = {velocity ? "R" : "j", velocity ? "K" : "k", velocity ? "i" : "a"};
    Check(std::strcmp(descriptor,velocity ? "I" : "F")==0,"field type");
    if (missingField && std::strcmp(name,names[1])==0) { pending=true;return nullptr; }
    for (std::uintptr_t i=0;i<3;++i) if (std::strcmp(name,names[i])==0) return reinterpret_cast<jfieldID>(i+1);
    Check(false,"verified mapping field name");return nullptr;
}
jint JNICALL GetInt(JNIEnv*, jobject object, jfieldID field) { return reinterpret_cast<Packet*>(object)->ints[reinterpret_cast<std::uintptr_t>(field)-1]; }
void JNICALL SetInt(JNIEnv*, jobject object, jfieldID field, jint value) { reinterpret_cast<Packet*>(object)->ints[reinterpret_cast<std::uintptr_t>(field)-1]=value; }
jfloat JNICALL GetFloat(JNIEnv*, jobject object, jfieldID field) { return reinterpret_cast<Packet*>(object)->floats[reinterpret_cast<std::uintptr_t>(field)-1]; }
void JNICALL SetFloat(JNIEnv*, jobject object, jfieldID field, jfloat value) { reinterpret_cast<Packet*>(object)->floats[reinterpret_cast<std::uintptr_t>(field)-1]=value; }
}

// The production receiver runs against fake JNI/game objects. Symbol names come
// from the real generated mapping table, not a second hand-written table.
namespace client::features::modules { void StateChanged(Id, bool, bool) {} }
namespace client::mapping {
std::optional<Symbol> Field(std::string_view key) {
    for (const auto& symbol : generated::fields) if (key==symbol.key) return Symbol{symbol.name,symbol.descriptor};
    return {};
}
std::optional<FieldInfo> ResolveField(std::string_view key) {
    if (key!="Entity.entityId" && key!="VelocityPacket.entityId") return {};
    FieldInfo field{};field.offset=0;return field;
}
std::uintptr_t Oop(jobject handle) { return reinterpret_cast<std::uintptr_t>(handle); }
jobject StaticObject(JNIEnv*, std::string_view key) {
    return key=="Minecraft.theMinecraft" ? reinterpret_cast<jobject>(&minecraft) : nullptr;
}
jobject Object(JNIEnv*, jobject object, std::string_view key) {
    if (!object) return nullptr;
    if (key=="Minecraft.thePlayer") return hasPlayer ? reinterpret_cast<jobject>(&player) : nullptr;
    if (key=="Minecraft.theWorld") return connected ? reinterpret_cast<jobject>(&world) : nullptr;
    return nullptr;
}
bool Instance(jobject object, std::string_view alias) {
    const auto kind=reinterpret_cast<Packet*>(object)->kind;
    return (alias=="VelocityPacket" && kind==Kind::Velocity) || (alias=="ExplosionPacket" && kind==Kind::Explosion);
}
}
namespace client::hotspot {
bool ReadMemory(std::uintptr_t address, void* output, std::size_t size) { std::memcpy(output,reinterpret_cast<void*>(address),size);return true; }
}

int main() {
    namespace velocity=client::features::velocity;
    Check(!velocity::Options().enabled&&velocity::Options().horizontal==0&&velocity::Options().vertical==0&&velocity::Options().explosions,"Harakiri Standard defaults: disabled, 0/0, explosion scaling enabled");
    JNINativeInterface_ table{};
    table.ExceptionCheck=&ExceptionCheck;table.ExceptionClear=&ExceptionClear;
    table.PushLocalFrame=&PushFrame;table.PopLocalFrame=&PopFrame;
    table.GetObjectClass=&GetClass;table.GetFieldID=&GetField;
    table.GetIntField=&GetInt;table.SetIntField=&SetInt;
    table.GetFloatField=&GetFloat;table.SetFloatField=&SetFloat;
    JNIEnv_ env{&table};
    auto receive=[&](Packet& packet) { const bool allow=velocity::BeforeReceive(&env,reinterpret_cast<jobject>(&packet));Check(frames==0,"balanced local frames");return allow; };
    Packet packet;
    const auto original=packet.ints;
    Check(receive(packet)&&packet.ints==original,"disabled passthrough");
    auto settings=velocity::Options();settings.enabled=true;settings.horizontal=50;settings.vertical=25;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.ints==std::array<jint,3>{4000,1000,-4000},"horizontal/vertical scale and signed Z");
    Check(player.id==42&&packet.id==42,"player and packet IDs unchanged");
    packet={};packet.id=43;
    Check(receive(packet)&&packet.ints==original,"other entity untouched");
    packet={};settings.horizontal=100;settings.vertical=100;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.ints==original,"100/100 passthrough");
    settings.horizontal=0;settings.vertical=0;velocity::SetOptions(settings);
    Check(!receive(packet)&&packet.ints==original,"0/0 cancels entity update");
    settings.vertical=100;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.ints==std::array<jint,3>{0,4000,0},"0/100 preserves vertical update");
    packet={};settings.horizontal=100;settings.vertical=0;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.ints==std::array<jint,3>{8000,0,-8000},"100/0 preserves horizontal update");
    packet={};packet.kind=Kind::Explosion;settings.horizontal=50;settings.vertical=25;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.floats==std::array<jfloat,3>{.5f,.125f,-.5f},"explosion impulse scaled and forwarded");
    packet={};packet.kind=Kind::Explosion;settings.horizontal=0;settings.vertical=0;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.floats==std::array<jfloat,3>{0,0,0},"0/0 explosion still forwarded");
    packet={};packet.kind=Kind::Explosion;settings.explosions=false;velocity::SetOptions(settings);
    Check(receive(packet)&&packet.floats==std::array<jfloat,3>{1,.5f,-1},"explosion option off");
    packet={};packet.kind=Kind::Other;Check(receive(packet)&&packet.ints==original,"other packet type untouched");
    packet={};connected=false;Check(receive(packet)&&packet.ints==original,"disconnected passthrough");connected=true;
    hasPlayer=false;Check(receive(packet)&&packet.ints==original,"no local player passthrough");hasPlayer=true;
    pending=true;Check(receive(packet)&&pending&&packet.ints==original,"preexisting Java exception preserved");pending=false;
    settings.horizontal=50;settings.vertical=50;velocity::SetOptions(settings);
    const auto failures=velocity::Status().failed;
    missingField=true;Check(receive(packet)&&!pending&&packet.ints==original,"mapping failure leaves all axes intact");missingField=false;
    badFrame=true;Check(receive(packet)&&!pending&&packet.ints==original,"frame failure fails open");badFrame=false;
    Check(velocity::Status().failed==failures+2,"failure counters");
    settings.horizontal=std::numeric_limits<float>::quiet_NaN();settings.vertical=200;velocity::SetOptions(settings);
    Check(velocity::Options().horizontal==0&&velocity::Options().vertical==100,"nonfinite and oversized settings sanitized");
    settings.horizontal=-10;settings.vertical=std::numeric_limits<float>::infinity();velocity::SetOptions(settings);
    Check(velocity::Options().horizontal==0&&velocity::Options().vertical==0,"negative and infinite settings sanitized");
    settings.enabled=false;velocity::SetOptions(settings);
    packet={};Check(receive(packet)&&packet.ints==original,"disable restores passthrough immediately");
    player.id=77;packet.id=77;settings.enabled=true;settings.horizontal=0;settings.vertical=0;velocity::SetOptions(settings);
    Check(!receive(packet)&&player.id==77,"respawn uses current player ID without rewriting it");
    Check(velocity::Status().modified==5&&velocity::Status().cancelled==2&&velocity::Status().explosions==2,"result counters");
    std::puts("PASS: production Velocity receiver, percentages, local targeting/respawn, explosions, disabled/disconnect, mapping errors, JNI frames and counters");
}
