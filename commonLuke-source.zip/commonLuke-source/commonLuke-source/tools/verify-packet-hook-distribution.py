from pathlib import Path
import sys
import zipfile


archive = Path(sys.argv[1])
allow_diagnostics = "--allow-diagnostics" in sys.argv[2:]
banned = (
    b"[Reference]",
    b"SaoriNhdCapture.run",
    b"bindings ready path=",
    b"capture rejected entity=",
    b"capture stage=",
    b"before nhd entity=",
    b"proof queued entity=",
    b"discarding stale expected game send",
    b"C:\\Saori\\logs",
    b"nhd-direct-",
    b"proofHex",
    b"sha256=",
    b"java/io/FileOutputStream",
    b"java/io/PrintWriter",
)

expected_classes = {
    "client/packethook/PacketHook.class",
    "client/packethook/PacketHook$Listener.class",
    "client/packethook/PacketHook$Handler.class",
    "client/packethook/PacketHook$NativeListener.class",
}
hits = []
with zipfile.ZipFile(archive) as jar:
    classes = {name for name in jar.namelist() if name.endswith(".class")}
    if classes != expected_classes:
        raise SystemExit(f"Unexpected packet hook classes: {sorted(classes ^ expected_classes)}")
    for name in sorted(classes):
        if not name.endswith(".class"):
            continue
        data = jar.read(name)
        for token in banned:
            if token in data:
                hits.append(f"{name}: {token.decode('ascii')}")

if hits and not allow_diagnostics:
    print("packet-hook.jar contains distribution diagnostics:", file=sys.stderr)
    print("\n".join(hits), file=sys.stderr)
    raise SystemExit(1)

if allow_diagnostics:
    print(f"verified {archive}: diagnostic Java constants allowed")
else:
    print(f"verified {archive}: no Java log/dump constants")
