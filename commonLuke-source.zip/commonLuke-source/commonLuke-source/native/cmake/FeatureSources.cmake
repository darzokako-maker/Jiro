# Feature source ownership is kept here so the root build file only describes
# targets. Paths are relative to native/.

# Settings, pure logic and render code are also linked by the HUD smoke target.
set(AOKI_FEATURE_HUD_SOURCES
    src/features/core/ModuleRegistry.cpp

    src/features/combat/kill_aura/KillAuraSettings.cpp
    src/features/combat/velocity/VelocitySettings.cpp
    src/features/combat/auto_harm/AutoHarm.cpp
    src/features/combat/aim_assist/AimAssistSettings.cpp

    src/features/exploit/no_rotate/NoRotateSettings.cpp

    src/features/movement/clips/ClipsLogic.cpp
    src/features/movement/clips/ClipsRuntime.cpp
    src/features/movement/ncp/NcpMovementSettings.cpp
    src/features/movement/fly/FlySettings.cpp
    src/features/movement/no_jump_cooldown/NoJumpCooldownSettings.cpp

    src/features/player/auto_disconnect/AutoDisconnectSettings.cpp
    src/features/player/scaffold/ScaffoldSettings.cpp

    src/features/utility/auto_miner/AutoMinerSettings.cpp
    src/features/utility/extra_modules/ExtraModulesSettings.cpp
    src/features/utility/seed_dumper/SeedDumperSettings.cpp

    src/features/visual/dragon_wings/DragonWings.cpp
    src/features/visual/esp/Esp.cpp
    src/features/visual/item_esp/ItemEsp.cpp
    src/features/visual/freecam/FreeCam.cpp
    src/features/visual/spotify_widget/SpotifyWidgetSettings.cpp
    src/features/visual/spotify_widget/SpotifyWidgetRender.cpp
    src/features/visual/inventory_hud/InventoryHudSettings.cpp
    src/features/visual/inventory_hud/InventoryHudRender.cpp
    src/features/visual/target_hud/TargetHudSettings.cpp
    src/features/visual/target_hud/TargetHudRender.cpp
    src/features/visual/cosmetics/CosmeticsSettings.cpp
    src/features/visual/ambiance/AmbianceSettings.cpp
    src/features/visual/xray/XraySettings.cpp
    src/features/visual/xray/XrayRender.cpp
)

# Game/JVM-dependent module execution.
set(AOKI_FEATURE_RUNTIME_SOURCES
    src/features/combat/aim_assist/AimAssistRuntime.cpp
    src/features/combat/velocity/VelocityRuntime.cpp
    src/features/exploit/no_rotate/NoRotateRuntime.cpp
    src/features/movement/ncp/NcpMovementRuntime.cpp
    src/features/movement/no_jump_cooldown/NoJumpCooldownRuntime.cpp
    src/features/player/auto_disconnect/AutoDisconnectRuntime.cpp
    src/features/player/scaffold/ScaffoldPlacement.cpp
    src/features/player/scaffold/ScaffoldRuntime.cpp
    src/features/utility/auto_miner/AutoMinerRuntime.cpp
    src/features/utility/extra_modules/ExtraModulesRuntime.cpp
    src/features/utility/nav/PathFinder.cpp
    src/features/utility/ore/OreScan.cpp
    src/features/utility/world/BlockGrid.cpp
    src/features/visual/spotify_widget/SpotifySession.cpp
    src/features/visual/spotify_widget/SpotifyWidgetRuntime.cpp
    src/features/visual/ambiance/AmbianceRuntime.cpp
    src/features/visual/ambiance/LyricsHttp.cpp
    src/features/visual/ambiance/LyricsLogic.cpp
    src/features/visual/ambiance/LyricsJson.cpp
    src/features/visual/ambiance/LyricsService.cpp
    src/features/visual/ambiance/ParticleLyricsLogic.cpp
    src/features/visual/ambiance/ParticleRaster.cpp
    src/features/visual/ambiance/ParticleLyrics.cpp
    src/features/visual/cosmetics/CosmeticsRuntime.cpp
    src/features/visual/freecam/FreeCamRuntime.cpp
)

# Render-thread snapshots kept separate from both settings and drawing.
set(AOKI_FEATURE_CAPTURE_SOURCES
    src/features/utility/seed_dumper/SeedDumperCapture.cpp
    src/features/utility/seed_dumper/SeedDump.cpp
    src/features/visual/dragon_wings/DragonWingsCapture.cpp
    src/features/visual/esp/EspCapture.cpp
    src/features/visual/esp/EspGlowRenderer.cpp
    src/features/visual/target_hud/TargetHudCapture.cpp
    src/features/visual/inventory_hud/InventoryHudCapture.cpp
    src/features/visual/xray/XrayCapture.cpp
)
