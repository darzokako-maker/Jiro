#pragma once
#include "render/GlApi.hpp"
#include <span>
#include <vector>
namespace client::render {
struct DecodedImage {std::vector<unsigned char> pixels;int width=0,height=0;};
// Requires a current context and loaded GlApi. Caller owns the resulting texture.
DecodedImage DecodeImageRgba(std::span<const unsigned char> bytes);
GLuint LoadPngTexture(std::span<const unsigned char> bytes);
GLuint UploadRgba(std::span<const unsigned char> pixels,int width,int height);
}
