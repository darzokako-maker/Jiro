#pragma once
namespace client::render {
void RenderHud(int framebufferWidth, int framebufferHeight);
}
