#pragma once
#include <vector>
struct ImDrawData;
namespace client::render {
struct PixelRect {int x=0,y=0,right=0,bottom=0;};
// Conservative coverage in framebuffer pixels. Rectangles never overlap, so
// alpha compositing a set of regions cannot apply the effect twice to a pixel.
class EffectRegion {
 static constexpr int Tile=128;
 int width_,height_,columns_,rows_;
 std::vector<unsigned char> cells_;
public:
 EffectRegion(int width,int height);
 void Add(float x,float y,float right,float bottom,float padding);
 void Add(const ImDrawData* data,float padding);
 std::vector<PixelRect> Rectangles(bool restrictWork=true) const;
};
}
