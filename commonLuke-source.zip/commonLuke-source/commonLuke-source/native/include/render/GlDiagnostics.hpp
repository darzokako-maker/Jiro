#pragma once
#include <Windows.h>
#include <cstdint>
#include <cstddef>

namespace client::render::diagnostics {
#if defined(AOKI_DISTRIBUTION)
class Scope {
public:
 explicit constexpr Scope(const char*) noexcept {}
};
inline void RegisterImage(void*,std::size_t) noexcept {}
inline bool Install() noexcept {return true;}
inline void Flush() noexcept {}
inline std::uint64_t ErrorCount() noexcept {return 0;}
inline std::uint32_t LastStackDepth() noexcept {return 0;}
#else
// The game context is owned by its render thread. No static TLS: the DLL is manually mapped.
class Scope {
public:
 explicit Scope(const char* label);
 ~Scope();
 Scope(const Scope&)=delete;
 Scope& operator=(const Scope&)=delete;
 const char* label;
 void* callSite=nullptr;
 const Scope* parent=nullptr;
private:
 bool active=false;
};
void RegisterImage(void* base, std::size_t size);
bool Install(); // Call only with the captured game context current; also repairs callback replacement.
void Flush();   // Symbolize queued stacks outside the driver callback.
std::uint64_t ErrorCount();
std::uint32_t LastStackDepth();
#endif
}
