#pragma once
#include <cstdint>
namespace client::render {
struct RoundedPanel {
 float x,y,width,height,radius;
 std::uint32_t color=0xC7191919u;
 float opacity=1.f;
 bool blur=true,border=true;
};
}
