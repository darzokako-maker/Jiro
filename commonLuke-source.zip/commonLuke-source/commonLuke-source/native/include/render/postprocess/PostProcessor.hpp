#pragma once
#include "render/GlApi.hpp"
#include "render/RoundedPanel.hpp"
#include "render/EffectRegion.hpp"
#include <array>
#include <span>
struct ImDrawData;
namespace client::render {
class PostProcessor {
 struct Target { GLuint fbo=0, texture=0; };
 Target scene_, mask_, scratch_, bloom_;
 GLuint program_=0, vao_=0;
 int width_=0, height_=0;
 bool restrictWork_=true;
 struct Uniforms {GLint source,mask,radius,bloom,strength,texel,direction,weights;} uniforms_{};
 std::array<float,15> blurKernel_{},bloomKernel_{};
 bool MakeTarget(Target& target);
 void DeleteTarget(Target& target);
 void Pass(GLuint source, GLuint mask, GLuint output, int radius,
           float x, float y, bool bloom, bool composite,std::span<const PixelRect> regions);
 void Panels(std::span<const RoundedPanel> panels, int mode);
public:
 explicit PostProcessor(bool restrictWork=true):restrictWork_(restrictWork){}
 bool Initialize();
 bool Resize(int width, int height);
 void Render(ImDrawData* mask, ImDrawData* bloom, ImDrawData* foreground, std::span<const RoundedPanel> panels);
 void Shutdown(); // Call only while the owning GL context is current.
};
}
