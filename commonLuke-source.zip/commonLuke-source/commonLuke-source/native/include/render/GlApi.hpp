#pragma once
#include <Windows.h>
#include <GL/gl.h>
#include <cstddef>

namespace client::render {
// Only the modern entry points used by our renderer. OpenGL 1.1 is linked normally.
#define AOKI_GL_FUNCTIONS(X) \
 X(void, BindFramebuffer, (GLenum, GLuint)) \
 X(void, GenFramebuffers, (GLsizei, GLuint*)) \
 X(void, DeleteFramebuffers, (GLsizei, const GLuint*)) \
 X(void, FramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint)) \
 X(GLenum, CheckFramebufferStatus, (GLenum)) \
 X(void, BlitFramebuffer, (GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLbitfield, GLenum)) \
 X(GLuint, CreateShader, (GLenum)) \
 X(void, ShaderSource, (GLuint, GLsizei, const char* const*, const GLint*)) \
 X(void, CompileShader, (GLuint)) \
 X(void, GetShaderiv, (GLuint, GLenum, GLint*)) \
 X(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, char*)) \
 X(void, DeleteShader, (GLuint)) \
 X(GLuint, CreateProgram, ()) \
 X(void, AttachShader, (GLuint, GLuint)) \
 X(void, LinkProgram, (GLuint)) \
 X(void, GetProgramiv, (GLuint, GLenum, GLint*)) \
 X(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, char*)) \
 X(void, DeleteProgram, (GLuint)) \
 X(void, UseProgram, (GLuint)) \
 X(GLint, GetUniformLocation, (GLuint, const char*)) \
 X(void, Uniform1i, (GLint, GLint)) \
 X(void, Uniform1f, (GLint, GLfloat)) \
 X(void, Uniform4f, (GLint, GLfloat, GLfloat, GLfloat, GLfloat)) \
 X(void, Uniform1fv, (GLint, GLsizei, const GLfloat*)) \
 X(void, Uniform2f, (GLint, GLfloat, GLfloat)) \
 X(void, GenVertexArrays, (GLsizei, GLuint*)) \
 X(void, DeleteVertexArrays, (GLsizei, const GLuint*)) \
 X(void, BindVertexArray, (GLuint)) \
 X(void, ActiveTexture, (GLenum)) \
 X(void, BindBuffer, (GLenum, GLuint)) \
 X(void, BlendFuncSeparate, (GLenum, GLenum, GLenum, GLenum)) \
 X(void, BlendEquationSeparate, (GLenum, GLenum))
struct GlApi {
#define DECLARE(returnType, name, args) using name##Fn = returnType (APIENTRY*) args; name##Fn name = nullptr;
 AOKI_GL_FUNCTIONS(DECLARE)
#undef DECLARE
 bool Load();
 void (APIENTRY* BindSampler)(GLuint, GLuint) = nullptr; // Optional before GL 3.3.
};
inline GlApi gl;
inline constexpr GLenum DrawFramebuffer=0x8CA9, ReadFramebuffer=0x8CA8;
inline constexpr GLenum Texture0=0x84C0, Texture1=0x84C1;

// Covers state changed by initialization, FBO passes and the UI backend.
class GlState {
 GLint draw{}, read{}, defaultDraw{}, defaultRead{}, program{}, vao{}, active{}, unpack{}, arrayBuffer{};
 GLint textures[2]{}, samplers[2]{}, viewport[4]{}, scissor[4]{}, polygon[2]{};
 GLint srcRgb{}, dstRgb{}, srcAlpha{}, dstAlpha{}, eqRgb{}, eqAlpha{};
 GLfloat clearColor[4]{};
 GLboolean mask[4]{}, enabled[10]{}, alphaTest{};
 bool compatibility=false;
 static constexpr GLenum caps[10] = {GL_BLEND, GL_CULL_FACE, GL_DEPTH_TEST,
     GL_STENCIL_TEST, GL_SCISSOR_TEST, 0x8C89, 0x8DB9, 0x8F9D, GL_COLOR_LOGIC_OP, 0x809E};
public:
 explicit GlState(bool prepareUi=true);
 ~GlState();
 void RestoreFramebuffers() const;
 void RestoreTextures() const;
};
}
