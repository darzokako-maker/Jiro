#pragma once
#include "render/GlApi.hpp"

namespace client::render {
// Java's 1.8 renderer uses client-memory vertex arrays, which require VAO zero.
// Protect that VAO's legacy client state separately from the game's current VAO.
class LegacyGuiState {
 GlState saved_{false};
 GLint matrixMode_=0;
public:
 LegacyGuiState();
 ~LegacyGuiState();
 LegacyGuiState(const LegacyGuiState&)=delete;
 LegacyGuiState& operator=(const LegacyGuiState&)=delete;
 void RestoreTextures() const {saved_.RestoreTextures();}
 static void BindClientArrays();
};
}
