#pragma once
#include "client/Logger.hpp"
inline constexpr bool kEnableLogging = false;
#define Log(...) AOKI_LOG(__VA_ARGS__)
