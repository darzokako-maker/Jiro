#pragma once
#include <jni.h>
#include "client/NativePacketEngine.hpp"
#include <cstdint>

namespace client::features::freecam {

struct Settings {
    bool enabled = false;
    float speed = 1.0f;
    bool operator==(const Settings&) const = default;
};

struct Vector3d {
    double x = 0.0, y = 0.0, z = 0.0;
};

struct Vector2f {
    float yaw = 0.0f, pitch = 0.0f;
};

const Settings& Options();
void SetOptions(Settings settings);
std::uint64_t Revision();

void Poll(JNIEnv* env);
jobject BeforeSend(JNIEnv* env, jobject packet);
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet);

bool IsActive();
Vector3d OriginalPosition();

} // namespace client::features::freecam

