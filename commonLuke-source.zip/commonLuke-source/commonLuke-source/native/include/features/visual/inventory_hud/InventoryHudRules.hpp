#pragma once

namespace client::features::inventory_hud::rules {

struct Layout {
    float cardWidth = 0;
    float cardHeight = 0;
    float gridLeft = 0;
    float gridTop = 0;
    float gridWidth = 0;
    float gridHeight = 0;
    float bottomInset = 0;
    float cell = 0;
    float iconSize = 0;
    float dashLength = 0;
    float dashGap = 0;
    float lineThickness = 0;
};

inline constexpr Layout LayoutForScale(float scale) {
    // SpotifyWidget's exact 314x151 reference canvas. The remaining vertical
    // space is four square rows; nine copies of that square are centred.
    const float width = 314.0f * scale;
    const float height = 151.0f * scale;
    const float gridTop = 27.0f * scale;
    const float bottom = 8.0f * scale;
    const float cell = (height - gridTop - bottom) / 4.0f;
    const float gridWidth = cell * 9.0f;
    return {
        width,
        height,
        (width - gridWidth) * 0.5f,
        gridTop,
        gridWidth,
        cell * 4.0f,
        bottom,
        cell,
        cell * (24.0f / 29.0f),
        cell / 12.0f,
        cell / 10.0f,
        cell / 52.0f,
    };
}

inline constexpr int InventoryIndex(int row, int column) {
    return row < 3 ? 9 + row * 9 + column : column;
}

} // namespace client::features::inventory_hud::rules
