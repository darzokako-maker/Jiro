#pragma once

#include "features/visual/esp/Esp.hpp"

#include <array>
#include <memory>
#include <vector>

struct JNIEnv_;
using JNIEnv = JNIEnv_;
struct ImDrawList;
namespace client::render { struct RoundedPanel; }
namespace client::ui { class FontManager; }

namespace client::features::inventory_hud {

struct Settings {
    bool enabled = false;
    bool operator==(const Settings&) const = default;
};

struct Slot {
    esp::Image image;
    int count = 0;
};

struct State {
    bool available = false;
    int selectedHotbar = 0;
    int occupied = 0;
    std::array<Slot, 36> slots{};
};

Settings Options();
void SetOptions(Settings settings);
std::shared_ptr<const State> Snapshot();
void Publish(State state);
void Capture(JNIEnv* env, int width, int height);
void Draw(const ui::FontManager& fonts, ImDrawList& foreground, float width, float height,
          std::vector<render::RoundedPanel>& panels);

} // namespace client::features::inventory_hud
