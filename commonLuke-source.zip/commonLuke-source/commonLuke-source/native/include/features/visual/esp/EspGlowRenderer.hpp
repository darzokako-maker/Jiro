#pragma once

#include "features/visual/esp/Esp.hpp"
#include "client/MethodManager.hpp"
#include "render/GlApi.hpp"
#include <jni.h>
#include <memory>

namespace client::features::esp {

// Reuses the game's RenderManager on the already-hooked render thread. Entities
// are drawn into half-resolution alpha masks; no Java references survive End().
class EspGlowRenderer {
 struct ScopedState;
 struct Target { GLuint fbo=0,texture=0,depth=0; int width=0,height=0; };
 std::unique_ptr<ScopedState> state_;
 Target living_,items_;
 JNIEnv* env_=nullptr;
 jobject manager_=nullptr;
 Camera camera_{};
 Target* bound_=nullptr;
 std::optional<bool> renderShadow_;
 struct StaticFloat { std::uintptr_t address=0; float value=0; };
 std::array<StaticFloat,2> nameRanges_{};
 bool livingActive_=false,itemsActive_=false;
 bool sharedMask_=false;
 bool ready_=false;

 bool Resize(Target& target,int width,int height);
 bool Bind(Target& target);
 bool Call(const char* key,const std::vector<methods::Argument>& args={});
 void RestoreJavaState();
public:
 EspGlowRenderer();
 ~EspGlowRenderer();
 EspGlowRenderer(const EspGlowRenderer&)=delete;
 EspGlowRenderer& operator=(const EspGlowRenderer&)=delete;

 bool Begin(JNIEnv* env,jobject minecraft,const Camera& camera,bool living,bool items,bool shareMasks);
 bool Draw(jobject entity,bool item,const Vec3& position,const Vec3& last);
 void End();
 std::uint32_t LivingTexture() const { return livingActive_?living_.texture:0; }
 std::uint32_t ItemTexture() const { return itemsActive_?(sharedMask_?living_.texture:items_.texture):0; }
};

}
