#pragma once
#include "features/visual/esp/Esp.hpp"
#include <unordered_map>

namespace client::features::esp {
// Values/images only: no Java objects or raw heap addresses survive a capture.
struct Details { Entity entity; bool hidden=false; };
class DetailsCache {
 std::unordered_map<int,Details> entries_;
 std::uint64_t refreshed_=0,revision_=0;
 bool valid_=false;
public:
 static constexpr std::uint64_t IntervalMs=33;
 bool Due(std::uint64_t now,std::uint64_t revision) const {
  return !valid_||revision!=revision_||now-refreshed_>=IntervalMs;
 }
 const Details* Find(int id) const {const auto found=entries_.find(id);return found==entries_.end()?nullptr:&found->second;}
 void Commit(std::uint64_t now,std::uint64_t revision,std::unordered_map<int,Details> entries) {
  entries_=std::move(entries);refreshed_=now;revision_=revision;valid_=true;
 }
 void Clear(){entries_.clear();valid_=false;}
};
}
