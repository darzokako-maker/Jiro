#pragma once
#include <jni.h>
namespace client::features::esp {
void Capture(JNIEnv* environment,int width,int height);
void UpdateNameTags();
}
