#pragma once

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <Windows.h>

#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "asm/AsmJvm.hpp"

// Temporary ESP regression diagnostics. Counters are plain atomics merged once
// per capture/draw call; the 3-second flush runs on the render thread inside
// EspCapture::Capture and only emits when AOKI_ENABLE_LOGGING is defined.
namespace client::features::esp::debug {

enum ExitReason : std::uint32_t {
    kExitDisabled = 0,
    kExitNoEnv,
    kExitPendingException,
    kExitRefsFailed,
    kExitNoMinecraft,
    kExitNoWorld,
    kExitNoPlayer,
    kExitCachedWorldFail,
    kExitNoManager,
    kExitNoTimer,
    kExitMatrixFetch,
    kExitMatrixNonFinite,
    kExitNoOrigin,
    kExitBadViewport,
    kExitNoEntityList,
    kExitBadEntityArray,
    kExitGlUnavailable,
    kExitCount
};

inline const char* const kExitNames[kExitCount] = {
    "disabled", "no-env", "pending-exception", "refs-failed",
    "no-minecraft", "no-world", "no-player", "cached-world-fail",
    "no-manager", "no-timer", "matrix-fetch", "matrix-nonfinite",
    "no-origin", "bad-viewport", "no-entity-list", "bad-entity-array", "gl-unavailable"
};

struct FrameStats {
    std::uint64_t scanFrames = 0, total = 0, classFail = 0, maskZero = 0,
        living = 0, item = 0, player = 0, animal = 0, mob = 0,
        notTarget = 0, dead = 0, self = 0, valid = 0, selected = 0,
        gatherRefNull = 0, gatherFallback = 0, detailSkipped = 0,
        projCalls = 0, projAccepted = 0, projRejected = 0, onScreen = 0,
        drawFrames = 0, drawReceived = 0, drawOnScreen = 0, drawBoxes = 0;
    void Merge() const;
};

struct Window {
    std::atomic<std::uint64_t> scanFrames, total, classFail, maskZero,
        living, item, player, animal, mob,
        notTarget, dead, self, valid, selected,
        gatherRefNull, gatherFallback, detailSkipped,
        projCalls, projAccepted, projRejected, onScreen, published,
        drawFrames, drawReceived, drawOnScreen, drawBoxes;
};
inline Window g_window{};
inline std::atomic<std::uint64_t> g_exits[kExitCount]{};
inline std::atomic<std::uint32_t> g_loggedExits{0};
inline std::uint64_t g_lastFlush = 0; // render thread only (EspCapture::Capture)

inline void FrameStats::Merge() const
{
    g_window.scanFrames += scanFrames;
    g_window.total += total;
    g_window.classFail += classFail;
    g_window.maskZero += maskZero;
    g_window.living += living;
    g_window.item += item;
    g_window.player += player;
    g_window.animal += animal;
    g_window.mob += mob;
    g_window.notTarget += notTarget;
    g_window.dead += dead;
    g_window.self += self;
    g_window.valid += valid;
    g_window.selected += selected;
    g_window.gatherRefNull += gatherRefNull;
    g_window.gatherFallback += gatherFallback;
    g_window.detailSkipped += detailSkipped;
    g_window.projCalls += projCalls;
    g_window.projAccepted += projAccepted;
    g_window.projRejected += projRejected;
    g_window.onScreen += onScreen;
    g_window.drawFrames += drawFrames;
    g_window.drawReceived += drawReceived;
    g_window.drawOnScreen += drawOnScreen;
    g_window.drawBoxes += drawBoxes;
}

inline void AddPublished(std::uint64_t count)
{
    g_window.published += count;
}

inline void NoteExit(std::uint32_t reason)
{
    if (reason >= kExitCount) return;
    g_exits[reason].fetch_add(1, std::memory_order_relaxed);
#if defined(AOKI_ENABLE_LOGGING)
    const auto bit = 1u << reason;
    if (!(g_loggedExits.fetch_or(bit, std::memory_order_relaxed) & bit))
        AOKI_LOG("[ESP-DEBUG] exit: reason=%s", kExitNames[reason]);
#endif
}

inline void Tick()
{
#if defined(AOKI_ENABLE_LOGGING)
    const auto now = client::scheduler::Now();
    if (now - g_lastFlush < 3000) return;
    g_lastFlush = now;
    auto snap = [](std::atomic<std::uint64_t>& c) {
        return c.exchange(0, std::memory_order_relaxed);
    };
    auto& w = g_window;
    AOKI_LOG("[ESP-DEBUG] capture: scans=%llu total=%llu classFail=%llu maskZero=%llu living=%llu item=%llu player=%llu animal=%llu mob=%llu notTarget=%llu dead=%llu self=%llu valid=%llu selected=%llu",
        snap(w.scanFrames), snap(w.total), snap(w.classFail), snap(w.maskZero), snap(w.living), snap(w.item),
        snap(w.player), snap(w.animal), snap(w.mob), snap(w.notTarget), snap(w.dead),
        snap(w.self), snap(w.valid), snap(w.selected));
    const auto a = asm_jvm::TakeAsmDebug();
    AOKI_LOG("[ESP-DEBUG] asm: decode calls=%llu fail=%llu seh=%llu nullAddr=%llu badCfg=%llu | walk calls=%llu seh=%llu zero=%llu matched=%llu",
        a.decodeCalls, a.decodeFailures, a.decodeExceptions, a.decodeNullAddress, a.decodeInvalidConfig,
        a.walkCalls, a.walkExceptions, a.walkZeroMask, a.walkMatched);
    AOKI_LOG("[ESP-DEBUG] gather: entity calls=%llu ok=%llu fail=%llu | box calls=%llu ok=%llu fail=%llu | invalidOp=%llu seh=%llu refNull=%llu fallback=%llu",
        a.gatherEntityCalls, a.gatherEntityOk, a.gatherEntityFail,
        a.gatherBoxCalls, a.gatherBoxOk, a.gatherBoxFail,
        a.gatherInvalidOp, a.gatherExceptions, snap(w.gatherRefNull), snap(w.gatherFallback));
    AOKI_LOG("[ESP-DEBUG] projection: calls=%llu accepted=%llu rejected=%llu onScreen=%llu skipped=%llu published=%llu",
        snap(w.projCalls), snap(w.projAccepted), snap(w.projRejected), snap(w.onScreen),
        snap(w.detailSkipped), snap(w.published));
    AOKI_LOG("[ESP-DEBUG] draw: frames=%llu received=%llu onScreen=%llu glows=%llu",
        snap(w.drawFrames), snap(w.drawReceived), snap(w.drawOnScreen), snap(w.drawBoxes));
    char exits[640]{};
    std::size_t pos = 0;
    for (std::uint32_t i = 0; i < kExitCount && pos + 48 < sizeof(exits); ++i) {
        const auto n = g_exits[i].exchange(0, std::memory_order_relaxed);
        if (n) pos += std::snprintf(exits + pos, sizeof(exits) - pos, " %s=%llu", kExitNames[i],
            static_cast<unsigned long long>(n));
    }
    if (pos) AOKI_LOG("[ESP-DEBUG] exits:%s", exits);
#endif
}

} // namespace client::features::esp::debug
