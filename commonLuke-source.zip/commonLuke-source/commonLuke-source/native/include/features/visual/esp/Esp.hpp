#pragma once
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>
#include <imgui.h>
namespace client::ui { class FontManager; }
namespace client::features::esp {
struct Vec3 { double x=0,y=0,z=0; };
struct Bounds { Vec3 min,max; };
struct Camera {
 std::array<float,16> model{},projection{};
 std::array<int,4> viewport{};
 Vec3 origin;
 float partial=1.f;
 int framebufferHeight=0;
};
struct ScreenBox { float x,y,right,bottom; };
 struct Image { std::uint32_t texture=0; float u0=0,v0=0,u1=1,v1=1,width=0,height=0; };
struct Entity {
 int id=0;
 Bounds bounds;
 Vec3 position,last;
 bool player=false,animal=false,mob=false,isItem=false,sneaking=false,friendEntity=false,invisible=false;
 std::optional<float> health,maxHealth;
 std::string name,formattedName,heldItem;
 std::array<Image,4> equipment{};
 struct Durability { int remaining=0,total=0; };
 std::array<Durability,4> equipmentDurability{};
 Image nameImage,heldImage,healthImage;
 ScreenBox box{};
 bool onScreen=false;
};
struct GlowMasks {
 std::uint32_t living=0;
 std::uint32_t items=0;
};
struct Frame { Camera camera; std::vector<Entity> entities; GlowMasks glow; };
struct Settings {
 // `box`/`boxPostprocess` retain their old serialized positions. `box` now
 // enables the entity silhouette glow; no rectangle is drawn.
 bool enabled=true,players=true,animals=true,mobs=true,box=true,boxPostprocess=true;
 bool invisibles=true;
 // Kept in the serialized layout for compatibility. ESP text always uses the
 // shared native font now; SetOptions forces this field off.
 bool minecraftFont=false,heldItem=true,equipment=true,healthBar=true,healthText=true;
 bool nametags=true,redTags=false,formattedTags=false,tagPostprocess=false;
 bool tagHealth=true,tagBackground=true,redBackground=false,roundedTags=true;
 bool healthByValue=false,customColor=false,rainbow=false;
 float tagScale=.75f;
 ImU32 color=IM_COL32_WHITE,alternate=IM_COL32(180,180,180,255);
 std::string friends;
};
const Settings& Options();
void SetOptions(const Settings& settings);
std::uint64_t OptionsRevision();
void Publish(Frame frame);
std::optional<Frame> Snapshot();
std::optional<ScreenBox> Project(const Bounds& box,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera);
std::optional<ScreenBox> ProjectCppReference(const Bounds& box,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera);
std::optional<ScreenBox> ProjectOptimizedCpp(const Bounds& box,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera);
std::optional<ScreenBox> ProjectAsmScalar(const Bounds& box,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera);
std::optional<ScreenBox> ProjectAsmAVX2(const Bounds& box,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera);
void Draw(const ui::FontManager& fonts,ImDrawList& foreground,ImDrawList& bloom);
void DrawFrame(const Frame& frame,const Settings& settings,const ui::FontManager& fonts,ImDrawList& foreground,ImDrawList& bloom);
}
