#pragma once

#include "features/utility/ore/OreTargets.hpp"
#include "features/visual/esp/Esp.hpp"

#include <jni.h>
#include <cstdint>
#include <optional>
#include <vector>

namespace client::ui { class FontManager; }

namespace client::features::xray {

struct Settings {
    bool enabled = false;
    ore::Toggles ores{};
    float radius = 32.f;
    bool boxes = true, tracers = false, labels = true;
    float lineWidth = 1.5f;
    bool operator==(const Settings&) const = default;
};

struct OreBox {
    ore::Kind kind = ore::Kind::Diamond;
    esp::Vec3 min, max, center;
    float distance = 0.f;
};

struct Frame {
    esp::Camera camera;
    std::vector<OreBox> ores;
};

const Settings& Options();
void SetOptions(const Settings& settings);
std::uint64_t OptionsRevision();

// Render-thread camera snapshot plus the throttled ore scan. Runs every
// present so the projection follows the camera even though the chunk walk is
// rate limited internally.
void Capture(JNIEnv* env, int width, int height);
void Publish(Frame frame);
void Clear();
std::optional<Frame> Snapshot();

void Draw(const ui::FontManager& fonts, ImDrawList& foreground);

} // namespace client::features::xray
