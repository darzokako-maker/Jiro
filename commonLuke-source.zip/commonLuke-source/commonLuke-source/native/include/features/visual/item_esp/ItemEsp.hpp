#pragma once
#include <cstdint>
#include <string>
#include <imgui.h>

namespace client::features::item_esp {
struct Settings {
 bool enabled=true;
 // Legacy serialized names: `box` now means entity silhouette glow.
 bool box=true,boxPostprocess=true;
 // Serialized for compatibility only. ItemESP always uses the native font.
 bool minecraftFont=false;
 bool nametags=true,formattedTags=true,tagPostprocess=false;
 bool tagBackground=true,redBackground=false,roundedTags=true;
 bool customColor=false,rainbow=false;
 float tagScale=.75f;
 ImU32 color=IM_COL32_WHITE,alternate=IM_COL32(180,180,180,255);
};

const Settings& Options();
void SetOptions(const Settings& settings);
std::uint64_t OptionsRevision();
}
