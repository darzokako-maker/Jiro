#pragma once
#include "features/visual/ambiance/Lyrics.hpp"
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>

namespace client::features::ambiance::lyrics {

struct HttpResponse {
 int status=0;          // HTTP status; 0 = transport failure
 std::string body;
 std::string retryAfter;
 std::string error;     // transport-level failure description
 bool TransportFailed()const{return status==0;}
};

using Transport=std::function<HttpResponse(std::string_view)>;

// WinHTTP implementation; declared here so the service can use it as default.
HttpResponse TransportWinHttp(std::string_view url);

struct TrackQuery {
 std::string trackKey;
 std::string title;
 std::string artist;
 std::int64_t durationMs=0;
};

struct FetchResult {
 LyricsStatus status=LyricsStatus::Error;
 std::string detail;
 std::shared_ptr<const LyricsContent> content;
 bool cacheable=false;        // safe to store in the bounded cache
 bool retryable=false;        // transient failure (429/5xx/transport)
 std::int64_t retryAfterMs=0;
};

// Single attempt: /api/get then validated /api/search fallback.
FetchResult FetchOnce(const TrackQuery& query,const Transport& transport);

// Retry policy wrapper (bounded attempts, Retry-After aware backoff).
FetchResult Fetch(const TrackQuery& query);

// Overrides the transport used by Fetch. Empty restores WinHTTP.
void SetTransport(Transport transport);
// Overrides the API base URL (testing / mirrors). Empty restores default.
void SetEndpoint(std::string_view baseUrl);
// Diagnostic: total HTTP requests issued through FetchOnce.
unsigned HttpRequestCount();

}
