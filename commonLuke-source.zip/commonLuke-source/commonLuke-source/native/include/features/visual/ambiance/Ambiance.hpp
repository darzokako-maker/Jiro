#pragma once
#include "features/visual/ambiance/Lyrics.hpp"
#include <functional>

namespace client::features::ambiance {

struct Lyrics3DColor {
 unsigned color=0xFFFFFFFFu; // IM_COL32: AABBGGRR
 float brightness=1.f;
 float glow=1.f;
 bool follow=true;           // player-relative world anchor vs fixed world anchor
 float distance=16.f;        // blocks along the initial horizontal facing
 float hOffset=0.f;          // lateral offset, -15..+15
 float vOffset=10.f;         // vertical lift, -4..+25
 float scale=1.f;            // world-size multiplier, 0.4..2.0
 bool billboard=true;        // camera-facing quads vs fixed world orientation
 bool operator==(const Lyrics3DColor&)const=default;
};

struct Settings {
 bool enabled=false;
 bool lyrics=false;
 bool lyrics3d=false;
 float offsetMs=0.f;
 Lyrics3DColor lyrics3dColor;
 bool operator==(const Settings&)const=default;
};

Settings Options();
void SetOptions(Settings settings);

// Internal publish points used by the runtime workers.
void PublishMedia(MediaSnapshot snapshot);
void PublishLyrics(LyricsPayload payload);

void PollRuntime();
void Shutdown();

// Smoke-test hooks. Empty provider falls back to Windows GSMTC via the
// Spotify session service, independent of the SpotifyWidget module state.
using TrackProvider=std::function<TrackInfo()>;
void SetTrackProviderForTest(TrackProvider provider);

}
