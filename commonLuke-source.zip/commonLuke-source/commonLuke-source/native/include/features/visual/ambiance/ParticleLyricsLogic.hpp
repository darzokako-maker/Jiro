#pragma once
#include "features/visual/ambiance/Lyrics.hpp"
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

namespace client::features::ambiance::lyrics3d {

// Pure particle-field logic ported from the ParticleText reference component.
// No GL/JNI dependencies: the renderer samples text into LineLayout targets,
// steps the field with *lyrics* time (so pause/seek behave correctly) and reads
// per-particle karaoke fill for coloring.

struct ParticleTarget {
 float x=0,y=0;        // text-pixel coordinate, centered on the line bounds
 int word=-1;          // index into LineLayout::words
 float xNorm=0;        // 0..1 position inside that word's horizontal span
 float weight=1;       // glyph coverage 0..1
};

struct WordSpan {
 std::int64_t startMs=0,endMs=0;
 float left=0,right=0; // text-pixel bounds inside the centered layout
};

struct LineLayout {
 std::vector<ParticleTarget> targets;
 std::vector<WordSpan> words;
 float width=0,height=0; // uncentered pixel size; targets are centered
};

struct Particle {
 float x=0,y=0;          // current position (text pixels, centered space)
 float targetX=0,targetY=0;
 float startX=0,startY=0;// position captured when this target was assigned
 float seed=0,depth=0;
 int word=-1;
 float xNorm=0;
 float weight=1;
 float heat=0;           // smoothed motion amount 0..1 (brightness boost only)
 float fade=1;           // current alpha multiplier, eases toward fadeGoal
 float fadeGoal=1;       // 0 = retiring (surplus particle), 1 = active
};

inline float Clamp01(float v){return v<0?0:v>1?1:v;}
inline float EaseOutCubic(float t){return 1.f-(1.f-t)*(1.f-t)*(1.f-t);}
// Exponential follow factor for a frame delta expressed in 60fps frames.
inline float FollowFactor(float frames){return 1.f-std::pow(0.78f,frames);}

class Field {
public:
 // No fixed particle cap: the raster target count (real glyph density at
 // density=1) decides how many particles exist. Spawn/fade logic in
 // SetLayout keeps morphs continuous in both directions.
 // Assigns new targets. Existing particles keep their current position and are
 // retargeted (morph); surplus targets spawn at scattered offsets, surplus
 // particles reuse targets with a small seed jitter so density stays even.
 void SetLayout(const LineLayout& layout,std::uint32_t seed=1);
 void Clear();
 // Advances the simulation by dtMs of lyrics time. Returns true while any
 // particle is still noticeably moving (used to skip redraw work).
 bool Step(float dtMs,float idleDrift=0.8f);
 // Recomputes per-word karaoke progress for positionMs and stores it for
 // KaraokeFill(). Words use their own left/right span; progress is clamped.
 void SetKaraoke(std::int64_t positionMs);
 // 0..1 sung fraction for a particle: its xNorm inside the word span versus
 // that word's playback progress, with a soft edge. Uses targetX ordering,
 // never the particle's animated position, so morphs cannot smear the fill.
 float KaraokeFill(const Particle& particle) const;
 const std::vector<Particle>& Particles()const{return particles_;}
 std::vector<Particle>& Particles(){return particles_;}
 bool Empty()const{return particles_.empty();}
 const LineLayout* Layout()const{return layout_?&*layout_:nullptr;}
 float TimeSeconds()const{return timeMs_*0.001f;}
private:
 std::vector<Particle> particles_;
 std::vector<float> wordProgress_;
 std::shared_ptr<const LineLayout> layout_;
 float timeMs_=0;
 std::uint32_t rng_=1;
 float NextRandom();
};

// Smooth mix helper shared by renderer and tests.
inline void MixRgb(float& r,float& g,float& b,float tr,float tg,float tb,float t){
 r+=(tr-r)*t;g+=(tg-g)*t;b+=(tb-b)*t;
}

// Lyrics playback clock that separates real seeks from media-snapshot jitter.
// rawMs is PredictPositionMs() output; elapsedMs is real time since the
// previous sync. While playing, heldMs advances at real-time rate and only
// resyncs to rawMs when it deviates beyond the deadband (a genuine seek or
// track jump); smaller deviations are absorbed so karaoke never jumps
// backward. seek is set on resync so the caller can snap particles.
// Paused playback adopts rawMs verbatim (the position is already frozen).
struct LyricsClock { std::int64_t heldMs=0; bool valid=false; };
std::int64_t SyncLyricsClock(LyricsClock& clock,std::int64_t rawMs,std::int64_t elapsedMs,
                             bool playing,std::int64_t durationMs,bool& seek);

// Index of the word to display at positionMs: the last word whose startMs has
// been reached. Holds through inter-word gaps and past the last word until the
// line changes; npos before the first word starts. Works for both real and
// estimated timings.
std::size_t SelectDisplayWord(const std::vector<LyricWord>& words,std::int64_t positionMs);

// Builds the visible window around activeWord: words [active-radius,
// active+radius] clamped to the line. Targets are re-centered horizontally on
// the active word's span center so the billboard never slides while morphing;
// neighbor words keep their karaoke spans but their target weight is scaled
// by neighborWeight so they read as a dim background layer. Word indices are
// remapped to window-local positions to match WordSpan order.
LineLayout WordWindowLayout(const LineLayout& full,std::size_t activeWord,
                            std::size_t radius=2,float neighborWeight=0.55f);

// World scale for a layout: text pixel height -> world height, clamped so the
// layout never exceeds maxWorldWidth/maxWorldHeight blocks (frustum-fit values
// supplied by the caller). Returns pixels-per-world-unit (wpp); world dims via
// out params.
float WorldScale(float layoutPixelWidth,float layoutPixelHeight,float targetWorldHeight,
                 float maxWorldWidth,float maxWorldHeight,
                 float& outWorldWidth,float& outWorldHeight);

// Finds the word range [outFirst,outLast] of the display chunk containing
// activeWord: the maximal run of consecutive words whose combined pixel span
// fits budgetPx, expanded toward the side that keeps the active word centred.
// Cheap: no target copying, safe to call every frame for cache keys.
void ChunkWordRange(const LineLayout& full,std::size_t activeWord,float budgetPx,
                    std::size_t& outFirst,std::size_t& outLast);

// Builds the LineLayout for the chunk range [first,last]: recentred on the
// chunk centre, word indices remapped to chunk-local order, every particle
// target of the chunk's words preserved.
LineLayout ChunkLayout(const LineLayout& full,std::size_t first,std::size_t last);

// Index of the word span nearest to pixel x (0 when x falls inside a span,
// otherwise the closer neighbour). -1 only when there are no words.
int NearestWordIndex(const std::vector<WordSpan>& words,float x);

// ---- manual world-space placement ----
// No automatic placement: the anchor is playerPos + forward*distance +
// right*hOffset + up*vOffset using the sliders; all math is inline in the
// renderer.

// True when a layout built this long into a word should snap particles to
// targets instead of playing the gather animation (late-arriving lyrics or
// mid-word seeks must not replay the intro).
bool ShouldSnapOnLayout(std::int64_t positionMs,std::int64_t wordStartMs,
                        std::int64_t thresholdMs=700);

}
