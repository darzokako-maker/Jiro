#pragma once
#include <cstddef>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace client::features::ambiance::lyricsjson {

struct JsonValue {
 enum class Type { Null, Bool, Number, String, Array, Object };
 Type type=Type::Null;
 bool boolean=false;
 double number=0;
 std::string text;
 std::vector<JsonValue> items;
 std::vector<std::pair<std::string,JsonValue>> members;
 const JsonValue* Find(std::string_view key)const;
};

// Returns false on malformed input, excessive depth or trailing garbage.
bool Parse(std::string_view text,JsonValue& out);

}
