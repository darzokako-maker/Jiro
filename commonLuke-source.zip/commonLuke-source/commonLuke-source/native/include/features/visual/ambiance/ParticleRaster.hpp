#pragma once
#include "features/visual/ambiance/Lyrics.hpp"
#include "features/visual/ambiance/ParticleLyricsLogic.hpp"

namespace client::features::ambiance::lyrics3d {

// Rasterizes one synced lyric line into particle targets using GDI+ and the
// embedded Fredoka font. Pure CPU work: no JNI, no OpenGL. Returns false on
// failure; each stage logs its own diagnostic when logging is enabled.
// Safe to call from the render thread only when a line change requires it.
bool RasterizeLine(const LyricLine& line,LineLayout& layout);

// Diagnostics: FontKit failStage (0=ok, 1=GdiplusStartup, 2=temp write,
// 3=AddFontFile, 4=GetFamilies); returns failStage, or -1 when ready.
int RasterFontKitStatus();

}
