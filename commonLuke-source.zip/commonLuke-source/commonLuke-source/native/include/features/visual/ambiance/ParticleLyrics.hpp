#pragma once
#include <jni.h>

namespace client::features::ambiance {

// World-space particle lyrics renderer. Called from the glClear hook on the
// render thread with a current GL context; all JVM/GL work stays there.
// Rasterization runs synchronously only when the active lyric line changes.
void RenderLyricsWorld(JNIEnv* env,unsigned mask);

// Drops particle state immediately (module disabled / shutdown).
void ResetLyrics3D();

// Per-frame world-pass reset; call once per rendered frame (swap present).
void Lyrics3DPresent();

}
