#pragma once
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace client::features::ambiance {

enum class LyricsStatus { Loading, Synced, Plain, Instrumental, NotFound, Error };

struct LyricWord {
 std::string text;
 std::int64_t startMs=0;
 std::int64_t endMs=0; // 0 = open-ended / unknown
 bool estimated=false; // true when times are even-split estimates, not real tags
};

struct LyricLine {
 std::int64_t startMs=0;
 std::int64_t endMs=0; // next line start; 0 = open-ended
 std::string text;
 std::vector<LyricWord> words;
};

struct LyricsContent {
 std::vector<LyricLine> lines;       // synced lyrics, sorted by startMs
 std::vector<std::string> plainLines; // plain lyrics, display order
 std::int64_t offsetMs=0;             // [offset:] tag from the LRC source
};

struct TrackInfo {
 bool available=false;
 std::string title;
 std::string artist;
 std::int64_t durationMs=0;
 std::int64_t positionMs=0;
 bool playing=false;
};

struct MediaSnapshot : TrackInfo {
 std::chrono::steady_clock::time_point positionAt{};
 std::string trackKey;
};

struct LyricsPayload {
 std::string trackKey;
 LyricsStatus status=LyricsStatus::Loading;
 std::shared_ptr<const LyricsContent> content;
 std::string detail;
};

struct LyricsState {
 bool available=false;
 LyricsStatus status=LyricsStatus::Loading;
 std::string trackKey;
 std::string title;
 std::string artist;
 std::int64_t durationMs=0;
 std::int64_t positionMs=0;
 bool playing=false;
 std::chrono::steady_clock::time_point positionAt{};
 std::shared_ptr<const LyricsContent> content;
 std::string detail;
 std::int64_t offsetMs=0; // user trim applied at lookup time
};

struct ActiveLyrics {
 static constexpr std::size_t npos=static_cast<std::size_t>(-1);
 std::size_t lineIndex=npos;
 std::size_t wordIndex=npos;
 const LyricLine* line=nullptr;
};

LyricsState LyricsSnapshot();
ActiveLyrics GetActiveLyrics(const LyricsState& state,std::int64_t positionMs);
std::int64_t PredictPositionMs(const LyricsState& state,std::chrono::steady_clock::time_point now=std::chrono::steady_clock::now());

}
