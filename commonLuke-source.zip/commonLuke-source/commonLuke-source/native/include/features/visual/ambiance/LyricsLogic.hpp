#pragma once
#include "features/visual/ambiance/Lyrics.hpp"
#include <string>
#include <string_view>
#include <vector>

namespace client::features::ambiance::lyricslogic {

// Parses LRC content. Enhanced <mm:ss.xx> word tags populate LyricWord timings;
// words without explicit tags get evenly spaced estimates inside their line.
// offsetMs receives the [offset:] tag value (0 when absent).
std::vector<LyricLine> ParseLrc(std::string_view lrc,std::int64_t& offsetMs);

// Plain lyrics split into display lines. No timestamps are invented.
std::vector<std::string> ParsePlain(std::string_view plain);

// Lowercase, punctuation-stripped, feat./ft. removed comparison form.
std::string NormalizeName(std::string_view name);

// 0..1 similarity between two names (levenshtein blended with token overlap).
double NameSimilarity(std::string_view a,std::string_view b);

// MediaWorker playback clock. GSMTC republishes positionMs every poll but the
// underlying value can stay stale for seconds; anchoring each stale sample to
// a fresh positionAt makes PredictPositionMs sawtooth and floods the lyrics
// clock with fake seeks. This clock free-runs between identical GSMTC samples
// while playing, adopts fresh samples (advances, real seeks, pause/resume,
// track changes) and never moves backward while playing.
// nowTickMs is an arbitrary monotonic millisecond counter injected by caller.
struct PlaybackClock {
 std::int64_t rawGsm=-1;  // last GSMTC-reported position
 std::int64_t pubPos=-1;  // last adopted/published position
 std::int64_t pubAtMs=0;  // tick when pubPos was adopted
 bool wasPlaying=false;
};
// Returns the position (ms) to publish for this poll.
std::int64_t AdvancePlaybackClock(PlaybackClock& clock,std::int64_t gsmPosMs,
                                  bool playing,std::int64_t durationMs,
                                  std::int64_t nowTickMs);

}
