#pragma once
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

struct JNIEnv_;
using JNIEnv=JNIEnv_;

namespace client::features::cosmetics {
enum class Model { Original=0, Classic=1, Slim=2 };

struct Settings {
 bool enabled=false;
 Model model=Model::Original;
 std::string skin;
 std::string cape;
 bool operator==(const Settings&)const=default;
};

Settings Options();
void SetOptions(Settings value);
std::filesystem::path Root();
std::vector<std::string> SkinChoices();
std::vector<std::string> CapeChoices();
void Poll(JNIEnv* env);
void Debug(std::string_view message);
}
