#pragma once
#include "features/visual/esp/Esp.hpp"
#include <array>
#include <memory>
#include <string>
#include <vector>

struct JNIEnv_;
using JNIEnv=JNIEnv_;
struct ImDrawList;
namespace client::render { struct RoundedPanel; }
namespace client::ui { class FontManager; }

namespace client::features::targethud {
struct Settings {
 bool enabled=false;
 bool operator==(const Settings&)const=default;
};
struct State {
 bool available=false;
 int id=-1;
 std::string name;
 float health=0,maxHealth=20;
 esp::Image model,held;
 std::array<esp::Image,4> armor{};
};
Settings Options();
void SetOptions(Settings settings);
std::shared_ptr<const State> Snapshot();
void Publish(State state);
void Capture(JNIEnv* env,int width,int height);
void Draw(const ui::FontManager& fonts,ImDrawList& foreground,ImDrawList& bloom,float width,float height,std::vector<render::RoundedPanel>& panels);
}
