#pragma once
#include <array>
#include <cstdint>
#include <imgui.h>
namespace client::features::wings {
struct Settings {bool enabled=false;float scale=1.f;ImU32 color=IM_COL32_WHITE;};
struct Pose {
 std::array<float,16> model{},projection{};
 std::array<int,4> viewport{};
 double x=0,y=0,z=0;
 float yaw=0;
 bool thirdPerson=true,invisible=false,sneaking=false;
};
struct Angles {float x,y,z,tip;};
const Settings& Options();
void SetOptions(Settings settings);
Angles Animation(std::uint64_t milliseconds);
float InterpolateYaw(float previous,float current,float partial);
bool Render(const Pose& pose,const Settings& settings,std::uint64_t milliseconds);
// Tracks the world's first depth clear. Actual rendering additionally validates
// perspective, the main framebuffer, the local player and third-person mode.
class WorldPass {
 bool armed_=false,drawn_=false;
public:
 bool Clear(unsigned mask){if((mask&0x4100)==0x4100)armed_=true;return armed_&&!drawn_&&mask==0x100;}
 void Drawn(){drawn_=true;}
 void Present(){armed_=drawn_=false;}
};
}
