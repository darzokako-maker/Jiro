#pragma once
#include <jni.h>
namespace client::features::wings {
void BeforeClear(JNIEnv* env,unsigned mask);
void Present();
double FrameMilliseconds();
}
