#pragma once
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include <optional>

namespace client::features::spotify::session {
std::optional<MediaState> Query();
// Same GSMTC query without reading/decoding album artwork.
std::optional<MediaState> QueryPlayback();
bool Execute(Action action);
}
