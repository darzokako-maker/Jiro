#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

struct ImDrawList;
namespace client::render { struct RoundedPanel; }
namespace client::ui { class FontManager; }

namespace client::features::spotify {
struct Settings {
 bool enabled=false;
 bool operator==(const Settings&)const=default;
};

enum class Action : unsigned { Previous=1, Toggle=2, Next=4 };

struct MediaState {
 bool available=false;
 bool playing=false;
 std::string title;
 std::string artist;
 std::string source;
 std::int64_t positionMs=0;
 std::int64_t durationMs=0;
 std::uint64_t artworkHash=0;
 std::vector<std::uint8_t> artwork;
};

Settings Options();
void SetOptions(Settings settings);
std::shared_ptr<const MediaState> Snapshot();
void Publish(MediaState state);
void Request(Action action);
unsigned TakeRequests();
void PollRuntime();
void Draw(const ui::FontManager& fonts,ImDrawList& foreground,float width,float height,std::vector<render::RoundedPanel>& panels);
}
