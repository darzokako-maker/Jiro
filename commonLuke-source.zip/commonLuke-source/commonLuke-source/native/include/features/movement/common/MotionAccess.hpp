#pragma once
#include "game/MappingRepository.hpp"
#include <stdexcept>
#include <string>

namespace client::features::motion {
namespace detail {
inline methods::Argument Double(double value){methods::Argument argument{methods::Type::Double};argument.value.d=value;return argument;}
inline methods::Result Invoke(JNIEnv* env,jobject entity,const char* key,const std::vector<methods::Argument>& arguments={}) {
 if(!env||!entity)throw std::runtime_error(std::string("missing motion receiver ")+key);
 auto result=mapping::Invoke(env,entity,key,arguments);
 if(!result.ok)throw std::runtime_error(std::string("motion call failed ")+key+": "+result.error);
 return result;
}
}

inline double Y(JNIEnv* env,jobject entity) {
 auto result=detail::Invoke(env,entity,"Entity.getMotionY");const auto value=result.value.d;result.Release(env);return value;
}

inline void Set(JNIEnv* env,jobject entity,double x,double y,double z) {
 auto result=detail::Invoke(env,entity,"Entity.setVelocity",{detail::Double(x),detail::Double(y),detail::Double(z)});result.Release(env);
}
}
