#pragma once

struct JNIEnv_;
using JNIEnv = JNIEnv_;

namespace client::features::clips {
void Poll(JNIEnv* env);
}
