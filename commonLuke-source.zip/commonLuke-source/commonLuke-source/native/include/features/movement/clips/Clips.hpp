#pragma once
#include "features/visual/esp/Esp.hpp"
#include <functional>
namespace client::features::clips {
enum class Kind {Up,Down,Look};
struct Settings {
 bool enabled=false,smart=true,effects=true,humanize=true,paperBypass=false;
 float distance=5;
 bool operator==(const Settings&) const=default;
};
const Settings& Options(Kind kind);
void SetOptions(Kind kind,Settings settings);
void RequestLook();
void Request(Kind kind);
void CancelRequest(Kind kind);
bool TakeRequest(Kind kind);
// Paper/Spigot increases its moved-too-quickly allowance with the number of
// movement packets received in one server tick. Returns zero when the required
// burst would exceed the protocol-safe 20-packet ceiling.
int PaperPacketCount(double distance);
struct Cell {bool loaded=false,hazard=false;std::optional<esp::Bounds> collision;};
struct Body {esp::Vec3 position;double halfWidth=.3,height=1.8;};
using Probe=std::function<Cell(int,int,int)>;
using Fits=std::function<bool(const esp::Bounds&)>;
esp::Bounds PlayerBox(const Body& body,esp::Vec3 feet);
std::optional<esp::Vec3> FindVertical(const Body& body,double range,int direction,const Probe& probe,const Fits& fits);
std::optional<esp::Vec3> FindLook(const Body& body,esp::Vec3 block,bool smart,const Probe& probe,const Fits& fits);
struct Visual {
 esp::Camera camera;
 std::optional<esp::Vec3> block,target;
 double surface=1;
 bool valid=false;
 std::uint64_t stamp=0;
};
void Publish(Visual visual);
const Visual& Current();
void RenderWorld(const Visual& visual,const Settings& settings,float time);
}
