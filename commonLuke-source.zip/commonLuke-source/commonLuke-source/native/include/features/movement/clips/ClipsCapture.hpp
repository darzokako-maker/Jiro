#pragma once
#include <jni.h>
namespace client::features::clips {
void Capture(JNIEnv* env,int width,int height);
void BeforeClear(JNIEnv* env,unsigned mask);
void Present();
jobject BeforeSend(JNIEnv* env,jobject packet);
}
