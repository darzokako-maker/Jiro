#pragma once
#include <jni.h>
namespace client::features::nojump {
struct Settings {
 bool enabled=false;
 bool operator==(const Settings&)const=default;
};
Settings Options();
void SetOptions(Settings settings);
void Poll(JNIEnv* env);
}
