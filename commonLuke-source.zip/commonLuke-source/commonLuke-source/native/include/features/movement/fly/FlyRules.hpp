#pragma once

#include <cmath>
#include <optional>

namespace client::features::fly::rules {

struct HorizontalMotion {
    double x = 0.0;
    double z = 0.0;
};

inline std::optional<HorizontalMotion> Horizontal(float yaw, float forward, float strafe,
                                                   double speed) {
    if (forward == 0.0f && strafe == 0.0f) return std::nullopt;

    constexpr double pi = 3.14159265358979323846;
    constexpr float floatPi = static_cast<float>(pi);
    float yawRad = static_cast<float>(static_cast<double>(yaw) * (pi / 180.0));
    if (forward < 0.0f) yawRad = static_cast<float>(static_cast<double>(yawRad) + pi);

    if (strafe > 0.0f) {
        const int divisor = forward == 0.0f ? 2 : (forward > 0.0f ? 4 : -4);
        yawRad -= floatPi / static_cast<float>(divisor);
    } else if (strafe < 0.0f) {
        const int divisor = forward == 0.0f ? 2 : (forward > 0.0f ? 4 : -4);
        yawRad += floatPi / static_cast<float>(divisor);
    }

    return HorizontalMotion{
        -std::sin(static_cast<double>(yawRad)) * speed,
        std::cos(static_cast<double>(yawRad)) * speed,
    };
}

inline double Smooth(double current, double target) {
    constexpr double previousWeight = 0.8;
    return current * previousWeight + target * (1.0 - previousWeight);
}

inline double Friction(double current) {
    return current * 0.8;
}

inline double GlideVertical(double verticalSpeed, bool jumpDown, bool sneakDown,
                            bool screenOpen, double jumpJitter, double sneakJitter,
                            bool disableY = false) {
    double motionY = 0.0;
    if (!screenOpen) {
        if (jumpDown && !disableY) motionY += verticalSpeed * jumpJitter;
        if (sneakDown && !disableY) motionY -= verticalSpeed * sneakJitter;
    }
    if (!disableY && (screenOpen || (!jumpDown && !sneakDown))) motionY -= 0.04;
    return motionY;
}

inline std::optional<double> AacInitialMotion(bool onGround) {
    if (!onGround) return std::nullopt;
    return 0.42;
}

inline bool AacRecovery(double motionY) {
    return motionY < -0.30;
}

inline std::optional<double> AacNextMotion(bool onGround, double motionY) {
    if (onGround || AacRecovery(motionY)) return 0.42;
    return std::nullopt;
}

} // namespace client::features::fly::rules
