#pragma once

#include <jni.h>

#include <algorithm>
#include <cmath>

namespace client::features::fly {

enum class Mode {
    Aac,
    Glide,
};

struct Settings {
    bool enabled = false;
    Mode mode = Mode::Aac;
    float speed = 0.24f;
    float verticalSpeed = 0.22f;
    bool disableY = false;
    bool operator==(const Settings&) const = default;
};

inline Settings Normalize(Settings settings) {
    if (!std::isfinite(settings.speed)) settings.speed = 0.24f;
    if (!std::isfinite(settings.verticalSpeed)) settings.verticalSpeed = 0.22f;
    settings.speed = std::clamp(settings.speed, 0.05f, 3.0f);
    settings.verticalSpeed = std::clamp(settings.verticalSpeed, 0.05f, 2.0f);
    return settings;
}

Settings Options();
void SetOptions(Settings settings);
void AfterInput(JNIEnv* env, jobject minecraft, jobject player);
void Stop(jobject player);

} // namespace client::features::fly
