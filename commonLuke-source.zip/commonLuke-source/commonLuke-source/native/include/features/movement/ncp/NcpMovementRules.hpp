#pragma once
#include "features/movement/ncp/NcpMovement.hpp"
#include <algorithm>
#include <cmath>
#include <array>
namespace client::features::movement::rules {
inline bool InputHookRequired(bool speed,bool longJump,bool extras,bool scaffold,bool fly){
 return speed||longJump||extras||scaffold||fly;
}
inline std::array<double,2> Horizontal(double speed,float yaw,float forward,float strafe){
 const double length=std::max(1.,std::hypot(static_cast<double>(forward),static_cast<double>(strafe)));
 const double radians=static_cast<double>(yaw)*3.14159265358979323846/180.;
 return {(strafe*std::cos(radians)-forward*std::sin(radians))*speed/length,(forward*std::cos(radians)+strafe*std::sin(radians))*speed/length};
}
struct State {double speed=0;bool reset=false;};
struct Input {bool moving=false,collided=false;int offGround=0,sinceVelocity=100000,jumpAmplifier=-1;double base=.221,motionY=0;float fallDistance=0,forward=0,strafe=0;};
struct Output {double motionY;float friction;};
inline double Base(bool web,bool liquid,bool sneak,bool sprint,int speedAmplifier,int speedDuration,bool slowdown,int depth){
 double base;bool modifiers=false;
 if(web)base=.105;
 else if(liquid){constexpr double swim=static_cast<double>(.115f)/.221;constexpr double levels[]={1,static_cast<double>(.1645f)/swim/.221,static_cast<double>(.1995f)/swim/.221,1/swim};base=swim*.221;if(depth>0){base*=levels[std::clamp(depth,0,3)];modifiers=true;}}
 else if(sneak)base=static_cast<double>(.3f)*.221;
 else {base=.221;modifiers=true;}
 if(modifiers){if(sprint)base*=static_cast<double>(1.3f);if(speedAmplifier>=0&&speedDuration>0)base*=1+.2*(speedAmplifier+1);if(slowdown)base=.29;}
 return base;
}
inline Output Step(Kind kind,const Settings& s,State& state,const Input& in){
 double y=in.motionY;
 if(kind==Kind::Speed){
  if(s.lowHop&&in.offGround==4)y=-.09800000190734864;
  if(s.yPort&&in.offGround==5&&std::abs(y-.09800000190734864)<.12)y=-.09800000190734864;
  if(s.customBoost&&in.sinceVelocity<=static_cast<int>(s.hurtTime))state.speed=s.boostSpeed;
 }
 if(in.moving){
  if(in.offGround==0){float jump=kind==Kind::LongJump?.42f:(in.collided?.42f:s.jumpMotion==.4f?s.jumpMotion:.42f);y=static_cast<double>(jump)+(in.jumpAmplifier>=0?static_cast<double>((in.jumpAmplifier+1)*.1f):0);state.speed=kind==Kind::Speed?in.base*s.groundSpeed:s.groundSpeed;}
  else if(in.offGround==1){if(kind==Kind::Speed)state.speed-=s.bunnySlope*(state.speed-in.base);else state.speed=s.jumpSpeed;}
  else state.speed-=state.speed/static_cast<double>(159.9f);
  state.reset=false;
 }else if(!state.reset){state.speed=in.base;state.reset=true;}
 if(kind==Kind::LongJump&&in.fallDistance>0)y+=s.glide/100.f;
 if(in.collided)state.speed=in.base;
 const double speed=std::max(state.speed,in.base);
 return {y,static_cast<float>(in.forward!=0&&in.strafe!=0?speed*.98f:speed)};
}
}
