#pragma once
#include <jni.h>
#include <cstdint>
namespace client::features::movement {
enum class Kind {Speed,LongJump};
struct Settings {
 bool enabled=false;
 float jumpMotion=.4f,groundSpeed=1.75f,bunnySlope=.66f;
 bool damageBoost=true,customBoost=false,lowHop=false,yPort=false;
 float boostSpeed=.8f,hurtTime=6;
 float bunnyFriction=159,jumpSpeed=1.4f,glide=0;
 bool autoDisable=true,fakeDamage=false,disableOnTeleport=false,stopOnDisable=false;
 bool operator==(const Settings&)const=default;
};
Settings Defaults(Kind kind);
Settings Options(Kind kind);
void SetOptions(Kind kind,Settings settings);
void Poll(JNIEnv* env);
void Stop(JNIEnv* env);
bool BeforeReceive(JNIEnv* env,jobject packet);
}
