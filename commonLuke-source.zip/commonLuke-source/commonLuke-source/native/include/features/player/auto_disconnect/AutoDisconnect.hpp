#pragma once
#include <jni.h>
#include <cmath>
#include <array>
#include "client/NativePacketEngine.hpp"
namespace client::features::disconnect {
struct Settings {bool enabled=false,lowHealth=true,countAbsorption=true;float health=6;bool operator==(const Settings&)const=default;};
Settings Options();void SetOptions(Settings settings);void Poll(JNIEnv* env);void Stop(JNIEnv* env);bool BeforeReceive(JNIEnv* env,jobject packet);
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet);
inline bool Below(const Settings& s,float health,float absorption){return std::isfinite(health)&&(!s.countAbsorption||std::isfinite(absorption))&&health+(s.countAbsorption?absorption:0)<=s.health;}
inline constexpr std::array<jchar,6> IllegalMessage{1,0x00a7,'k',0x00a7,'r',7};
}
