#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <numbers>
#include <optional>
#include <type_traits>
#include <unordered_map>

namespace client::features::scaffold {

enum class Mode { Normal, Telly };
enum class SameY { Off, On, AutoJump };

struct TellyPhase {
    bool rightClick;
    bool aimAtBlock;
    bool allowPlacement;
};

constexpr TellyPhase TellyAt(int offGroundTicks, SameY sameY) {
    return {offGroundTicks == 0 || offGroundTicks == 2,
            offGroundTicks >= 3 && offGroundTicks <= (sameY == SameY::Off ? 7 : 10),
            offGroundTicks > 3};
}

constexpr bool AutoJump(Mode mode, SameY sameY, bool grounded, bool moving,
                        double y, double startY) {
    return grounded && moving &&
        (mode == Mode::Telly || (sameY == SameY::AutoJump && y == startY));
}

template<class Eligible>
int FindHotbarSlot(int count, int cachedSlot, Eligible&& eligible) {
    count = std::max(count, 0);
    if (cachedSlot >= 0 && cachedSlot < count && eligible(cachedSlot)) return cachedSlot;
    for (int slot = 0; slot < count; ++slot) {
        if (slot != cachedSlot && eligible(slot)) return slot;
    }
    return -1;
}

struct Vec3 {
    double x, y, z;

    Vec3 operator+(Vec3 other) const {
        return {x + other.x, y + other.y, z + other.z};
    }
};

struct BlockPos {
    int x, y, z;
    bool operator==(const BlockPos&) const = default;
};

struct BlockPosHash {
    std::size_t operator()(BlockPos pos) const noexcept {
        std::size_t hash = static_cast<std::uint32_t>(pos.x) * 0x9E3779B1u;
        hash ^= static_cast<std::uint32_t>(pos.y) + 0x9E3779B9u + (hash << 6) + (hash >> 2);
        hash ^= static_cast<std::uint32_t>(pos.z) + 0x85EBCA77u + (hash << 6) + (hash >> 2);
        return hash;
    }
};

template<class Lookup>
class ReplaceableCache {
public:
    explicit ReplaceableCache(Lookup& lookup) : lookup_(&lookup) {
        values_.reserve(805);
    }

    std::optional<bool> operator()(BlockPos pos) {
        if (const auto found = values_.find(pos); found != values_.end()) return found->second;
        const auto value = (*lookup_)(pos);
        values_.emplace(pos, value);
        return value;
    }

private:
    Lookup* lookup_;
    std::unordered_map<BlockPos, std::optional<bool>, BlockPosHash> values_;
};

template<class T>
struct IsReplaceableCache : std::false_type {};

template<class Lookup>
struct IsReplaceableCache<ReplaceableCache<Lookup>> : std::true_type {};

inline BlockPos Floor(Vec3 point) {
    return {static_cast<int>(std::floor(point.x)),
            static_cast<int>(std::floor(point.y)),
            static_cast<int>(std::floor(point.z))};
}

enum class Face { Down, Up, North, South, West, East };

struct Support {
    Face face;
    Vec3 offset;
};

// The callback returns nullopt when the world lookup fails.
template<class Replaceable>
std::optional<Vec3> FindTarget(Vec3 player, Vec3 offset, std::optional<int> plane,
                               Replaceable&& replaceable) {
    constexpr std::array<Vec3, 6> neighbors{{
        {-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}
    }};
    const int range = static_cast<int>(5 + (std::abs(offset.x) + std::abs(offset.z)));
    const Vec3 desired = player + Vec3{offset.x, -1 + offset.y, offset.z};
    struct Candidate {
        Vec3 delta;
        float distance;
    };
    std::array<Candidate, 515> candidates{}; // Integer lattice points inside a radius-five sphere.
    std::size_t candidateCount = 0;
    for (int x = -5; x <= 5; ++x) {
        for (int y = -5; y <= 5; ++y) {
            for (int z = -5; z <= 5; ++z) {
                if (x * x + y * y + z * z > 25) continue;
                const Vec3 delta{static_cast<double>(x), static_cast<double>(y), static_cast<double>(z)};
                const auto candidate = player + delta;
                const double tx = desired.x - candidate.x;
                const double ty = desired.y - candidate.y;
                const double tz = desired.z - candidate.z;
                candidates[candidateCount++] = {delta,
                    static_cast<float>(std::sqrt(tx * tx + ty * ty + tz * tz))};
            }
        }
    }
    std::sort(candidates.begin(), candidates.begin() + candidateCount,
              [](const Candidate& left, const Candidate& right) {
                  return left.distance < right.distance;
              });

    const int side = range * 2 + 1;
    const auto search = [&](auto& lookup) -> std::optional<Vec3> {
        for (std::size_t begin = 0; begin < candidateCount;) {
            std::size_t end = begin + 1;
            while (end < candidateCount && candidates[end].distance == candidates[begin].distance) ++end;

            std::optional<Vec3> target;
            std::size_t bestDiscovery = std::numeric_limits<std::size_t>::max();
            for (std::size_t index = begin; index < end; ++index) {
                const auto& delta = candidates[index].delta;
                const auto candidate = player + delta;
                if (plane && std::floor(candidate.y + 1) != *plane) continue;

                const auto candidateEmpty = lookup(Floor(candidate));
                if (!candidateEmpty) return std::nullopt;
                if (!*candidateEmpty) continue;

                for (std::size_t neighborIndex = 0; neighborIndex < neighbors.size(); ++neighborIndex) {
                    const auto neighbor = neighbors[neighborIndex];
                    const int x = static_cast<int>(delta.x - neighbor.x);
                    const int y = static_cast<int>(delta.y - neighbor.y);
                    const int z = static_cast<int>(delta.z - neighbor.z);
                    if (x < -range || x > range || y < -range || y > range ||
                        z < -range || z > range) continue;

                    const auto supportEmpty = lookup(Floor(player + Vec3{
                        static_cast<double>(x), static_cast<double>(y), static_cast<double>(z)}));
                    if (!supportEmpty) return std::nullopt;
                    if (*supportEmpty) continue;

                    const auto blockRank = static_cast<std::size_t>(x + range) * side * side
                        + static_cast<std::size_t>(y + range) * side
                        + static_cast<std::size_t>(z + range);
                    const auto discovery = blockRank * neighbors.size() + neighborIndex;
                    if (discovery < bestDiscovery) {
                        bestDiscovery = discovery;
                        target = candidate;
                    }
                }
            }
            if (target) return target;
            begin = end;
        }
        return std::nullopt;
    };

    using Lookup = std::remove_reference_t<Replaceable>;
    if constexpr (IsReplaceableCache<std::remove_cv_t<Lookup>>::value) {
        return search(replaceable);
    } else {
        ReplaceableCache<Lookup> lookup(replaceable);
        return search(lookup);
    }
}

template<class Replaceable>
std::optional<Support> FindSupport(Vec3 target, float yaw, bool downwards,
                                   Replaceable&& replaceable) {
    constexpr std::array<Support, 4> horizontal{{
        {Face::South, {0, 0, -1}}, {Face::North, {0, 0, 1}},
        {Face::East, {-1, 0, 0}}, {Face::West, {1, 0, 0}}
    }};
    const double rotation = std::fmod(yaw, 360.0f) + 90.0f;
    std::optional<Support> support;
    double best = std::numeric_limits<double>::infinity();
    for (const auto side : horizontal) {
        const auto empty = replaceable(Floor(target + side.offset));
        if (!empty) return std::nullopt;
        if (*empty) continue;

        const double angle = std::atan2(side.offset.z, side.offset.x)
            * (180.0 / std::numbers::pi);
        // Keep Harakiri's wrappedDifference formula, including its signed terms.
        const auto distance = std::abs(std::min({
            std::abs(angle - rotation),
            std::abs(angle - 360) - std::abs(rotation),
            std::abs(rotation - 360) - std::abs(angle)
        }));
        if (distance < best) {
            support = side;
            best = distance;
        }
    }
    if (support) return support;

    constexpr Support below{Face::Up, {0, -1, 0}};
    constexpr Support above{Face::Down, {0, 1, 0}};
    const auto belowEmpty = replaceable(Floor(target + below.offset));
    if (!belowEmpty) return std::nullopt;
    if (!*belowEmpty) return below;
    if (downwards) {
        const auto aboveEmpty = replaceable(Floor(target + above.offset));
        if (aboveEmpty && !*aboveEmpty) return above;
    }
    return std::nullopt;
}

inline Vec3 RandomHit(BlockPos block, Face face, Vec3 random) {
    Vec3 hit{block.x + random.x, block.y + random.y, block.z + random.z};
    switch (face) {
    case Face::Down:  hit.y = block.y; break;
    case Face::Up:    hit.y = block.y + 1; break;
    case Face::North: hit.z = block.z; break;
    case Face::South: hit.z = block.z + 1; break;
    case Face::West:  hit.x = block.x; break;
    case Face::East:  hit.x = block.x + 1; break;
    }
    return hit;
}

}
