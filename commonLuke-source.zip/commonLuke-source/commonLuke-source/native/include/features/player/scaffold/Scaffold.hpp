#pragma once

#include "features/player/scaffold/ScaffoldPlacement.hpp"
#include "client/NativePacketEngine.hpp"

namespace client::features::scaffold {

struct Settings {
    bool enabled = false;
    RayCast rayCast = RayCast::Strict;
    SameY sameY = SameY::Off;
    float rotationMin = 5, rotationMax = 10;
    float delayMin = 0, delayMax = 0;
    float expand = 0;
    bool safeWalk = true;
    bool movementCorrection = false;
    Mode mode = Mode::Normal;
    bool operator==(const Settings&) const = default;
};

Settings Options();
void SetOptions(Settings settings);
void AfterInput(JNIEnv* env, jobject minecraft, jobject player, jobject world, jobject input);
void Reset(JNIEnv* env = nullptr);
void ApplyInput(JNIEnv* env, jobject input);
jobject BeforeSend(JNIEnv* env, jobject packet);
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet);

}
