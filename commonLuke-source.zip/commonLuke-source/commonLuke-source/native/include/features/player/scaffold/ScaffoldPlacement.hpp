#pragma once

#include "features/player/scaffold/ScaffoldRules.hpp"
#include <jni.h>

namespace client::features::scaffold {

struct Placement {
    Vec3 target;
    BlockPos support;
    Face face;
};

enum class RayCast { Off, Normal, Strict };

std::optional<bool> IsReplaceable(JNIEnv* env, jobject world, BlockPos pos);
jobject JavaFace(JNIEnv* env, Face face);

// Called on the game thread with the position and rotations for the current tick.
std::optional<Placement> FindPlacement(JNIEnv* env, jobject world, Vec3 player,
                                      Vec3 offset, std::optional<int> plane, float yaw);

// The caller owns the timing and ray-cast gate. For Normal and Off, rayHit is
// present only when the trace hit this placement's support block and face.
bool Place(JNIEnv* env, jobject minecraft, jobject player, jobject stack,
           const Placement& placement, RayCast rayCast, std::optional<Vec3> rayHit,
           Vec3 randomHit);

}
