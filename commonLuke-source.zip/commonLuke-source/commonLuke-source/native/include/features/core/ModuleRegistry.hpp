#pragma once
#include <array>
namespace client::features::modules {
enum Id {
 Hud=0,
 Esp=1,
 DragonWings=2,
 UpClip=3,
 DownClip=4,
 LookClip=5,
 KillAura=6,
 Velocity=7,
 NoRotate=8,
 Speed=9,
 LongJump=10,
 AutoDisconnect=11,
 NoWeb=12,
 TargetStrafe=13,
 AutoTool=14,
 FastUse=15,
 Spammer=16,
 AimBacktrack=17,
 AutoClicker=18,
 Aimbot=19,
 Eagle=20,
 Breaker=21,
 InventoryMove=22,
 NoJumpCooldown=23,
 SpotifyWidget=24,
 TargetHud=25,
 Cosmetics=26,
 SeedDumper=27,
 ItemEsp=28,
 FreeCam=29,
 AutoHarm=30,
 Ambiance=31,
 Scaffold=32,
 Mcf=33,
 Fly=34,
 InventoryHud=35,
 NoFall=36,
 FastPlace=37,
 AimAssist=38,
 FakeLag=39,
 PacketLogger=40,
 Xray=41,
 AutoMiner=42,
 Count=43
};
struct Info {
 Id id;
 const char* name;
 const char* description;
 const char* firstLine;
 const char* secondLine;
 int category=4;
};
inline constexpr std::array<Info,Count> Catalog{{
 {Hud,"HUD","Shows the logo and your location","Shows the logo","and your location"},
 {Esp,"ESP","Outlines players and creatures","Outlines players","and creatures"},
 {DragonWings,"DragonWings","Adds moving wings to your character","Adds moving wings","to your character"},
 {UpClip,"UpClip","Moves you to a safe spot above","Moves you to a","safe spot above",2},
 {DownClip,"DownClip","Moves you to a safe spot below","Moves you to a","safe spot below",2},
 {LookClip,"LookClip","Moves you where you are looking","Moves you where","you are looking",2},
 {KillAura,"KillAura","Attacks nearby targets for you","Attacks nearby","targets for you",1},
 {Velocity,"Velocity","Changes how far hits push you","Changes how far","hits push you",1},
 {NoRotate,"NoRotate","Stops the server from turning your view","Stops the server","from turning your view",5},
 {Speed,"Speed","Lets you move faster","Lets you move","faster",2},
 {LongJump,"LongJump","Lets you jump farther","Lets you jump","farther",2},
 {AutoDisconnect,"AutoDisconnect","Leaves when your health gets low","Leaves when your","health gets low",3},
 {NoWeb,"NoWeb","Keeps cobwebs from slowing you down","Keeps cobwebs from","slowing you down",2},
 {TargetStrafe,"TargetStrafe","Moves you around your target","Moves you around","your target",2},
 {AutoTool,"AutoTool","Picks the right tool for the block","Picks the right tool","for the block",3},
 {FastUse,"FastUse","Lets you use items more quickly","Lets you use items","more quickly",3},
 {Spammer,"Spammer","Repeats a message in chat","Repeats a message","in chat",3},
 {AimBacktrack,"Backtrack","Delays one attacked target while it moves away","Delays one target","while it moves away",6},
 {AutoClicker,"AutoClicker","Repeats clicks while you hold the button","Repeats clicks while","you hold the button",6},
 {Aimbot,"Aimbot","Turns your view toward a target","Turns your view","toward a target",6},
 {Eagle,"Eagle","Crouches for you near block edges","Crouches for you","near block edges",6},
 {Breaker,"Breaker","Breaks nearby beds for you","Breaks nearby beds","for you",3},
 {InventoryMove,"InventoryMove","Lets you walk with your inventory open","Lets you walk with","your inventory open",2},
 {NoJumpCooldown,"NoJumpCooldown","Lets you jump again without waiting","Lets you jump again","without waiting",2},
 {SpotifyWidget,"SpotifyWidget","Shows and controls your Spotify music","Shows and controls","your Spotify music",4},
 {TargetHud,"TargetHUD","Shows who you aim at and their health","Shows who you aim at","and their health",4},
 {Cosmetics,"Cosmetics","Changes the skin or cape you see","Changes the skin or","cape you see",4},
 {SeedDumper,"SeedDumper","Saves nearby terrain to study it later","Saves nearby terrain","to study it later",3},
 {ItemEsp,"ItemESP","Outlines items on the ground","Outlines items","on the ground",4},
 {FreeCam,"FreeCam","Moves the camera without moving you","Moves the camera","without moving you",4},
 {AutoHarm,"AutoHarm","Throws damage potions at your target","Throws damage potions","at your target",1},
 {Ambiance,"Ambiance","Shows lyrics in time with your music","Shows lyrics in time","with your music",4},
 {Scaffold,"Scaffold","Places blocks as you build a bridge","Places blocks as","you build a bridge",3},
 {Mcf,"MCF","Middle-click a player to mark as a friend","Middle-click a player","to mark as a friend",3},
 {Fly,"Fly","Lets you fly through the air","Lets you fly","through the air",2},
 {InventoryHud,"InventoryHUD","Shows your items on the screen","Shows your items","on the screen",4},
 {NoFall,"NoFall","Clutches falls with MLG items or packet spoofing","Clutches falls with","MLG items or spoofing",3},
 {FastPlace,"FastPlace","Lets you place blocks more quickly","Lets you place","blocks more quickly",6},
 {AimAssist,"AimAssist","Smoothly tracks valid combat targets","Smoothly tracks valid","combat targets",1},
 {FakeLag,"FakeLag","Simulates network latency","Simulates network","latency",5},
 {PacketLogger,"Packet Logger","Writes incoming packet names to chat","Writes packet names","to chat",5},
 {Xray,"Xray","Highlights nearby ores through terrain","Highlights nearby","ores through terrain",4},
 {AutoMiner,"AutoMiner","Mines nearby ores for you","Mines nearby","ores for you",3}
}};
constexpr bool Available(Id id) {
 switch(id) {
  case KillAura:
  case Speed:
  case LongJump:
  case Fly:
  case TargetStrafe:
  case AutoHarm:
  case Breaker:
   return false;
  default:return id>=0&&id<Count;
 }
}
bool Enabled(Id id);
void SetEnabled(Id id,bool enabled);
void Toggle(Id id);
void StateChanged(Id id,bool previous,bool enabled);
}
