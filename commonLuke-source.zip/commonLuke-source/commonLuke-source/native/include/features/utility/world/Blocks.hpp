#pragma once

#include <cstdint>

// Numeric block table helpers shared by ore scanning and navigation. Only the
// "can something stand / walk here" question is answered, so the tables cover
// the non-colliding vanilla 1.8 ids and treat everything else as solid.
namespace client::features::blocks {

inline bool Passable(std::uint16_t id) noexcept {
    switch (id) {
        case 0:                               // air
        case 6:                               // sapling
        case 8: case 9:                       // water
        case 27: case 28: case 66: case 157:  // rails
        case 31: case 32:                     // tall grass, dead bush
        case 37: case 38:                     // flowers
        case 39: case 40:                     // mushrooms
        case 50: case 75: case 76:            // torches
        case 55:                              // redstone wire
        case 59:                              // wheat
        case 63: case 68:                     // signs
        case 65: case 106:                    // ladder, vine (climbable, no support)
        case 69: case 77: case 143:           // lever, buttons
        case 70: case 72: case 147: case 148: // pressure plates
        case 78:                              // snow layer
        case 83:                              // reeds
        case 90: case 119:                    // portals
        case 93: case 94:                     // repeaters
        case 104: case 105:                   // stems
        case 111:                             // lily pad
        case 115:                             // nether wart
        case 127:                             // cocoa
        case 131: case 132:                   // tripwire
        case 141: case 142:                   // crops
        case 151:                             // daylight detector
        case 171:                             // carpet
        case 175:                             // tall plants
        case 176: case 177:                   // banners
        case 178:                             // inverted daylight detector
            return true;
        default:
            return false;
    }
}

inline bool Liquid(std::uint16_t id) noexcept {
    return id == 8 || id == 9 || id == 10 || id == 11;
}

// Lava, fire and cactus. Navigation never steps into these.
inline bool Hazard(std::uint16_t id) noexcept {
    return id == 10 || id == 11 || id == 51 || id == 81;
}

} // namespace client::features::blocks
