#pragma once

#include "features/utility/world/Blocks.hpp"

#include <jni.h>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace client::features::blocks {

enum class BuildStatus : std::uint8_t {
    Ok = 0,
    NoWorld,
    UnsupportedProvider,
    NoChunks,
    Failed
};

// Dense voxel snapshot of the loaded chunk sections around a point. Ore
// filtering and navigation both use it so the chunk walk happens once per
// interval instead of once per query.
struct Grid {
    int ox = 0, oy = 0, oz = 0;
    int sx = 0, sy = 0, sz = 0;
    std::vector<std::uint16_t> ids;
    std::vector<std::uint8_t> known;

    bool Empty() const noexcept { return ids.empty(); }

    bool Contains(int x, int y, int z) const noexcept {
        return x >= ox && y >= oy && z >= oz && x < ox + sx && y < oy + sy && z < oz + sz;
    }

    std::size_t Index(int x, int y, int z) const noexcept {
        return (static_cast<std::size_t>(y - oy) * sz + (z - oz)) * sx + (x - ox);
    }

    // Unseen cells read as stone so neither feature ever plans through terrain
    // it has not loaded.
    std::uint16_t Id(int x, int y, int z) const noexcept {
        if (!Contains(x, y, z)) return 1;
        const auto index = Index(x, y, z);
        return known[index] ? ids[index] : 1;
    }

    bool Seen(int x, int y, int z) const noexcept {
        if (!Contains(x, y, z)) return false;
        return known[Index(x, y, z)] != 0;
    }
};

// Reads every chunk section that overlaps the requested box. `horizontalRadius`
// and `verticalRadius` are clamped internally (40 / 24) to bound the copy cost.
BuildStatus Build(JNIEnv* env, jobject world, int centerX, int centerY, int centerZ,
                  int horizontalRadius, int verticalRadius, Grid& out);

} // namespace client::features::blocks
