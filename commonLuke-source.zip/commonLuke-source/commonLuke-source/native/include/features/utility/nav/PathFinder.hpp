#pragma once

#include "features/utility/world/BlockGrid.hpp"

#include <cstdint>
#include <vector>

namespace client::features::nav {

struct Node {
    int x = 0, y = 0, z = 0;
    bool operator==(const Node&) const = default;
};

// Cell:   the path must end exactly on the target cell.
// Adjacent: the path may end on any standable cell touching the target
//           (used for ores, which are solid blocks embedded in stone).
enum class Goal : std::uint8_t { Cell, Adjacent };

struct Options {
    int maxNodes = 9000;
    int maxFall = 3;
    int maxJump = 1;
    bool avoidHazards = true;
};

struct Path {
    // True when a goal cell was reached. When false but `steps` is not empty a
    // partial path toward the closest reachable cell is still returned, which
    // lets the miner keep making progress instead of standing still.
    bool found = false;
    int expanded = 0;
    std::vector<Node> steps; // start excluded; last element is the reached cell
};

// Feet cell is air, head cell is air and the block below is solid, non-liquid
// and non-hazardous.
bool Standable(const blocks::Grid& grid, int x, int y, int z);

// Nearest standable cell to a raw player position. Returns the input when it is
// already standable and nothing better exists.
Node Snap(const blocks::Grid& grid, int x, int y, int z);

// A* over the dense snapshot. Horizontal 4-neighbour movement, one block step
// up and up to `maxFall` blocks down. Cells that were never loaded are treated
// as stone by the grid, so the planner never walks through unseen terrain.
Path Find(const blocks::Grid& grid, Node start, Node target, Goal goal,
          const Options& options = {});

} // namespace client::features::nav
