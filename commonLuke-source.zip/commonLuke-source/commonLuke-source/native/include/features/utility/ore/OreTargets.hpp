#pragma once

#include <cstdint>
#include <optional>
#include <imgui.h>

namespace client::features::ore {

// Ore families this client can classify. Block ids come from the 1.8.x
// numeric block table; SonOyuncu adds a second copper id (635) and a
// titanium ore at 807 that are not part of the vanilla table.
enum class Kind : std::uint8_t {
    Diamond = 0,
    Emerald,
    Gold,
    Iron,
    Coal,
    Lapis,
    Redstone,
    Quartz,
    Copper,
    Titanium,
    Count
};

struct Toggles {
    bool diamond = true, emerald = true, gold = true, iron = true, coal = true;
    bool lapis = true, redstone = true, quartz = true, copper = true, titanium = true;
    bool operator==(const Toggles&) const = default;
};

constexpr int BlockId(Kind kind) noexcept {
    switch (kind) {
        case Kind::Diamond:  return 56;
        case Kind::Emerald:  return 129;
        case Kind::Gold:     return 14;
        case Kind::Iron:     return 15;
        case Kind::Coal:     return 16;
        case Kind::Lapis:    return 21;
        case Kind::Redstone: return 73;
        case Kind::Quartz:   return 153;
        case Kind::Copper:   return 715;
        case Kind::Titanium: return 807;
        default:             return 0;
    }
}

inline std::optional<Kind> FromBlockId(int id) noexcept {
    switch (id) {
        case 56:  return Kind::Diamond;
        case 129: return Kind::Emerald;
        case 14:  return Kind::Gold;
        case 15:  return Kind::Iron;
        case 16:  return Kind::Coal;
        case 21:  return Kind::Lapis;
        case 73:  // Redstone ore
        case 74:  return Kind::Redstone; // Lit redstone ore
        case 153: return Kind::Quartz;
        case 635: // SonOyuncu copper variant
        case 715: return Kind::Copper;
        case 807: return Kind::Titanium;
        default:  return std::nullopt;
    }
}

inline bool IsOre(int id) noexcept { return FromBlockId(id).has_value(); }

inline bool Enabled(const Toggles& toggles, Kind kind) noexcept {
    switch (kind) {
        case Kind::Diamond:  return toggles.diamond;
        case Kind::Emerald:  return toggles.emerald;
        case Kind::Gold:     return toggles.gold;
        case Kind::Iron:     return toggles.iron;
        case Kind::Coal:     return toggles.coal;
        case Kind::Lapis:    return toggles.lapis;
        case Kind::Redstone: return toggles.redstone;
        case Kind::Quartz:   return toggles.quartz;
        case Kind::Copper:   return toggles.copper;
        case Kind::Titanium: return toggles.titanium;
        default:             return false;
    }
}

inline const char* Name(Kind kind) noexcept {
    switch (kind) {
        case Kind::Diamond:  return "Diamond";
        case Kind::Emerald:  return "Emerald";
        case Kind::Gold:     return "Gold";
        case Kind::Iron:     return "Iron";
        case Kind::Coal:     return "Coal";
        case Kind::Lapis:    return "Lapis";
        case Kind::Redstone: return "Redstone";
        case Kind::Quartz:   return "Quartz";
        case Kind::Copper:   return "Copper";
        case Kind::Titanium: return "Titanium";
        default:             return "Ore";
    }
}

inline ImU32 Color(Kind kind) noexcept {
    switch (kind) {
        case Kind::Diamond:  return IM_COL32(95, 235, 255, 255);
        case Kind::Emerald:  return IM_COL32(70, 245, 140, 255);
        case Kind::Gold:     return IM_COL32(255, 215, 70, 255);
        case Kind::Iron:     return IM_COL32(216, 178, 150, 255);
        case Kind::Coal:     return IM_COL32(130, 130, 136, 255);
        case Kind::Lapis:    return IM_COL32(70, 120, 235, 255);
        case Kind::Redstone: return IM_COL32(255, 70, 70, 255);
        case Kind::Quartz:   return IM_COL32(238, 230, 218, 255);
        case Kind::Copper:   return IM_COL32(230, 145, 85, 255);
        case Kind::Titanium: return IM_COL32(196, 220, 240, 255);
        default:             return IM_COL32_WHITE;
    }
}

} // namespace client::features::ore
