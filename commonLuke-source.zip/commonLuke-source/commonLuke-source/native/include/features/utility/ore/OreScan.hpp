#pragma once

#include "features/utility/ore/OreTargets.hpp"
#include "features/utility/world/BlockGrid.hpp"

#include <jni.h>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace client::features::ore {

struct Block {
    int x = 0, y = 0, z = 0;
    int id = 0;
    Kind kind = Kind::Diamond;
    float distance = 0.f;
};

enum class ScanStatus : std::uint8_t {
    Ok = 0,
    NoWorld,
    UnsupportedProvider,
    NoChunks,
    Failed
};

struct Result {
    ScanStatus status = ScanStatus::NoWorld;
    // Whitelisted ore blocks seen in the loaded grid before the anti-xray
    // filter ran. Useful to see how much of the map is fake ore.
    std::size_t raw = 0;
    std::vector<Block> blocks;
};

// Copies the loaded chunk sections around (x,y,z) into a dense voxel grid once,
// then classifies every cell. `filter` throws away the ore-shaped noise that
// anti-xray servers inject; `limit` caps the distance-sorted result.
Result Scan(JNIEnv* env, jobject world, double x, double y, double z,
            double radius, const Toggles& toggles, const Filter& filter,
            std::size_t limit = 4096);

} // namespace client::features::ore
