#pragma once

#include "features/utility/ore/OreTargets.hpp"

#include <jni.h>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace client::features::ore {

struct Block {
    int x = 0, y = 0, z = 0;
    int id = 0;
    Kind kind = Kind::Diamond;
    float distance = 0.f;
};

enum class ScanStatus : std::uint8_t {
    Ok = 0,
    NoWorld,
    UnsupportedProvider,
    NoChunks,
    Failed
};

struct Result {
    ScanStatus status = ScanStatus::NoWorld;
    std::vector<Block> blocks;
};

// Walks the loaded chunk sections of the client chunk provider and returns the
// whitelisted ore blocks inside a sphere. The result is sorted by distance and
// trimmed to `limit`. Sections are read through the same array layout the seed
// dumper uses: state = block_id << 4 | metadata, index = y * 256 + z * 16 + x.
Result Scan(JNIEnv* env, jobject world, double x, double y, double z,
            double radius, const Toggles& toggles, std::size_t limit = 4096);

} // namespace client::features::ore
