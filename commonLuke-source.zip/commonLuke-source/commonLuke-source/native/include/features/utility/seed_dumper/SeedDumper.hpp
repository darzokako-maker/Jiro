#pragma once
#include <jni.h>
#include <cstdint>
#include <string>
namespace client::features::seeddumper {
struct Settings {bool enabled=false;bool operator==(const Settings&)const=default;};
struct Status {std::string message="Disabled",directory;std::uint32_t saved=0;};
Settings Options();
void SetOptions(Settings settings);
Status CurrentStatus();
void Publish(Status status);
void Capture(JNIEnv* env);
}
