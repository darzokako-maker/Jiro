#pragma once
#include <array>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <vector>

namespace client::features::seeddumper {
inline constexpr std::int32_t UnknownDimension=(-2147483647-1);
struct Snapshot {
 std::int32_t x=0,z=0,dimension=UnknownDimension;
 std::uint64_t capturedMs=0;
 std::uint16_t sections=0;
 std::array<std::uint8_t,256> biomes{};
 // (y << 8) | (z << 4) | x; storage state = (block ID << 4) | metadata.
 std::array<std::uint16_t,65536> states{};
 bool operator==(const Snapshot&)const=default;
};
std::vector<std::uint8_t> Encode(const Snapshot& snapshot);
bool Decode(std::span<const std::uint8_t> bytes,Snapshot& output,std::string& error);
std::uint64_t Fingerprint(const Snapshot& snapshot);
// Immutable revisions: callers provide a unique filename; an existing file is an error.
bool WriteSnapshot(const std::filesystem::path& path,const Snapshot& snapshot,std::string& error);
}
