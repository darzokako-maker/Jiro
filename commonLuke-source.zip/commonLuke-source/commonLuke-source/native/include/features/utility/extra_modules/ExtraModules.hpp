#pragma once
#include <jni.h>
#include <array>
#include <string>
#include <cstdint>
#include <optional>
#include "client/NativePacketEngine.hpp"
namespace client::features::extras {
enum class Kind {NoWeb,TargetStrafe,AutoTool,FastUse,Spammer,AimBacktrack,AutoClicker,AimAssist,Eagle,Breaker,InventoryMove,NoFall,FastPlace,FakeLag,Count};
struct Settings {
 bool enabled=false;
 float range=1,speed=2,delay=3000,fov=90,history=1,cps=12;
 int mode=0;
 bool holdJump=true,speedOnly=true,thirdPerson=false,circle=true,behind=false;
 bool right=false,left=true,breakBlocks=true,disableOnUi=true;
 bool requireSwing=true,sticky=false,requireMouse=false,limitItems=false,aimOnTarget=false,targets=false;
 bool visibleOnly=true;
 bool players=true,invisibles=false,animals=false,mobs=false,teammates=true;
 bool blocksOnly=false;
 bool bed=true,keepProgress=true,cancelVelocity=true,throughWalls=true,emptySurrounding=false;
 bool rotate=true,importantRotations=true,whitelistBed=true,slowInAir=true;
 bool bedBox=true,defenseLayers=true,breakingOutline=true,bloom=false;float boxAlpha=.18f,layerCount=4,scanRange=64,outlineWidth=2;std::uint32_t outlineColor=0xff000000u;
 std::string message="Harakiri";
 bool operator==(const Settings&)const=default;
};
struct BacktrackVisual {double x=0,y=0,z=0,width=.6,height=1.8;bool valid=false;};
Settings Defaults(Kind kind);Settings Options(Kind kind);void SetOptions(Kind kind,Settings settings);
void PublishBacktrackVisual(BacktrackVisual visual);BacktrackVisual BacktrackVisualSnapshot();
int ModuleIndex(Kind kind);std::optional<Kind> FromModuleIndex(int module);
bool AnyEnabled();bool NeedsInput();void DisableInputFeatures();
void Poll(JNIEnv* env);void Stop(JNIEnv* env);void AfterInput(JNIEnv* env,jobject input);
jobject BeforeSend(JNIEnv* env,jobject packet);
bool BeforeReceive(JNIEnv* env,jobject packet);
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet);
}
