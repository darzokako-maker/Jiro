#pragma once
#include <array>
#include <cmath>
#include <algorithm>
#include <optional>
#include <cstdint>
namespace client::features::extras::rules {
struct Vec {double x=0,y=0,z=0;};struct Pos {int x=0,y=0,z=0;bool operator==(const Pos&)const=default;};
inline Pos Block(Vec v){return {static_cast<int>(std::floor(v.x)),static_cast<int>(std::floor(v.y)),static_cast<int>(std::floor(v.z))};}
inline double Distance(Vec a,Vec b){return std::hypot(std::hypot(a.x-b.x,a.z-b.z),a.y-b.y);}
inline float Wrap(float v){v=std::fmod(v,360.f);if(v>=180)v-=360;if(v< -180)v+=360;return v;}
inline std::array<float,2> Aim(Vec eye,Vec point){const auto x=point.x-eye.x,y=point.y-eye.y,z=point.z-eye.z;return {static_cast<float>(std::atan2(z,x)*180/3.14159265358979323846-90),static_cast<float>(-std::atan2(y,std::hypot(x,z))*180/3.14159265358979323846)};}
inline std::optional<double> RayBox(Vec eye,Vec direction,Vec lo,Vec hi,double range,double border=0){
 double enter=0,exit=range;const double p[]={eye.x,eye.y,eye.z},d[]={direction.x,direction.y,direction.z},a[]={lo.x-border,lo.y-border,lo.z-border},b[]={hi.x+border,hi.y+border,hi.z+border};
 for(int i=0;i<3;++i){if(a[i]>b[i])return {};if(std::abs(d[i])<1e-12){if(p[i]<a[i]||p[i]>b[i])return {};continue;}const auto first=(a[i]-p[i])/d[i],last=(b[i]-p[i])/d[i];enter=std::max(enter,std::min(first,last));exit=std::min(exit,std::max(first,last));if(enter>exit)return {};}
 return enter;
}
inline Vec Direction(std::array<float,2> angle){const auto yaw=angle[0]*3.14159265358979323846/180,pitch=angle[1]*3.14159265358979323846/180;return {-std::sin(yaw)*std::cos(pitch),-std::sin(pitch),std::cos(yaw)*std::cos(pitch)};}
inline bool AimbotCandidate(float yawDelta,float pitchDelta,float fov){return std::hypot(yawDelta,pitchDelta)<=std::clamp(fov,0.f,180.f);}
inline std::array<float,2> InventoryAxes(bool forward,bool back,bool left,bool right){return {static_cast<float>(forward)-static_cast<float>(back),static_cast<float>(left)-static_cast<float>(right)};}
inline bool InventoryMoveAllowed(bool enabled,bool screen,bool chat,bool clickGui){return enabled&&screen&&!chat&&!clickGui;}
inline int ClickDelay(int cps){return cps>0?1000/cps:1000;}
inline std::uint32_t AutoClickInterval(float cps){return static_cast<std::uint32_t>(ClickDelay(static_cast<int>(std::round(std::clamp(cps,1.f,20.f)))));}
inline bool SpoofGround(bool enabled,bool movementPacket,bool current){return enabled&&movementPacket?true:current;}
inline bool MlgReady(float fallDistance,double motionY,bool grounded,bool inWater,bool onLadder,bool blockedUi){
 return !blockedUi&&!grounded&&!inWater&&!onLadder&&fallDistance>=3.f&&motionY<-.08;
}
inline float MlgTrackedFall(float accumulated,double deltaY,bool grounded){
 if(grounded||deltaY>0.)return 0.f;
 return deltaY<0.?accumulated+static_cast<float>(-deltaY):accumulated;
}
inline bool MlgWithinReach(Vec eye,Pos support){
 return Distance(eye,{support.x+.5,support.y+1.,support.z+.5})<=4.4;
}
inline int FastPlaceDelay(int current,bool holdingBlock){return holdingBlock?std::min(current,0):current;}
inline constexpr int FastPlaceLimiterValue(){return 99;}
inline float Remaining(float estimate,float progress){return std::max(0.f,estimate)*(1-std::clamp(progress,0.f,1.f));}
inline bool CriticalReady(bool enabled,bool grounded,int groundTicks,unsigned long long elapsed,float delay){return enabled&&grounded&&groundTicks>2&&elapsed>=static_cast<unsigned long long>(delay);}
inline bool EagleAllowed(bool blocksOnly,bool holdingBlock){return !blocksOnly||holdingBlock;}
inline bool EagleMaySneak(float,bool grounded){return grounded;}
inline std::array<double,6> EagleCollisionBox(Vec low,Vec high,Vec motion){
 return {low.x+.2+motion.x,low.y-1.,low.z+.2+motion.z,high.x-.2+motion.x,high.y-1.,high.z-.2+motion.z};
}
inline double BacktrackRayDistance(Vec player,Vec target){
 const Vec eye{player.x,player.y+1.62,player.z};const auto length=Distance(player,target);if(length<=1e-9)return 0;
 const Vec direction{(target.x-player.x)/length,(target.y-player.y)/length,(target.z-player.z)/length};
 return RayBox(eye,direction,{target.x-.4,target.y-.1,target.z-.4},{target.x+.4,target.y+1.9,target.z+.4},length+2).value_or(0);
}
inline bool BacktrackShouldDelay(Vec player,Vec previous,Vec next){return BacktrackRayDistance(player,next)>BacktrackRayDistance(player,previous)+.001;}
}
