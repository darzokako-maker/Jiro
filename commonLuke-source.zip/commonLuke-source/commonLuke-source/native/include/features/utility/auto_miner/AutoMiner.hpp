#pragma once

#include "features/utility/ore/OreTargets.hpp"

#include <jni.h>
#include <cstdint>

namespace client::features::autominer {

struct Settings {
    bool enabled = false;
    ore::Toggles ores{};
    float range = 4.5f;
    float scanIntervalMs = 150.f;
    bool rotate = true;
    bool swing = true;
    bool operator==(const Settings&) const = default;
};

const Settings& Options();
void SetOptions(const Settings& settings);
std::uint64_t OptionsRevision();

// Called from the module poll on the Java thread. Targets the nearest
// whitelisted ore inside reach, turns toward it and continues the dig through
// PlayerControllerMP. No pathfinding is performed.
void Poll(JNIEnv* env);

} // namespace client::features::autominer
