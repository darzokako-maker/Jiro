#pragma once

#include "features/utility/ore/OreTargets.hpp"

#include <jni.h>
#include <cstdint>

namespace client::features::autominer {

struct Settings {
    bool enabled = false;
    ore::Toggles ores{};
    // Same anti-xray plausibility filter X-ray uses. Without it the miner chases
    // the fake ore wall the server injects.
    ore::Filter filter{};
    // Reach used for the actual dig call.
    float range = 4.5f;
    // How far the autonomous search looks for the next vein when Navigate is on.
    float searchRadius = 16.f;
    float scanIntervalMs = 150.f;
    bool rotate = true;
    bool swing = true;
    // Walk to out-of-reach veins with the A* planner instead of standing still.
    bool nav = true;
    // Blocks moved per 50 ms game tick while following the path. 0.14 is below
    // the vanilla sprint step, so the server-side movement check stays happy;
    // raise it only if the server does not rubber-band you.
    float moveSpeed = 0.14f;
    bool operator==(const Settings&) const = default;
};

const Settings& Options();
void SetOptions(const Settings& settings);
std::uint64_t OptionsRevision();

// Called from the module poll on the Java thread. Picks the nearest plausible
// vein; when it is inside reach it turns and digs, otherwise it plans an A*
// path through the loaded chunks and walks it without clipping into terrain.
// Veins that cannot be reached or dug are skipped for a few seconds.
void Poll(JNIEnv* env);

} // namespace client::features::autominer
