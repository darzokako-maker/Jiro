#pragma once

#include <jni.h>

namespace client::features::aimassist {

enum class Mode { Simple, Adaptive };
enum class TargetMode { Yaw, Distance, Armor, Threat, Health };
enum class TargetArea { Center, Closest };

struct Settings {
 bool enabled=false;
 Mode mode=Mode::Adaptive;
 TargetMode targetMode=TargetMode::Yaw;
 TargetArea targetArea=TargetArea::Closest;
 bool requireMouseDown=true;
 bool aimVertically=true;
 bool strafeIncrease=true;
 bool checkBlockBreak=true;
 bool limitItems=true;
 bool visibleOnly=true;
 bool players=true;
 bool invisibles=false;
 bool animals=false;
 bool mobs=false;
 bool teammates=false;
 float horizontalSpeed=7.f;
 float verticalSpeed=4.5f;
 float maxAngle=120.f;
 float distance=4.2f;
 bool operator==(const Settings&) const=default;
};

Settings Options();
void SetOptions(Settings settings);
void Poll(JNIEnv* env);
void Stop(JNIEnv* env);

}
