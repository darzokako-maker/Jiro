#pragma once
#include <jni.h>
#include <cstdint>
namespace client::features::autoharm {
struct Settings {
    bool enabled=false;
    float targetMaxHealth=18.f;
    float minSafeDistance=4.25f;
    float maxDistance=6.5f;
    float delayMin=600.f,delayMax=950.f;
    float rotationSpeedMin=8.f,rotationSpeedMax=10.f;
    bool preferTrapped=true;
    bool checkSelfHealth=true;
    bool protectVelocity=true;
    bool autoRefill=true;
    float refillSlot=8.f;
    bool silentSwing=true;
    bool notifications=true;
    bool operator==(const Settings&) const = default;
};
const Settings& Options();
void SetOptions(Settings settings);
std::uint64_t Revision();
void Poll(JNIEnv* env);
bool BeforeReceive(JNIEnv* env,jobject packet);
}

