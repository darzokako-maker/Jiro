#pragma once
#include <algorithm>

namespace client::features::velocity::rules {
struct Percents { float horizontal = 0.f, vertical = 0.f; };

inline Percents ReducedPercents(float horizontal, float vertical, double jitter) {
    const float shared = static_cast<float>(std::clamp(jitter, 0.0, 1.0) * 5.0);
    if (horizontal > 0.f) horizontal = std::min(100.f, horizontal + shared);
    if (vertical > 0.f) {
        vertical += shared;
        if (vertical >= 90.f) vertical = 100.f;
    }
    return {horizontal, vertical};
}

inline bool ChanceSucceeds(float chance, int roll) {
    return roll >= 100.f - std::clamp(chance, 0.f, 100.f);
}
}
