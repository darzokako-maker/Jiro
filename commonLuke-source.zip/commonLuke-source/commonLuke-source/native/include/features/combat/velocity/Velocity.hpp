#pragma once
#include <jni.h>
#include <cstdint>
#include "client/NativePacketEngine.hpp"

namespace client::features::velocity {
struct Settings {
    bool enabled = false;
    float horizontal = 90.f;
    float vertical = 100.f;
    float chance = 40.f;
    float ticks = 1.f;
    bool waterCheck = false;
    bool onlyWhenTargeting = false;
    bool explosions = true;
    bool operator==(const Settings&) const = default;
};
struct Stats {
    std::uint64_t modified = 0, cancelled = 0, explosions = 0, failed = 0;
};
Settings Options();
void SetOptions(Settings settings);
Stats Status();
bool BeforeReceive(JNIEnv* env, jobject packet);
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet);
void Poll(JNIEnv* env);
namespace detail {
enum class Outcome { Modified, Cancelled, Explosion, Failed };
void Record(Outcome outcome);
void ResetPending();
}
}
