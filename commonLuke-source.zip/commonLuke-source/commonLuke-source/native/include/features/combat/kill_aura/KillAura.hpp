#pragma once
#include <jni.h>
#include <array>
#include <cstdint>
#include <string>
#include <imgui.h>
#include "features/visual/esp/Esp.hpp"
namespace client::features::aura {
enum class AttackMode {Single,Switch,Multiple};
enum class BlockMode {None,Fake,Vanilla,NCP,Legit,Grim,Intave,OldIntave,ImperfectVanilla,VanillaReBlock,Watchdog117,NewNCP,Universal,Watchdog,Watchdog2};
enum class Sort {Distance,Health,HurtTime};
enum class ClickMode {Normal,HitSelect,Cooldown19,Cooldown19Animations};
enum class RotationMode {Normal,Snap,NCP,Spin};
enum class MovementFix {Off,Normal,Traditional,BackwardsSprint};
enum class TargetEsp {Ring,Box,None};
struct Settings {
    bool enabled=false;
    AttackMode attackMode=AttackMode::Multiple;
    BlockMode blockMode=BlockMode::None;
    Sort sorting=Sort::Distance;
    ClickMode clickMode=ClickMode::Normal;
    RotationMode rotationMode=RotationMode::Normal;
    MovementFix movementFix=MovementFix::Off;
    TargetEsp targetEsp=TargetEsp::Ring;
    bool fullBox=false,rightClickOnly=false,preventBlocking=false,keepSprint=false,bloom=true;
    bool rayCast=false,throughWalls=false,advanced=false;
    bool noSwing=false,autoDisable=false,badPacketsCheck=true,showTargets=false;
    bool slowSwing=false;
    float slowSwingSpeed=15.f;
    bool criticals=false;
    float criticalDelay=500;
    bool players=true,invisibles=false,animals=false,mobs=false,teammates=true;
    float range=6.f,cpsMin=10.f,cpsMax=15.f,rotationMin=5.f,rotationMax=10.f;
    float switchMin=0.f,switchMax=0.f;
    std::string friends,priorityTargets,bots;
    bool operator==(const Settings&) const = default;
};
struct Stats {
    int target=-1,candidates=0,queued=0,blockTicks=0;
    std::uint64_t cycles=0,attacks=0,failed=0;
    bool blocking=false,rotating=false;
    std::string error;
};
const Settings& Options();
void SetOptions(Settings settings);
void SetAttackGate(void (*gate)(bool));
std::uint64_t Revision();
Stats Status();
void Publish(Stats stats);
void Poll(JNIEnv* env);
jobject BeforeSend(JNIEnv* env,jobject packet);
void Stop(JNIEnv* env);
void Draw(ImDrawList& draw);
bool BeforeReceive(JNIEnv* env,jobject packet);
void SetTarget(int id);
int Target();
struct Visual {esp::Camera camera;esp::Vec3 position;float width=.6f,height=1.8f,eyeHeight=1.62f;int hurtTime=0;bool sneaking=false;};
void RenderWorld(const Visual& visual,std::uint64_t wallMilliseconds);
void BeforeClear(JNIEnv* env,unsigned mask);
void Present();
void ClearVisual();
}
