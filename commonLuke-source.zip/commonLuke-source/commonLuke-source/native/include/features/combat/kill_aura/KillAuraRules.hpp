#pragma once
#include "features/combat/kill_aura/KillAura.hpp"
#include <algorithm>
#include <cmath>
#include <vector>
namespace client::features::aura::rules {
// BoundsNumberValue.getRandomBetween truncates bounds to long and multiplies
// two independent samples. Preserve that distribution and the exclusive top.
inline long Bound(double a,double b,double u,double v) {
    auto low=static_cast<long>(a),high=static_cast<long>(b);if(low>high)std::swap(low,high);
    return low==high?low:static_cast<long>(low+(high-low)*u*v);
}
inline long SwingDelay(long sample) {return 1000/std::max(1L,static_cast<long>(sample*1.5));}
inline double BoxDistance(double x,double y,double z,double minX,double minY,double minZ,double maxX,double maxY,double maxZ) {
    const auto dx=x<std::min(minX,maxX)?std::min(minX,maxX)-x:x>std::max(minX,maxX)?x-std::max(minX,maxX):0.;
    const auto dy=y<std::min(minY,maxY)?std::min(minY,maxY)-y:y>std::max(minY,maxY)?y-std::max(minY,maxY):0.;
    const auto dz=z<std::min(minZ,maxZ)?std::min(minZ,maxZ)-z:z>std::max(minZ,maxZ)?z-std::max(minZ,maxZ):0.;
    return std::hypot(std::hypot(dx,dy),dz);
}
struct Candidate {int id;double distance;float health;int hurtTime;bool priority=false;};
inline void Order(std::vector<Candidate>& targets,Sort sort) {
    if(sort==Sort::Distance)return; // Reference leaves World.loadedEntityList order intact.
    std::stable_sort(targets.begin(),targets.end(),[&](const auto& a,const auto& b){
        return sort==Sort::Health?a.health<b.health:a.hurtTime<b.hurtTime;
    });
    std::stable_sort(targets.begin(),targets.end(),[](const auto& a,const auto& b){return a.priority&&!b.priority;});
}
inline std::vector<int> Multiple(const std::vector<Candidate>& targets,double range) {
    std::vector<int> ids;for(const auto& target:targets)if(target.distance<=range)ids.push_back(target.id);return ids;
}
inline double ClickDelay(BlockMode mode,int ticks,bool sword,bool held,bool target,double delay) {
    if(mode==BlockMode::Universal)return ticks>=4?-1:500;
    if(mode==BlockMode::Watchdog2)return ticks>=1?-1:500;
    if(mode==BlockMode::Watchdog){if(sword)return ticks>=2?-1:500;if(target&&held)return 0;}
    return delay;
}
inline bool ReleaseBefore(BlockMode mode){return mode==BlockMode::NCP||mode==BlockMode::Intave;}
inline bool BlockAfterMotion(BlockMode mode){return mode==BlockMode::NCP||mode==BlockMode::NewNCP;}
inline double Wrap(double degrees) {degrees=std::fmod(degrees+180.,360.);if(degrees<0)degrees+=360.;return degrees-180.;}
inline std::array<float,2> Move(std::array<float,2> last,std::array<float,2> target,double speed) {
    const auto dy=Wrap(target[0]-last[0]),dp=double(target[1]-last[1]),distance=std::hypot(dy,dp);
    if(distance>0&&speed!=0) {
        last[0]+=static_cast<float>(std::clamp(dy,-speed*std::abs(dy/distance),speed*std::abs(dy/distance)));
        last[1]+=static_cast<float>(std::clamp(dp,-speed*std::abs(dp/distance),speed*std::abs(dp/distance)));
    } else if(speed==0)last=target;
    last[1]=std::clamp(last[1],-90.f,90.f);return last;
}
struct RotationRequirement {
    bool required=false;
    std::uint64_t afterSequence=0;
    std::array<float,2> rotation{};
};
inline bool RotationReady(const RotationRequirement& requirement,bool haveMovement,
        std::uint64_t movementSequence,std::array<float,2> movement) {
    if(!requirement.required)return true;
    if(!haveMovement||movementSequence<=requirement.afterSequence)return false;
    constexpr double tolerance=.001;
    return std::abs(Wrap(movement[0]-requirement.rotation[0]))<=tolerance&&
        std::abs(double(movement[1]-requirement.rotation[1]))<=tolerance;
}
}
