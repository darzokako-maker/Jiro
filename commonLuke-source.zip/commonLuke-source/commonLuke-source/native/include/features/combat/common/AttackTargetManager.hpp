#pragma once

#include "features/combat/common/AttackTargetRules.hpp"
#include "game/MappingRepository.hpp"
#include "client/NativeScheduler.hpp"

#include <cstdint>
#include <mutex>
#include <unordered_map>

namespace client::features::combat::targets {
namespace detail {

struct NpcCacheEntry {
    bool npc = false;
    std::uint64_t expires = 0;
};

inline std::mutex npcCacheMutex;
inline std::unordered_map<std::uintptr_t, NpcCacheEntry> npcCache;

} // namespace detail

// SonOyuncu NPC players use Minecraft's bold formatting code in their display
// name. Cache the result briefly because target selection runs every game tick.
inline bool IsNpcPlayer(JNIEnv* env, jobject entity) {
    if (!env || !entity || !mapping::Instance(entity, "EntityPlayer")) return false;

    const auto key = mapping::Oop(entity);
    const auto now = client::scheduler::Now();
    if (key) {
        std::lock_guard lock(detail::npcCacheMutex);
        if (const auto found = detail::npcCache.find(key);
            found != detail::npcCache.end() && found->second.expires > now) {
            return found->second.npc;
        }
    }

    bool npc = false;
    bool resolved = false;
    auto displayName = mapping::Invoke(env, entity, "Entity.getDisplayName");
    if (displayName.ok && displayName.value.l) {
        if (const auto formatted = mapping::String(
                env, displayName.value.l, "ChatComponentBase.formatted")) {
            npc = rules::HasBoldFormatting(*formatted);
            resolved = true;
        }
    }
    displayName.Release(env);

    if (key && resolved) {
        std::lock_guard lock(detail::npcCacheMutex);
        if (detail::npcCache.size() >= 512) {
            for (auto it = detail::npcCache.begin(); it != detail::npcCache.end();) {
                if (it->second.expires <= now) it = detail::npcCache.erase(it);
                else ++it;
            }
            if (detail::npcCache.size() >= 512) detail::npcCache.clear();
        }
        detail::npcCache[key] = {npc, now + 1000};
    }
    return npc;
}

inline void ClearNpcCache() {
    std::lock_guard lock(detail::npcCacheMutex);
    detail::npcCache.clear();
}

} // namespace client::features::combat::targets
