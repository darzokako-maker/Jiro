#pragma once

#include <string_view>

namespace client::features::combat::targets::rules {

inline bool HasBoldFormatting(std::string_view text) {
    for (std::size_t i = 0; i < text.size(); ++i) {
        std::size_t code = std::string_view::npos;
        const auto byte = static_cast<unsigned char>(text[i]);
        if (byte == 0xA7) {
            code = i + 1;
        } else if (byte == 0xC2 && i + 1 < text.size() &&
                   static_cast<unsigned char>(text[i + 1]) == 0xA7) {
            code = i + 2;
        }
        if (code < text.size() && (text[code] == 'l' || text[code] == 'L')) return true;
    }
    return false;
}

} // namespace client::features::combat::targets::rules
