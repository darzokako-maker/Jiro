#pragma once
#include <array>
#include <imgui.h>
namespace client::ui {
class FontManager;
class Spring {
 float value_=0.f, velocity_=0.f;
 bool initialized_=false;
public:
 float Update(float target,float dt,float stiffness=250.f,float damping=25.f);
 float Value() const { return value_; }
 void Reset(float value) { value_=value;velocity_=0;initialized_=true; }
};
// Integer odometer based on Seiko AnimatedNumber's exponent springs (250 / 25).
class AnimatedNumber {
 std::array<Spring,10> places_;
 Spring width_;
 int value_=0, digits_=1, drawingDigits_=1;
 float column_=0.f;
 const ImFont* metricsFont_=nullptr;
 float metricsSize_=0.f;
 std::array<float,10> glyphWidths_{};
public:
 void Update(int value,float dt,const FontManager& fonts,float size);
 float Width() const { return width_.Value(); }
 void Draw(const FontManager& fonts,ImDrawList& list,ImVec2 position,float size,ImU32 color) const;
};
}
