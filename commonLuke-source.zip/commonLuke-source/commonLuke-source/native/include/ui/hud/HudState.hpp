#pragma once
#include <optional>
#include <string>
namespace client::ui {
struct HudPosition { double x, y, z; };
void SetChatOpen(bool open);
bool IsChatOpen();
void SetScreenOpen(bool open);
bool IsScreenOpen();
void PublishHudPosition(std::optional<HudPosition> position);
std::optional<HudPosition> GetHudPosition();
void PublishHudPlayerName(std::string name);
std::string GetHudPlayerName();
}
