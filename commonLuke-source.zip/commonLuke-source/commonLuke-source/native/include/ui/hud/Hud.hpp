#pragma once
#include "ui/hud/HudState.hpp"
#include <string>
#include <vector>
#include "render/RoundedPanel.hpp"
struct ImDrawList;
namespace client::ui {
class FontManager;
std::string FormatCoordinates(HudPosition position);
void DrawHud(const FontManager& fonts, ImDrawList& bloom,
             ImDrawList& foreground, float width, float height,
             std::vector<render::RoundedPanel>& panels);
}
