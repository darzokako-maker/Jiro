#pragma once
namespace client::ui::hud_layout {
enum class Element {Watermark,ArrayList,Coordinates,Spotify,Notifications,TargetHud,Inventory,Count};
struct Point {float x=0,y=0;};
struct GuideState {bool vertical=false,horizontal=false;float x=0,y=0;};
void BeginFrame();
void Report(Element element,float width,float height);
Point Position(Element element,float screenWidth,float screenHeight);
void UpdateEditor(float mouseX,float mouseY,float screenWidth,float screenHeight,bool leftDown);
void EndEditor();
bool Dragging(Element element);
GuideState Guides();
}
