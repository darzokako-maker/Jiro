#pragma once
#include "render/RoundedPanel.hpp"
#include <deque>
#include <string>
#include <string_view>
#include <vector>
struct ImDrawList;
namespace client::ui {class FontManager;}
namespace client::ui::notifications {
enum class Type {Success,Info,Disabled};
struct Toast {
 Type type;
 std::string title,message;
 float age=0,y=-1;
};
// Owned by the render thread, like module settings. Pending messages receive
// their full display time when a visible slot becomes available.
class Queue {
 bool enabled_=true;
 std::deque<Toast> pending_;
 std::vector<Toast> active_;
public:
 static constexpr float Enter=.24f,Hold=3.f,Exit=.22f,Lifetime=Enter+Hold+Exit;
 static constexpr std::size_t MaxPending=32,MaxVisible=3;
 bool Enabled() const{return enabled_;}
 void SetEnabled(bool enabled){enabled_=enabled;if(!enabled)Clear();}
 void Clear(){pending_.clear();active_.clear();}
 void Push(Type type,std::string_view title,std::string_view message);
 void Update(float dt,int capacity);
 std::size_t Count() const{return pending_.size()+active_.size();}
 std::vector<Toast>& Active(){return active_;}
 const std::vector<Toast>& Active() const{return active_;}
};
Queue& State();
void ModuleChanged(std::string_view name,bool enabled);
bool InitializeGraphics();
// Separate overlay pass: notifications remain above the ClickGUI and visible
// when the HUD module itself is switched off.
void Draw(const FontManager& fonts,ImDrawList& bloom,ImDrawList& front,float width,float height,float dt,std::vector<render::RoundedPanel>& panels);
}
