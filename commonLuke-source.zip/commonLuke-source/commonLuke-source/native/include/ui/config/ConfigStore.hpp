#pragma once
#include <string>
#include <string_view>
#include <vector>

namespace client::ui::configs {
struct Entry {std::string name;};
std::vector<Entry> List();
bool Exists(std::string_view name);
bool Save(std::string_view name,bool overwrite,std::string& error);
bool Load(std::string_view name,std::string& error);
bool Remove(std::string_view name,std::string& error);
std::string Current();
std::string StorageLocation();
}
