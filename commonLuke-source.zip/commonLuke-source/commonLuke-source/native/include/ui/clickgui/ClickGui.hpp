#pragma once
struct ImDrawList;
namespace client::ui { class FontManager; }
namespace client::ui::clickgui {
void Draw(const FontManager& fonts,ImDrawList& blurMask);
bool HudEnabled();
bool RequestClose();
void OpenModuleSettings(int module);
void OpenConfigs();
}
