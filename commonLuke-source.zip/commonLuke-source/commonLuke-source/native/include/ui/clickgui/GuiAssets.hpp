#pragma once
#include <imgui.h>
namespace client::ui::clickgui {
struct WatermarkTextures {
 ImTextureID image;
 ImTextureID bloom;
};
WatermarkTextures WatermarkLogo();
ImTextureID BackgroundPattern();
}
