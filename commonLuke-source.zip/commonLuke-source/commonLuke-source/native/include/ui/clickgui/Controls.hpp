#pragma once
#include "ui/font/FontManager.hpp"
#include "ui/font/ReferenceFont.hpp"
#include "ui/clickgui/ReferencePrimitives.hpp"
#include <imgui.h>
#include <algorithm>
#include <cmath>
#include <functional>
#include <span>
#include <string>
namespace client::ui::clickgui {
namespace palette {
inline constexpr ImU32 background=IM_COL32(20,20,21,255);
inline constexpr ImU32 secondary=IM_COL32(24,24,25,255);
inline constexpr ImU32 overlay=IM_COL32(29,29,30,255);
inline constexpr ImU32 hoveredSurface=IM_COL32(39,39,41,255);
inline constexpr ImU32 ink=IM_COL32(237,237,239,255);
inline constexpr ImU32 muted=IM_COL32(153,153,158,255);
inline constexpr ImU32 border=IM_COL32(55,55,58,255);
inline constexpr ImU32 glass=IM_COL32(17,17,18,216);
}
struct Canvas {
 ImVec2 origin;float scale;ImDrawList* draw;const FontManager& fonts;
 float alpha=1.f;
 bool reference=false;
 ImU32 Fade(ImU32 color) const { return (color&0xffffff)|(static_cast<ImU32>(((color>>24)&255)*std::clamp(alpha,0.f,1.f))<<24); }
 ImVec2 P(float x,float y) const { return {origin.x+x*scale,origin.y+y*scale}; }
 void Rect(float x,float y,float w,float h,ImU32 color,float round=0) const {
  if(reference&&ReferenceRectangle(*draw,P(x,y),w,h,round,scale,Fade(color)))return;
  draw->AddRectFilled(P(x,y),P(x+w,y+h),Fade(color),round*scale);
 }
 ImVec2 Measure(std::string_view text,float size,FontWeight weight=FontWeight::Regular) const {
  if(reference){auto result=reference_fonts::Measure(text,static_cast<int>(size),weight);result.x*=scale;result.y*=scale;return result;}
  return fonts.Measure(text,size*scale,weight);
 }
 void Text(const char* value,float x,float y,float size,ImU32 color=palette::ink,FontWeight weight=FontWeight::Regular) const {
  if(reference&&reference_fonts::Draw(*draw,value,P(x,y),static_cast<int>(size),scale,Fade(color),weight))return;
  fonts.Draw(*draw,value,P(x,y),size*scale,Fade(color),weight);
 }
 void RowText(const char* value,float x,float centerY,float size) const {
  const auto baked=fonts.Get(FontWeight::Regular)->GetFontBaked(size*scale);
  const float glyphScale=size*scale/baked->Size;
  float top=INFINITY,bottom=-INFINITY;
  for(const unsigned char* p=reinterpret_cast<const unsigned char*>(value);*p;++p) if(const auto glyph=baked->FindGlyph(*p)) {
   top=std::min(top,glyph->Y0*glyphScale);bottom=std::max(bottom,glyph->Y1*glyphScale);
  }
  Text(value,x,centerY-(top+bottom)/(2*scale),size);
 }
 void RowIcon(ImWchar value,float centerX,float centerY,float size) const {
  auto font=fonts.Icons();const auto baked=font->GetFontBaked(size*scale);const auto glyph=baked->FindGlyph(value);
  if(!glyph)return;
  char utf8[4]{static_cast<char>(0xe0|(value>>12)),static_cast<char>(0x80|((value>>6)&0x3f)),static_cast<char>(0x80|(value&0x3f)),0};
  const float glyphScale=size*scale/baked->Size;
  draw->AddText(font,size*scale,P(centerX-(glyph->X0+glyph->X1)*glyphScale/(2*scale),centerY-(glyph->Y0+glyph->Y1)*glyphScale/(2*scale)),Fade(palette::ink),utf8,utf8+3);
 }
 bool Button(const char* id,float x,float y,float w,float h) const {
  ImGui::SetCursorScreenPos(P(x,y));return ImGui::InvisibleButton(id,{w*scale,h*scale});
 }
 void Center(const char* text,float x,float y,float width,float size,ImU32 color=palette::ink) const {
  Text(text,x+(width-Measure(text,size,FontWeight::Medium).x/scale)*.5f,y,size,color,FontWeight::Medium);
 }
};
void Slider(const Canvas& c,const char* label,float& value,float minimum,float maximum,float step,float y);
void RangeSlider(const Canvas& c,const char* label,float& first,float& second,float minimum,float maximum,float step,float y);
void ResetOptionControls();
void Dropdown(const Canvas& c,const char* label,bool& value,const char* first,const char* second,float y);
// The setting referenced by onSelect must outlive the open popup.
void Dropdown(const Canvas& c,const char* label,const void* identity,int selected,
              std::span<const char* const> names,std::function<void(int)> onSelect,float y);
template<class E,std::size_t N>
void Dropdown(const Canvas& c,const char* label,E& value,const char* const(&names)[N],float y) {
 Dropdown(c,label,&value,static_cast<int>(value),std::span<const char* const>(names,N),
          [&value](int choice){value=static_cast<E>(choice);},y);
}
void TextOption(const Canvas& c,const char* label,std::string& value,float y);
void ColorOption(const Canvas& c,const char* label,ImU32& color,float y);
void DrawControlOverlays(const Canvas& c);
void CloseControlOverlays();
bool ControlOverlayOpen();
}

