#pragma once
#include <imgui.h>
namespace client::ui::clickgui {
bool ReferenceRectangle(ImDrawList& list,ImVec2 position,float width,float height,float radius,float scale,ImU32 color);
bool ReferenceImageRounded(ImDrawList& list,unsigned int texture,ImVec2 position,float width,float height,float radius,ImVec2 uv0,ImVec2 uv1,ImU32 tint);
bool ReferenceWave(ImDrawList& list,ImVec2 position,float width,float height,float amplitude,float wavelength,float thickness,float phase,ImU32 color);
void ReleaseReferencePrimitives();
}
