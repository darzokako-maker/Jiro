#pragma once
#include <Windows.h>
#include <array>
#include <string>
namespace client::ui::input {
struct Snapshot {std::array<bool,256> down{},pressed{};bool focused=false;};
void Install(HWND window,void* glfwWindow);
void Poll();
const Snapshot& State();
bool MenuTogglePending();
void NewFrame();
bool IsOpen();
int PressedKey();
void SetOpen(bool value);
// A non-null handler reserves gameplay left clicks; menus keep normal input.
void SetEntityClickHandler(void (*handler)());
using GameplayKeyFilter=int(*)(void*,int,int,int(*)(void*,int));
using GameplayMouseFilter=bool(*)(int);
// Named DLL-lifetime callbacks; lower priorities run first. Mouse suppression
// is combined with OR. Key callbacks see the preceding callback's value.
void SetGameplayFilters(std::string owner,GameplayKeyFilter key,GameplayMouseFilter mouse,int priority=0);
}
