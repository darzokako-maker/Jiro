#pragma once
#include <algorithm>
#include <cmath>

namespace client::ui::clickgui {
// ModuleSettingsPanel.Spring: preserve its integration step, not the HUD spring.
class OptionSpring {
 double value_=0,velocity_=0;
public:
 OptionSpring()=default;
 explicit OptionSpring(double initial):value_(initial){}
 float Value() const {return static_cast<float>(value_);}
 void Reset(double target){value_=target;velocity_=0;}
 float Update(double target,double seconds,double stiffness=250,double damping=25){
  const double dt=std::clamp(seconds,0.,.04);
  const int steps=std::max(1,static_cast<int>(std::ceil(dt/.008)));
  const double slice=dt/steps;
  for(int i=0;i<steps;++i){velocity_+=((target-value_)*stiffness-velocity_*damping)*slice;value_+=velocity_*slice;}
  if(std::abs(target-value_)<.001&&std::abs(velocity_)<.01)Reset(target);
  return Value();
 }
};
class OptionFade {
 double value_=0,from_=0,to_=0,start_=0;
public:
 void Reset(){value_=from_=to_=start_=0;}
 float Update(double target,double now){
  if(target!=to_){from_=value_;to_=target;start_=now;}
  const double t=std::clamp((now-start_)/.240,0.,1.);
  const double eased=t<.5?4*t*t*t:1-std::pow(-2*t+2,3)/2;
  value_=from_+(to_-from_)*eased;
  return static_cast<float>(value_);
 }
};
}
