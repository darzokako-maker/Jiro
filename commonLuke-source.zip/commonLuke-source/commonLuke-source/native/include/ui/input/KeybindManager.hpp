#pragma once
#include "features/core/ModuleRegistry.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include <cstdint>
#include <string>

namespace client::ui::bindings {
struct Binding {int key=0;bool hold=false;bool operator==(const Binding&) const=default;};
struct Config {Binding module,action;bool operator==(const Config&) const=default;};
bool Bindable(int key);
bool SupportsAction(features::modules::Id id);
std::string KeyName(int key);
const Config& Options(features::modules::Id id);
void SetOptions(features::modules::Id id,Config config);
// Call once per game presentation, before any queued clip is consumed.
bool NeedsGameCheck(const input::Snapshot& input);
void Update(const input::Snapshot& input,bool allowed,std::uint64_t now);
bool Holding(features::modules::Id id);
inline constexpr std::uint64_t RepeatMilliseconds=150;
inline constexpr std::uint64_t RepeatJitterMilliseconds=35;
}
