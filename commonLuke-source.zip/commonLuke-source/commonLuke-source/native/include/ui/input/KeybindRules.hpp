#pragma once

namespace client::ui::bindings::rules {

inline bool ModuleKeyRemoved(int previousKey, int currentKey) {
    return previousKey != 0 && currentKey == 0;
}

} // namespace client::ui::bindings::rules
