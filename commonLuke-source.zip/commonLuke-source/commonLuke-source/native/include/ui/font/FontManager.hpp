#pragma once
#include <imgui.h>
#include <string_view>
#include <string>
namespace client::ui {
enum class FontWeight { Regular, Medium, SemiBold };
class FontManager {
 ImFont* fonts_[3]{};
 ImFont* icons_{};
 bool asciiComplete_[3]{};
 bool PlainAscii(std::string_view text,FontWeight weight) const;
public:
 bool Initialize();
 ImFont* Icons() const { return icons_; }
 ImFont* Get(FontWeight weight = FontWeight::SemiBold) const { return fonts_[static_cast<int>(weight)]; }
 std::string ResolveText(std::string_view text, FontWeight weight = FontWeight::SemiBold) const;
 ImVec2 Measure(std::string_view text, float size, FontWeight weight = FontWeight::SemiBold) const;
 void Draw(ImDrawList& list, std::string_view text, ImVec2 position,
           float size, ImU32 color, FontWeight weight = FontWeight::SemiBold) const;
};
}
