#pragma once
#include "ui/font/FontManager.hpp"

namespace client::ui::reference_fonts {
ImVec2 Measure(std::string_view text,int size,FontWeight weight);
bool Draw(ImDrawList& list,std::string_view text,ImVec2 position,int size,float scale,ImU32 color,FontWeight weight);
void Release(); // current OpenGL context only
}
