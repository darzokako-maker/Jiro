#pragma once
#include <Windows.h>

namespace client::hud {
bool Install();
bool CaptureContext();
}
