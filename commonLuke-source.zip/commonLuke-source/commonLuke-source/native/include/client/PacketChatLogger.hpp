#pragma once

#include <jni.h>

namespace client::packet_chat {

void Install();
bool Enabled();
void SetEnabled(bool enabled);
void Poll(JNIEnv* env);
bool BeforeReceive(JNIEnv* env, jobject packet);
void Stop();

} // namespace client::packet_chat
