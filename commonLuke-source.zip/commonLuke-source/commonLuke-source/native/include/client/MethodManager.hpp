#pragma once
#include <jni.h>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>
#include <functional>
#include <future>
namespace client::classes { struct ClassRecord; }
namespace client::methods {
enum class Type : int { Boolean=4, Char=5, Float=6, Double=7, Byte=8, Short=9, Int=10, Long=11, Object=12, Void=14 };
struct Argument {
    Type type;
    jvalue value{};
};
struct Result {
    using Releaser = void(*)(JNIEnv*, jobject);
    Type type = Type::Void;
    jvalue value{};
    bool ok = false;
    std::string error;
    Releaser releaser = nullptr;
    // Object results are HotSpot global handles. Release on a Java thread.
    void Release(JNIEnv* env) {
        if (type != Type::Object || !value.l) return;
        if (releaser) releaser(env, value.l);
        else if (env) env->DeleteGlobalRef(value.l); // test/foreign Result adapter
        value.l = nullptr;
    }
};
// receiver and object arguments are JNI handles; never queued raw heap oops.
Result Invoke(JNIEnv* env, jobject receiver, const classes::ClassRecord& owner,
    const std::string& name, const std::string& descriptor,
    const std::vector<Argument>& arguments = {}, bool virtualCall = true,
    bool explicitClassInitializer = false);
// Tasks execute on the captured render thread. Never wait on the render thread.
bool Enqueue(std::function<void(JNIEnv*)> task);
void Drain(JNIEnv* env);
// No-argument instance method returning java.lang.String. Render thread only.
std::optional<std::string> InvokeString(JNIEnv* env, std::uintptr_t receiver,
    std::uintptr_t method);
void TestPlayerName(JNIEnv* env, std::uintptr_t player);
}
