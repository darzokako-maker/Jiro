#pragma once
#include "client/JarReader.hpp"
#include <regex>
#include <set>

namespace client::payload {
// Check both class constants and descriptors: Java8 synthetic constructor
// parameters can reference a marker class even when its body is never used.
inline bool ValidatePayloadClosure(const std::vector<jar::ParsedClass>& classes, std::string& missing) {
    std::set<std::string> names;
    for(const auto& item:classes) {
        const auto& cp=item.class_file.constant_pool;
        const auto index=cp.get_entry(item.class_file.this_class)
            .get<jcfp::ConstantPoolEntry::ClassInfo>().name_index;
        names.insert(cp.get_entry(index).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes);
    }
    const std::regex reference("client/packethook/[A-Za-z0-9_$/]+");
    for(const auto& item:classes) {
        const auto& cp=item.class_file.constant_pool;
        for(jcfp::u2 i=1;i<cp.count();++i) {
            if(cp.get_tag(i)!=jcfp::ConstantPoolEntry::Tag::Utf8)continue;
            const auto& bytes=cp.get_entry(i).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
            for(auto it=std::sregex_iterator(bytes.begin(),bytes.end(),reference);it!=std::sregex_iterator();++it)
                if(!names.contains(it->str())) { missing=it->str();return false; }
        }
    }
    return true;
}
}
