#pragma once

#include <cstddef>
#include <cstdint>
#include <jni.h>

namespace client::hotspot::runtime {

// Resolve a JNI local/global/weak handle to its current oop. The returned oop
// is only valid while the current thread cannot cross a safepoint.
std::uintptr_t Resolve(jobject handle);

// Create JNI roots through HotSpot's JNIHandles implementation. Global and
// destroy operations perform the native <-> VM thread-state transition.
jobject Local(JNIEnv* env, std::uintptr_t oop);
jobject LocalFromRoot(JNIEnv* env, std::uintptr_t* rootedOop);
jobject Global(JNIEnv* env, jobject source);

// rootedOop must point at a slot known to HotSpot's GC (for example
// JavaThread::_vm_result). It must not point at an ordinary native stack value.
jobject GlobalFromRoot(JNIEnv* env, std::uintptr_t* rootedOop);
bool DestroyGlobal(JNIEnv* env, jobject global);

// Resolve the owner only after entering VM state, then read its mapped field
// and return a GC-tracked local handle. No JNI class/field lookup is involved.
jobject LoadObject(JNIEnv* env, jobject owner, std::uint32_t offset);
bool LoadPrimitive(JNIEnv* env, jobject owner, std::uint32_t offset,
    void* output, std::size_t size);
bool IsInstance(JNIEnv* env, jobject object, std::uintptr_t targetKlass,
    std::uint32_t superOffset);

// Store an oop into an instance or mirror field through HotSpot's BarrierSet.
// owner and value are resolved after entering VM state so moving-GC cannot
// invalidate a previously decoded oop.
bool StoreObject(JNIEnv* env, jobject owner, std::uint32_t offset, jobject value);

} // namespace client::hotspot::runtime
