#pragma once
#include <jni.h>

namespace client::lwjgl_env_hook {

bool Install();
JNIEnv* CurrentEnvironment();

} // namespace client::lwjgl_env_hook
