#pragma once
#include <cstdint>
#include <jni.h>

namespace client::jar_vm {
// Manual, ordered API probes. No automatic calls or payload class publication.
void PrintTestHelp();
void RunTestStep(JNIEnv* env, unsigned step);
void PollTests(JNIEnv* env);
}
