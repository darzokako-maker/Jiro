#pragma once

#include <cstdint>
#include <utility>

namespace client::methods {

template<class DestroyWrapper, class PromoteRoot>
auto FinalizeObjectResult(std::uintptr_t value, std::uintptr_t* rooted,
    DestroyWrapper&& destroyWrapper, PromoteRoot&& promoteRoot)
{
    *rooted = value;
    std::forward<DestroyWrapper>(destroyWrapper)();
    return value ? std::forward<PromoteRoot>(promoteRoot)(rooted)
                 : decltype(promoteRoot(rooted)){};
}

} // namespace client::methods
