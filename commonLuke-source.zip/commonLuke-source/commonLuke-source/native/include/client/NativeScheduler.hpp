#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace client::scheduler {

enum class Task : std::uint8_t {
    ModulePoll,
    InputModules,
    AutoClicker,
    Spammer,
    EagleRelease,
    FakeLagRelease,
    BacktrackRelease,
    FastUse,
    EspCapture,
    InventoryCapture,
    TargetHudCapture,
    XrayCapture,
    WingsFlags,
    AimAssistFrame,
    SeedDumperCapture,
    CosmeticsPlayerCheck,
    CosmeticsScan,
    HudPlayerName,
    SpotifyRefresh,
    AmbianceMediaPoll,
    Count
};

struct Cursor {
    std::uint64_t generation = 0;
};

namespace detail {

inline constexpr std::uint32_t HighResolutionTimerFlag = 0x00000002u;
enum class Wake : std::uint8_t { None, Stop, Tick };
constexpr std::uint32_t TimerFlagsForAttempt(unsigned attempt) noexcept
{
    return attempt == 0 ? HighResolutionTimerFlag : 0u;
}
constexpr Wake SelectWake(bool stopSignaled, bool timerSignaled) noexcept
{
    return stopSignaled ? Wake::Stop : timerSignaled ? Wake::Tick : Wake::None;
}

class DeadlineBank {
public:
    void Configure(Task task, bool enabled, std::uint32_t intervalMilliseconds) noexcept;
    void Advance(std::uint64_t nowMilliseconds) noexcept;
    bool Consume(Task task, Cursor& cursor) const noexcept;

private:
    static constexpr std::size_t TaskCount = static_cast<std::size_t>(Task::Count);
    struct Slot {
        std::atomic<std::uint64_t> configuration{0};
        std::atomic<std::uint64_t> generation{0};
        std::uint64_t observedConfiguration = 0;
        std::uint64_t nextDeadline = 0;
    };
    std::array<Slot, TaskCount> slots_{};
};

void Advance(std::uint64_t nowMilliseconds) noexcept;
void PublishNow(std::uint64_t nowMilliseconds) noexcept;

}

void Configure(Task task, bool enabled, std::uint32_t intervalMilliseconds) noexcept;
bool Consume(Task task, Cursor& cursor) noexcept;
std::uint64_t Now() noexcept;
void Run(void* shutdownEvent) noexcept;

}
