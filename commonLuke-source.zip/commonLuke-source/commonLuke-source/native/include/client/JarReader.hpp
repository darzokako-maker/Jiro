#pragma once
#include <cstddef>
#include <string>
#include <vector>
#include "jcfp/jcfp.hpp"

namespace client::jar {
struct ParsedClass {
    std::string name;
    std::vector<jcfp::u1> bytecode;
    jcfp::ClassFile class_file;
};

// Reads and validates only. Does not access a JVM or publish classes.
std::vector<ParsedClass> Read(const std::string& path, bool allowNativeMethods = false);
std::vector<ParsedClass> ReadMemory(const void* bytes,std::size_t size,bool allowNativeMethods=false);
}
