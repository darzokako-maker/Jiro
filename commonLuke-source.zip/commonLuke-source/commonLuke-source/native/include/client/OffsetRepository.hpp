#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>

namespace client::offsets {
struct Profile {
    std::string id;
    // Module-relative addresses, never process absolute addresses.
    std::unordered_map<std::string, std::uintptr_t> rvas;
    std::unordered_map<std::string, std::uint32_t> members;
};
std::shared_ptr<const Profile> Get();
// Future server transport may supply a validated profile through this API.
bool Publish(Profile profile);
bool LoadBuiltin();
}
