#pragma once

#include <jvmti.h>

struct JavaVM_;
using JavaVM = JavaVM_;

namespace client::jvmti_probe {

void Run(JavaVM* virtualMachine);
jvmtiEnv* Get();

} // namespace client::jvmti_probe
