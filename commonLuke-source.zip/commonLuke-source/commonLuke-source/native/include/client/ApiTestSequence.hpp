#pragma once
#include <array>

namespace client::jar_vm {
class ApiTestSequence {
public:
    static constexpr unsigned Count = 10;
private:
    unsigned next_ = 0;
    bool failed_ = false, enabled_ = true;
    std::array<bool, Count> previous_{};
public:
    unsigned Next() const { return next_; }
    bool Failed() const { return failed_; }
    bool Enabled() const { return enabled_; }
    bool CanRun(unsigned step) const {
        return enabled_ && !failed_ && step < Count && step == next_;
    }
    void Complete(bool ok) { if (ok) ++next_; else failed_ = true; }
    void Stop() { enabled_ = false; }
    // A held key never repeats; simultaneous key edges are ignored.
    int Pressed(const std::array<bool, Count>& down) {
        int pressed = -1;
        unsigned count = 0;
        for (unsigned i = 0; i < down.size(); ++i) {
            if (down[i] && !previous_[i]) { pressed = static_cast<int>(i); ++count; }
        }
        previous_ = down;
        return count == 1 ? pressed : -1;
    }
};
}
