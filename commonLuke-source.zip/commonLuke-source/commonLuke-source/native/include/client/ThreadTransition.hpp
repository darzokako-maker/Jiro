#pragma once

#include "client/OffsetRepository.hpp"

#include <atomic>
#include <cstdint>

namespace client::thread_transition {

namespace detail {

inline std::uintptr_t Rva(const offsets::Profile& profile, const char* name)
{
    const auto found = profile.rvas.find(name);
    return found == profile.rvas.end() ? 0 : found->second;
}

inline void Fence()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
}

} // namespace detail

// Mirrors ThreadStateTransition::transition_from_native in this exact JVM.
// check_native_transition is intentionally called unconditionally: the VM
// routine performs the safepoint/suspend tests itself and must run while the
// JavaThread is still in _thread_in_native_trans.
inline bool EnterVm(std::uintptr_t base, const offsets::Profile& profile,
    std::uintptr_t thread, volatile int* state)
{
    if (!base || !thread || !state || *state != 4) return false;
    const auto serialize = detail::Rva(profile, "Thread.serialize");
    const auto check = detail::Rva(profile, "Thread.check_native_transition");
    if (!serialize || !check) return false;

    using ThreadCall = void(__fastcall*)(std::uintptr_t);
    *state = 5;
    detail::Fence();
    reinterpret_cast<ThreadCall>(base + serialize)(thread);
    reinterpret_cast<ThreadCall>(base + check)(thread);
    *state = 6;
    detail::Fence();
    return true;
}

// Mirrors ThreadStateTransition::transition_and_fence from VM to native.
inline bool LeaveVm(std::uintptr_t base, const offsets::Profile& profile,
    std::uintptr_t thread, volatile int* state)
{
    if (!base || !thread || !state || *state != 6) return false;
    const auto serialize = detail::Rva(profile, "Thread.serialize");
    const auto safepointState = detail::Rva(profile, "SafepointSynchronize.state");
    const auto safepointBlock = detail::Rva(profile, "SafepointSynchronize.block");
    if (!serialize || !safepointState || !safepointBlock) return false;

    using ThreadCall = void(__fastcall*)(std::uintptr_t);
    *state = 7;
    detail::Fence();
    reinterpret_cast<ThreadCall>(base + serialize)(thread);
    if (*reinterpret_cast<volatile int*>(base + safepointState) != 0)
        reinterpret_cast<ThreadCall>(base + safepointBlock)(thread);
    *state = 4;
    detail::Fence();
    return true;
}

} // namespace client::thread_transition
