#pragma once
#include <jni.h>
#include <cstdint>
#include <string>

namespace client::classes { struct ClassRecord; }

namespace client::packets {
// Callbacks run on the Java caller's thread. JNI handles must not escape it.
// Send: return packet/replacement, or nullptr to cancel. Receive: false cancels.
using SendFilter = jobject(*)(JNIEnv*, jobject);
using ReceiveFilter = bool(*)(JNIEnv*, jobject);
// Named subscriptions run in ascending priority, then registration order.
// Send replacements flow to the next subscriber; cancellation stops the chain.
// Registration is copy-on-write: callbacks never hold the registry mutex.
// Changes affect the next dispatch; an in-flight snapshot can still call an
// removed subscriber. Functions must remain valid for this DLL's lifetime.
// Callbacks may run concurrently and must synchronize their own mutable state.
void SetFilter(std::string owner, SendFilter send, ReceiveFilter receive, int priority = 0);
bool RemoveFilter(const std::string& owner);
// Returns a local ChannelFuture reference. Direct send bypasses SendFilter.
// The caller supplies its current JNIEnv and owns the returned local reference.
jobject Send(JNIEnv* env, jobject packet);
bool Receive(JNIEnv* env, jobject packet);
bool BindNativeCallbacks(JNIEnv* env, jclass payloadClass);
bool SetHook(JNIEnv* env, jobject hook, const classes::ClassRecord& owner);
bool Uninstall(JNIEnv* env);
bool IsInstalled(JNIEnv* env);
struct Counters { std::uint64_t sent, received, cancelledSend, cancelledReceive, directSend; };
Counters GetCounters();
}
