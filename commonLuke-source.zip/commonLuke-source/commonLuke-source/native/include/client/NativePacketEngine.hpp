#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <span>
#include <string_view>
#include <vector>

namespace client::native_packets {

enum class Direction : std::uint8_t { Inbound = 0, Outbound = 1 };
enum class Action : std::uint8_t { Pass, Modify, Cancel, Replace, Delay };

struct PacketView {
    Direction direction{};
    std::int32_t packetId = -1;
    std::string_view mappingKey;
    std::string_view className;
    std::vector<std::uint8_t> payload;
    bool compressionEnvelope = false;
    bool compressed = false;
    std::uint32_t delayMilliseconds = 0;
};

using Handler = std::function<Action(PacketView&)>;
using Observer = std::function<void(const PacketView&)>;

struct StreamHealth {
    bool active = false;
    bool validated = false;
    bool failed = false;
    std::uint64_t inputCalls = 0;
    std::uint64_t inputBytes = 0;
    std::uint64_t packets = 0;
    std::uint64_t lastInputTick = 0;
    std::uint64_t lastPacketTick = 0;
    std::uint64_t boundaryLosses = 0;
    std::uint64_t recoveries = 0;
};

// Read-only packet notifications. Observers never switch SocketTap into the
// active rewrite path and therefore cannot perturb the wire stream.
void SetObserver(Observer observer);

// The sole rule seam. An empty handler restores passive observation.
void SetHandler(Handler handler);
bool HasHandler();

// Registry-backed symbolic rules. Pass removes a rule; Cancel drops matching
// frames while keeping both CFB8 stream states synchronized. Modify/Replace
// require SetHandler because they need a payload callback.
bool SetMappedAction(std::string_view mappingKey, Action action);
void ClearMappedActions();
std::string_view PacketName(Direction direction, std::int32_t packetId);
std::string_view PacketClassName(Direction direction, std::int32_t packetId);

// Publishes the live HotSpot CipherFeedback state. No Java/JNI call is made.
void PublishCipher(Direction direction, const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& registerBytes);
bool NeedsCipherResync(Direction direction);
bool IsStreamActive(Direction direction);
// True only after a complete run of registry-valid frames has proven the
// stream boundary. Before this point SocketTap must preserve original NIO I/O.
bool CanRewrite(Direction direction);
StreamHealth GetStreamHealth(Direction direction);
void RequestCipherResync(Direction direction, const char* reason);
void SetCompressionThreshold(std::int32_t threshold);
void SetCompressionEnabled(bool enabled);

// Passive mode parses and dispatches a copy while leaving network bytes alone.
void Observe(Direction direction, std::span<const std::uint8_t> ciphertext);

// Active mode consumes JVM/wire ciphertext and returns translated ciphertext.
// Output may be empty (partial frame or Cancel) or differ in size (Replace).
std::vector<std::uint8_t> Transform(Direction direction,
    std::span<const std::uint8_t> ciphertext);

void Reset();
// Drops cipher/parser state for a closed transport without removing the
// feature rules that must survive a reconnect.
void ResetStreams();

// Exposed only as the deterministic test surface for the deep module.
namespace testing {
std::vector<std::uint8_t> Cfb8Encrypt(
    const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& iv,
    std::span<const std::uint8_t> plaintext);
std::vector<std::uint8_t> Cfb8Decrypt(
    const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& iv,
    std::span<const std::uint8_t> ciphertext);
}

} // namespace client::native_packets
