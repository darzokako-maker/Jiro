#pragma once

namespace client::log {

void Initialize(const wchar_t* path = nullptr);
void Write(const char* format, ...);

} // namespace client::log

#if !defined(AOKI_ENABLE_LOGGING)
#define AOKI_LOG(...) ((void)0)
#define AOKI_LOG_INITIALIZE(...) ((void)0)
#else
#define AOKI_LOG(...) ::client::log::Write(__VA_ARGS__)
#define AOKI_LOG_INITIALIZE(...) ::client::log::Initialize(__VA_ARGS__)
#endif
