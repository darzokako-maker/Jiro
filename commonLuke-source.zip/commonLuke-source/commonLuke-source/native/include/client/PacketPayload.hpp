#pragma once
#include <jni.h>
#include <cstdint>
namespace client::payload {
void PrintHelp();
void Poll(JNIEnv* env);

}
