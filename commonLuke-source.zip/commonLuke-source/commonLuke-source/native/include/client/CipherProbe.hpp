#pragma once

#include <jni.h>

namespace client::cipher_probe {

// Walks the live NetworkManager -> Netty pipeline -> Minecraft cipher wrapper.
// The JNIEnv path uses GC-tracked handles only; it never installs Java code,
// loads a helper class, or hooks the interpreter/JIT.
void Poll(JNIEnv* environment) noexcept;

} // namespace client::cipher_probe
