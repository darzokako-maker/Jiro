#pragma once
#include "client/ClassRepository.hpp"
#include <cstddef>
#include <memory>
#include <optional>
#include <type_traits>
#include <jni.h>

namespace client::hotspot {
bool ReadMemory(std::uintptr_t address, void* output, std::size_t size);
bool WriteMemory(std::uintptr_t address, const void* input, std::size_t size);
// JVM-image constants decoded once per offsets::Profile. Values are read from
// jvm.dll globals; heap pointers are never stored here.
struct JvmConstants {
    const void* profile = nullptr;
    std::uintptr_t jvmBase = 0;
    std::optional<bool> compressedOops;
    std::optional<std::uintptr_t> narrowOopBase;
    std::optional<unsigned> narrowOopShift;
    std::optional<bool> compressedKlass;
    std::optional<std::uintptr_t> narrowKlassBase;
    std::optional<unsigned> narrowKlassShift;
};
std::shared_ptr<const JvmConstants> GetConstants();
template<class T> std::optional<T> Read(std::uintptr_t address)
{
    static_assert(std::is_trivially_copyable_v<T>);
    T value{};
    if (!ReadMemory(address, &value, sizeof(value))) return {};
    return value;
}
// Primitive fields only. Object references require HotSpot barriers/handles.
template<class T> bool WritePrimitive(std::uintptr_t address, const T& value)
{
    static_assert(std::is_arithmetic_v<T>);
    return WriteMemory(address, &value, sizeof(value));
}
std::optional<FieldInfo> FindField(const classes::ClassRecord& owner,
    const std::string& name, const std::string& signature);
std::optional<MethodInfo> FindMethod(const classes::ClassRecord& owner,
    const std::string& name, const std::string& signature);
void DumpCoordinateCandidates();
struct Coordinates { double x, y, z; };
// The caller supplies a current full oop, never a compressed reference or JNI handle.
std::optional<Coordinates> ReadCoordinates(std::uintptr_t playerOop);
void ResolvePlayerMapping();
std::optional<std::uintptr_t> ReadObjectReference(std::uintptr_t address);
void PollCoordinates(JNIEnv* env);
}
