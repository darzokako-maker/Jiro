#pragma once

#include "KlassInjector.hpp"
#include "jcfp/jcfp.hpp"
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

namespace client::payload {

// Extracted from reference dllmain.cpp's four-pass Java 8 field planner.
// Target contract: compressed oops (4-byte references), 8-byte HeapWords.
// The caller retains fieldsArray for the injected class/session lifetime.
inline bool BuildReferenceFieldPlan(jcfp::ClassFile& cf,
                                   uintptr_t resolvedSuperKlass,
                                   uint32_t mirrorStaticBase,
                                   RawInstanceFieldPlan& out)
{
    const auto fail = [](const char* reason) {
        Log("[FieldLayout] rejected field plan: %s", reason);
        return false;
    };
    constexpr uint64_t u32Max = (std::numeric_limits<uint32_t>::max)();
    constexpr uint64_t u16Max = (std::numeric_limits<uint16_t>::max)();
    if (!resolvedSuperKlass || JvmMapper::Klass::layout_helper < 0
            || JvmMapper::InstanceKlass::nonstatic_field_size < 0
            || JvmMapper::CompactU2Array::length < 0
            || JvmMapper::CompactU2Array::data < 0)
        return fail("missing superclass/layout binding");
    const int32_t parentLayout = JvmApi::SafeRead<int32_t>(
        resolvedSuperKlass + JvmMapper::Klass::layout_helper);
    if (parentLayout <= 0 || mirrorStaticBase == 0 || (mirrorStaticBase & 3u))
        return fail("invalid instance layout or mirror static base");
    const uint64_t parentBytes = static_cast<uint32_t>(parentLayout) & ~1u;
    const uint64_t parentFieldWords = JvmApi::SafeRead<uint32_t>(
        resolvedSuperKlass + JvmMapper::InstanceKlass::nonstatic_field_size);
    const size_t fieldCount = cf.fields.size();
    if (fieldCount > u16Max) return fail("Java field count exceeds u2");

    std::vector<uint32_t> offsets(fieldCount, 0);
    std::vector<std::string> descriptors;
    descriptors.reserve(fieldCount);
    for (const auto& field : cf.fields) {
        if (!field.descriptor_index || field.descriptor_index >= cf.constant_pool.count()
                || cf.constant_pool.get_tag(field.descriptor_index)
                    != jcfp::ConstantPoolEntry::Tag::Utf8)
            return fail("invalid descriptor constant-pool entry");
        const auto& descriptor = cf.constant_pool.get_entry(field.descriptor_index)
            .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
        if (descriptor.empty() || std::strchr("ZBCSIJFDL[", descriptor[0]) == nullptr)
            return fail("invalid field descriptor");
        descriptors.push_back(descriptor);
    }

    uint64_t instanceCursor = parentBytes;
    uint64_t staticCursor = mirrorStaticBase;
    uint64_t firstOopOffset = 0, oopCount = 0, staticOopCount = 0;
    for (int pass = 0; pass < 4; ++pass) {
        for (size_t fi = 0; fi < fieldCount; ++fi) {
            const auto access = static_cast<uint32_t>(cf.fields[fi].access_flags);
            const bool isStatic = (access & 0x0008) != 0;
            const auto& descriptor = descriptors[fi];
            const bool oop = descriptor[0] == 'L' || descriptor[0] == '[';
            if ((pass >= 2) != isStatic || ((pass & 1) == 0) != oop) continue;
            // Preserve the reference layout: references first, then primitive
            // slots; J/D occupy eight bytes and all other slots occupy four.
            const uint64_t width = descriptor[0] == 'J' || descriptor[0] == 'D' ? 8u : 4u;
            uint64_t& cursor = isStatic ? staticCursor : instanceCursor;
            cursor = (cursor + width - 1) & ~(width - 1);
            if (cursor > (u32Max >> JvmMapper::FieldInfo::offset_tag_bits))
                return fail("packed field offset exceeds u4");
            offsets[fi] = static_cast<uint32_t>(cursor);
            if (oop && isStatic) ++staticOopCount;
            else if (oop) {
                if (!firstOopOffset) firstOopOffset = cursor;
                ++oopCount;
            }
            cursor += width;
        }
    }
    const uint64_t instanceBytes = (instanceCursor + 7u) & ~uint64_t(7u);
    const uint64_t nonstaticWords = parentFieldWords + (instanceBytes - parentBytes + 7u) / 8u;
    const uint64_t staticWords = (staticCursor - mirrorStaticBase + 7u) / 8u;
    if (instanceBytes > u32Max || nonstaticWords > u32Max || staticWords > u32Max
            || oopCount > u16Max || staticOopCount > u16Max)
        return fail("field size/count overflow");

    RawInstanceFieldPlan plan{};
    if (fieldCount) {
        const size_t wordCount = fieldCount * JvmMapper::FieldInfo::entry_words;
        if (wordCount > static_cast<size_t>((std::numeric_limits<int32_t>::max)()))
            return fail("field metadata array length exceeds s4");
        const size_t bytes = static_cast<size_t>(JvmMapper::CompactU2Array::data)
            + wordCount * sizeof(uint16_t);
        plan.fieldsArray = reinterpret_cast<uintptr_t>(VirtualAlloc(
            nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!plan.fieldsArray) return fail("field metadata allocation failed");
        std::memset(reinterpret_cast<void*>(plan.fieldsArray), 0, bytes);
        *reinterpret_cast<int32_t*>(plan.fieldsArray + JvmMapper::CompactU2Array::length)
            = static_cast<int32_t>(wordCount);
        auto* words = reinterpret_cast<uint16_t*>(
            plan.fieldsArray + JvmMapper::CompactU2Array::data);
        for (size_t fi = 0; fi < fieldCount; ++fi) {
            const auto& field = cf.fields[fi];
            auto* entry = words + fi * JvmMapper::FieldInfo::entry_words;
            entry[JvmMapper::FieldInfo::initval_index_word] = 0;
            entry[JvmMapper::FieldInfo::access_flags_word] = static_cast<uint16_t>(field.access_flags);
            entry[JvmMapper::FieldInfo::signature_index_word] = field.descriptor_index;
            entry[JvmMapper::FieldInfo::name_index_word] = field.name_index;
            const uint32_t packed = (offsets[fi] << JvmMapper::FieldInfo::offset_tag_bits) | 1u;
            entry[JvmMapper::FieldInfo::low_offset_word] = static_cast<uint16_t>(packed);
            entry[JvmMapper::FieldInfo::high_offset_word] = static_cast<uint16_t>(packed >> 16);
            Log("[FieldLayout] field=%zu offset=%u access=0x%04X", fi, offsets[fi],
                static_cast<unsigned>(field.access_flags));
        }
    }
    plan.javaFieldCount = static_cast<uint16_t>(fieldCount);
    plan.instanceSizeBytes = static_cast<uint32_t>(instanceBytes);
    plan.nonstaticFieldWords = static_cast<uint32_t>(nonstaticWords);
    plan.oopOffsetBytes = static_cast<uint32_t>(firstOopOffset);
    plan.oopCount = static_cast<uint32_t>(oopCount);
    plan.staticFieldWords = static_cast<uint32_t>(staticWords);
    plan.staticOopCount = static_cast<uint16_t>(staticOopCount);
    out = plan;
    Log("[FieldLayout] instance_bytes=%u static_words=%u static_oops=%u fields=%u",
        plan.instanceSizeBytes, plan.staticFieldWords, plan.staticOopCount, plan.javaFieldCount);
    return true;
}

inline bool DeriveReferenceMirrorStaticBase(uint32_t& out)
{
    const auto system = JvmApi::FindClass("java/lang/System");
    if (!system) return false;
    uint32_t base = (std::numeric_limits<uint32_t>::max)();
    for (const auto& field : JvmApi::GetFields(system))
        if ((field.access_flags & 0x0008) && field.offset < base) base = field.offset;
    if (base == (std::numeric_limits<uint32_t>::max)() || (base & 3u)) return false;
    out = base;
    return true;
}

} // namespace client::payload
