#pragma once

namespace client::class_jar {

// Derives output.jar from the loader-provided commonLuke.log path.
void ConfigureOutputPath(const wchar_t* logPath) noexcept;

// Starts the HotSpot metadata reconstructor on a low-priority native worker.
// No JNI or Java class-loader calls are made.
void Start() noexcept;

} // namespace client::class_jar
