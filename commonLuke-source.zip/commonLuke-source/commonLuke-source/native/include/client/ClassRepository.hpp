#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include <jni.h>
#include "ClassScanner.hpp"

namespace client::classes {
struct MethodRecord {
    MethodInfo metadata;
    std::vector<std::uint8_t> bytecode;
    bool bytecodeReadable = false;
};
struct ClassRecord {
    std::string name;
    std::uintptr_t klass = 0;
    std::uintptr_t loaderData = 0;
    std::vector<FieldInfo> fields;
    std::vector<MethodRecord> methods;
};
struct Snapshot {
    std::vector<ClassRecord> classes;
    // A name can occur under several class loaders.
    std::unordered_map<std::string, std::vector<std::size_t>> byName;
    std::unordered_map<std::uintptr_t, std::size_t> byKlass;
};
void Capture(JNIEnv* environment = nullptr);
std::shared_ptr<const Snapshot> GetSnapshot();
}
