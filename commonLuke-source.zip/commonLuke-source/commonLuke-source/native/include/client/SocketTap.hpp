#pragma once

#include <cstdint>

namespace client::socket_tap {

// Uses the loader-provided log path as the stable output location. The capture
// is written beside it with a .nio.bin suffix.
void ConfigureCapturePath(const wchar_t* logPath) noexcept;

// Installs passive hooks on the JDK NIO SocketDispatcher exports. No Java
// methods are invoked and the network buffers are never modified.
bool Install() noexcept;

// Pins interception to the socket owned by the mapped live NioSocketChannel.
// SocketTap never guesses ownership from unrelated process traffic.
bool BindTransport(std::uintptr_t socket) noexcept;

// Releases the socket/cipher ownership when the live Netty pipeline changes.
// The next fully initialized cipher pair binds the replacement transport.
void ResetTransport() noexcept;

} // namespace client::socket_tap
