#pragma once
#include "features/visual/esp/Esp.hpp"
#include "render/GlApi.hpp"
#include "render/LegacyGuiState.hpp"
#include <jni.h>
#include <memory>
#include <unordered_map>
namespace client::game {
// Owns GPU atlases only; Java references are borrowed for the current call.
class GuiAtlas {
 struct CacheSnapshot;
 std::unique_ptr<CacheSnapshot> cache_;
 struct Target { GLuint fbo=0,texture=0,depth=0; int width=0,height=0; };
 Target items_,text_,models_;
 int itemSlot_=0,textX_=0,textY_=0;
 std::unordered_map<std::string,features::esp::Image> textCache_;
 JNIEnv* env_=nullptr;
 jobject minecraft_=nullptr,renderer_=nullptr,font_=nullptr;
 bool ready_=false;
 bool itemsCleared_=false,textCleared_=false,modelsCleared_=false;
 std::unique_ptr<render::LegacyGuiState> saved_;
 bool TargetReady(Target& target,int width,int height);
 void Bind(Target& target);
public:
 GuiAtlas();
 ~GuiAtlas();
 bool Begin(JNIEnv* env,jobject minecraft);
 void End();
 features::esp::Image Item(jobject stack);
 features::esp::Image Model(jobject entity);
 features::esp::Image Text(const std::string& text);
};
}
