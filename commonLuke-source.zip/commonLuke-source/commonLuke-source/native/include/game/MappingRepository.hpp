#pragma once
#include "client/HotSpotAccess.hpp"
#include "client/HotSpotRuntime.hpp"
#include "client/MethodManager.hpp"
#include <cstdint>
#include <string_view>
#include <vector>
namespace client::mapping {
struct Symbol { std::string_view name, descriptor; };
std::string_view ClassName(std::string_view alias);
std::optional<Symbol> Field(std::string_view key);
std::optional<Symbol> Method(std::string_view key);
const classes::ClassRecord* Class(std::string_view alias);
// Snapshot-bound variants: callers resolving many keys against one snapshot
// must hold the shared_ptr for the duration to keep records alive.
const classes::ClassRecord* Class(std::string_view alias, const classes::Snapshot& snapshot);
const classes::ClassRecord* RuntimeClass(jobject object);
std::optional<FieldInfo> ResolveField(std::string_view key);
std::optional<FieldInfo> ResolveField(std::string_view key, const classes::Snapshot& snapshot);
std::uintptr_t Oop(jobject handle);
jobject Root(JNIEnv* env,std::uintptr_t oop);
jobject Global(JNIEnv* env,jobject source);
void ReleaseGlobal(JNIEnv* env,jobject& global);
jobject Object(JNIEnv* env,jobject receiver,std::string_view key);
jobject StaticObject(JNIEnv* env,std::string_view key);
std::uintptr_t StaticAddress(std::string_view key);
// Writes object references through HotSpot's BarrierSet so the GC write
// barrier is preserved. Returns false on any resolution failure.
bool WriteStaticObject(JNIEnv* env,std::string_view key,jobject value);
bool WriteObject(JNIEnv* env,jobject receiver,std::string_view key,jobject value);
// jclass mirror for a mapped class alias (for array class creation).
jclass StaticMirror(JNIEnv* env,std::string_view alias);
bool Instance(jobject object,std::string_view alias);
bool Instance(JNIEnv* env,jobject object,std::string_view alias);
struct InstanceInfo {
    std::uint32_t bits = 0;
    bool resolved = false;
};
// Single super-chain walk testing membership against pre-resolved klass
// addresses. Bit i of bits corresponds to targets[i]; unresolved targets
// (0) never match. resolved mirrors RuntimeClass(object) != nullptr.
InstanceInfo InstanceMask(jobject object, const std::vector<std::uintptr_t>& targets);
methods::Result Invoke(JNIEnv* env,jobject receiver,std::string_view key,const std::vector<methods::Argument>& args={});
jobject Allocate(JNIEnv* env,std::string_view alias);
jobject New(JNIEnv* env,std::string_view constructor,const std::vector<methods::Argument>& args={});
// One-shot diagnostic: reports how the current class snapshot resolves a fixed
// set of probe names. Read-only; never triggers Capture or class loading.
void DiagnoseSnapshot(JNIEnv* env);
std::optional<std::string> String(JNIEnv* env,jobject receiver,std::string_view key);
template<class T> std::optional<T> Read(jobject receiver,std::string_view key) {
 const auto field=ResolveField(key); const auto oop=Oop(receiver);
 if(!field || !oop) return {};
 return hotspot::Read<T>(oop+field->offset);
}
template<class T> std::optional<T> Read(JNIEnv* env,jobject receiver,std::string_view key) {
 static_assert(std::is_trivially_copyable_v<T>);
 const auto field=ResolveField(key);T value{};
 if(!field || !hotspot::runtime::LoadPrimitive(env,receiver,field->offset,&value,sizeof(value)))return {};
 return value;
}
template<class T> bool Write(jobject receiver,std::string_view key,const T& value) {
 const auto field=ResolveField(key); const auto oop=Oop(receiver);
 if(!field || !oop) return false;
 return hotspot::WritePrimitive(oop+field->offset,value);
}
template<class T> std::optional<T> ReadStatic(std::string_view key) {
 const auto address=StaticAddress(key);
 return address?hotspot::Read<T>(address):std::nullopt;
}
template<class T> bool WriteStatic(std::string_view key,const T& value) {
 const auto address=StaticAddress(key);
 return address&&hotspot::WritePrimitive(address,value);
}
}
