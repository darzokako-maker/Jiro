#pragma once

#include <cstdint>
#include <array>

#pragma pack(push, 8)
struct AsmProjectParams {
    // 0: Bounds
    double minX;      // offset 0
    double minY;      // offset 8
    double minZ;      // offset 16
    double maxX;      // offset 24
    double maxY;      // offset 32
    double maxZ;      // offset 40

    // 48: Positions
    double posX;      // offset 48
    double posY;      // offset 56
    double posZ;      // offset 64
    double lastX;     // offset 72
    double lastY;     // offset 80
    double lastZ;     // offset 88
    double camX;      // offset 96
    double camY;      // offset 104
    double camZ;      // offset 112

    // 120: Controls
    float partial;    // offset 120
    int32_t sneaking; // offset 124

    // 128: Matrices (16 floats each = 64 bytes each, column-major)
    float model[16];      // offset 128
    float projection[16]; // offset 192

    // 256: Viewport & Screen
    int32_t viewport[4];       // offset 256: x, y, width, height (16 bytes)
    int32_t framebufferHeight; // offset 272
    int32_t pad;               // offset 276
};
#pragma pack(pop)
static_assert(sizeof(AsmProjectParams) == 280, "AsmProjectParams size mismatch with ASM layout");

struct AsmScreenBox {
    float x;
    float y;
    float right;
    float bottom;
};

extern "C" {
    // Pure x64 MASM implementations:
    // Returns 1 if box is valid and on-screen, 0 otherwise.
    int asm_ProjectScalar(const AsmProjectParams* params, AsmScreenBox* outBox);
    int asm_ProjectAVX2(const AsmProjectParams* params, AsmScreenBox* outBox);
}

namespace client::asm_math {

enum class ProjectionBackend {
    Auto,
    AsmAVX2,
    AsmScalar,
    OptimizedCpp,
    ReferenceCpp
};

bool HasAVX2AndFMA() noexcept;

void SetProjectionBackend(ProjectionBackend b) noexcept;
ProjectionBackend GetProjectionBackend() noexcept;
const char* GetProjectionBackendName(ProjectionBackend b) noexcept;

int ProjectReferenceCpp(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept;
int ProjectOptimizedCpp(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept;

int ProjectDispatch(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept;
int ProjectWithBackend(ProjectionBackend backend, const AsmProjectParams* params, AsmScreenBox* outBox) noexcept;

} // namespace client::asm_math

