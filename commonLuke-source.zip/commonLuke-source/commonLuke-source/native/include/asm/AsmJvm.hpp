#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>

// Pure x64 MASM JVM field-access kernels.
//
// Safety contract: every kernel performs raw JVM heap/metadata reads with no
// internal guard. Callers MUST go through the client::asm_jvm bridge, which
// wraps each call in a single __try/__except region per invocation. A fault
// discards the whole call result; partially gathered data is never published.
//
// GC model (verified against OpenJDK 8u492 safepoint.cpp): a thread executing
// native code is NOT a safepoint participant — the VM does not wait for it.
// A moving GC initiated by another thread can therefore relocate objects while
// a kernel runs. SEH only catches unmapped accesses; it does NOT validate that
// a read oop is still current. The mitigation is identical to the pre-existing
// C++ path: jobject handles are re-resolved via mapping::Oop() immediately
// before use (handles are GC roots and stay valid), raw oops are never held
// across JNI/VM calls or allocations, and each kernel window is bounded to a
// few reads. A stale-but-mapped read can yield transient garbage for one
// frame; it cannot be silently retained because results are re-captured every
// frame and filtered by the same isfinite/validity checks as before.

extern "C" {
    // int asm_DecodePointer(uintptr_t fieldAddress, uint32_t compressed,
    //                       uintptr_t narrowBase, uint32_t narrowShift,
    //                       uint32_t nullIsZero, uintptr_t* out)
    // compressed!=0: reads u32 narrow ref -> narrowBase + (narrow << shift);
    //   narrow==0 -> nullIsZero ? 0 : narrowBase.
    // compressed==0: reads full u64 pointer.
    // Returns 0 on success (out always written), never faults by contract.
    int asm_DecodePointer(std::uintptr_t fieldAddress, std::uint32_t compressed,
        std::uintptr_t narrowBase, std::uint32_t narrowShift,
        std::uint32_t nullIsZero, std::uintptr_t* out);

    // uint32_t asm_InstanceWalk(uintptr_t klass, uintptr_t superOffset,
    //                           const uintptr_t* targets, uint32_t count)
    // Walks the Klass.super chain (max 64 levels) and returns a bitmask:
    // bit i set when some level equals targets[i]. count must be <= 32.
    // Identical match semantics to client::mapping::Instance / InstanceMask.
    std::uint32_t asm_InstanceWalk(std::uintptr_t klass, std::uintptr_t superOffset,
        const std::uintptr_t* targets, std::uint32_t count);

    // int asm_GatherFields(const AsmGatherJob* job)
    // Copies typed fields from job->oop into job->out following the op table.
    // Returns 0 on success, 1 on an invalid op (bad size/kind or bounds).
    int asm_GatherFields(const void* job);
}

namespace client::asm_jvm {

struct FieldOp {
    std::uint32_t offset; // field offset within the source oop
    std::uint32_t dest;   // destination offset within the out buffer
    std::uint32_t size;   // copy size for OpCopy (1/2/4/8); ignored for OpRef
    std::uint32_t kind;   // FieldOpKind
};

enum FieldOpKind : std::uint32_t {
    OpCopy = 0, // raw copy of size bytes
    OpRef  = 1  // compressed-or-wide object reference decode -> uintptr_t (8 bytes)
};

// Must match the offsets used by asm_GatherFields exactly.
struct GatherJob {
    std::uintptr_t oop;        // 0x00
    const FieldOp* ops;        // 0x08
    std::uint32_t count;       // 0x10
    std::uint32_t pad0;        // 0x14
    void* out;                 // 0x18
    std::uint32_t outSize;     // 0x20
    std::uint32_t refCompressed; // 0x24
    std::uintptr_t refBase;    // 0x28
    std::uint32_t refShift;    // 0x30
    std::uint32_t refNullIsZero; // 0x34
};
static_assert(sizeof(GatherJob) == 0x38, "GatherJob layout mismatch with ASM");
static_assert(offsetof(GatherJob, oop) == 0x00, "GatherJob.oop offset");
static_assert(offsetof(GatherJob, ops) == 0x08, "GatherJob.ops offset");
static_assert(offsetof(GatherJob, count) == 0x10, "GatherJob.count offset");
static_assert(offsetof(GatherJob, out) == 0x18, "GatherJob.out offset");
static_assert(offsetof(GatherJob, outSize) == 0x20, "GatherJob.outSize offset");
static_assert(offsetof(GatherJob, refCompressed) == 0x24, "GatherJob.refCompressed offset");
static_assert(offsetof(GatherJob, refBase) == 0x28, "GatherJob.refBase offset");
static_assert(offsetof(GatherJob, refShift) == 0x30, "GatherJob.refShift offset");
static_assert(offsetof(GatherJob, refNullIsZero) == 0x34, "GatherJob.refNullIsZero offset");

// Guarded bridges: one SEH region per call. Return false/0 on any fault.
// tag classifies GatherFields callers for diagnostics: 0=other, 1=entity,
// 2=boundingBox. It does not affect kernel behavior.
bool DecodePointer(std::uintptr_t fieldAddress, bool compressed,
    std::uintptr_t narrowBase, unsigned narrowShift, bool nullIsZero,
    std::uintptr_t* out);
std::uint32_t InstanceWalk(std::uintptr_t klass, std::uintptr_t superOffset,
    const std::uintptr_t* targets, std::uint32_t count);
bool GatherFields(const GatherJob* job, std::uint32_t tag = 0);

// Bridge-level diagnostics (temporary ESP regression debugging).
struct AsmDebugCounters {
    std::atomic<std::uint64_t> decodeCalls{0}, decodeFailures{0}, decodeExceptions{0},
        decodeNullAddress{0}, decodeInvalidConfig{0};
    std::atomic<std::uint64_t> walkCalls{0}, walkExceptions{0}, walkZeroMask{0}, walkMatched{0};
    std::atomic<std::uint64_t> gatherCalls{0}, gatherOk{0}, gatherInvalidOp{0}, gatherExceptions{0};
    std::atomic<std::uint64_t> gatherEntityCalls{0}, gatherEntityOk{0}, gatherEntityFail{0};
    std::atomic<std::uint64_t> gatherBoxCalls{0}, gatherBoxOk{0}, gatherBoxFail{0};
};
inline AsmDebugCounters debugCounters{};

struct AsmDebugSnapshot {
    std::uint64_t decodeCalls, decodeFailures, decodeExceptions,
        decodeNullAddress, decodeInvalidConfig;
    std::uint64_t walkCalls, walkExceptions, walkZeroMask, walkMatched;
    std::uint64_t gatherCalls, gatherOk, gatherInvalidOp, gatherExceptions;
    std::uint64_t gatherEntityCalls, gatherEntityOk, gatherEntityFail;
    std::uint64_t gatherBoxCalls, gatherBoxOk, gatherBoxFail;
};
// Exchanges all bridge counters to zero and returns the window snapshot.
AsmDebugSnapshot TakeAsmDebug();
// Exercises all three kernels against fabricated stack data (no JVM access).
bool SelfTest();

} // namespace client::asm_jvm
