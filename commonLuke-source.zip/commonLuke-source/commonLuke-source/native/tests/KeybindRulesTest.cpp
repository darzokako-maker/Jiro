#include "ui/input/KeybindRules.hpp"

#include <cstdlib>
#include <iostream>

int main() {
    using client::ui::bindings::rules::ModuleKeyRemoved;

    if (!ModuleKeyRemoved('F', 0)) {
        std::cerr << "FAIL: clearing an assigned module key is a removal\n";
        return EXIT_FAILURE;
    }
    if (ModuleKeyRemoved(0, 0) || ModuleKeyRemoved('F', 'G') || ModuleKeyRemoved(0, 'F')) {
        std::cerr << "FAIL: unchanged, replaced, or newly assigned keys are not removals\n";
        return EXIT_FAILURE;
    }

    std::cout << "KeybindRulesTest: PASS\n";
    return EXIT_SUCCESS;
}
