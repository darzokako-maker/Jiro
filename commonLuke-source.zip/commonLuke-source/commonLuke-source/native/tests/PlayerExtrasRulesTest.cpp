#include "features/utility/extra_modules/ExtraModuleRules.hpp"

#include <cstdlib>
#include <iostream>
#include <string_view>

namespace {
int failures = 0;
void Check(bool condition, std::string_view name) {
    if (!condition) {
        ++failures;
        std::cerr << "FAIL: " << name << '\n';
    }
}
}

int main() {
    using namespace client::features::extras::rules;

    Check(SpoofGround(true, true, false),
          "SpoofGround forces movement packets on ground");
    Check(!SpoofGround(false, true, false),
          "disabled SpoofGround preserves movement packet state");
    Check(!SpoofGround(true, false, false),
          "SpoofGround ignores non-movement packets");

    Check(MlgReady(4.0f, -0.4, false, false, false, false),
          "MLG activates for a damaging downward fall");
    Check(!MlgReady(2.9f, -0.4, false, false, false, false),
          "MLG ignores harmless short falls");
    Check(!MlgReady(4.0f, -0.4, false, true, false, false),
          "MLG ignores falls already in water");
    Check(MlgTrackedFall(1.25f, -0.75, false) == 2.0f,
          "MLG accumulates measured downward position changes");
    Check(MlgTrackedFall(2.0f, 0.25, false) == 0.0f,
          "MLG clears measured fall while rising");
    Check(MlgTrackedFall(2.0f, -0.25, true) == 0.0f,
          "MLG clears measured fall on landing");
    Check(MlgWithinReach({0.5, 5.0, 0.5}, {0, 0, 0}),
          "MLG accepts a support inside placement reach");
    Check(!MlgWithinReach({0.5, 6.0, 0.5}, {0, 0, 0}),
          "MLG waits while the support is outside placement reach");

    Check(FastPlaceDelay(4, true) == 0,
          "FastPlace removes the block placement delay");
    Check(FastPlaceDelay(4, false) == 4,
          "FastPlace leaves non-block items untouched");
    Check(FastPlaceLimiterValue() == 99,
          "FastPlace raises the client CPS limiter to 99 while active");
    Check(AutoClickInterval(1.f) == 1000 && AutoClickInterval(20.f) == 50,
          "AutoClicker scheduler interval follows configured CPS");


    if (failures) return EXIT_FAILURE;
    std::cout << "PlayerExtrasRulesTest: PASS\n";
    return EXIT_SUCCESS;
}
