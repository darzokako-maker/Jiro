#include "features/combat/common/AttackTargetRules.hpp"

#include <cstdlib>
#include <iostream>

namespace {

void Check(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "AttackTargetRulesTest: " << message << '\n';
        std::exit(1);
    }
}

} // namespace

int main() {
    using client::features::combat::targets::rules::HasBoldFormatting;

    Check(HasBoldFormatting("\xC2\xA7lNPC"), "UTF-8 bold code must mark an NPC");
    Check(HasBoldFormatting("\xC2\xA7" "a[SHOP] \xC2\xA7" "LMerchant"),
          "uppercase bold code must mark an NPC");
    Check(HasBoldFormatting("\xA7lLegacy"), "legacy section-sign byte must be accepted");
    Check(!HasBoldFormatting("\xC2\xA7" "aRealPlayer"), "colour alone must not mark an NPC");
    Check(!HasBoldFormatting("RealPlayer"), "plain names must remain players");
    Check(!HasBoldFormatting("&lLiteralText"), "ampersand text is not game formatting");

    std::cout << "AttackTargetRulesTest: PASS\n";
    return 0;
}
