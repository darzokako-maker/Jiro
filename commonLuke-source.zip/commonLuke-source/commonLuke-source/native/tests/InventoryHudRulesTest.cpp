#include "features/visual/inventory_hud/InventoryHudRules.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>

namespace {

void Check(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "InventoryHudRulesTest: " << message << '\n';
        std::exit(1);
    }
}

bool Near(float left, float right) {
    return std::abs(left - right) < 0.001f;
}

} // namespace

int main() {
    using client::features::inventory_hud::rules::LayoutForScale;
    using client::features::inventory_hud::rules::InventoryIndex;
    constexpr float spotifyScale = 0.936f;
    const auto layout = LayoutForScale(spotifyScale);

    Check(Near(layout.cardWidth, 314.0f * spotifyScale), "width must match SpotifyWidget");
    Check(Near(layout.cardHeight, 151.0f * spotifyScale), "height must match SpotifyWidget");
    Check(Near(layout.gridWidth, layout.cell * 9.0f), "nine columns must fill the grid exactly");
    Check(Near(layout.gridHeight, layout.cell * 4.0f), "four rows must fill the grid exactly");
    Check(Near(layout.gridLeft * 2.0f + layout.gridWidth, layout.cardWidth),
          "grid must be horizontally centred");
    Check(Near(layout.gridTop + layout.gridHeight + layout.bottomInset, layout.cardHeight),
          "vertical proportions must close exactly");
    Check(layout.iconSize < layout.cell, "item renderer must remain inside its square cell");
    Check(layout.dashLength < layout.dashGap, "separators must use small broken strokes");
    Check(InventoryIndex(0, 0) == 9 && InventoryIndex(2, 8) == 35,
          "storage rows must preserve Minecraft inventory order");
    Check(InventoryIndex(3, 0) == 0 && InventoryIndex(3, 8) == 8,
          "hotbar must occupy the bottom row");

    std::cout << "InventoryHudRulesTest: PASS\n";
    return 0;
}
