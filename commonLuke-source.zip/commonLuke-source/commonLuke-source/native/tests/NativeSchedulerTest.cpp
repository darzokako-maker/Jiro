#include "client/NativeScheduler.hpp"

#include <cstdlib>
#include <iostream>

namespace {

void Check(bool condition, const char* message)
{
    if (condition) return;
    std::cerr << "NativeSchedulerTest: " << message << '\n';
    std::exit(1);
}

void DeadlinePublishesOnlyWhenDue()
{
    using namespace client::scheduler;
    detail::DeadlineBank bank;
    Cursor cursor;
    bank.Configure(Task::AutoClicker, true, 10);
    bank.Advance(100);
    bank.Advance(109);
    Check(!bank.Consume(Task::AutoClicker, cursor), "deadline fired early");
    bank.Advance(110);
    Check(bank.Consume(Task::AutoClicker, cursor), "deadline did not publish");
    Check(!bank.Consume(Task::AutoClicker, cursor), "one generation consumed twice");
}

void StallCoalescesMissedPeriods()
{
    using namespace client::scheduler;
    detail::DeadlineBank bank;
    Cursor cursor;
    bank.Configure(Task::AutoClicker, true, 10);
    bank.Advance(100);
    bank.Advance(200);
    Check(bank.Consume(Task::AutoClicker, cursor), "stalled task did not publish");
    Check(!bank.Consume(Task::AutoClicker, cursor), "stall produced a catch-up burst");
    bank.Advance(209);
    Check(!bank.Consume(Task::AutoClicker, cursor), "post-stall deadline drifted early");
    bank.Advance(210);
    Check(bank.Consume(Task::AutoClicker, cursor), "post-stall cadence was not preserved");
}

void IdenticalConfigurationDoesNotPostponeDeadline()
{
    using namespace client::scheduler;
    detail::DeadlineBank bank;
    Cursor cursor;
    bank.Configure(Task::AutoClicker, true, 50);
    bank.Advance(100);
    bank.Configure(Task::AutoClicker, true, 50);
    bank.Advance(140);
    bank.Advance(150);
    Check(bank.Consume(Task::AutoClicker, cursor), "identical configuration postponed deadline");
}

void ChangedConfigurationRestartsDeadline()
{
    using namespace client::scheduler;
    detail::DeadlineBank bank;
    Cursor cursor;
    bank.Configure(Task::AutoClicker, true, 10);
    bank.Advance(100);
    bank.Configure(Task::AutoClicker, true, 25);
    bank.Advance(105);
    bank.Advance(110);
    Check(!bank.Consume(Task::AutoClicker, cursor), "stale deadline survived reconfiguration");
    bank.Advance(130);
    Check(bank.Consume(Task::AutoClicker, cursor), "changed interval did not restart deadline");
}

void DisabledAndZeroIntervalsStayIdle()
{
    using namespace client::scheduler;
    detail::DeadlineBank bank;
    Cursor cursor;
    bank.Configure(Task::AutoClicker, false, 10);
    bank.Advance(100);
    bank.Advance(1000);
    Check(!bank.Consume(Task::AutoClicker, cursor), "disabled task published");
    bank.Configure(Task::AutoClicker, true, 0);
    bank.Advance(1000);
    bank.Advance(2000);
    Check(!bank.Consume(Task::AutoClicker, cursor), "zero interval task published");
}

void RuntimePrefersHighResolutionThenFallsBack()
{
    using namespace client::scheduler::detail;
    Check(TimerFlagsForAttempt(0) == HighResolutionTimerFlag,
          "runtime did not request high-resolution timer first");
    Check(TimerFlagsForAttempt(1) == 0,
          "runtime did not fall back to a compatible timer");
}

void StopSignalWinsOverTimerTick()
{
    using namespace client::scheduler::detail;
    Check(SelectWake(true, true) == Wake::Stop,
          "timer tick won over shutdown");
    Check(SelectWake(false, true) == Wake::Tick,
          "timer signal was not selected");
    Check(SelectWake(false, false) == Wake::None,
          "unsignaled handles produced work");
}

void WorkerClockIsPublishedAtomically()
{
    using namespace client::scheduler;
    detail::PublishNow(123456);
    Check(Now() == 123456, "consumer did not observe worker clock");
    detail::PublishNow(123999);
    Check(Now() == 123999, "worker clock update was lost");
}

}

int main()
{
    DeadlinePublishesOnlyWhenDue();
    StallCoalescesMissedPeriods();
    IdenticalConfigurationDoesNotPostponeDeadline();
    ChangedConfigurationRestartsDeadline();
    DisabledAndZeroIntervalsStayIdle();
    RuntimePrefersHighResolutionThenFallsBack();
    StopSignalWinsOverTimerTick();
    WorkerClockIsPublishedAtomically();
    std::cout << "NativeSchedulerTest: PASS\n";
    return 0;
}
