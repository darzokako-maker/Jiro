#include "features/player/scaffold/ScaffoldRules.hpp"

#include <cstdlib>
#include <iostream>
#include <optional>

using namespace client::features::scaffold;

namespace {

void Check(bool condition, const char* message) {
    if (condition) return;
    std::cerr << "ScaffoldRulesTest: " << message << '\n';
    std::exit(1);
}

void ExistingPlacementBehaviorIsPreserved() {
    auto world = [](BlockPos pos) -> std::optional<bool> {
        return pos != BlockPos{-1, 62, 0};
    };
    const Vec3 player{-.25, 64, .5};
    const auto target = FindTarget(player, {}, {}, world);
    Check(target && Floor(*target) == BlockPos{-1, 63, 0},
          "negative-coordinate target changed");

    const auto support = FindSupport(*target, 0, false, world);
    Check(support && support->face == Face::Up, "support below target changed");
    Check(!FindTarget(player, {}, 70, world), "Same Y plane filter changed");

    auto above = [](BlockPos pos) -> std::optional<bool> {
        return pos != BlockPos{-1, 64, 0};
    };
    Check(!FindSupport(*target, 0, false, above),
          "above support accepted without downwards mode");
    const auto downward = FindSupport(*target, 0, true, above);
    Check(downward && downward->face == Face::Down,
          "downwards support selection changed");

    const auto hit = RandomHit({-1, 62, 0}, Face::East, {.25, .5, .75});
    Check(hit.x == 0 && hit.y == 62.5 && hit.z == .75,
          "random hit face projection changed");
}

void EqualDistanceKeepsOriginalStableWinner() {
    auto world = [](BlockPos pos) -> std::optional<bool> {
        return pos != BlockPos{-1, 63, 0} && pos != BlockPos{1, 63, 0};
    };
    const auto target = FindTarget(Vec3{.5, 64, .5}, {}, {}, world);
    Check(target && Floor(*target) == BlockPos{0, 63, 0},
          "equal-distance stable target changed");
}

void LookupFailureReturnsNoTarget() {
    int calls = 0;
    auto unavailable = [&](BlockPos) -> std::optional<bool> {
        ++calls;
        return std::nullopt;
    };
    Check(!FindTarget(Vec3{.5, 64, .5}, {}, {}, unavailable),
          "lookup failure produced a target");
    Check(calls == 1, "lookup continued after failure");
}

void AllAirSearchHasBoundedWorldQueries() {
    int calls = 0;
    const auto allAir = [&](BlockPos) -> std::optional<bool> {
        ++calls;
        return true;
    };
    Check(!FindTarget(Vec3{.5, 64, .5}, {}, {}, allAir),
          "all-air world produced a target");
    // A radius-five candidate sphere plus its one-block shell contains 805
    // unique positions. The old 11^3 solid-first scan performs 1,331 calls.
    Check(calls <= 805, "all-air search exceeded the native query budget");
}

void PlacementCacheIsSharedWithSupportSelection() {
    int repeatCalls = 0;
    auto repeatWorld = [&](BlockPos) -> std::optional<bool> {
        ++repeatCalls;
        return true;
    };
    ReplaceableCache repeatCache(repeatWorld);
    (void)repeatCache({0, 63, -1});
    (void)repeatCache({0, 63, -1});
    Check(repeatCalls == 1, "cache did not retain an identical block position");

    int calls = 0;
    auto world = [&](BlockPos pos) -> std::optional<bool> {
        ++calls;
        return pos != BlockPos{0, 62, 0};
    };
    ReplaceableCache cache(world);
    const auto target = FindTarget(Vec3{.5, 64, .5}, {}, {}, cache);
    Check(target && Floor(*target) == BlockPos{0, 63, 0},
          "cached target lookup failed");
    const int callsAfterTarget = calls;
    const auto support = FindSupport(*target, 0, false, cache);
    Check(support && support->face == Face::Up,
          "cached support selection failed");
    Check(calls == callsAfterTarget,
          "support selection repeated an already-known world lookup");
}

void HotbarCacheChecksTheKnownSlotFirst() {
    int checks = 0;
    const int cached = FindHotbarSlot(9, 6, [&](int slot) {
        ++checks;
        return slot == 6;
    });
    Check(cached == 6 && checks == 1,
          "valid cached hotbar slot triggered a full scan");

    std::array<int, 9> order{};
    int count = 0;
    const int fallback = FindHotbarSlot(9, 6, [&](int slot) {
        order[count++] = slot;
        return slot == 2;
    });
    Check(fallback == 2, "hotbar fallback did not find the eligible slot");
    Check(count == 4 && order[0] == 6 && order[1] == 0 &&
              order[2] == 1 && order[3] == 2,
          "hotbar fallback order changed or rechecked the cached slot");
}

} // namespace

int main() {
    ExistingPlacementBehaviorIsPreserved();
    EqualDistanceKeepsOriginalStableWinner();
    LookupFailureReturnsNoTarget();
    AllAirSearchHasBoundedWorldQueries();
    PlacementCacheIsSharedWithSupportSelection();
    HotbarCacheChecksTheKnownSlotFirst();
    std::cout << "ScaffoldRulesTest: PASS\n";
}
