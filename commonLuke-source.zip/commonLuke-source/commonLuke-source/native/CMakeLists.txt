enable_language(ASM_MASM)
file(MAKE_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/generated")
find_package(Python3 REQUIRED COMPONENTS Interpreter)
find_package(Java REQUIRED COMPONENTS Development)
execute_process(COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/embed-reference-fonts.py"
    "${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/reference" "${CMAKE_CURRENT_BINARY_DIR}/generated/ReferenceFonts.hpp"
    COMMAND_ERROR_IS_FATAL ANY)
file(GLOB reference_font_assets CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/reference/*")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${reference_font_assets}
    "${PROJECT_SOURCE_DIR}/tools/embed-reference-fonts.py")
set(proxy_jdk "C:/Program Files/Java/jdk-21.0.12/bin")
if(NOT EXISTS "${proxy_jdk}/javac.exe" OR NOT EXISTS "${proxy_jdk}/jar.exe")
    message(FATAL_ERROR "Proxy-compatible JDK 21.0.12 is required at ${proxy_jdk}.")
endif()
set(packet_javac "${proxy_jdk}/javac.exe")
set(packet_jar "${proxy_jdk}/jar.exe")
set(packet_source_root "${PROJECT_SOURCE_DIR}/java/src/main/java")
set(packet_distribution_root "${CMAKE_BINARY_DIR}/packet-hook-distribution-src")
set(packet_java "${packet_distribution_root}/client/packethook/PacketHook.java")
set(packet_original_source "${packet_source_root}/client/packethook/PacketHook.java")
set(packet_classes "${CMAKE_BINARY_DIR}/packet-hook-native-classes")
add_custom_command(OUTPUT "${CMAKE_BINARY_DIR}/packet-hook.jar"
    COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/prepare-packet-hook-distribution.py"
        "${packet_source_root}" "${packet_distribution_root}"
    COMMAND ${CMAKE_COMMAND} -E remove_directory "${packet_classes}"
    COMMAND ${CMAKE_COMMAND} -E make_directory "${packet_classes}"
    COMMAND "${packet_javac}" --release 8 -encoding UTF-8 -d "${packet_classes}"
        "${packet_java}"
    COMMAND "${packet_jar}" cf "${CMAKE_BINARY_DIR}/packet-hook.jar"
        -C "${packet_classes}" client/packethook/PacketHook.class
        -C "${packet_classes}" client/packethook/PacketHook$Listener.class
        -C "${packet_classes}" client/packethook/PacketHook$Handler.class
        -C "${packet_classes}" client/packethook/PacketHook$NativeListener.class
    COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/verify-packet-hook-distribution.py"
        "${CMAKE_BINARY_DIR}/packet-hook.jar"
    DEPENDS "${packet_original_source}"
        "${PROJECT_SOURCE_DIR}/tools/prepare-packet-hook-distribution.py"
        "${PROJECT_SOURCE_DIR}/tools/verify-packet-hook-distribution.py" VERBATIM)
set(packet_embedded_header "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedPacketHook.hpp")
set(packet_embedded_source "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedPacketHook.cpp")
add_custom_command(OUTPUT "${packet_embedded_header}" "${packet_embedded_source}"
    COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/embed-binary.py"
        "${CMAKE_BINARY_DIR}/packet-hook.jar" "${packet_embedded_header}" "${packet_embedded_source}" kEmbeddedPacketHook
    DEPENDS "${CMAKE_BINARY_DIR}/packet-hook.jar" "${PROJECT_SOURCE_DIR}/tools/embed-binary.py" VERBATIM)
set_source_files_properties("${packet_embedded_source}" PROPERTIES GENERATED TRUE)
add_custom_target(packet_hook_payload DEPENDS "${packet_embedded_header}" "${packet_embedded_source}")
execute_process(COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/generate-mappings.py"
    "${CMAKE_CURRENT_SOURCE_DIR}/mappings/client.json" "${CMAKE_CURRENT_BINARY_DIR}/generated/ClientMappings.hpp"
    COMMAND_ERROR_IS_FATAL ANY)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
    mappings/client.json
    ${PROJECT_SOURCE_DIR}/tools/generate-mappings.py)
execute_process(COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/generate-injection-profile.py"
    "${PROJECT_SOURCE_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/generated/InjectionLayout.hpp"
    COMMAND_ERROR_IS_FATAL ANY)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
    ${PROJECT_SOURCE_DIR}/tools/generate-injection-profile.py)
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedFonts.hpp" "#pragma once\n")
foreach(weight Regular Medium SemiBold)
    file(READ "${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/Fredoka-${weight}.ttf" font_hex HEX)
    string(REGEX REPLACE "(..)" "0x\\1," font_bytes "${font_hex}")
    string(REPLACE "-" "" symbol "${weight}")
    file(APPEND "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedFonts.hpp"
        "inline const unsigned char kFredoka${symbol}[] = {${font_bytes}};\n")
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "assets/fonts/Fredoka-${weight}.ttf")
endforeach()
file(READ "${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/TablerIcons-subset.ttf" font_hex HEX)
string(REGEX REPLACE "(..)" "0x\\1," font_bytes "${font_hex}")
file(APPEND "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedFonts.hpp" "inline const unsigned char kTablerIcons[] = {${font_bytes}};\n")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS assets/fonts/TablerIcons-subset.ttf)
set(watermark_logo "${PROJECT_SOURCE_DIR}/loader/assets/commonLuke-logo.png")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${watermark_logo}")
file(READ "${watermark_logo}" watermark_hex HEX)
string(REGEX REPLACE "(..)" "0x\\1," watermark_bytes "${watermark_hex}")
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/generated/GuiLogo.hpp" "#pragma once\ninline const unsigned char kWatermarkLogo[] = {${watermark_bytes}};\n")
file(READ "${CMAKE_CURRENT_SOURCE_DIR}/assets/textures/dragon-wings.png" wings_hex HEX)
string(REGEX REPLACE "(..)" "0x\\1," wings_bytes "${wings_hex}")
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/generated/DragonWingsTexture.hpp" "#pragma once\ninline const unsigned char kDragonWingsTexture[] = {${wings_bytes}};\n")
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS assets/textures/dragon-wings.png)


include("${CMAKE_CURRENT_SOURCE_DIR}/cmake/FeatureSources.cmake")

add_executable(seed_dump_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/seed-dumper-smoke/CodecTest.cpp
    src/features/utility/seed_dumper/SeedDump.cpp)
target_include_directories(seed_dump_test PRIVATE include)
target_compile_features(seed_dump_test PRIVATE cxx_std_20)
add_test(NAME seed_dump_codec COMMAND seed_dump_test)

set(clickgui_background "${CMAKE_CURRENT_SOURCE_DIR}/assets/textures/clickgui-planetaria.png")
set(clickgui_background_header "${CMAKE_CURRENT_BINARY_DIR}/generated/ClickGuiBackground.hpp")
set(clickgui_background_source "${CMAKE_CURRENT_BINARY_DIR}/generated/ClickGuiBackground.cpp")
execute_process(COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/embed-binary.py"
    "${clickgui_background}" "${clickgui_background_header}" "${clickgui_background_source}" kClickGuiBackground
    COMMAND_ERROR_IS_FATAL ANY)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
    "${clickgui_background}" "${PROJECT_SOURCE_DIR}/tools/embed-binary.py")


set(hud_sources
    "${clickgui_background_source}"
    src/asm/AsmProjectionScalar.asm
    src/asm/AsmProjectionAVX2.asm
    src/asm/AsmProjectionBridge.cpp
    src/asm/AsmInstanceWalk.asm
    src/asm/AsmFieldGather.asm
    src/asm/AsmJvmBridge.cpp
    src/render/GlApi.cpp
    src/render/Texture.cpp
    src/render/LegacyGuiState.cpp
    src/render/EffectRegion.cpp
    src/render/Renderer.cpp
    src/ui/font/FontManager.cpp
    src/ui/font/ReferenceFont.cpp
    src/ui/animation/AnimatedNumber.cpp
    src/ui/hud/Hud.cpp
    src/ui/hud/HudLayout.cpp
    src/ui/hud/Notifications.cpp
    src/ui/hud/HudState.cpp
    src/ui/clickgui/ClickGui.cpp
    src/ui/clickgui/Controls.cpp
    src/ui/clickgui/ReferencePrimitives.cpp
    src/ui/clickgui/GuiAssets.cpp
    src/ui/clickgui/InputBridge.cpp
    src/ui/input/KeybindManager.cpp
    src/ui/config/ConfigStore.cpp
    ${AOKI_FEATURE_HUD_SOURCES}
    src/render/postprocess/PostProcessor.cpp
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_opengl3.cpp
)
# Reference JAR parser only; no HotSpot internal APIs or runtime startup calls.
set(reference_root "${PROJECT_SOURCE_DIR}/referans/dll")
add_library(aoki_jar_reader STATIC
    src/jvm/JarReader.cpp
    ${reference_root}/src/third_party/miniz/miniz.c
    ${reference_root}/src/third_party/jcfp/attribute.cpp
    ${reference_root}/src/third_party/jcfp/constant_pool.cpp
    ${reference_root}/src/third_party/jcfp/jcfp.cpp
)
# jcfp uses std::expected.
target_compile_features(aoki_jar_reader PUBLIC cxx_std_23)
target_include_directories(aoki_jar_reader PUBLIC
    include
    ${reference_root}/include
    PRIVATE
    ${reference_root}/src
    ${reference_root}/src/io
    ${reference_root}/src/third_party
)
target_compile_definitions(aoki_jar_reader PRIVATE
    WIN32_LEAN_AND_MEAN NOMINMAX _CRT_SECURE_NO_WARNINGS AOKI_DISTRIBUTION=1)
if(MSVC)
    set_property(TARGET aoki_jar_reader PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(aoki_jar_reader PRIVATE /utf-8 /Zc:threadSafeInit-)
endif()

add_library(sonoyuncu_jni SHARED
    "${packet_embedded_source}"
    src/bootstrap/DllMain.cpp
    src/common/NativeScheduler.cpp
    src/hooks/LwjglEnvHook.cpp
    src/hooks/SocketTap.cpp
    src/hooks/NativePacketEngine.cpp
    src/hooks/PacketChatLogger.cpp
    src/render/HudHook.cpp
    ${hud_sources}
    src/jvm/CipherProbe.cpp
    src/jvm/PacketPayload.cpp
    src/jvm/PacketBridge.cpp
    ${AOKI_FEATURE_RUNTIME_SOURCES}
    src/jvm/ClassRepository.cpp
    src/jvm/ClassJarDumper.cpp
    src/jvm/OffsetRepository.cpp
    src/jvm/HotSpotAccess.cpp
    src/jvm/HotSpotRuntime.cpp
    src/jvm/MethodManager.cpp
    src/jvm/MethodDispatch.cpp
    src/game/MappingRepository.cpp
    src/game/GuiAtlas.cpp
    ${AOKI_FEATURE_CAPTURE_SOURCES}
    ${PROJECT_SOURCE_DIR}/referans/dll/src/core/ClassScanner.cpp
)

target_compile_features(sonoyuncu_jni PRIVATE cxx_std_20)
option(AOKI_ENABLE_LOGGING "Enable flushed native diagnostics in distribution builds" ON)
if(AOKI_ENABLE_LOGGING)
    target_sources(sonoyuncu_jni PRIVATE src/common/Logger.cpp)
    target_compile_definitions(sonoyuncu_jni PRIVATE AOKI_ENABLE_LOGGING=1)
    message(STATUS "commonLuke native logging ON (commonLuke.log beside the loader)")
endif()
add_dependencies(sonoyuncu_jni packet_hook_payload)
option(AOKI_ENV_PROBE_ONLY "Start only the direct JVM environment probe" OFF)
if(AOKI_ENV_PROBE_ONLY)
    target_compile_definitions(sonoyuncu_jni PRIVATE AOKI_ENV_PROBE_ONLY=1)
    message(STATUS "commonLuke JVM environment probe-only mode ON")
endif()

target_include_directories(sonoyuncu_jni PRIVATE
    include
    ${CMAKE_CURRENT_BINARY_DIR}/generated
    ${imgui_SOURCE_DIR}
    ${imgui_SOURCE_DIR}/backends
    ${PROJECT_SOURCE_DIR}/referans/dll/src/core
    ${PROJECT_SOURCE_DIR}/referans/dll/src/injection
    ${PROJECT_SOURCE_DIR}/referans/dll/src
    ${PROJECT_SOURCE_DIR}/third_party/minhook/src/hde
    ${PROJECT_SOURCE_DIR}/third_party/jni/include
    ${reference_root}/src/third_party
)

target_link_libraries(sonoyuncu_jni PRIVATE aoki_jar_reader minhook windowsapp runtimeobject opengl32 user32 gdi32 ole32 windowscodecs winhttp gdiplus ws2_32)

add_executable(jar_api_sequence_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/jar-api-sequence/SequenceTest.cpp)
target_include_directories(jar_api_sequence_test PRIVATE include)
target_compile_features(jar_api_sequence_test PRIVATE cxx_std_20)
add_executable(packet_bridge_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/packet-hook-smoke/BridgeTest.cpp src/jvm/PacketBridge.cpp)
target_include_directories(packet_bridge_test PRIVATE include src/jvm ${PROJECT_SOURCE_DIR}/third_party/jni/include
    ${reference_root}/src/core ${reference_root}/src
    ${PROJECT_SOURCE_DIR}/third_party/minhook/src/hde)
target_compile_features(packet_bridge_test PRIVATE cxx_std_20)
add_executable(packet_jar_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/packet-hook-smoke/JarTest.cpp)
target_include_directories(packet_jar_test PRIVATE include
    ${reference_root}/src/core ${reference_root}/src
    ${PROJECT_SOURCE_DIR}/third_party/jni/include)
target_compile_features(packet_jar_test PRIVATE cxx_std_20)
target_link_libraries(packet_jar_test PRIVATE aoki_jar_reader)
add_dependencies(packet_jar_test packet_hook_payload)
if(MSVC)
    set_property(TARGET packet_jar_test PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()
add_executable(native_packet_engine_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tests/NativePacketEngineTest.cpp
    src/hooks/NativePacketEngine.cpp
    src/common/NativeScheduler.cpp)
target_include_directories(native_packet_engine_test PRIVATE include
    ${CMAKE_CURRENT_BINARY_DIR}/generated
    ${reference_root}/src/third_party)
target_compile_features(native_packet_engine_test PRIVATE cxx_std_20)
target_link_libraries(native_packet_engine_test PRIVATE aoki_jar_reader)
add_test(NAME native_packet_engine COMMAND native_packet_engine_test)
add_executable(object_result_lifecycle_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tests/ObjectResultLifecycleTest.cpp)
target_include_directories(object_result_lifecycle_test PRIVATE include)
target_compile_features(object_result_lifecycle_test PRIVATE cxx_std_20)
add_test(NAME object_result_lifecycle COMMAND object_result_lifecycle_test)
add_executable(native_scheduler_test EXCLUDE_FROM_ALL
    tests/NativeSchedulerTest.cpp
    src/common/NativeScheduler.cpp)
target_include_directories(native_scheduler_test PRIVATE include)
target_compile_features(native_scheduler_test PRIVATE cxx_std_20)
add_test(NAME native_scheduler COMMAND native_scheduler_test)
add_executable(velocity_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/velocity-smoke/VelocityTest.cpp
    src/features/combat/velocity/VelocitySettings.cpp
    src/features/combat/velocity/VelocityRuntime.cpp)
target_include_directories(velocity_test PRIVATE include ${PROJECT_SOURCE_DIR}/third_party/jni/include
    ${reference_root}/src/core ${CMAKE_CURRENT_BINARY_DIR}/generated
    ${PROJECT_SOURCE_DIR}/third_party/minhook/src/hde)
target_compile_features(velocity_test PRIVATE cxx_std_20)
add_executable(no_rotate_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/no-rotate-smoke/NoRotateTest.cpp
    src/features/exploit/no_rotate/NoRotateSettings.cpp
    src/features/exploit/no_rotate/NoRotateRuntime.cpp)
target_include_directories(no_rotate_test PRIVATE include ${PROJECT_SOURCE_DIR}/third_party/jni/include
    ${reference_root}/src/core ${CMAKE_CURRENT_BINARY_DIR}/generated
    ${PROJECT_SOURCE_DIR}/third_party/minhook/src/hde)
target_compile_features(no_rotate_test PRIVATE cxx_std_20)
add_executable(scaffold_rules_test EXCLUDE_FROM_ALL tests/ScaffoldRulesTest.cpp)
target_include_directories(scaffold_rules_test PRIVATE include)
target_compile_features(scaffold_rules_test PRIVATE cxx_std_20)
add_executable(keybind_rules_test EXCLUDE_FROM_ALL tests/KeybindRulesTest.cpp)
target_include_directories(keybind_rules_test PRIVATE include)
target_compile_features(keybind_rules_test PRIVATE cxx_std_20)
add_executable(attack_target_rules_test EXCLUDE_FROM_ALL tests/AttackTargetRulesTest.cpp)
target_include_directories(attack_target_rules_test PRIVATE include)
target_compile_features(attack_target_rules_test PRIVATE cxx_std_20)
add_executable(inventory_hud_rules_test EXCLUDE_FROM_ALL tests/InventoryHudRulesTest.cpp)
target_include_directories(inventory_hud_rules_test PRIVATE include)
target_compile_features(inventory_hud_rules_test PRIVATE cxx_std_20)
if(BUILD_TESTING)
    add_test(NAME packet_bridge COMMAND packet_bridge_test)
    add_test(NAME velocity COMMAND velocity_test)
    add_test(NAME no_rotate COMMAND no_rotate_test)
    add_test(NAME scaffold_rules COMMAND scaffold_rules_test)
    add_test(NAME keybind_rules COMMAND keybind_rules_test)
    add_test(NAME attack_target_rules COMMAND attack_target_rules_test)
    add_test(NAME inventory_hud_rules COMMAND inventory_hud_rules_test)
endif()
if(MSVC)
    set_property(TARGET packet_bridge_test PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
endif()

target_compile_definitions(sonoyuncu_jni PRIVATE
    WIN32_LEAN_AND_MEAN
    NOMINMAX
    _CRT_SECURE_NO_WARNINGS
    AOKI_DISTRIBUTION=1
    AOKI_IMAGE_PATH="${CMAKE_BINARY_DIR}/bin/commonLuke.dll"
)

if(MSVC)
    set_property(TARGET sonoyuncu_jni PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    # The mapper rejects static TLS. Local-static initialization is serialized
    # by the exported bootstrap entry point instead.
    # Keep debug records in each object. /Z7 avoids the external PDB server,
    # which is brittle across Visual Studio toolset updates and parallel builds.
    target_compile_options(sonoyuncu_jni PRIVATE $<$<COMPILE_LANGUAGE:CXX>:/W4;/permissive-;/EHsc;/Zc:threadSafeInit-;/Z7;/utf-8>)
    target_link_options(sonoyuncu_jni PRIVATE /INCREMENTAL:NO /DEBUG /OPT:REF /OPT:ICF)
endif()

set_target_properties(sonoyuncu_jni PROPERTIES
    OUTPUT_NAME "commonLuke"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_DEBUG "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_RELWITHDEBINFO "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_MINSIZEREL "${CMAKE_BINARY_DIR}/bin"
    LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
    ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/lib"
)

option(AOKI_BUILD_HUD_SMOKE "Build a hidden-window OpenGL HUD smoke test" OFF)
if(AOKI_BUILD_HUD_SMOKE)
    add_executable(hud_smoke
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/Main.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/ControlsFixture.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/AtlasFixture.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/Benchmark.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/PerformanceFixture.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/WingsFixture.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/NotificationsFixture.cpp
        ${PROJECT_SOURCE_DIR}/tools/hud-smoke/RuntimeStubs.cpp
        src/common/NativeScheduler.cpp
        src/render/GlDiagnostics.cpp
        src/features/visual/spotify_widget/SpotifySession.cpp
        ${hud_sources})
    get_target_property(hud_includes sonoyuncu_jni INCLUDE_DIRECTORIES)
    target_include_directories(hud_smoke PRIVATE ${hud_includes})
    target_compile_features(hud_smoke PRIVATE cxx_std_20)
    target_compile_definitions(hud_smoke PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX _CRT_SECURE_NO_WARNINGS)
    target_link_libraries(hud_smoke PRIVATE windowsapp runtimeobject opengl32 user32 gdi32 ole32 windowscodecs minhook dbghelp)
    if(MSVC)
        set_property(TARGET hud_smoke PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
        target_compile_options(hud_smoke PRIVATE $<$<COMPILE_LANGUAGE:CXX>:/EHsc;/Zc:threadSafeInit-;/Zi;/utf-8>)
        target_link_options(hud_smoke PRIVATE /DEBUG /INCREMENTAL:NO)
    endif()
endif()



add_executable(extra_modules_rules_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/extra-modules-smoke/RulesTest.cpp
    src/features/utility/extra_modules/ExtraModulesSettings.cpp)
target_include_directories(extra_modules_rules_test PRIVATE include ${PROJECT_SOURCE_DIR}/third_party/jni/include)
target_compile_features(extra_modules_rules_test PRIVATE cxx_std_20)

add_executable(spotify_media_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/spotify-smoke/SpotifyMediaTest.cpp
    src/features/visual/spotify_widget/SpotifySession.cpp)
target_include_directories(spotify_media_test PRIVATE include)
target_compile_features(spotify_media_test PRIVATE cxx_std_20)
target_compile_definitions(spotify_media_test PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(spotify_media_test PRIVATE windowsapp runtimeobject ole32)
if(MSVC)
    set_property(TARGET spotify_media_test PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(spotify_media_test PRIVATE /EHsc /utf-8)
endif()

add_executable(spotify_worker_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/spotify-smoke/SpotifyWorkerTest.cpp
    src/features/visual/spotify_widget/SpotifyWidgetSettings.cpp
    src/features/visual/spotify_widget/SpotifySession.cpp
    src/features/visual/spotify_widget/SpotifyWidgetRuntime.cpp)
target_include_directories(spotify_worker_test PRIVATE include)
target_compile_features(spotify_worker_test PRIVATE cxx_std_20)
target_compile_definitions(spotify_worker_test PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(spotify_worker_test PRIVATE windowsapp runtimeobject ole32)
if(MSVC)
    set_property(TARGET spotify_worker_test PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(spotify_worker_test PRIVATE /EHsc /utf-8)
endif()

if(EXISTS "${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/AmbianceTest.cpp")
add_executable(ambiance_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/AmbianceTest.cpp
    src/features/visual/ambiance/AmbianceSettings.cpp
    src/features/visual/ambiance/AmbianceRuntime.cpp
    src/features/visual/ambiance/LyricsLogic.cpp
    src/features/visual/ambiance/LyricsJson.cpp
    src/features/visual/ambiance/LyricsService.cpp
    src/features/visual/ambiance/LyricsHttp.cpp
    src/features/visual/ambiance/ParticleLyricsLogic.cpp
    src/features/visual/spotify_widget/SpotifySession.cpp
    src/features/visual/spotify_widget/SpotifyWidgetSettings.cpp)
target_include_directories(ambiance_test PRIVATE include)
target_compile_features(ambiance_test PRIVATE cxx_std_20)
target_compile_definitions(ambiance_test PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(ambiance_test PRIVATE windowsapp runtimeobject ole32 winhttp)
if(MSVC)
    set_property(TARGET ambiance_test PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(ambiance_test PRIVATE /EHsc /utf-8)
endif()
endif()

if(EXISTS "${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/Lyrics3dRasterTest.cpp")
add_executable(lyrics3d_raster_test EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/Lyrics3dRasterTest.cpp
    src/features/visual/ambiance/ParticleRaster.cpp
    src/features/visual/ambiance/ParticleLyricsLogic.cpp)
target_include_directories(lyrics3d_raster_test PRIVATE include ${CMAKE_CURRENT_BINARY_DIR}/generated)
target_compile_features(lyrics3d_raster_test PRIVATE cxx_std_20)
target_compile_definitions(lyrics3d_raster_test PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(lyrics3d_raster_test PRIVATE gdiplus)
if(MSVC)
    set_property(TARGET lyrics3d_raster_test PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(lyrics3d_raster_test PRIVATE /EHsc /utf-8)
endif()
endif()

if(EXISTS "${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/LiveDiag.cpp")
add_executable(ambiance_diag EXCLUDE_FROM_ALL
    ${PROJECT_SOURCE_DIR}/tools/ambiance-smoke/LiveDiag.cpp
    src/features/visual/ambiance/AmbianceSettings.cpp
    src/features/visual/ambiance/AmbianceRuntime.cpp
    src/features/visual/ambiance/LyricsLogic.cpp
    src/features/visual/ambiance/LyricsJson.cpp
    src/features/visual/ambiance/LyricsService.cpp
    src/features/visual/ambiance/LyricsHttp.cpp
    src/features/visual/spotify_widget/SpotifySession.cpp
    src/features/visual/spotify_widget/SpotifyWidgetSettings.cpp)
target_include_directories(ambiance_diag PRIVATE include)
target_compile_features(ambiance_diag PRIVATE cxx_std_20)
target_compile_definitions(ambiance_diag PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(ambiance_diag PRIVATE windowsapp runtimeobject ole32 winhttp)
if(MSVC)
    set_property(TARGET ambiance_diag PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(ambiance_diag PRIVATE /EHsc /utf-8)
endif()
endif()
