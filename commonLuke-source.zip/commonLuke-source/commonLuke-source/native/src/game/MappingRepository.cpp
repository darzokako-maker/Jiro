#include "game/MappingRepository.hpp"
#include "client/OffsetRepository.hpp"
#include "client/Logger.hpp"
#include "client/HotSpotRuntime.hpp"
#include "asm/AsmJvm.hpp"
#include "ClientMappings.hpp"
#include <Windows.h>
#include <algorithm>
namespace client::mapping {
namespace {
template<std::size_t N> const generated::Symbol* Lookup(const generated::Symbol (&symbols)[N],std::string_view key) {
 const auto found=std::lower_bound(std::begin(symbols),std::end(symbols),key,[](const generated::Symbol& value,std::string_view wanted){return std::string_view(value.key)<wanted;});
 return found!=std::end(symbols)&&key==found->key?found:nullptr;
}
const classes::ClassRecord* ClassIn(std::string_view alias,const classes::Snapshot& snapshot) {
 const auto it=snapshot.byName.find(std::string(ClassName(alias)));
 if(it==snapshot.byName.end() || it->second.size()!=1) return nullptr;
 return &snapshot.classes[it->second.front()];
}
std::uintptr_t DecodeKlass(jobject object) {
 const auto profile=offsets::Get(); const auto oop=Oop(object);
 if(!profile || !oop) return 0;
 const auto constants=hotspot::GetConstants();
 const auto address=oop+profile->members.at("HeapObject.klass");
 if(!constants || !constants->compressedKlass.value_or(false)) {
  std::uintptr_t decoded=0;
  return asm_jvm::DecodePointer(address,false,0,0,false,&decoded)?decoded:0;
 }
 const auto shift=constants->narrowKlassShift.value_or(64);
 if(shift>16) return 0;
 std::uintptr_t decoded=0;
 if(!asm_jvm::DecodePointer(address,true,constants->narrowKlassBase.value_or(0),
     static_cast<unsigned>(shift),false,&decoded)) return 0;
 return decoded;
}
}
std::string_view ClassName(std::string_view alias) {
 if(const auto symbol=Lookup(generated::classes,alias))return symbol->name;
 return {};
}
std::optional<Symbol> Field(std::string_view key) {
 if(const auto symbol=Lookup(generated::fields,key))return Symbol{symbol->name,symbol->descriptor};
 return {};
}
std::optional<Symbol> Method(std::string_view key) {
 if(const auto symbol=Lookup(generated::methods,key))return Symbol{symbol->name,symbol->descriptor};
 return {};
}
const classes::ClassRecord* Class(std::string_view alias) {
 const auto snapshot=classes::GetSnapshot(); if(!snapshot) return nullptr;
 return ClassIn(alias,*snapshot);
}
const classes::ClassRecord* Class(std::string_view alias,const classes::Snapshot& snapshot) {
 return ClassIn(alias,snapshot);
}
std::optional<FieldInfo> ResolveField(std::string_view key,const classes::Snapshot& snapshot) {
 const auto spec=Field(key); const auto owner=ClassIn(key.substr(0,key.find('.')),snapshot);
 if(!spec || !owner) return {};
 return hotspot::FindField(*owner,std::string(spec->name),std::string(spec->descriptor));
}
std::optional<FieldInfo> ResolveField(std::string_view key) {
 const auto snapshot=classes::GetSnapshot(); if(!snapshot) return {};
 return ResolveField(key,*snapshot);
}
std::uintptr_t Oop(jobject handle) {
 return hotspot::runtime::Resolve(handle);
}
jobject Root(JNIEnv* env,std::uintptr_t oop) {
 return hotspot::runtime::Local(env,oop);
}
jobject Global(JNIEnv* env,jobject source) {
 return hotspot::runtime::Global(env,source);
}
void ReleaseGlobal(JNIEnv* env,jobject& global) {
 if(global&&hotspot::runtime::DestroyGlobal(env,global))global=nullptr;
}
jobject Object(JNIEnv* env,jobject receiver,std::string_view key) {
 const auto field=ResolveField(key);
 return field?hotspot::runtime::LoadObject(env,receiver,field->offset):nullptr;
}
jobject StaticObject(JNIEnv* env,std::string_view key) {
 const auto field=ResolveField(key);
 const auto owner=Class(key.substr(0,key.find('.'))); const auto profile=offsets::Get();
 if(!field || !owner || !profile || !(field->access_flags&8)) return nullptr;
 auto mirror=hotspot::runtime::LocalFromRoot(env,reinterpret_cast<std::uintptr_t*>(
  owner->klass+profile->members.at("Klass.java_mirror")));
 if(!mirror)return nullptr;
 const auto value=hotspot::runtime::LoadObject(env,mirror,field->offset);
 env->DeleteLocalRef(mirror);return value;
}
std::uintptr_t StaticAddress(std::string_view key) {
 const auto field=ResolveField(key); const auto owner=Class(key.substr(0,key.find('.'))); const auto profile=offsets::Get();
 if(!field || !owner || !profile || !(field->access_flags&8) || hotspot::Read<std::uint8_t>(owner->klass+profile->members.at("InstanceKlass.init_state")).value_or(0)!=4) return 0;
 const auto mirror=hotspot::Read<std::uintptr_t>(owner->klass+profile->members.at("Klass.java_mirror")).value_or(0);
 return mirror?mirror+field->offset:0;
}
jclass StaticMirror(JNIEnv* env,std::string_view alias) {
 const auto owner=Class(alias);const auto profile=offsets::Get();
 if(!env||!owner||!profile)return nullptr;
 return static_cast<jclass>(hotspot::runtime::LocalFromRoot(env,
  reinterpret_cast<std::uintptr_t*>(owner->klass+profile->members.at("Klass.java_mirror"))));
}
bool WriteStaticObject(JNIEnv* env,std::string_view key,jobject value) {
 const auto field=ResolveField(key);const auto owner=Class(key.substr(0,key.find('.')));const auto profile=offsets::Get();
 if(!env||!field||!owner||!profile||!(field->access_flags&8))return false;
 const auto mirror=hotspot::Read<std::uintptr_t>(owner->klass+profile->members.at("Klass.java_mirror")).value_or(0);
 const auto root=Root(env,mirror);if(!root)return false;
 const bool ok=hotspot::runtime::StoreObject(env,root,field->offset,value);
 env->DeleteLocalRef(root);return ok;
}
bool WriteObject(JNIEnv* env,jobject receiver,std::string_view key,jobject value) {
 const auto field=ResolveField(key);
 return env&&receiver&&field&&!(field->access_flags&8)&&hotspot::runtime::StoreObject(env,receiver,field->offset,value);
}
const classes::ClassRecord* RuntimeClass(jobject object) {
 const auto klass=DecodeKlass(object);
 const auto snapshot=classes::GetSnapshot();
 if(snapshot) { const auto it=snapshot->byKlass.find(klass); if(it!=snapshot->byKlass.end()) return &snapshot->classes[it->second]; }
 return nullptr;
}
bool Instance(jobject object,std::string_view alias) {
 const auto owner=Class(alias); const auto actual=RuntimeClass(object); const auto profile=offsets::Get();
 if(!owner||!actual||!profile) return false;
 const std::uintptr_t target=owner->klass;
 return (asm_jvm::InstanceWalk(actual->klass,profile->members.at("Klass.super"),&target,1)&1)!=0;
}
bool Instance(JNIEnv* env,jobject object,std::string_view alias) {
 const auto owner=Class(alias);const auto profile=offsets::Get();
 return owner&&profile&&hotspot::runtime::IsInstance(env,object,owner->klass,
  profile->members.at("Klass.super"));
}
InstanceInfo InstanceMask(jobject object,const std::vector<std::uintptr_t>& targets) {
 InstanceInfo info;
 const auto klass=DecodeKlass(object);
 const auto snapshot=classes::GetSnapshot();
 const auto profile=offsets::Get();
 if(!klass || !snapshot || !profile) return info;
 if(snapshot->byKlass.find(klass)==snapshot->byKlass.end()) return info;
 info.resolved=true;
 const std::size_t count=std::min<std::size_t>(targets.size(),32);
 if(count)
  info.bits=asm_jvm::InstanceWalk(klass,profile->members.at("Klass.super"),targets.data(),static_cast<std::uint32_t>(count));
 return info;
}
methods::Result Invoke(JNIEnv* env,jobject receiver,std::string_view key,const std::vector<methods::Argument>& args) {
 const auto owner=Class(key.substr(0,key.find('.'))); const auto spec=Method(key);
 if(!owner || !spec) { methods::Result r; r.error="mapping missing: "+std::string(key); return r; }
 return methods::Invoke(env,receiver,*owner,std::string(spec->name),std::string(spec->descriptor),args);
}
std::optional<std::string> String(JNIEnv* env,jobject receiver,std::string_view key) {
 auto result=Invoke(env,receiver,key); std::optional<std::string> output;
 if(result.ok && result.value.l && result.type==methods::Type::Object) {
  const auto string=static_cast<jstring>(result.value.l);
  const char* chars=env->GetStringUTFChars(string,nullptr);
  if(chars) { output=chars; env->ReleaseStringUTFChars(string,chars); }
 }
 result.Release(env); return output;
}
jobject Allocate(JNIEnv* env,std::string_view alias) {
 const auto owner=Class(alias);const auto profile=offsets::Get();
 if(!env||!owner||!profile||env->ExceptionCheck())return nullptr;
 const auto mirror=hotspot::Read<std::uintptr_t>(owner->klass+profile->members.at("Klass.java_mirror")).value_or(0);
 const auto root=Root(env,mirror);if(!root)return nullptr;
 const auto object=env->AllocObject(static_cast<jclass>(root));env->DeleteLocalRef(root);
 if(!object||env->ExceptionCheck()){if(env->ExceptionCheck())env->ExceptionClear();return nullptr;}
 return object;
}
jobject New(JNIEnv* env,std::string_view constructor,const std::vector<methods::Argument>& args) {
 const auto owner=Class(constructor.substr(0,constructor.find('.')));
 if(!owner)return nullptr;
 const auto object=Allocate(env,constructor.substr(0,constructor.find('.')));if(!object)return nullptr;
 const auto spec=Method(constructor);
 if(!spec){env->DeleteLocalRef(object);return nullptr;}
 // Constructors are invokespecial targets. Resolving them virtually can select
 // an unrelated body when an obfuscated subclass shares the same descriptor.
 auto result=methods::Invoke(env,object,*owner,std::string(spec->name),std::string(spec->descriptor),args,false);
 const bool ok=result.ok;
 if(!ok)AOKI_LOG("[Mapping] constructor %.*s failed: %s",static_cast<int>(constructor.size()),constructor.data(),result.error.c_str());
 result.Release(env);
 if(!ok){env->DeleteLocalRef(object);return nullptr;}return object;
}
void DiagnoseSnapshot(JNIEnv* env) {
 const auto snap=classes::GetSnapshot();
 if(!snap){AOKI_LOG("[ClassDiag] no snapshot");return;}
 const auto profile=offsets::Get();
 const auto mirrorMember=profile?profile->members.find("Klass.java_mirror"):std::unordered_map<std::string,std::uint32_t>::const_iterator{};
 const bool hasMirror=profile&&mirrorMember!=profile->members.end();
 AOKI_LOG("[ClassDiag] tick=%llu classes=%zu",static_cast<unsigned long long>(GetTickCount64()),snap->classes.size());
 static const char* names[]={"bj","HX","jV","net/minecraft/client/QH","net/minecraft/client/XK"};
 for(const auto* wanted:names) {
  const auto it=snap->byName.find(wanted);
  if(it==snap->byName.end()){AOKI_LOG("[ClassDiag] name='%s' ABSENT",wanted);continue;}
  AOKI_LOG("[ClassDiag] name='%s' records=%zu",wanted,it->second.size());
  for(const auto index:it->second) {
   if(index>=snap->classes.size())continue;
   const auto& record=snap->classes[index];
   std::uintptr_t mirror=0;
   if(hasMirror)mirror=hotspot::Read<std::uintptr_t>(record.klass+mirrorMember->second).value_or(0);
   // ClassLoaderData._class_loader sits at offset 0 (injection-layout profile).
   const auto loaderOop=record.loaderData?hotspot::Read<std::uintptr_t>(record.loaderData).value_or(0):0;
   AOKI_LOG("[ClassDiag]   rec name='%s' klass=0x%llx cld=0x%llx loaderOop=0x%llx mirror=0x%llx fields=%zu methods=%zu",
    record.name.c_str(),static_cast<unsigned long long>(record.klass),
    static_cast<unsigned long long>(record.loaderData),static_cast<unsigned long long>(loaderOop),
    static_cast<unsigned long long>(mirror),record.fields.size(),record.methods.size());
  }
 }
 for(const auto* alias:{"CustomSkyLayer","CustomSky","ClientCosmetics","Minecraft","RenderGlobal"}) {
  const auto owner=Class(alias);
  AOKI_LOG("[ClassDiag] Class('%s') -> %s",alias,owner?"resolved":"NULL");
 }
 if(env) {
  const auto mc=StaticObject(env,"Minecraft.theMinecraft");
  const auto world=mc?Object(env,mc,"Minecraft.theWorld"):nullptr;
  const auto player=mc?Object(env,mc,"Minecraft.thePlayer"):nullptr;
  AOKI_LOG("[ClassDiag] mc=%s world=%s player=%s",
   mc?"yes":"no",world?"yes":"no",player?"yes":"no");
  if(world)env->DeleteLocalRef(world);
  if(player)env->DeleteLocalRef(player);
  if(mc)env->DeleteLocalRef(mc);
 }
}
}
