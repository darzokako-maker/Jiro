#include "game/GuiAtlas.hpp"
#include "render/GlDiagnostics.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include <algorithm>
#include <cmath>
namespace client::game {
namespace {
using namespace render;
void (APIENTRY* GenRenderbuffers)(GLsizei,GLuint*)=nullptr;
void (APIENTRY* BindRenderbuffer)(GLenum,GLuint)=nullptr;
void (APIENTRY* RenderbufferStorage)(GLenum,GLenum,GLsizei,GLsizei)=nullptr;
void (APIENTRY* FramebufferRenderbuffer)(GLenum,GLenum,GLenum,GLuint)=nullptr;
methods::Argument ObjectArg(jobject object) { methods::Argument a{methods::Type::Object}; a.value.l=object; return a; }
methods::Argument IntArg(int value) { methods::Argument a{methods::Type::Int}; a.value.i=value; return a; }
methods::Argument FloatArg(float value) { methods::Argument a{methods::Type::Float}; a.value.f=value; return a; }
methods::Argument BoolArg(bool value) { methods::Argument a{methods::Type::Boolean}; a.value.z=value?JNI_TRUE:JNI_FALSE; return a; }
}
struct GuiAtlas::CacheSnapshot {
 struct Value { jobject owner; unsigned offset; std::vector<unsigned char> bytes; };
 std::vector<Value> values;
 std::vector<jobject> seen;
 std::string allowedPrefix;
 JNIEnv* env;
 explicit CacheSnapshot(JNIEnv* e):env(e) {
  const auto klass=mapping::Class("GlStateManager"); const auto profile=offsets::Get();
  if(!klass || !profile) return;
  allowedPrefix=klass->name.substr(0,klass->name.find_last_of('/')+1);
  const auto mirror=hotspot::Read<std::uintptr_t>(klass->klass+profile->members.at("Klass.java_mirror")).value_or(0);
  if(const auto root=mapping::Root(env,mirror)) Save(root,*klass,true,0);
 }
 void Save(jobject root,const classes::ClassRecord& klass,bool statics,int depth) {
  if(depth>5 || seen.size()>256 || (depth && klass.name.rfind(allowedPrefix,0)!=0)) return;
  for(auto previous:seen) if(env->IsSameObject(root,previous)) return;
  seen.push_back(root);
  for(const auto& field:klass.fields) {
   if(((field.access_flags&8)!=0)!=statics || field.signature.empty()) continue;
   const char type=field.signature[0];
   const auto oop=mapping::Oop(root); if(!oop) continue;
   const unsigned size=type=='Z'||type=='B'?1:type=='S'||type=='C'?2:type=='I'||type=='F'?4:type=='J'||type=='D'?8:0;
   if(size) {
    Value value{root,field.offset,std::vector<unsigned char>(size)};
    if(hotspot::ReadMemory(oop+field.offset,value.bytes.data(),size)) values.push_back(std::move(value));
   } else if(type=='L' || (field.signature.size()>1 && field.signature[0]=='[' && field.signature[1]=='L')) {
    const auto object=mapping::Root(env,hotspot::ReadObjectReference(oop+field.offset).value_or(0));
    if(!object) continue;
    if(type=='[') {
     const auto array=static_cast<jobjectArray>(object);const int length=env->GetArrayLength(array);
     if(length>64) continue;
     for(int i=0;i<length;++i) if(const auto child=env->GetObjectArrayElement(array,i)) {
      if(const auto c=mapping::RuntimeClass(child)) Save(child,*c,false,depth+1);
     }
    } else if(const auto c=mapping::RuntimeClass(object)) Save(object,*c,false,depth+1);
   }
  }
 }
 void Restore() {
  for(const auto& value:values) if(const auto oop=mapping::Oop(value.owner))
   hotspot::WriteMemory(oop+value.offset,value.bytes.data(),value.bytes.size());
 }
};
GuiAtlas::GuiAtlas()=default;
GuiAtlas::~GuiAtlas()=default;
bool GuiAtlas::TargetReady(Target& target,int width,int height) {
 diagnostics::Scope trace("GuiAtlas.TargetReady");
 if(target.fbo) return true;
 if(!GenRenderbuffers) {
  GenRenderbuffers=reinterpret_cast<decltype(GenRenderbuffers)>(wglGetProcAddress("glGenRenderbuffers"));
  BindRenderbuffer=reinterpret_cast<decltype(BindRenderbuffer)>(wglGetProcAddress("glBindRenderbuffer"));
  RenderbufferStorage=reinterpret_cast<decltype(RenderbufferStorage)>(wglGetProcAddress("glRenderbufferStorage"));
  FramebufferRenderbuffer=reinterpret_cast<decltype(FramebufferRenderbuffer)>(wglGetProcAddress("glFramebufferRenderbuffer"));
 }
 if(!GenRenderbuffers||!BindRenderbuffer||!RenderbufferStorage||!FramebufferRenderbuffer) return false;
 target.width=width;target.height=height;
 glGenTextures(1,&target.texture); glBindTexture(GL_TEXTURE_2D,target.texture);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR); glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,0x812F); glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,0x812F);
 render::gl.BindBuffer(0x88EC,0);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
 render::gl.GenFramebuffers(1,&target.fbo); render::gl.BindFramebuffer(0x8D40,target.fbo);
 render::gl.FramebufferTexture2D(0x8D40,0x8CE0,GL_TEXTURE_2D,target.texture,0);
 GLint prior=0;glGetIntegerv(0x8CA7,&prior);
 GenRenderbuffers(1,&target.depth);BindRenderbuffer(0x8D41,target.depth);RenderbufferStorage(0x8D41,0x81A6,width,height);
 FramebufferRenderbuffer(0x8D40,0x8D00,0x8D41,target.depth);BindRenderbuffer(0x8D41,prior);
 glDrawBuffer(0x8CE0);glReadBuffer(0x8CE0);
 return render::gl.CheckFramebufferStatus(0x8D40)==0x8CD5;
}
void GuiAtlas::Bind(Target& target) {
 diagnostics::Scope trace("GuiAtlas.Bind");
 render::gl.BindFramebuffer(0x8D40,target.fbo);glViewport(0,0,target.width,target.height);
 render::gl.UseProgram(0);
 render::LegacyGuiState::BindClientArrays();
 glMatrixMode(GL_PROJECTION);glLoadIdentity();glOrtho(0,target.width,target.height,0,1000,3000);
 glMatrixMode(GL_MODELVIEW);glLoadIdentity();glTranslatef(0,0,-2000);
 glDisable(GL_SCISSOR_TEST);glDisable(GL_STENCIL_TEST);glDisable(0x8DB9);
 glDisable(0x8C89);glDisable(0x8F9D);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 if(render::gl.BindSampler){render::gl.BindSampler(0,0);render::gl.BindSampler(1,0);}
 render::gl.BlendEquationSeparate(0x8006,0x8006);
 auto call=[&](const char* key,const std::vector<methods::Argument>& args=std::vector<methods::Argument>{}) {auto result=mapping::Invoke(env_,nullptr,key,args);result.Release(env_);};
 // Change cached fixed-function state through the game's own global mappings.
 // Direct GL changes here would let GlStateManager incorrectly skip later calls.
 call("GlStateManager.activeTexture",{IntArg(render::Texture0)});
 call("GlStateManager.enableTexture2D");call("GlStateManager.enableBlend");
 call("GlStateManager.disableCull");call("GlStateManager.disableFog");
 call("GlStateManager.colorMask",{BoolArg(true),BoolArg(true),BoolArg(true),BoolArg(true)});
 call("GlStateManager.blendFuncSeparate",{IntArg(GL_SRC_ALPHA),IntArg(GL_ONE_MINUS_SRC_ALPHA),IntArg(GL_ONE),IntArg(GL_ONE_MINUS_SRC_ALPHA)});
 call("GlStateManager.color",{FloatArg(1),FloatArg(1),FloatArg(1),FloatArg(1)});
 bool& cleared=&target==&items_?itemsCleared_:(&target==&models_?modelsCleared_:textCleared_);
 if(!cleared) {
  call("GlStateManager.depthMask",{BoolArg(true)});
  glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);cleared=true;
 }
}
bool GuiAtlas::Begin(JNIEnv* env,jobject minecraft) {
 diagnostics::Scope trace("GuiAtlas.Begin");
 env_=env;minecraft_=minecraft;renderer_=mapping::Object(env,minecraft,"Minecraft.renderItem");font_=mapping::Object(env,minecraft,"Minecraft.fontRenderer");
 if(!renderer_ && !font_) return false;
 cache_=std::make_unique<CacheSnapshot>(env);
 saved_=std::make_unique<render::LegacyGuiState>();
 ready_=true;
 if(!TargetReady(items_,1024,1024)||!TargetReady(text_,2048,2048)||!TargetReady(models_,128,128)) { End(); return false; }
 // Allocation binds atlas textures; restore real game bindings before Java's
 // texture cache is used. Otherwise it can skip binding an apparently bound font.
 saved_->RestoreTextures();
 itemsCleared_=textCleared_=modelsCleared_=false;
 itemSlot_=textX_=textY_=0;textCache_.clear();
 return true;
}
void GuiAtlas::End() {
 diagnostics::Scope trace("GuiAtlas.End");
 if(!ready_) return;
 if(cache_) { cache_->Restore(); cache_.reset(); }
 saved_.reset(); ready_=false;env_=nullptr;minecraft_=renderer_=font_=nullptr;
}
features::esp::Image GuiAtlas::Item(jobject stack) {
 diagnostics::Scope trace("GuiAtlas.Item / game RenderItem");
 if(!ready_||!stack||!renderer_||itemSlot_>=1024) return {};
 Bind(items_);
 auto depth=mapping::Invoke(env_,nullptr,"GlStateManager.enableDepth");depth.Release(env_);
 const int slot=itemSlot_++, x=(slot%32)*32, y=(slot/32)*32;
 glScalef(2,2,1);
 auto enabled=mapping::Invoke(env_,nullptr,"RenderHelper.enable"); enabled.Release(env_);
 auto result=mapping::Invoke(env_,renderer_,"RenderItem.draw",{ObjectArg(stack),IntArg(x/2),IntArg(y/2)});
 auto disabled=mapping::Invoke(env_,nullptr,"RenderHelper.disable"); disabled.Release(env_);
 if(!result.ok) { result.Release(env_);return {}; } result.Release(env_);
 return {items_.texture,x/1024.f,1.f-y/1024.f,(x+32)/1024.f,1.f-(y+32)/1024.f,32,32};
}
features::esp::Image GuiAtlas::Model(jobject entity) {
 diagnostics::Scope trace("GuiAtlas.Model / game GUI entity renderer");
 if(!ready_||!entity||!minecraft_||!mapping::Instance(entity,"EntityLivingBase"))return {};
 Bind(models_);
 auto rendered=mapping::Invoke(env_,nullptr,"TargetHudGui.drawEntity",{
  IntArg(64),IntArg(120),FloatArg(44),ObjectArg(entity),FloatArg(1)});
 const bool ok=rendered.ok;rendered.Release(env_);
 if(!ok)return {};
 constexpr float x0=24,y0=27,x1=104,y1=127;
 return {models_.texture,x0/128.f,1.f-y0/128.f,x1/128.f,1.f-y1/128.f,x1-x0,y1-y0};
}
features::esp::Image GuiAtlas::Text(const std::string& text) {
 diagnostics::Scope trace("GuiAtlas.Text / game FontRenderer");
 if(!ready_||!font_||text.empty()) return {};
 if(const auto found=textCache_.find(text);found!=textCache_.end())return found->second;
 const auto string=env_->NewStringUTF(text.c_str());if(!string) return {};
 auto width=mapping::Invoke(env_,font_,"FontRenderer.width",{ObjectArg(string)});
 if(!width.ok) { width.Release(env_);env_->DeleteLocalRef(string);return {}; }
 // Reserve a little extra room: the game's draw path can use different advances
 // than its preflight width calculation (formatting/resource-pack font state).
 const int pixels=std::clamp(width.value.i*2+36,36,508);width.Release(env_);
 if(textX_+pixels>text_.width) { textX_=0;textY_+=24; }
 if(textY_+24>text_.height) { env_->DeleteLocalRef(string);return {}; }
 const int x=textX_,y=textY_;textX_+=pixels+2;
 Bind(text_);
 auto depth=mapping::Invoke(env_,nullptr,"GlStateManager.disableDepth");depth.Release(env_);
 glScalef(2,2,1);
 glEnable(GL_SCISSOR_TEST);glScissor(x,text_.height-y-24,pixels,24);
 auto result=mapping::Invoke(env_,font_,"FontRenderer.draw",{ObjectArg(string),FloatArg(x/2.f+1.f),FloatArg(y/2.f+1.f),IntArg(-1)});
 env_->DeleteLocalRef(string);
 if(!result.ok) { result.Release(env_);return {}; }
 // FontRenderer.draw returns the actual ending X. Crop the atlas quad to that
 // advance, including symmetric 2px padding, so nametags center the text that
 // was drawn rather than a potentially stale measured width.
 const int renderedPixels=std::clamp((result.value.i-(x/2+1))*2+4,4,pixels);
 result.Release(env_);
 const features::esp::Image image{text_.texture,x/2048.f,1.f-y/2048.f,(x+renderedPixels)/2048.f,1.f-(y+24)/2048.f,static_cast<float>(renderedPixels),24};
 textCache_.emplace(text,image);return image;
}
}
