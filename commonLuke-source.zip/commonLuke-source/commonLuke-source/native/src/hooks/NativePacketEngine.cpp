#include "client/NativePacketEngine.hpp"

#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "ClientMappings.hpp"
#include "miniz/miniz.h"
#include <Windows.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <deque>
#include <limits>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>

namespace client::native_packets {
namespace {

constexpr std::size_t kMaximumFrame = 2u * 1024u * 1024u;
constexpr std::size_t kShadowRecoveryWindow = 64u * 1024u;
// A single random VarInt + registry id is too weak to prove an encrypted
// stream boundary.  Live captures have produced exactly that false positive,
// after which a bogus large frame length starved the socket.  Three adjacent
// frames makes accidental acceptance vanishingly unlikely while still
// converging quickly on the busy play stream.
constexpr std::size_t kRecoveryProofFrames = 3;
constexpr std::size_t kRecoveryProofBytes = 8;

constexpr std::array<std::uint8_t, 256> kSbox{
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16};

class Aes128 {
public:
    void SetKey(const std::array<std::uint8_t, 16>& key)
    {
        std::copy(key.begin(), key.end(), roundKeys_.begin());
        std::uint8_t temp[4]{};
        std::uint8_t rcon = 1;
        std::size_t generated = 16;
        while (generated < roundKeys_.size()) {
            std::memcpy(temp, roundKeys_.data() + generated - 4, 4);
            if ((generated % 16) == 0) {
                const auto first = temp[0];
                temp[0] = kSbox[temp[1]] ^ rcon;
                temp[1] = kSbox[temp[2]];
                temp[2] = kSbox[temp[3]];
                temp[3] = kSbox[first];
                rcon = static_cast<std::uint8_t>((rcon << 1) ^ ((rcon & 0x80) ? 0x1b : 0));
            }
            for (unsigned index = 0; index < 4; ++index) {
                roundKeys_[generated] = roundKeys_[generated - 16] ^ temp[index];
                ++generated;
            }
        }
    }

    std::array<std::uint8_t, 16> Encrypt(
        const std::array<std::uint8_t, 16>& input) const
    {
        auto state = input;
        AddRoundKey(state, 0);
        for (unsigned round = 1; round < 10; ++round) {
            for (auto& value : state) value = kSbox[value];
            ShiftRows(state);
            MixColumns(state);
            AddRoundKey(state, round);
        }
        for (auto& value : state) value = kSbox[value];
        ShiftRows(state);
        AddRoundKey(state, 10);
        return state;
    }

private:
    static std::uint8_t Xtime(std::uint8_t value)
    {
        return static_cast<std::uint8_t>((value << 1) ^ ((value & 0x80) ? 0x1b : 0));
    }

    void AddRoundKey(std::array<std::uint8_t, 16>& state, unsigned round) const
    {
        for (unsigned index = 0; index < 16; ++index)
            state[index] ^= roundKeys_[round * 16 + index];
    }

    static void ShiftRows(std::array<std::uint8_t, 16>& s)
    {
        const auto copy = s;
        s[1]=copy[5]; s[5]=copy[9]; s[9]=copy[13]; s[13]=copy[1];
        s[2]=copy[10]; s[6]=copy[14]; s[10]=copy[2]; s[14]=copy[6];
        s[3]=copy[15]; s[7]=copy[3]; s[11]=copy[7]; s[15]=copy[11];
    }

    static void MixColumns(std::array<std::uint8_t, 16>& s)
    {
        for (unsigned column = 0; column < 4; ++column) {
            auto* a = s.data() + column * 4;
            const auto total = a[0] ^ a[1] ^ a[2] ^ a[3];
            const auto first = a[0];
            a[0] ^= total ^ Xtime(a[0] ^ a[1]);
            a[1] ^= total ^ Xtime(a[1] ^ a[2]);
            a[2] ^= total ^ Xtime(a[2] ^ a[3]);
            a[3] ^= total ^ Xtime(a[3] ^ first);
        }
    }

    std::array<std::uint8_t, 176> roundKeys_{};
};

class Cfb8 {
public:
    void Reset(const std::array<std::uint8_t, 16>& key,
        const std::array<std::uint8_t, 16>& registerBytes)
    {
        aes_.SetKey(key);
        register_ = registerBytes;
    }

    std::uint8_t Decrypt(std::uint8_t ciphertext)
    {
        const auto plaintext = static_cast<std::uint8_t>(
            ciphertext ^ aes_.Encrypt(register_)[0]);
        Shift(ciphertext);
        return plaintext;
    }

    std::uint8_t Encrypt(std::uint8_t plaintext)
    {
        const auto ciphertext = static_cast<std::uint8_t>(
            plaintext ^ aes_.Encrypt(register_)[0]);
        Shift(ciphertext);
        return ciphertext;
    }

private:
    void Shift(std::uint8_t ciphertext)
    {
        std::move(register_.begin() + 1, register_.end(), register_.begin());
        register_.back() = ciphertext;
    }

    Aes128 aes_;
    std::array<std::uint8_t, 16> register_{};
};

struct VarInt {
    std::int32_t value = 0;
    std::size_t bytes = 0;
};

std::optional<VarInt> ReadVarInt(std::span<const std::uint8_t> input)
{
    std::uint32_t result = 0;
    for (std::size_t index = 0; index < 5; ++index) {
        if (index >= input.size()) return {};
        const auto byte = input[index];
        result |= static_cast<std::uint32_t>(byte & 0x7f) << (index * 7);
        if (!(byte & 0x80)) return VarInt{static_cast<std::int32_t>(result), index + 1};
    }
    return VarInt{-1, 5};
}

void WriteVarInt(std::vector<std::uint8_t>& output, std::int32_t signedValue)
{
    auto value = static_cast<std::uint32_t>(signedValue);
    do {
        auto byte = static_cast<std::uint8_t>(value & 0x7f);
        value >>= 7;
        if (value) byte |= 0x80;
        output.push_back(byte);
    } while (value);
}

std::mutex g_handlerMutex;
Handler g_handler;
Observer g_observer;
std::unordered_map<std::string, Action> g_mappedActions;
// Negative means the protocol has no compression envelope. A nonnegative
// value is the live Netty threshold and controls both parsing and rebuilding.
std::atomic<std::int32_t> g_compressionThreshold{-1};
std::array<std::atomic<bool>, 2> g_cipherResync{};

const mapping::generated::Packet* ResolvePacket(Direction direction,
    std::int32_t packetId)
{
    const bool inbound = direction == Direction::Inbound;
    for (const auto& packet : mapping::generated::packets)
        if (packet.inbound == inbound && packet.id == packetId) return &packet;
    return nullptr;
}

void Notify(const PacketView& packet) noexcept
{
    Observer observer;
    {
        std::lock_guard lock(g_handlerMutex);
        observer = g_observer;
    }
    if (!observer) return;
    try { observer(packet); }
    catch (...) { AOKI_LOG("[NATIVE-PACKET] observer threw; packet left unchanged"); }
}

Action Dispatch(PacketView& packet)
{
    Handler handler;
    Action mapped = Action::Pass;
    {
        std::lock_guard lock(g_handlerMutex);
        handler = g_handler;
        if (!packet.mappingKey.empty()) {
            const auto found = g_mappedActions.find(std::string(packet.mappingKey));
            if (found != g_mappedActions.end()) mapped = found->second;
        }
    }
    if (handler) {
        try {
            const auto action = handler(packet);
            if (action != Action::Pass) return action;
        } catch (...) {
            AOKI_LOG("[NATIVE-PACKET] handler threw; packet left unchanged");
        }
    }
    return mapped;
}

bool Inflate(std::span<const std::uint8_t> compressed, std::size_t expected,
    std::vector<std::uint8_t>& output)
{
    if (!expected || expected > kMaximumFrame) return false;
    output.resize(expected);
    mz_ulong size = static_cast<mz_ulong>(output.size());
    if (mz_uncompress(output.data(), &size, compressed.data(),
        static_cast<mz_ulong>(compressed.size())) != MZ_OK || size != expected) {
        output.clear();
        return false;
    }
    return true;
}

bool Deflate(std::span<const std::uint8_t> input, std::vector<std::uint8_t>& output)
{
    mz_ulong capacity = mz_compressBound(static_cast<mz_ulong>(input.size()));
    output.resize(capacity);
    if (mz_compress2(output.data(), &capacity, input.data(),
        static_cast<mz_ulong>(input.size()), MZ_DEFAULT_COMPRESSION) != MZ_OK) {
        output.clear();
        return false;
    }
    output.resize(capacity);
    return true;
}

class Stream {
public:
    void Initialize(const std::array<std::uint8_t, 16>& key,
        const std::array<std::uint8_t, 16>& registerBytes)
    {
        std::lock_guard lock(mutex_);
        input_.Reset(key, registerBytes);
        output_.Reset(key, registerBytes);
        plaintext_.clear();
        active_ = true;
        failed_ = false;
        validated_ = false;
        shadowing_ = false;
        transparentRemaining_ = 0;
        packets_ = 0;
        inputCalls_ = 0;
        inputBytes_ = 0;
        lastInputTick_ = client::scheduler::Now();
        lastPacketTick_ = lastInputTick_;
        boundaryLosses_ = 0;
        recoveries_ = 0;
    }

    std::vector<std::uint8_t> Process(Direction direction,
        std::span<const std::uint8_t> ciphertext)
    {
        std::lock_guard lock(mutex_);
        if (!active_ || failed_)
            return {ciphertext.begin(), ciphertext.end()};
        if (!ciphertext.empty()) {
            ++inputCalls_;
            inputBytes_ += ciphertext.size();
            lastInputTick_ = client::scheduler::Now();
        }
        std::vector<std::uint8_t> wire;
        const auto emitDue=[&]{const auto now=client::scheduler::Now();while(!delayed_.empty()&&delayed_.front().releaseAt<=now){for(const auto byte:delayed_.front().plaintext)wire.push_back(output_.Encrypt(byte));delayed_.pop_front();}};
        emitDue();
        const auto bufferedBefore = plaintext_.size();
        plaintext_.reserve(plaintext_.size() + ciphertext.size());
        for (const auto byte : ciphertext) plaintext_.push_back(input_.Decrypt(byte));

        // A socket read/write may end in the middle of a frame. That frame has
        // already crossed the NIO boundary and cannot safely be retained, so
        // pass only its remaining bytes through unchanged. Keeping the exact
        // remaining length preserves the proven boundary for the next frame
        // instead of forcing a three-frame recovery after every TCP split.
        if (transparentRemaining_ != 0) {
            const auto bypass = (std::min)(transparentRemaining_, plaintext_.size());
            for (std::size_t index = 0; index < bypass; ++index)
                wire.push_back(output_.Encrypt(plaintext_[index]));
            transparentRemaining_ -= bypass;
            plaintext_.erase(plaintext_.begin(), plaintext_.begin() + bypass);
            if (transparentRemaining_ != 0) {
                emitDue();
                return wire;
            }
        }

        bool transparentFallback = false;
        const auto fallbackToTransparent=[&](std::size_t begin,const char* reason){
            for(std::size_t index=begin;index<plaintext_.size();++index)
                wire.push_back(output_.Encrypt(plaintext_[index]));
            plaintext_.clear();
            validated_=false;
            shadowing_=true;
            transparentFallback=true;
            const auto loss=++boundaryLosses_;
            if(loss<=8||(loss%128)==0)
                AOKI_LOG("[NATIVE-PACKET] %s boundary lost (%s); transparent recovery total=%llu",
                    direction==Direction::Inbound?"IN":"OUT",reason,
                    static_cast<unsigned long long>(loss));
        };

        // Until the first packet boundary has been proven, never retain bytes
        // that Java has already been told were written. A stale CFB register
        // can otherwise produce a plausible large length and silently hold all
        // outbound keepalives while waiting for a frame that will never exist.
        if (!validated_) {
            // Shadow mode is deliberately transparent.  Prove several
            // adjacent frames before enabling edits; never let speculative
            // parsing change or retain bytes already consumed by NIO.
            shadowing_ = true;
            for (std::size_t index = bufferedBefore; index < plaintext_.size(); ++index)
                static_cast<void>(output_.Encrypt(plaintext_[index]));
            RecoverBoundary(direction);
            if (plaintext_.size() > kShadowRecoveryWindow)
                plaintext_.erase(plaintext_.begin(),
                    plaintext_.end() - kShadowRecoveryWindow);
            return {ciphertext.begin(), ciphertext.end()};
        }

        std::size_t consumed = 0;
        while (consumed < plaintext_.size()) {
            const auto available = std::span<const std::uint8_t>(plaintext_).subspan(consumed);
            const auto length = ReadVarInt(available);
            if (!length) break;
            if (length->value < 0 || static_cast<std::size_t>(length->value) > kMaximumFrame) {
                fallbackToTransparent(consumed,"invalid frame length");
                break;
            }
            const auto frameBytes = length->bytes + static_cast<std::size_t>(length->value);
            if (available.size() < frameBytes) {
                transparentRemaining_ = frameBytes - available.size();
                for (const auto byte : available) wire.push_back(output_.Encrypt(byte));
                plaintext_.clear();
                consumed = 0;
                transparentFallback = true;
                break;
            }
            const auto originalFrame = available.first(frameBytes);
            if(!ValidateFrame(direction,originalFrame.subspan(length->bytes))){
                fallbackToTransparent(consumed,"unknown packet id");
                break;
            }
            std::vector<std::uint8_t> rebuilt;
            std::uint32_t delayMilliseconds=0;
            if (!TransformFrame(direction, originalFrame.subspan(length->bytes), rebuilt,delayMilliseconds)) {
                rebuilt.assign(originalFrame.begin(), originalFrame.end());
            } else if (!rebuilt.empty()) {
                std::vector<std::uint8_t> wrapped;
                WriteVarInt(wrapped, static_cast<std::int32_t>(rebuilt.size()));
                wrapped.insert(wrapped.end(), rebuilt.begin(), rebuilt.end());
                rebuilt.swap(wrapped);
            }
            if(delayMilliseconds&&!rebuilt.empty())delayed_.push_back({client::scheduler::Now()+delayMilliseconds,std::move(rebuilt)});
            else for (const auto byte : rebuilt) wire.push_back(output_.Encrypt(byte));
            consumed += frameBytes;
        }
        if(!transparentFallback&&consumed<plaintext_.size()&&delayed_.empty())
            fallbackToTransparent(consumed,"partial socket frame");
        if (!transparentFallback&&consumed)
            plaintext_.erase(plaintext_.begin(), plaintext_.begin() + consumed);
        emitDue();
        return wire;
    }

    bool IsActive()
    {
        std::lock_guard lock(mutex_);
        return active_ && !failed_;
    }

    bool CanRewrite()
    {
        std::lock_guard lock(mutex_);
        return active_ && !failed_ && validated_;
    }

    client::native_packets::StreamHealth Health()
    {
        std::lock_guard lock(mutex_);
        return {active_, validated_, failed_, inputCalls_, inputBytes_, packets_,
            lastInputTick_, lastPacketTick_, boundaryLosses_, recoveries_};
    }

    void Reset()
    {
        std::lock_guard lock(mutex_);
        active_ = false;
        failed_ = false;
        validated_ = false;
        shadowing_ = false;
        transparentRemaining_ = 0;
        plaintext_.clear();
        delayed_.clear();
        packets_ = 0;
        inputCalls_ = 0;
        inputBytes_ = 0;
        lastInputTick_ = 0;
        lastPacketTick_ = 0;
        boundaryLosses_ = 0;
        recoveries_ = 0;
    }

private:
    bool RecoverBoundary(Direction direction)
    {
        // AES/CFB8 self-synchronizes after one 16-byte register. A stale
        // Java-side register can therefore only corrupt the first 16 decoded
        // bytes. Search a small bounded prefix for the first sequence of
        // complete, registry-valid Minecraft frames. Everything searched has
        // already passed through unchanged; editing starts on the next call.
        const auto retainedBegin = plaintext_.size() > kShadowRecoveryWindow
            ? plaintext_.size() - kShadowRecoveryWindow : 0;
        // Do not trust a boundary found inside the first CFB register: with a
        // stale snapshot those bytes are deterministic garbage and can
        // accidentally resemble a tiny valid packet.  At byte 16 and later
        // CFB8 plaintext is independent of the stale register.
        for (std::size_t start = retainedBegin; start < plaintext_.size(); ++start) {
            // With a stale CFB register bytes 0..15 are garbage.  Offset zero
            // remains a valid candidate for an exact snapshot; intermediate
            // offsets are never trustworthy until CFB8 has self-synchronized.
            if (retainedBegin == 0 && start > 0 && start < 16) continue;
            std::size_t consumed = start;
            std::size_t completed = 0;
            while (consumed < plaintext_.size()) {
                const auto available = std::span<const std::uint8_t>(plaintext_).subspan(consumed);
                const auto length = ReadVarInt(available);
                if (!length || length->value < 0 ||
                    static_cast<std::size_t>(length->value) > kMaximumFrame) break;
                const auto bytes = length->bytes + static_cast<std::size_t>(length->value);
                if (available.size() < bytes) break;
                if (!ValidateFrame(direction, available.subspan(length->bytes,
                    static_cast<std::size_t>(length->value)))) break;
                consumed += bytes;
                ++completed;
            }
            std::size_t trailingRemaining = 0;
            bool hasSafeTrailingPartial = false;
            if (consumed < plaintext_.size()) {
                const auto trailing = std::span<const std::uint8_t>(plaintext_)
                    .subspan(consumed);
                const auto trailingLength = ReadVarInt(trailing);
                if (trailingLength && trailingLength->value >= 0 &&
                    static_cast<std::size_t>(trailingLength->value) <= kMaximumFrame) {
                    const auto trailingFrameBytes = trailingLength->bytes +
                        static_cast<std::size_t>(trailingLength->value);
                    if (trailing.size() < trailingFrameBytes) {
                        trailingRemaining = trailingFrameBytes - trailing.size();
                        hasSafeTrailingPartial = true;
                    }
                }
            }
            if (completed >= kRecoveryProofFrames &&
                consumed - start >= kRecoveryProofBytes &&
                (consumed == plaintext_.size() || hasSafeTrailingPartial)) {
                plaintext_.clear();
                validated_ = true;
                shadowing_ = false;
                // The partial prefix was already returned transparently while
                // shadowing. Bypass exactly the remaining bytes of that frame,
                // then editing can resume at the next proven boundary.
                transparentRemaining_ = trailingRemaining;
                const auto recovery = ++recoveries_;
                AOKI_LOG("[NATIVE-PACKET] %s boundary proven offset=%zu frames=%zu bytes=%zu trailing=%zu recovery=%llu; editing enabled",
                    direction == Direction::Inbound ? "IN" : "OUT", start,
                    completed, consumed - start, trailingRemaining,
                    static_cast<unsigned long long>(recovery));
                return true;
            }
        }
        return false;
    }

    bool ValidateFrame(Direction direction, std::span<const std::uint8_t> frame)
    {
        const auto threshold = g_compressionThreshold.load();
        std::vector<std::uint8_t> packetData;
        if (threshold >= 0) {
            const auto dataLength = ReadVarInt(frame);
            if (!dataLength || dataLength->value < 0 ||
                static_cast<std::size_t>(dataLength->value) > kMaximumFrame)
                return false;
            const auto body = frame.subspan(dataLength->bytes);
            if (dataLength->value == 0)
                packetData.assign(body.begin(), body.end());
            else if (!Inflate(body, static_cast<std::size_t>(dataLength->value), packetData))
                return false;
        } else {
            packetData.assign(frame.begin(), frame.end());
        }
        const auto id = ReadVarInt(packetData);
        return id && id->value >= 0 && ResolvePacket(direction, id->value) != nullptr;
    }

    void Suspend(Direction direction, const char* reason)
    {
        plaintext_.clear();
        failed_ = true;
        shadowing_ = false;
        g_cipherResync[static_cast<std::size_t>(direction)].store(true);
        AOKI_LOG("[NATIVE-PACKET] parser suspended: %s", reason);
    }

    bool TransformFrame(Direction direction, std::span<const std::uint8_t> frame,
        std::vector<std::uint8_t>& rebuilt,std::uint32_t& delayMilliseconds)
    {
        const auto threshold = g_compressionThreshold.load();
        const bool compression = threshold >= 0;
        std::vector<std::uint8_t> packetData;
        bool compressed = false;
        if (compression) {
            const auto dataLength = ReadVarInt(frame);
            if (!dataLength || dataLength->value < 0 ||
                static_cast<std::size_t>(dataLength->value) > kMaximumFrame) return false;
            const auto body = frame.subspan(dataLength->bytes);
            if (dataLength->value == 0) packetData.assign(body.begin(), body.end());
            else {
                compressed = true;
                if (!Inflate(body, static_cast<std::size_t>(dataLength->value), packetData))
                    return false;
            }
        } else packetData.assign(frame.begin(), frame.end());

        const auto id = ReadVarInt(packetData);
        if (!id || id->value < 0) return false;
        PacketView packet;
        packet.direction = direction;
        packet.packetId = id->value;
        if (const auto* mapped = ResolvePacket(direction, packet.packetId)) {
            packet.mappingKey = mapped->key;
            packet.className = mapped->className;
        }
        packet.payload.assign(packetData.begin() + id->bytes, packetData.end());
        packet.compressionEnvelope = compression;
        packet.compressed = compressed;
        Notify(packet);
        const auto action = Dispatch(packet);
        ++packets_;
        lastPacketTick_ = client::scheduler::Now();
        if (packets_ <= 32)
            AOKI_LOG("[NATIVE-PACKET] %s id=%d bytes=%zu compressed=%d action=%u",
                direction == Direction::Inbound ? "IN" : "OUT", packet.packetId,
                packet.payload.size(), static_cast<int>(compressed),
                static_cast<unsigned>(action));
        if (action == Action::Cancel) {
            rebuilt.clear();
            return true;
        }
        if (action == Action::Pass) {
            rebuilt.assign(frame.begin(), frame.end());
            return true;
        }
        if(action==Action::Delay)delayMilliseconds=(std::max)(1u,packet.delayMilliseconds);

        packetData.clear();
        WriteVarInt(packetData, packet.packetId);
        packetData.insert(packetData.end(), packet.payload.begin(), packet.payload.end());
        if (!compression) {
            rebuilt = std::move(packetData);
            return true;
        }
        // Minecraft requires packets smaller than the negotiated threshold to
        // carry dataLength=0. Preserve neither the old compression bit nor its
        // zlib body after a mutation: decide again from rebuilt packet size.
        if (packetData.size() < static_cast<std::size_t>(threshold)) {
            rebuilt.clear();
            WriteVarInt(rebuilt, 0);
            rebuilt.insert(rebuilt.end(), packetData.begin(), packetData.end());
            return true;
        }
        std::vector<std::uint8_t> zipped;
        if (!Deflate(packetData, zipped)) return false;
        rebuilt.clear();
        WriteVarInt(rebuilt, static_cast<std::int32_t>(packetData.size()));
        rebuilt.insert(rebuilt.end(), zipped.begin(), zipped.end());
        return true;
    }

    std::mutex mutex_;
    Cfb8 input_;
    Cfb8 output_;
    std::vector<std::uint8_t> plaintext_;
    struct Delayed {ULONGLONG releaseAt;std::vector<std::uint8_t> plaintext;};
    std::deque<Delayed> delayed_;
    bool active_ = false;
    bool failed_ = false;
    bool validated_ = false;
    bool shadowing_ = false;
    std::size_t transparentRemaining_ = 0;
    std::uint64_t packets_ = 0;
    std::uint64_t inputCalls_ = 0;
    std::uint64_t inputBytes_ = 0;
    std::uint64_t lastInputTick_ = 0;
    std::uint64_t lastPacketTick_ = 0;
    std::uint64_t boundaryLosses_ = 0;
    std::uint64_t recoveries_ = 0;
};

std::array<Stream, 2> g_streams;

Stream& For(Direction direction)
{
    return g_streams[static_cast<std::size_t>(direction)];
}

} // namespace

void SetObserver(Observer observer)
{
    std::lock_guard lock(g_handlerMutex);
    g_observer = std::move(observer);
}

void SetHandler(Handler handler)
{
    std::lock_guard lock(g_handlerMutex);
    g_handler = std::move(handler);
}

bool HasHandler()
{
    std::lock_guard lock(g_handlerMutex);
    return static_cast<bool>(g_handler) || !g_mappedActions.empty();
}

bool SetMappedAction(std::string_view mappingKey, Action action)
{
    if (mappingKey.empty() || action == Action::Modify || action == Action::Replace || action == Action::Delay)
        return false;
    bool known = false;
    for (const auto& packet : mapping::generated::packets)
        if (mappingKey == packet.key) { known = true; break; }
    if (!known) return false;
    std::lock_guard lock(g_handlerMutex);
    if (action == Action::Pass) g_mappedActions.erase(std::string(mappingKey));
    else g_mappedActions[std::string(mappingKey)] = action;
    return true;
}

void ClearMappedActions()
{
    std::lock_guard lock(g_handlerMutex);
    g_mappedActions.clear();
}

std::string_view PacketName(Direction direction, std::int32_t packetId)
{
    const auto* packet = ResolvePacket(direction, packetId);
    if (!packet) return {};
    const std::string_view key = packet->key;
    const auto dot = key.rfind('.');
    return dot == std::string_view::npos ? key : key.substr(dot + 1);
}

std::string_view PacketClassName(Direction direction, std::int32_t packetId)
{
    const auto* packet = ResolvePacket(direction, packetId);
    return packet ? std::string_view(packet->className) : std::string_view{};
}

void PublishCipher(Direction direction, const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& registerBytes)
{
    For(direction).Initialize(key, registerBytes);
    g_cipherResync[static_cast<std::size_t>(direction)].store(false);
    AOKI_LOG("[NATIVE-PACKET] %s stream initialized",
        direction == Direction::Inbound ? "IN" : "OUT");
}

bool NeedsCipherResync(Direction direction)
{
    return g_cipherResync[static_cast<std::size_t>(direction)].load();
}

bool IsStreamActive(Direction direction)
{
    return For(direction).IsActive();
}

bool CanRewrite(Direction direction)
{
    return For(direction).CanRewrite();
}

StreamHealth GetStreamHealth(Direction direction)
{
    return For(direction).Health();
}

void RequestCipherResync(Direction direction, const char* reason)
{
    For(direction).Reset();
    g_cipherResync[static_cast<std::size_t>(direction)].store(true);
    AOKI_LOG("[NATIVE-PACKET] %s cipher resync requested: %s",
        direction == Direction::Inbound ? "IN" : "OUT",
        reason ? reason : "health check");
}

void SetCompressionEnabled(bool enabled)
{
    g_compressionThreshold.store(enabled ? 256 : -1);
}

void SetCompressionThreshold(std::int32_t threshold)
{
    if (threshold < 0 || static_cast<std::size_t>(threshold) > kMaximumFrame) {
        g_compressionThreshold.store(-1);
        AOKI_LOG("[NATIVE-PACKET] compression disabled");
        return;
    }
    const auto previous = g_compressionThreshold.exchange(threshold);
    if (previous != threshold)
        AOKI_LOG("[NATIVE-PACKET] compression threshold=%d", threshold);
}

void Observe(Direction direction, std::span<const std::uint8_t> ciphertext)
{
    (void)For(direction).Process(direction, ciphertext);
}

std::vector<std::uint8_t> Transform(Direction direction,
    std::span<const std::uint8_t> ciphertext)
{
    return For(direction).Process(direction, ciphertext);
}

void Reset()
{
    ResetStreams();
    ClearMappedActions();
}

void ResetStreams()
{
    for (auto& stream : g_streams) stream.Reset();
    for (auto& pending : g_cipherResync) pending.store(false);
}

namespace testing {
std::vector<std::uint8_t> Cfb8Encrypt(
    const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& iv,
    std::span<const std::uint8_t> plaintext)
{
    Cfb8 cipher;
    cipher.Reset(key, iv);
    std::vector<std::uint8_t> result;
    result.reserve(plaintext.size());
    for (const auto byte : plaintext) result.push_back(cipher.Encrypt(byte));
    return result;
}

std::vector<std::uint8_t> Cfb8Decrypt(
    const std::array<std::uint8_t, 16>& key,
    const std::array<std::uint8_t, 16>& iv,
    std::span<const std::uint8_t> ciphertext)
{
    Cfb8 cipher;
    cipher.Reset(key, iv);
    std::vector<std::uint8_t> result;
    result.reserve(ciphertext.size());
    for (const auto byte : ciphertext) result.push_back(cipher.Decrypt(byte));
    return result;
}
} // namespace testing

} // namespace client::native_packets
