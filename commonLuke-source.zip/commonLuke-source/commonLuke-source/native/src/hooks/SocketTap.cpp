#include "client/SocketTap.hpp"

#include "client/Logger.hpp"
#include "client/NativePacketEngine.hpp"

#include <winsock2.h>
#include <Windows.h>
#include <jni.h>
#include <MinHook.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cwchar>
#include <cstring>
#include <process.h>
#include <share.h>
#include <span>
#include <vector>

namespace {

constexpr char kFileMagic[8] = {'A', 'O', 'K', 'I', 'N', 'I', 'O', '1'};
constexpr std::uint32_t kRecordMagic = 0x314F494E; // "NIO1" little-endian
constexpr std::uint32_t kMaxRecordBytes = 16u * 1024u * 1024u;
constexpr std::uint32_t kMaxVectorCount = 1024;
constexpr std::size_t kMaxSocketChunk = 0x1ffff;
// Once a Java write has been accepted, the native sender owns the translated
// bytes until Winsock accepts them. Return backpressure before accepting more
// input once this queue reaches its high-water mark.
constexpr std::size_t kOutboundQueueHighWater = 8u * 1024u * 1024u;
constexpr DWORD kSenderIdleMilliseconds = 5;
constexpr jint kIoUnavailable = -2;

enum class Direction : std::uint8_t {
    Inbound = 0,
    Outbound = 1,
};

#pragma pack(push, 1)
struct RecordHeader {
    std::uint32_t magic;
    std::uint16_t headerSize;
    std::uint8_t direction;
    std::uint8_t reserved;
    std::uint32_t byteCount;
    std::uint32_t threadId;
    std::uint64_t tick;
    std::uint64_t fileDescriptorOop;
    std::uint64_t nativeAddress;
};

struct NativeIovec {
    std::uintptr_t base;
    std::size_t length;
};
#pragma pack(pop)

using ScalarIoFunction = jint (JNICALL*)(JNIEnv*, jclass, jobject, jlong, jint);
using VectorIoFunction = jlong (JNICALL*)(JNIEnv*, jclass, jobject, jlong, jint);
using FdValFunction = jint (JNICALL*)(JNIEnv*, jclass, jobject);
using CloseIoFunction = void (JNICALL*)(JNIEnv*, jclass, jobject);

ScalarIoFunction g_originalRead = nullptr;
ScalarIoFunction g_originalWrite = nullptr;
VectorIoFunction g_originalReadVector = nullptr;
VectorIoFunction g_originalWriteVector = nullptr;
FdValFunction g_fdVal = nullptr;
CloseIoFunction g_originalClose = nullptr;
CloseIoFunction g_originalPreClose = nullptr;

SRWLOCK g_captureLock = SRWLOCK_INIT;
FILE* g_captureFile = nullptr;
wchar_t g_capturePath[32768]{};
volatile LONG64 g_inboundBytes = 0;
volatile LONG64 g_outboundBytes = 0;
volatile LONG g_inboundRecords = 0;
volatile LONG g_outboundRecords = 0;
std::uint32_t g_captureRecordsSinceFlush = 0;
SRWLOCK g_inboundTransformLock = SRWLOCK_INIT;
SRWLOCK g_outboundTransformLock = SRWLOCK_INIT;
SRWLOCK g_socketBindLock = SRWLOCK_INIT;
std::vector<std::uint8_t> g_inboundPending;
std::vector<std::uint8_t> g_outboundPending;
std::size_t g_outboundPendingOffset = 0;
std::atomic<SOCKET> g_packetSocket{INVALID_SOCKET};
std::atomic<SOCKET> g_expectedSocket{INVALID_SOCKET};
HANDLE g_outboundEvent = nullptr;
HANDLE g_outboundThread = nullptr;
bool g_outboundSenderFailed = false;
std::atomic<bool> g_outboundSenderStop{false};

SOCKET ResolveSocket(JNIEnv* env, jobject fileDescriptor) noexcept
{
    if (!env || !fileDescriptor || !g_fdVal) return INVALID_SOCKET;
    const jint value = g_fdVal(env, nullptr, fileDescriptor);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return INVALID_SOCKET;
    }
    return static_cast<SOCKET>(static_cast<std::uint32_t>(value));
}

bool OwnsPacketSocket(SOCKET socket) noexcept
{
    if (socket == INVALID_SOCKET) return false;
    const auto expected = g_expectedSocket.load();
    return expected != INVALID_SOCKET && socket == expected &&
        g_packetSocket.load() == expected;
}

bool PacketTransportReady()
{
    return client::native_packets::HasHandler() &&
        client::native_packets::IsStreamActive(
            client::native_packets::Direction::Inbound) &&
        client::native_packets::IsStreamActive(
            client::native_packets::Direction::Outbound);
}

void AppendOutbound(std::span<const std::uint8_t> bytes)
{
    if (bytes.empty()) return;
    if (g_outboundPendingOffset != 0 &&
        (g_outboundPendingOffset >= 1024u * 1024u ||
         g_outboundPendingOffset * 2 >= g_outboundPending.size())) {
        g_outboundPending.erase(g_outboundPending.begin(),
            g_outboundPending.begin() + g_outboundPendingOffset);
        g_outboundPendingOffset = 0;
    }
    g_outboundPending.insert(g_outboundPending.end(), bytes.begin(), bytes.end());
}

std::size_t PendingOutboundBytes() noexcept
{
    return g_outboundPending.size() - g_outboundPendingOffset;
}

unsigned __stdcall OutboundSender(void*)
{
    while (!g_outboundSenderStop.load()) {
        WaitForSingleObject(g_outboundEvent, kSenderIdleMilliseconds);
        if (g_outboundSenderStop.load()) break;

        AcquireSRWLockExclusive(&g_outboundTransformLock);
        const SOCKET socket = g_packetSocket.load();
        if (socket != INVALID_SOCKET && !g_outboundSenderFailed &&
            PacketTransportReady() && client::native_packets::CanRewrite(
                client::native_packets::Direction::Outbound)) {
            // Delay actions must mature even if Java has no later write with
            // which to re-enter the packet engine.
            AppendOutbound(client::native_packets::Transform(
                client::native_packets::Direction::Outbound, {}));
        }

        if (socket == INVALID_SOCKET || g_outboundSenderFailed ||
            PendingOutboundBytes() == 0) {
            ReleaseSRWLockExclusive(&g_outboundTransformLock);
            continue;
        }

        WSABUF buffer{};
        buffer.buf = reinterpret_cast<char*>(
            g_outboundPending.data() + g_outboundPendingOffset);
        buffer.len = static_cast<ULONG>((std::min)(PendingOutboundBytes(),
            kMaxSocketChunk));
        DWORD sent = 0;
        const int result = WSASend(socket, &buffer, 1, &sent, 0,
            nullptr, nullptr);
        if (result == 0 && sent != 0) {
            g_outboundPendingOffset += sent;
            if (g_outboundPendingOffset == g_outboundPending.size()) {
                g_outboundPending.clear();
                g_outboundPendingOffset = 0;
            } else {
                SetEvent(g_outboundEvent);
            }
        } else if (result == SOCKET_ERROR) {
            const int error = WSAGetLastError();
            if (error != WSAEWOULDBLOCK) {
                g_outboundSenderFailed = true;
                AOKI_LOG("[NIO-TAP] native sender failed socket=%llu error=%d queued=%zu",
                    static_cast<unsigned long long>(socket), error,
                    PendingOutboundBytes());
                shutdown(socket, SD_BOTH);
            }
        }
        ReleaseSRWLockExclusive(&g_outboundTransformLock);
    }
    return 0;
}

void StopOutboundSender() noexcept
{
    if (!g_outboundThread) return;
    g_outboundSenderStop.store(true);
    SetEvent(g_outboundEvent);
    WaitForSingleObject(g_outboundThread, 5000);
    CloseHandle(g_outboundThread);
    g_outboundThread = nullptr;
    CloseHandle(g_outboundEvent);
    g_outboundEvent = nullptr;
}

bool ResetPacketTransport(SOCKET expectedSocket, const char* reason) noexcept
{
    AcquireSRWLockExclusive(&g_socketBindLock);
    const SOCKET socket = g_packetSocket.load();
    if (socket == INVALID_SOCKET ||
        (expectedSocket != INVALID_SOCKET && socket != expectedSocket)) {
        ReleaseSRWLockExclusive(&g_socketBindLock);
        return false;
    }

    AcquireSRWLockExclusive(&g_outboundTransformLock);
    AcquireSRWLockExclusive(&g_inboundTransformLock);
    g_outboundPending.clear();
    g_outboundPendingOffset = 0;
    g_inboundPending.clear();
    g_outboundSenderFailed = false;
    g_packetSocket.store(INVALID_SOCKET);
    g_expectedSocket.store(INVALID_SOCKET);
    client::native_packets::ResetStreams();
    ReleaseSRWLockExclusive(&g_inboundTransformLock);
    ReleaseSRWLockExclusive(&g_outboundTransformLock);
    ReleaseSRWLockExclusive(&g_socketBindLock);
    AOKI_LOG("[NIO-TAP] packet transport reset socket=%llu reason=%s",
        static_cast<unsigned long long>(socket), reason ? reason : "unknown");
    return true;
}

std::uint64_t ResolveHandleOop(jobject handle) noexcept
{
    if (!handle) return 0;
    __try {
        return static_cast<std::uint64_t>(reinterpret_cast<std::uintptr_t>(
            *reinterpret_cast<void**>(handle)));
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
}

void CaptureBytes(Direction direction, JNIEnv* env, jobject fileDescriptor,
    const void* data, std::uint32_t byteCount) noexcept
{
    if (!data || byteCount == 0 || byteCount > kMaxRecordBytes) return;
    // NIO is process-wide and also carries launcher/auth/telemetry sockets.
    // Capture and parse only the fd reached through the mapped live Netty
    // NioSocketChannel; never infer ownership from whichever socket fires first.
    if (!OwnsPacketSocket(ResolveSocket(env, fileDescriptor))) return;

    if (!client::native_packets::HasHandler()) {
        client::native_packets::Observe(
            direction == Direction::Inbound
                ? client::native_packets::Direction::Inbound
                : client::native_packets::Direction::Outbound,
            std::span(reinterpret_cast<const std::uint8_t*>(data), byteCount));
    }

    RecordHeader header{};
    header.magic = kRecordMagic;
    header.headerSize = sizeof(header);
    header.direction = static_cast<std::uint8_t>(direction);
    header.byteCount = byteCount;
    header.threadId = GetCurrentThreadId();
    header.tick = GetTickCount64();
    header.fileDescriptorOop = ResolveHandleOop(fileDescriptor);
    header.nativeAddress = static_cast<std::uint64_t>(
        reinterpret_cast<std::uintptr_t>(data));

    bool written = false;
    AcquireSRWLockExclusive(&g_captureLock);
    __try {
        if (g_captureFile &&
            fwrite(&header, sizeof(header), 1, g_captureFile) == 1 &&
            fwrite(data, byteCount, 1, g_captureFile) == 1) {
            if (++g_captureRecordsSinceFlush >= 256) {
                fflush(g_captureFile);
                g_captureRecordsSinceFlush = 0;
            }
            written = true;
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        written = false;
    }
    ReleaseSRWLockExclusive(&g_captureLock);
    if (!written) return;

    volatile LONG64* total = direction == Direction::Inbound
        ? &g_inboundBytes : &g_outboundBytes;
    volatile LONG* records = direction == Direction::Inbound
        ? &g_inboundRecords : &g_outboundRecords;
    const LONG record = InterlockedIncrement(records);
    const LONG64 bytes = InterlockedAdd64(total, byteCount);
    if (record <= 4 || (bytes / (1024 * 1024)) !=
        ((bytes - byteCount) / (1024 * 1024))) {
        AOKI_LOG("[NIO-TAP] %s record=%ld bytes=%u total=%lld fdOop=%p",
            direction == Direction::Inbound ? "IN" : "OUT", record,
            byteCount, bytes, reinterpret_cast<void*>(header.fileDescriptorOop));
    }
}

void CaptureVector(Direction direction, JNIEnv* env, jobject fileDescriptor,
    jlong vectorAddress, jint vectorCount, jlong transferred) noexcept
{
    if (vectorAddress == 0 || vectorCount <= 0 ||
        static_cast<std::uint32_t>(vectorCount) > kMaxVectorCount ||
        transferred <= 0 || transferred > kMaxRecordBytes) return;

    auto* joined = static_cast<std::uint8_t*>(HeapAlloc(
        GetProcessHeap(), 0, static_cast<SIZE_T>(transferred)));
    if (!joined) return;
    bool complete = false;
    __try {
        const auto* vectors = reinterpret_cast<const NativeIovec*>(
            static_cast<std::uintptr_t>(vectorAddress));
        std::uint64_t remaining = static_cast<std::uint64_t>(transferred);
        std::size_t offset = 0;
        for (jint index = 0; index < vectorCount && remaining; ++index) {
            const auto available = static_cast<std::uint64_t>(vectors[index].length);
            const auto current = static_cast<std::uint32_t>(
                (std::min)(remaining, available));
            if (current) {
                memcpy(joined + offset,
                    reinterpret_cast<const void*>(vectors[index].base), current);
                offset += current;
            }
            remaining -= current;
        }
        complete = remaining == 0;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        AOKI_LOG("[NIO-TAP] vector buffer access failed direction=%s",
            direction == Direction::Inbound ? "IN" : "OUT");
    }
    if (complete)
        CaptureBytes(direction, env, fileDescriptor, joined,
            static_cast<std::uint32_t>(transferred));
    HeapFree(GetProcessHeap(), 0, joined);
}

bool GatherVector(jlong vectorAddress, jint vectorCount, std::uint64_t byteCount,
    std::vector<std::uint8_t>& output) noexcept
{
    if (!vectorAddress || vectorCount <= 0 ||
        static_cast<std::uint32_t>(vectorCount) > kMaxVectorCount ||
        byteCount > kMaxRecordBytes) return false;
    output.resize(static_cast<std::size_t>(byteCount));
    __try {
        const auto* vectors = reinterpret_cast<const NativeIovec*>(
            static_cast<std::uintptr_t>(vectorAddress));
        std::size_t offset = 0;
        for (jint index = 0; index < vectorCount && offset < output.size(); ++index) {
            const auto count = (std::min)(vectors[index].length, output.size() - offset);
            if (count) std::memcpy(output.data() + offset,
                reinterpret_cast<const void*>(vectors[index].base), count);
            offset += count;
        }
        if (offset != output.size()) { output.clear(); return false; }
        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        output.clear();
        return false;
    }
}

std::size_t VectorCapacity(jlong vectorAddress, jint vectorCount) noexcept
{
    if (!vectorAddress || vectorCount <= 0 ||
        static_cast<std::uint32_t>(vectorCount) > kMaxVectorCount) return 0;
    __try {
        const auto* vectors = reinterpret_cast<const NativeIovec*>(
            static_cast<std::uintptr_t>(vectorAddress));
        std::size_t total = 0;
        for (jint index = 0; index < vectorCount; ++index) {
            if (vectors[index].length > kMaxRecordBytes - total) return 0;
            total += vectors[index].length;
        }
        return total;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
}

std::size_t ScatterVector(jlong vectorAddress, jint vectorCount,
    std::span<const std::uint8_t> input) noexcept
{
    __try {
        const auto* vectors = reinterpret_cast<const NativeIovec*>(
            static_cast<std::uintptr_t>(vectorAddress));
        std::size_t offset = 0;
        for (jint index = 0; index < vectorCount && offset < input.size(); ++index) {
            const auto count = (std::min)(vectors[index].length, input.size() - offset);
            if (count) std::memcpy(reinterpret_cast<void*>(vectors[index].base),
                input.data() + offset, count);
            offset += count;
        }
        return offset;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
}

jint JNICALL HookRead(JNIEnv* env, jclass owner, jobject fileDescriptor,
    jlong address, jint length)
{
    const bool transform = PacketTransportReady() &&
        OwnsPacketSocket(ResolveSocket(env, fileDescriptor));
    if (transform) {
        AcquireSRWLockExclusive(&g_inboundTransformLock);
        if (!g_inboundPending.empty()) {
            const auto count = (std::min)({static_cast<std::size_t>(length),
                g_inboundPending.size(), kMaxSocketChunk});
            std::memcpy(reinterpret_cast<void*>(static_cast<std::uintptr_t>(address)),
                g_inboundPending.data(), count);
            g_inboundPending.erase(g_inboundPending.begin(),
                g_inboundPending.begin() + count);
            ReleaseSRWLockExclusive(&g_inboundTransformLock);
            return static_cast<jint>(count);
        }
        ReleaseSRWLockExclusive(&g_inboundTransformLock);
    }
    const jint result = g_originalRead(env, owner, fileDescriptor, address, length);
    if (result > 0) {
        CaptureBytes(Direction::Inbound, env, fileDescriptor,
            reinterpret_cast<const void*>(static_cast<std::uintptr_t>(address)),
            static_cast<std::uint32_t>(result));
        if (transform) {
            const auto transformed = client::native_packets::Transform(
                client::native_packets::Direction::Inbound,
                std::span(reinterpret_cast<const std::uint8_t*>(
                    static_cast<std::uintptr_t>(address)), static_cast<std::size_t>(result)));
            if (transformed.empty()) return 0;
            const auto delivered = (std::min)({static_cast<std::size_t>(length),
                transformed.size(), kMaxSocketChunk});
            std::memcpy(reinterpret_cast<void*>(static_cast<std::uintptr_t>(address)),
                transformed.data(), delivered);
            if (delivered < transformed.size()) {
                AcquireSRWLockExclusive(&g_inboundTransformLock);
                g_inboundPending.insert(g_inboundPending.end(),
                    transformed.begin() + delivered, transformed.end());
                ReleaseSRWLockExclusive(&g_inboundTransformLock);
            }
            return static_cast<jint>(delivered);
        }
    }
    return result;
}

jint JNICALL HookWrite(JNIEnv* env, jclass owner, jobject fileDescriptor,
    jlong address, jint length)
{
    if (PacketTransportReady() && client::native_packets::CanRewrite(
            client::native_packets::Direction::Outbound) && length > 0) {
        const SOCKET socket = ResolveSocket(env, fileDescriptor);
        const bool candidateSocket = OwnsPacketSocket(socket);
        AcquireSRWLockExclusive(&g_outboundTransformLock);
        const bool ownsSocket = candidateSocket && g_packetSocket.load() == socket;
        if (ownsSocket && !g_outboundSenderFailed &&
            PendingOutboundBytes() < kOutboundQueueHighWater) {
            const auto accepted = (std::min)(static_cast<std::size_t>(length),
                kMaxSocketChunk);
            AppendOutbound(client::native_packets::Transform(
                client::native_packets::Direction::Outbound,
                std::span(reinterpret_cast<const std::uint8_t*>(
                    static_cast<std::uintptr_t>(address)), accepted)));
            ReleaseSRWLockExclusive(&g_outboundTransformLock);
            CaptureBytes(Direction::Outbound, env, fileDescriptor,
                reinterpret_cast<const void*>(static_cast<std::uintptr_t>(address)),
                static_cast<std::uint32_t>(accepted));
            SetEvent(g_outboundEvent);
            return static_cast<jint>(accepted);
        }
        const bool backpressured = ownsSocket && !g_outboundSenderFailed;
        ReleaseSRWLockExclusive(&g_outboundTransformLock);
        if (backpressured) return kIoUnavailable;
    }
    const jint result = g_originalWrite(env, owner, fileDescriptor, address, length);
    if (result > 0) {
        CaptureBytes(Direction::Outbound, env, fileDescriptor,
            reinterpret_cast<const void*>(static_cast<std::uintptr_t>(address)),
            static_cast<std::uint32_t>(result));
        if (PacketTransportReady() &&
            OwnsPacketSocket(ResolveSocket(env, fileDescriptor)) &&
            !client::native_packets::CanRewrite(
                client::native_packets::Direction::Outbound)) {
            // Shadow only bytes Winsock actually accepted. This preserves the
            // exact OpenJDK partial-write contract while proving frame bounds.
            (void)client::native_packets::Transform(
                client::native_packets::Direction::Outbound,
                std::span(reinterpret_cast<const std::uint8_t*>(
                    static_cast<std::uintptr_t>(address)),
                    static_cast<std::size_t>(result)));
        }
    }
    return result;
}

jlong JNICALL HookReadVector(JNIEnv* env, jclass owner, jobject fileDescriptor,
    jlong address, jint count)
{
    const bool transform = PacketTransportReady() &&
        OwnsPacketSocket(ResolveSocket(env, fileDescriptor));
    if (transform) {
        AcquireSRWLockExclusive(&g_inboundTransformLock);
        if (!g_inboundPending.empty()) {
            const auto delivered = ScatterVector(address, count,
                std::span<const std::uint8_t>(g_inboundPending).first(
                    (std::min)(g_inboundPending.size(), kMaxSocketChunk)));
            g_inboundPending.erase(g_inboundPending.begin(),
                g_inboundPending.begin() + delivered);
            ReleaseSRWLockExclusive(&g_inboundTransformLock);
            return static_cast<jlong>(delivered);
        }
        ReleaseSRWLockExclusive(&g_inboundTransformLock);
    }
    const jlong result = g_originalReadVector(env, owner, fileDescriptor, address, count);
    if (result > 0) {
        std::vector<std::uint8_t> joined;
        if (!GatherVector(address, count, static_cast<std::uint64_t>(result), joined))
            return result;
        CaptureBytes(Direction::Inbound, env, fileDescriptor, joined.data(),
            static_cast<std::uint32_t>(joined.size()));
        if (transform) {
            const auto transformed = client::native_packets::Transform(
                client::native_packets::Direction::Inbound, joined);
            if (transformed.empty()) return 0;
            const auto delivered = ScatterVector(address, count,
                std::span<const std::uint8_t>(transformed).first(
                    (std::min)(transformed.size(), kMaxSocketChunk)));
            if (delivered < transformed.size()) {
                AcquireSRWLockExclusive(&g_inboundTransformLock);
                g_inboundPending.insert(g_inboundPending.end(),
                    transformed.begin() + delivered, transformed.end());
                ReleaseSRWLockExclusive(&g_inboundTransformLock);
            }
            return static_cast<jlong>(delivered);
        }
    }
    return result;
}

jlong JNICALL HookWriteVector(JNIEnv* env, jclass owner, jobject fileDescriptor,
    jlong address, jint count)
{
    if (PacketTransportReady() && client::native_packets::CanRewrite(
            client::native_packets::Direction::Outbound)) {
        const auto total = VectorCapacity(address, count);
        std::vector<std::uint8_t> joined;
        const auto accepted = (std::min)(total, kMaxSocketChunk);
        if (!accepted || !GatherVector(address, count, accepted, joined))
            return g_originalWriteVector(env, owner, fileDescriptor, address, count);
        const SOCKET socket = ResolveSocket(env, fileDescriptor);
        const bool candidateSocket = OwnsPacketSocket(socket);
        AcquireSRWLockExclusive(&g_outboundTransformLock);
        const bool ownsSocket = candidateSocket && g_packetSocket.load() == socket;
        if (ownsSocket && !g_outboundSenderFailed &&
            PendingOutboundBytes() < kOutboundQueueHighWater) {
            AppendOutbound(client::native_packets::Transform(
                client::native_packets::Direction::Outbound, joined));
            ReleaseSRWLockExclusive(&g_outboundTransformLock);
            CaptureBytes(Direction::Outbound, env, fileDescriptor, joined.data(),
                static_cast<std::uint32_t>(joined.size()));
            SetEvent(g_outboundEvent);
            return static_cast<jlong>(accepted);
        }
        const bool backpressured = ownsSocket && !g_outboundSenderFailed;
        ReleaseSRWLockExclusive(&g_outboundTransformLock);
        if (backpressured) return static_cast<jlong>(kIoUnavailable);
    }
    const jlong result = g_originalWriteVector(env, owner, fileDescriptor, address, count);
    if (result > 0) {
        CaptureVector(Direction::Outbound, env, fileDescriptor, address, count, result);
        if (PacketTransportReady() &&
            OwnsPacketSocket(ResolveSocket(env, fileDescriptor)) &&
            !client::native_packets::CanRewrite(
                client::native_packets::Direction::Outbound)) {
            std::vector<std::uint8_t> written;
            if (GatherVector(address, count, static_cast<std::uint64_t>(result), written))
                (void)client::native_packets::Transform(
                    client::native_packets::Direction::Outbound, written);
        }
    }
    return result;
}

void JNICALL HookClose(JNIEnv* env, jclass owner, jobject fileDescriptor)
{
    const SOCKET socket = ResolveSocket(env, fileDescriptor);
    if (socket != INVALID_SOCKET) ResetPacketTransport(socket, "close0");
    g_originalClose(env, owner, fileDescriptor);
}

void JNICALL HookPreClose(JNIEnv* env, jclass owner, jobject fileDescriptor)
{
    const SOCKET socket = ResolveSocket(env, fileDescriptor);
    if (socket != INVALID_SOCKET) ResetPacketTransport(socket, "preClose0");
    g_originalPreClose(env, owner, fileDescriptor);
}

bool OpenCaptureFile() noexcept
{
    AcquireSRWLockExclusive(&g_captureLock);
    if (g_captureFile) {
        ReleaseSRWLockExclusive(&g_captureLock);
        return true;
    }
    if (!g_capturePath[0])
        wcscpy_s(g_capturePath, L"commonLuke.nio.bin");
    g_captureFile = _wfsopen(g_capturePath, L"ab+", _SH_DENYNO);
    if (!g_captureFile) {
        ReleaseSRWLockExclusive(&g_captureLock);
        AOKI_LOG("[NIO-TAP] capture file open failed path=%ls", g_capturePath);
        return false;
    }
    // Keep diagnostic capture writes off the Netty event-loop's disk path.
    // Periodic fflush above still makes bounded progress visible in the log.
    setvbuf(g_captureFile, nullptr, _IOFBF, 1024u * 1024u);
    _fseeki64(g_captureFile, 0, SEEK_END);
    if (_ftelli64(g_captureFile) == 0) {
        fwrite(kFileMagic, sizeof(kFileMagic), 1, g_captureFile);
        fflush(g_captureFile);
    }
    ReleaseSRWLockExclusive(&g_captureLock);
    return true;
}

} // namespace

namespace client::socket_tap {

bool BindTransport(std::uintptr_t value) noexcept
{
    const SOCKET requested = static_cast<SOCKET>(value);
    if (requested == INVALID_SOCKET) return false;

    const SOCKET current = g_packetSocket.load();
    if (current != INVALID_SOCKET && current != requested)
        ResetPacketTransport(current, "mapped NioSocketChannel changed");

    AcquireSRWLockExclusive(&g_socketBindLock);
    const bool changed = g_packetSocket.load() != requested ||
        g_expectedSocket.load() != requested;
    g_expectedSocket.store(requested);
    g_packetSocket.store(requested);
    ReleaseSRWLockExclusive(&g_socketBindLock);
    if (changed)
        AOKI_LOG("[NIO-TAP] mapped packet transport bound socket=%llu",
            static_cast<unsigned long long>(requested));
    return true;
}

void ConfigureCapturePath(const wchar_t* logPath) noexcept
{
    if (!logPath || !*logPath) return;
    _snwprintf_s(g_capturePath, _TRUNCATE, L"%ls.nio.bin", logPath);
}

void ResetTransport() noexcept
{
    ResetPacketTransport(INVALID_SOCKET, "netty pipeline changed");
}

bool Install() noexcept
{
    HMODULE nio = GetModuleHandleW(L"nio.dll");
    for (unsigned attempt = 0; attempt < 50 && !nio; ++attempt) {
        Sleep(100);
        nio = GetModuleHandleW(L"nio.dll");
    }
    if (!nio) {
        AOKI_LOG("[NIO-TAP] nio.dll was not loaded");
        return false;
    }
    if (!OpenCaptureFile()) return false;

    g_fdVal = reinterpret_cast<FdValFunction>(GetProcAddress(
        nio, "Java_sun_nio_ch_IOUtil_fdVal"));
    if (!g_fdVal) {
        AOKI_LOG("[NIO-TAP] missing export Java_sun_nio_ch_IOUtil_fdVal");
        return false;
    }
    g_outboundEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!g_outboundEvent) {
        AOKI_LOG("[NIO-TAP] sender event creation failed error=%lu", GetLastError());
        return false;
    }
    unsigned senderId = 0;
    g_outboundSenderStop.store(false);
    g_outboundThread = reinterpret_cast<HANDLE>(_beginthreadex(nullptr, 0,
        &OutboundSender, nullptr, 0, &senderId));
    if (!g_outboundThread) {
        AOKI_LOG("[NIO-TAP] sender thread creation failed");
        CloseHandle(g_outboundEvent);
        g_outboundEvent = nullptr;
        return false;
    }

    const MH_STATUS initialized = MH_Initialize();
    if (initialized != MH_OK && initialized != MH_ERROR_ALREADY_INITIALIZED) {
        AOKI_LOG("[NIO-TAP] MH_Initialize failed=%d", static_cast<int>(initialized));
        StopOutboundSender();
        return false;
    }

    struct HookSpec {
        const char* name;
        void* replacement;
        void** original;
        void* target;
        bool created;
    };
    std::array<HookSpec, 6> hooks{{
        {"Java_sun_nio_ch_SocketDispatcher_read0", reinterpret_cast<void*>(&HookRead),
            reinterpret_cast<void**>(&g_originalRead), nullptr, false},
        {"Java_sun_nio_ch_SocketDispatcher_write0", reinterpret_cast<void*>(&HookWrite),
            reinterpret_cast<void**>(&g_originalWrite), nullptr, false},
        {"Java_sun_nio_ch_SocketDispatcher_readv0", reinterpret_cast<void*>(&HookReadVector),
            reinterpret_cast<void**>(&g_originalReadVector), nullptr, false},
        {"Java_sun_nio_ch_SocketDispatcher_writev0", reinterpret_cast<void*>(&HookWriteVector),
            reinterpret_cast<void**>(&g_originalWriteVector), nullptr, false},
        {"Java_sun_nio_ch_SocketDispatcher_close0", reinterpret_cast<void*>(&HookClose),
            reinterpret_cast<void**>(&g_originalClose), nullptr, false},
        {"Java_sun_nio_ch_SocketDispatcher_preClose0", reinterpret_cast<void*>(&HookPreClose),
            reinterpret_cast<void**>(&g_originalPreClose), nullptr, false},
    }};

    bool ok = true;
    for (auto& hook : hooks) {
        hook.target = reinterpret_cast<void*>(GetProcAddress(nio, hook.name));
        if (!hook.target) {
            AOKI_LOG("[NIO-TAP] missing export %s", hook.name);
            ok = false;
            break;
        }
        const MH_STATUS created = MH_CreateHook(
            hook.target, hook.replacement, hook.original);
        if (created != MH_OK) {
            AOKI_LOG("[NIO-TAP] MH_CreateHook %s failed=%d", hook.name,
                static_cast<int>(created));
            ok = false;
            break;
        }
        hook.created = true;
        if (MH_QueueEnableHook(hook.target) != MH_OK) {
            AOKI_LOG("[NIO-TAP] queue enable failed for %s", hook.name);
            ok = false;
            break;
        }
    }
    if (ok && MH_ApplyQueued() != MH_OK) {
        AOKI_LOG("[NIO-TAP] applying hook transaction failed");
        ok = false;
    }
    if (!ok) {
        for (auto& hook : hooks)
            if (hook.created) MH_QueueDisableHook(hook.target);
        MH_ApplyQueued();
        for (auto& hook : hooks)
            if (hook.created) MH_RemoveHook(hook.target);
        StopOutboundSender();
        return false;
    }
    for (const auto& hook : hooks)
        AOKI_LOG("[NIO-TAP] hooked %s target=%p", hook.name, hook.target);
    AOKI_LOG("[NIO-TAP] install=PASS nio=%p capture=%ls senderThread=%u queueHighWater=%zu",
        nio, g_capturePath, senderId, kOutboundQueueHighWater);
    return true;
}

} // namespace client::socket_tap
