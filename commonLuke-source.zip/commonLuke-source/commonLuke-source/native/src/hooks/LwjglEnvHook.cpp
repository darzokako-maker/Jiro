#include "client/LwjglEnvHook.hpp"

#include "client/ClassJarDumper.hpp"
#include "client/PacketChatLogger.hpp"
#include "client/PacketBridge.hpp"
#include "client/PacketPayload.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/movement/ncp/NcpMovement.hpp"
#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/cosmetics/Cosmetics.hpp"
#include "features/visual/ambiance/Ambiance.hpp"
#include "features/visual/ambiance/ParticleLyrics.hpp"
#include "features/visual/freecam/FreeCam.hpp"
#include "features/combat/auto_harm/AutoHarm.hpp"
#include "features/combat/aim_assist/AimAssist.hpp"
#include "features/combat/velocity/Velocity.hpp"
#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/utility/auto_miner/AutoMiner.hpp"
#include "client/Logger.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "ui/hud/Notifications.hpp"
#include "client/ClassRepository.hpp"
#include "client/HotSpotAccess.hpp"
#include "game/MappingRepository.hpp"
#include "client/MethodManager.hpp"
#include "client/NativeScheduler.hpp"
#include "client/HudHook.hpp"
#include "features/visual/esp/EspCapture.hpp"
#include "features/visual/esp/Esp.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "features/visual/dragon_wings/DragonWingsCapture.hpp"
#include "features/movement/clips/ClipsCapture.hpp"
#include "features/movement/clips/ClipsRuntime.hpp"

#include <Windows.h>
#include <GL/gl.h>
#include <jni.h>
#include <MinHook.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <intrin.h>

namespace {

bool UpdateFriendList(std::string& list, const std::string& name, bool remove)
{
    std::string updated;
    bool found = false;
    for (std::size_t start = 0; start < list.size();) {
        const auto end = list.find(',', start);
        const auto token = list.substr(start, end == std::string::npos ? end : end - start);
        const auto first = token.find_first_not_of(" \t\r\n");
        const auto last = token.find_last_not_of(" \t\r\n");
        if (first != std::string::npos &&
            _stricmp(token.substr(first, last - first + 1).c_str(), name.c_str()) == 0) {
            found = true;
        } else if (!token.empty()) {
            if (!updated.empty()) updated += ',';
            updated += token;
        }
        if (end == std::string::npos) break;
        start = end + 1;
    }
    if (!remove) {
        if (!updated.empty()) updated += ',';
        updated += name;
    }
    list = std::move(updated);
    return found;
}

void MiddleClickFriend(JNIEnv* env, bool gameContext)
{
    static bool wasDown = false;
    const bool down = (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
    const bool pressed = down && !wasDown;
    wasDown = down;
    if (!pressed || !client::features::modules::Enabled(client::features::modules::Mcf) || !gameContext || client::ui::input::IsOpen() || env->ExceptionCheck()) return;
    DWORD foregroundProcess = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &foregroundProcess);
    if (foregroundProcess != GetCurrentProcessId() || env->PushLocalFrame(16) != JNI_OK) return;

    using namespace client;
    const auto mc = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto screen = mapping::Object(env, mc, "Minecraft.currentScreen");
    const auto player = mapping::Object(env, mc, "Minecraft.thePlayer");
    const auto hit = mapping::Object(env, mc, "Minecraft.objectMouseOver");
    const auto target = mapping::Object(env, hit, "MovingObjectPosition.entityHit");
    if (player && !screen && target && !env->IsSameObject(target, player) &&
        mapping::Instance(target, "EntityPlayer")) {
        const auto name = mapping::String(env, target, "Entity.getName");
        if (name && !name->empty() && name->find(',') == std::string::npos) {
            auto aura = features::aura::Options();
            auto esp = features::esp::Options();
            const bool inAura = UpdateFriendList(aura.friends, *name, true);
            const bool inEsp = UpdateFriendList(esp.friends, *name, true);
            if (!inAura && !inEsp) {
                UpdateFriendList(aura.friends, *name, false);
                UpdateFriendList(esp.friends, *name, false);
            }
            features::aura::SetOptions(std::move(aura));
            features::esp::SetOptions(esp);
            const bool removed = inAura || inEsp;
            ui::notifications::State().Push(removed ? ui::notifications::Type::Info : ui::notifications::Type::Success,
                                            removed ? "Friend removed" : "Friend added", *name);
            AOKI_LOG("[MCF] %s %s", inAura || inEsp ? "removed" : "added", name->c_str());
        }
    }
    env->PopLocalFrame(nullptr);
}

using GlClearFunction = void (JNICALL*)(JNIEnv*, jclass, jint);

GlClearFunction g_originalGlClear = nullptr;
std::atomic_flag g_probeLogged = ATOMIC_FLAG_INIT;

constexpr std::uintptr_t kMainVmRva = 0x6B0380;
constexpr std::uintptr_t kJniNativeInterfaceRva = 0x6B0390;
constexpr std::uintptr_t kJniInvokeInterfaceRva = 0x547570;
constexpr std::uintptr_t kTlsIndexRva = 0x6C0840;
constexpr std::uintptr_t kJavaThreadJniEnvironmentOffset = 0x1E8;
constexpr std::uintptr_t kTebTlsSlotsOffset = 0x1480;
constexpr std::uintptr_t kTebTlsExpansionSlotsOffset = 0x1780;
constexpr std::uint32_t kInlineTlsSlotCount = 64;
constexpr std::uint32_t kExpansionTlsSlotCount = 1024;

struct DirectJvmState {
    std::uintptr_t jvmBase = 0;
    std::uintptr_t jvmImageSize = 0;
    std::uint32_t tlsIndex = TLS_OUT_OF_INDEXES;
    void* javaThread = nullptr;
    JNIEnv* environment = nullptr;
    JavaVM* virtualMachine = nullptr;
    std::uintptr_t environmentTable = 0;
    std::uintptr_t getVersionEntry = 0;
    std::uintptr_t virtualMachineTable = 0;
};

bool ResolveDirectJvmState(DirectJvmState& state) noexcept
{
    state = {};
    __try {
        const auto jvm = GetModuleHandleW(L"jvm.dll");
        if (!jvm) return false;

        state.jvmBase = reinterpret_cast<std::uintptr_t>(jvm);
        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(state.jvmBase);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(
            state.jvmBase + static_cast<std::uintptr_t>(dos->e_lfanew));
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC ||
            nt->OptionalHeader.SizeOfImage <= kTlsIndexRva) {
            return false;
        }
        state.jvmImageSize = nt->OptionalHeader.SizeOfImage;

        state.tlsIndex = *reinterpret_cast<const std::uint32_t*>(
            state.jvmBase + kTlsIndexRva);
        if (state.tlsIndex == TLS_OUT_OF_INDEXES ||
            state.tlsIndex >= kInlineTlsSlotCount + kExpansionTlsSlotCount) {
            return false;
        }

        auto* teb = reinterpret_cast<std::byte*>(__readgsqword(0x30));
        if (!teb) return false;

        if (state.tlsIndex < kInlineTlsSlotCount) {
            auto** slots = reinterpret_cast<void**>(teb + kTebTlsSlotsOffset);
            state.javaThread = slots[state.tlsIndex];
        } else {
            auto*** expansionSlotAddress = reinterpret_cast<void***>(
                teb + kTebTlsExpansionSlotsOffset);
            auto** expansionSlots = *expansionSlotAddress;
            if (!expansionSlots) return false;
            state.javaThread = expansionSlots[state.tlsIndex - kInlineTlsSlotCount];
        }
        if (!state.javaThread) return false;

        state.environment = reinterpret_cast<JNIEnv*>(
            reinterpret_cast<std::byte*>(state.javaThread) +
            kJavaThreadJniEnvironmentOffset);
        state.virtualMachine = reinterpret_cast<JavaVM*>(state.jvmBase + kMainVmRva);
        state.environmentTable = *reinterpret_cast<const std::uintptr_t*>(state.environment);
        state.virtualMachineTable = *reinterpret_cast<const std::uintptr_t*>(state.virtualMachine);
        if (!state.environmentTable) return false;
        const auto* environmentFunctions =
            reinterpret_cast<const JNINativeInterface_*>(state.environmentTable);
        state.getVersionEntry = reinterpret_cast<std::uintptr_t>(
            environmentFunctions->GetVersion);

        const bool getVersionInJvm = state.getVersionEntry >= state.jvmBase &&
            state.getVersionEntry - state.jvmBase < state.jvmImageSize;
        return getVersionInJvm &&
            state.virtualMachineTable == state.jvmBase + kJniInvokeInterfaceRva;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        state = {};
        return false;
    }
}

void CaptureEnvironment(JNIEnv* hookEnvironment)
{
    if (g_probeLogged.test_and_set()) return;

    DirectJvmState direct;
    const bool valid = ResolveDirectJvmState(direct);
    AOKI_LOG("[JVM-DIRECT] base=%p tlsIndex=0x%X javaThread=%p",
        reinterpret_cast<void*>(direct.jvmBase), direct.tlsIndex, direct.javaThread);
    AOKI_LOG("[JVM-DIRECT] env=%p hookEnv=%p match=%s table=%p tableMode=%s getVersion=%p",
        static_cast<void*>(direct.environment), static_cast<void*>(hookEnvironment),
        direct.environment == hookEnvironment ? "YES" : "NO",
        reinterpret_cast<void*>(direct.environmentTable),
        direct.environmentTable == direct.jvmBase + kJniNativeInterfaceRva
            ? "STATIC" : "RUNTIME-COPY",
        reinterpret_cast<void*>(direct.getVersionEntry));
    AOKI_LOG("[JVM-DIRECT] vm=%p table=%p validation=%s",
        static_cast<void*>(direct.virtualMachine),
        reinterpret_cast<void*>(direct.virtualMachineTable), valid ? "PASS" : "FAIL");

    if (!valid || direct.environment != hookEnvironment) return;

#if defined(AOKI_ENV_PROBE_ONLY)
    client::class_jar::Start();
#else
    {
        client::classes::Capture(direct.environment);
        client::mapping::DiagnoseSnapshot(direct.environment);
        client::hotspot::ResolvePlayerMapping();
        client::packet_chat::Install();
        client::payload::PrintHelp();
    }
#endif
}

void JNICALL HookedGlClear(JNIEnv* environment, jclass owner, jint mask)
{
#if defined(AOKI_ENV_PROBE_ONLY)
    CaptureEnvironment(environment);
    g_originalGlClear(environment, owner, mask);
#else
    const bool gameContext=client::hud::CaptureContext();
    CaptureEnvironment(environment);
    client::payload::Poll(environment);
    client::methods::Drain(environment);
    static client::scheduler::Cursor moduleCursor;
    client::scheduler::Configure(client::scheduler::Task::ModulePoll, true, 1);
    const bool modulePoll = gameContext &&
        client::scheduler::Consume(client::scheduler::Task::ModulePoll, moduleCursor);
    if (modulePoll) client::packet_chat::Poll(environment);
    // Edge-triggered input must be sampled every render callback so a click
    // cannot be consumed by a non-poll frame.
    MiddleClickFriend(environment, gameContext);
    if (modulePoll) client::features::disconnect::Poll(environment);
    if (modulePoll) client::features::extras::Poll(environment);
    if (modulePoll) client::features::autominer::Poll(environment);
    if (modulePoll) client::features::aimassist::Poll(environment);
    if (modulePoll) client::features::velocity::Poll(environment);
    if (modulePoll) client::features::norotate::Poll(environment);
    if (modulePoll) client::features::nojump::Poll(environment);
    if (modulePoll) client::features::spotify::PollRuntime();
    if (modulePoll) client::features::ambiance::PollRuntime();
    if (modulePoll) client::features::cosmetics::Poll(environment);
    if (modulePoll) client::features::movement::Poll(environment);
    if (modulePoll) client::features::clips::Poll(environment);
    if (modulePoll) client::features::freecam::Poll(environment);
    client::hotspot::PollCoordinates(environment);
    if (modulePoll) client::features::esp::UpdateNameTags();
    if(gameContext)client::features::wings::BeforeClear(environment,static_cast<unsigned>(mask));
    if(gameContext)client::features::ambiance::RenderLyricsWorld(environment,static_cast<unsigned>(mask));
    g_originalGlClear(environment, owner, mask);
#endif
}


} // namespace 

namespace client::lwjgl_env_hook {
JNIEnv* CurrentEnvironment()
{
    DirectJvmState direct;
    return ResolveDirectJvmState(direct) ? direct.environment : nullptr;
}

bool Install()
{
    HMODULE lwjgl = nullptr;
    for (unsigned attempt = 0; attempt < 30 && lwjgl == nullptr; ++attempt) {
        lwjgl = GetModuleHandleW(L"lwjgl_opengl.dll");
        if (lwjgl == nullptr) {
            Sleep(100);
        }
    }
    if (lwjgl == nullptr) {
        AOKI_LOG("LWJGL module was not available during bootstrap");
        return false;
    }

    auto* target = reinterpret_cast<void*>(GetProcAddress(
        lwjgl, "Java_org_lwjgl_opengl_GL11C_glClear"));
    if (target == nullptr) {
        AOKI_LOG("LWJGL GL11C.glClear export was not found"); // 
        return false;
    }

    const MH_STATUS initializeStatus = MH_Initialize();
    if (initializeStatus != MH_OK &&
        initializeStatus != MH_ERROR_ALREADY_INITIALIZED) {
        AOKI_LOG("MH_Initialize failed: %d", static_cast<int>(initializeStatus));
        return false;
    }

    const MH_STATUS createStatus = MH_CreateHook(
        target,
        reinterpret_cast<void*>(&HookedGlClear),
        reinterpret_cast<void**>(&g_originalGlClear));
    if (createStatus != MH_OK) {
        AOKI_LOG("MH_CreateHook failed: %d", static_cast<int>(createStatus));
        return false;
    }

    const MH_STATUS enableStatus = MH_EnableHook(target);
    if (enableStatus != MH_OK) {
        AOKI_LOG("MH_EnableHook failed: %d", static_cast<int>(enableStatus));
        return false;
    }

#if defined(AOKI_ENV_PROBE_ONLY)
    AOKI_LOG("[JVM-DIRECT] LWJGL hook enabled; waiting for the Java render thread");
#else
    client::hud::Install();
#endif

    return true;
}

} // namespace client::lwjgl_env_hook
