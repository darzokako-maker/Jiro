#include "client/PacketChatLogger.hpp"

#include "client/Logger.hpp"
#include "client/MethodManager.hpp"
#include "client/NativePacketEngine.hpp"
#include "game/MappingRepository.hpp"
#include "ClientMappings.hpp"

#include <Windows.h>

#include <atomic>
#include <deque>
#include <mutex>
#include <string>

namespace client::packet_chat {
namespace {

constexpr std::size_t kMaximumQueuedMessages = 4096;
constexpr std::size_t kMaximumMessagesPerPoll = 64;

std::mutex g_mutex;
std::deque<std::string> g_messages;
std::atomic<std::uint64_t> g_dropped{0};
std::atomic<std::uint64_t> g_observed{0};
std::atomic<std::uint64_t> g_delivered{0};
std::atomic<std::uint64_t> g_lastDeferredLog{0};
std::atomic<bool> g_installed{false};
std::atomic<bool> g_enabled{false};

methods::Argument ObjectArgument(jobject value)
{
    methods::Argument argument{methods::Type::Object};
    argument.value.l = value;
    return argument;
}

void QueuePacket(std::int32_t packetId, std::string_view className)
{
    if (!g_enabled.load()) return;
    const auto name = packetId >= 0
        ? native_packets::PacketName(native_packets::Direction::Inbound, packetId)
        : std::string_view{};
    std::string text = "\xC2\xA7" "8[Packet] " "\xC2\xA7" "f";
    if (!name.empty()) text += std::string(name);
    else text += "Unknown";
    text += " [" + std::to_string(packetId) + "]";
    if (!className.empty()) {
        const auto slash = className.rfind('/');
        text += " <" + std::string(className.substr(
            slash == std::string_view::npos ? 0 : slash + 1)) + ">";
    }

    std::size_t queued = 0;
    {
        std::unique_lock lock(g_mutex, std::try_to_lock);
        if (!lock.owns_lock()) {
            ++g_dropped;
            return;
        }
        if (g_messages.size() >= kMaximumQueuedMessages) {
            ++g_dropped;
            return;
        }
        g_messages.push_back(std::move(text));
        queued = g_messages.size();
    }
    const auto observed = g_observed.fetch_add(1) + 1;
    if (observed == 1 || (observed % 1024) == 0)
        AOKI_LOG("[PACKET-CHAT] observed=%llu queued=%zu delivered=%llu",
            static_cast<unsigned long long>(observed), queued,
            static_cast<unsigned long long>(g_delivered.load()));
}

void RequeueFront(std::deque<std::string>& messages)
{
    if (messages.empty()) return;
    std::unique_lock lock(g_mutex, std::try_to_lock);
    if (!lock.owns_lock()) {
        g_dropped.fetch_add(messages.size());
        messages.clear();
        return;
    }
    while (g_messages.size() + messages.size() > kMaximumQueuedMessages &&
        !g_messages.empty()) {
        g_messages.pop_back();
        ++g_dropped;
    }
    while (!messages.empty()) {
        g_messages.push_front(std::move(messages.back()));
        messages.pop_back();
    }
}

bool AddChatMessage(JNIEnv* env, const std::string& text)
{
    if (!env || env->ExceptionCheck()) return false;
    const auto minecraft = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto player = minecraft
        ? mapping::Object(env, minecraft, "Minecraft.thePlayer") : nullptr;
    if (!player) return false;

    const auto javaText = env->NewStringUTF(text.c_str());
    if (!javaText || env->ExceptionCheck()) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return false;
    }
    const auto component = mapping::New(env, "ChatText.constructor",
        {ObjectArgument(javaText)});
    env->DeleteLocalRef(javaText);
    if (!component) return false;

    auto result = mapping::Invoke(env, player, "ClientPlayer.addChatMessage",
        {ObjectArgument(component)});
    env->DeleteLocalRef(component);
    const bool ok = result.ok;
    if (!ok) AOKI_LOG("[PACKET-CHAT] addChatMessage failed: %s", result.error.c_str());
    result.Release(env);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }
    return ok;
}

} // namespace

void Install()
{
    if (g_installed.exchange(true)) return;
    AOKI_LOG("[PACKET-CHAT] Java proxy observer ready; Packet Logger module is OFF");
}

bool BeforeReceive(JNIEnv*, jobject packet)
{
    if (!packet || !g_enabled.load()) return true;
    const auto* runtime = mapping::RuntimeClass(packet);
    if (!runtime) return true;
    std::int32_t packetId = -1;
    for (const auto& mapped : mapping::generated::packets) {
        if (mapped.inbound && runtime->name == mapped.className) {
            packetId = mapped.id;
            break;
        }
    }
    QueuePacket(packetId, runtime->name);
    return true;
}

bool Enabled()
{
    return g_enabled.load();
}

void SetEnabled(bool enabled)
{
    const bool previous = g_enabled.exchange(enabled);
    if (previous == enabled) return;
    if (!enabled) {
        std::unique_lock lock(g_mutex, std::try_to_lock);
        if (lock.owns_lock()) g_messages.clear();
        g_dropped.store(0);
    }
    g_observed.store(0);
    g_delivered.store(0);
    g_lastDeferredLog.store(0);
    AOKI_LOG("[PACKET-CHAT] module=%s", enabled ? "ON" : "OFF");
}

void Poll(JNIEnv* env)
{
    if (!g_installed.load() || !g_enabled.load() || !env || env->ExceptionCheck()) return;
    std::deque<std::string> batch;
    {
        std::unique_lock lock(g_mutex, std::try_to_lock);
        if (!lock.owns_lock()) return;
        for (std::size_t index = 0;
             index < kMaximumMessagesPerPoll && !g_messages.empty(); ++index) {
            batch.push_back(std::move(g_messages.front()));
            g_messages.pop_front();
        }
    }
    if (batch.empty()) return;
    if (env->PushLocalFrame(128) != JNI_OK) {
        RequeueFront(batch);
        return;
    }
    while (!batch.empty()) {
        if (!AddChatMessage(env, batch.front())) break;
        batch.pop_front();
        const auto delivered = g_delivered.fetch_add(1) + 1;
        if ((delivered % 512) == 0)
            AOKI_LOG("[PACKET-CHAT] delivered=%llu observed=%llu",
                static_cast<unsigned long long>(delivered),
                static_cast<unsigned long long>(g_observed.load()));
    }
    env->PopLocalFrame(nullptr);
    if (!batch.empty()) {
        RequeueFront(batch);
        const auto now = static_cast<std::uint64_t>(GetTickCount64());
        auto previous = g_lastDeferredLog.load();
        if (now >= previous + 5000 &&
            g_lastDeferredLog.compare_exchange_strong(previous, now))
            AOKI_LOG("[PACKET-CHAT] delivery deferred: player/chat mapping unavailable");
    }

    const auto dropped = g_dropped.exchange(0);
    if (dropped) AOKI_LOG("[PACKET-CHAT] dropped=%llu queue capacity=%zu",
        static_cast<unsigned long long>(dropped), kMaximumQueuedMessages);
}

void Stop()
{
    std::unique_lock lock(g_mutex, std::try_to_lock);
    if (lock.owns_lock()) g_messages.clear();
    g_enabled.store(false);
    g_installed.store(false);
}

} // namespace client::packet_chat
