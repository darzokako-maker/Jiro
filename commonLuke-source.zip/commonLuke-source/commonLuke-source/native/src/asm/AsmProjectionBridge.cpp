#include "asm/AsmProjection.hpp"
#include <intrin.h>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace client::asm_math {
namespace {

std::atomic<ProjectionBackend> g_backend{ProjectionBackend::Auto};

bool DetectCpuFeatures() noexcept {
    int cpuInfo[4] = {0};
    __cpuid(cpuInfo, 0);
    const int maxFunc = cpuInfo[0];
    if (maxFunc < 7) return false;

    __cpuid(cpuInfo, 1);
    const bool osUsesXSAVE = (cpuInfo[2] & (1 << 27)) != 0;
    const bool cpuAVX = (cpuInfo[2] & (1 << 28)) != 0;
    const bool cpuFMA = (cpuInfo[2] & (1 << 12)) != 0;

    if (!osUsesXSAVE || !cpuAVX || !cpuFMA) return false;

    const unsigned long long xcrFeatureMask = _xgetbv(_XCR_XFEATURE_ENABLED_MASK);
    if ((xcrFeatureMask & 0x6) != 0x6) return false; // Both XMM (bit 1) and YMM (bit 2) state enabled

    __cpuidex(cpuInfo, 7, 0);
    const bool cpuAVX2 = (cpuInfo[1] & (1 << 5)) != 0;
    return cpuAVX2;
}

const bool g_cpuSupportsAVX2 = DetectCpuFeatures();

struct V4Double { double x, y, z, w; };

V4Double MultiplyMatrix(const float* matrix, V4Double p) noexcept {
    return {
        matrix[0] * p.x + matrix[4] * p.y + matrix[8]  * p.z + matrix[12] * p.w,
        matrix[1] * p.x + matrix[5] * p.y + matrix[9]  * p.z + matrix[13] * p.w,
        matrix[2] * p.x + matrix[6] * p.y + matrix[10] * p.z + matrix[14] * p.w,
        matrix[3] * p.x + matrix[7] * p.y + matrix[11] * p.z + matrix[15] * p.w
    };
}

} // namespace

bool HasAVX2AndFMA() noexcept {
    return g_cpuSupportsAVX2;
}

void SetProjectionBackend(ProjectionBackend b) noexcept {
    g_backend.store(b, std::memory_order_relaxed);
}

ProjectionBackend GetProjectionBackend() noexcept {
    return g_backend.load(std::memory_order_relaxed);
}

const char* GetProjectionBackendName(ProjectionBackend b) noexcept {
    switch (b) {
    case ProjectionBackend::Auto: return "Auto (Hardware Selected)";
    case ProjectionBackend::AsmAVX2: return "Pure x64 MASM AVX2/FMA";
    case ProjectionBackend::AsmScalar: return "Pure x64 MASM Scalar";
    case ProjectionBackend::OptimizedCpp: return "Optimized C++ (Pre-multiplied VP)";
    case ProjectionBackend::ReferenceCpp: return "Original Reference C++";
    default: return "Unknown";
    }
}

// ----------------------------------------------------------------------------
// Reference C++ implementation (Exact bitwise logic of original Esp.cpp::Project)
// ----------------------------------------------------------------------------
int ProjectReferenceCpp(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept {
    if (!params || !outBox) return 0;
    if (params->viewport[2] <= 0 || params->viewport[3] <= 0) return 0;

    const double p = std::clamp(params->partial, 0.0f, 1.0f);
    const double centerX = params->lastX + (params->posX - params->lastX) * p - params->camX;
    const double centerY = params->lastY + (params->posY - params->lastY) * p - params->camY;
    const double centerZ = params->lastZ + (params->posZ - params->lastZ) * p - params->camZ;

    const double halfX = (params->maxX - params->minX) / 1.5 + 0.15;
    const double halfZ = (params->maxZ - params->minZ) / 1.5 + 0.15;
    const double bottom = centerY - 0.15;
    const double top = centerY + (params->maxY - params->minY) + (params->sneaking ? -0.3 : 0.18) + 0.15;

    std::array<V4Double, 8> corners;
    for (int i = 0; i < 8; ++i) {
        const double px = centerX + ((i & 1) ? halfX : -halfX);
        const double py = (i & 2) ? top : bottom;
        const double pz = centerZ + ((i & 4) ? halfZ : -halfZ);
        corners[i] = MultiplyMatrix(params->projection,
                        MultiplyMatrix(params->model, {px, py, pz, 1.0}));
    }

    AsmScreenBox result{INFINITY, INFINITY, -INFINITY, -INFINITY};
    int validCount = 0;

    auto add = [&](V4Double v) {
        if (v.w < 0.000001 || v.z < -v.w - 0.00001 || v.z > v.w) return;
        const float x = static_cast<float>(params->viewport[0] + (v.x / v.w + 1.0) * params->viewport[2] * 0.5);
        const float y = static_cast<float>(params->framebufferHeight - (params->viewport[1] + (v.y / v.w + 1.0) * params->viewport[3] * 0.5));
        if (!std::isfinite(x) || !std::isfinite(y)) return;
        result.x = std::min(result.x, x);
        result.y = std::min(result.y, y);
        result.right = std::max(result.right, x);
        result.bottom = std::max(result.bottom, y);
        ++validCount;
    };

    for (const auto& v : corners) add(v);

    for (int i = 0; i < 8; ++i) {
        for (int bit : {1, 2, 4}) {
            if (!(i & bit)) {
                const auto a = corners[i], b = corners[i | bit];
                const double da = a.z + a.w, db = b.z + b.w;
                if ((da < 0.0) != (db < 0.0)) {
                    const double t = da / (da - db);
                    add({a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t});
                }
            }
        }
    }

    if (validCount == 0 || !std::isfinite(result.x) || result.right < 0.0f || result.bottom < 0.0f ||
        result.x > static_cast<float>(params->viewport[2] + params->viewport[0]) ||
        result.y > static_cast<float>(params->framebufferHeight)) {
        return 0;
    }

    result.x = std::max(result.x, -256.0f);
    result.y = std::max(result.y, -256.0f);
    result.right = std::min(result.right, static_cast<float>(params->viewport[2] + params->viewport[0]) + 256.0f);
    result.bottom = std::min(result.bottom, static_cast<float>(params->framebufferHeight) + 256.0f);

    if (result.right > result.x && result.bottom > result.y) {
        *outBox = result;
        return 1;
    }
    return 0;
}

// ----------------------------------------------------------------------------
// Optimized C++ implementation (Pre-multiplied ViewProj + early frustum cull)
// ----------------------------------------------------------------------------
int ProjectOptimizedCpp(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept {
    if (!params || !outBox) return 0;
    if (params->viewport[2] <= 0 || params->viewport[3] <= 0) return 0;

    // Pre-multiply ViewProj = Projection * ModelView
    float vp[16];
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 4; ++row) {
            vp[col * 4 + row] =
                params->projection[0 * 4 + row] * params->model[col * 4 + 0] +
                params->projection[1 * 4 + row] * params->model[col * 4 + 1] +
                params->projection[2 * 4 + row] * params->model[col * 4 + 2] +
                params->projection[3 * 4 + row] * params->model[col * 4 + 3];
        }
    }

    const double p = std::clamp(params->partial, 0.0f, 1.0f);
    const float centerX = static_cast<float>(params->lastX + (params->posX - params->lastX) * p - params->camX);
    const float centerY = static_cast<float>(params->lastY + (params->posY - params->lastY) * p - params->camY);
    const float centerZ = static_cast<float>(params->lastZ + (params->posZ - params->lastZ) * p - params->camZ);

    const float halfX = static_cast<float>((params->maxX - params->minX) / 1.5 + 0.15);
    const float halfZ = static_cast<float>((params->maxZ - params->minZ) / 1.5 + 0.15);
    const float bottom = centerY - 0.15f;
    const float top = static_cast<float>(centerY + (params->maxY - params->minY) + (params->sneaking ? -0.3 : 0.18) + 0.15);

    struct V4Float { float x, y, z, w; };
    std::array<V4Float, 8> corners;
    int behindCount = 0;

    for (int i = 0; i < 8; ++i) {
        const float px = centerX + ((i & 1) ? halfX : -halfX);
        const float py = (i & 2) ? top : bottom;
        const float pz = centerZ + ((i & 4) ? halfZ : -halfZ);

        corners[i] = {
            vp[0] * px + vp[4] * py + vp[8]  * pz + vp[12],
            vp[1] * px + vp[5] * py + vp[9]  * pz + vp[13],
            vp[2] * px + vp[6] * py + vp[10] * pz + vp[14],
            vp[3] * px + vp[7] * py + vp[11] * pz + vp[15]
        };

        if (corners[i].z + corners[i].w < 0.0f) {
            ++behindCount;
        }
    }

    if (behindCount == 8) return 0; // Entire entity behind near plane

    AsmScreenBox result{INFINITY, INFINITY, -INFINITY, -INFINITY};
    int validCount = 0;

    auto add = [&](V4Float v) {
        if (v.w < 0.000001f || v.z < -v.w - 0.00001f || v.z > v.w) return;
        const float invW = 1.0f / v.w;
        const float x = params->viewport[0] + (v.x * invW + 1.0f) * params->viewport[2] * 0.5f;
        const float y = params->framebufferHeight - (params->viewport[1] + (v.y * invW + 1.0f) * params->viewport[3] * 0.5f);
        if (!std::isfinite(x) || !std::isfinite(y)) return;
        result.x = std::min(result.x, x);
        result.y = std::min(result.y, y);
        result.right = std::max(result.right, x);
        result.bottom = std::max(result.bottom, y);
        ++validCount;
    };

    for (const auto& v : corners) add(v);

    if (behindCount > 0) {
        // Only do edge clipping if at least one vertex crossed the near plane
        for (int i = 0; i < 8; ++i) {
            for (int bit : {1, 2, 4}) {
                if (!(i & bit)) {
                    const auto a = corners[i], b = corners[i | bit];
                    const float da = a.z + a.w, db = b.z + b.w;
                    if ((da < 0.0f) != (db < 0.0f)) {
                        const float t = da / (da - db);
                        add({a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t});
                    }
                }
            }
        }
    }

    if (validCount == 0 || !std::isfinite(result.x) || result.right < 0.0f || result.bottom < 0.0f ||
        result.x > static_cast<float>(params->viewport[2] + params->viewport[0]) ||
        result.y > static_cast<float>(params->framebufferHeight)) {
        return 0;
    }

    result.x = std::max(result.x, -256.0f);
    result.y = std::max(result.y, -256.0f);
    result.right = std::min(result.right, static_cast<float>(params->viewport[2] + params->viewport[0]) + 256.0f);
    result.bottom = std::min(result.bottom, static_cast<float>(params->framebufferHeight) + 256.0f);

    if (result.right > result.x && result.bottom > result.y) {
        *outBox = result;
        return 1;
    }
    return 0;
}

int ProjectWithBackend(ProjectionBackend backend, const AsmProjectParams* params, AsmScreenBox* outBox) noexcept {
    switch (backend) {
    case ProjectionBackend::AsmAVX2:
        return asm_ProjectAVX2(params, outBox);
    case ProjectionBackend::AsmScalar:
        return asm_ProjectScalar(params, outBox);
    case ProjectionBackend::OptimizedCpp:
        return ProjectOptimizedCpp(params, outBox);
    case ProjectionBackend::ReferenceCpp:
        return ProjectReferenceCpp(params, outBox);
    case ProjectionBackend::Auto:
    default:
        if (g_cpuSupportsAVX2) {
            return asm_ProjectAVX2(params, outBox);
        }
        return asm_ProjectScalar(params, outBox);
    }
}

int ProjectDispatch(const AsmProjectParams* params, AsmScreenBox* outBox) noexcept {
    return ProjectWithBackend(g_backend.load(std::memory_order_relaxed), params, outBox);
}

} // namespace client::asm_math

