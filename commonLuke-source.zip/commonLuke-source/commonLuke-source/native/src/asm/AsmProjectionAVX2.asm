; =============================================================================
; AOKI Client — Pure x64 MASM AVX2/FMA Projection Engine
; High-performance SIMD pipeline for 8-corner AABB World-to-Screen transformation
; Calling convention: Microsoft x64 ABI
;
; int asm_ProjectAVX2(const AsmProjectParams* params, AsmScreenBox* outBox)
; RCX = params
; RDX = outBox
; Returns EAX: 1 if visible & valid box written, 0 otherwise
; =============================================================================

OPTION CASEMAP:NONE

.const
ALIGN 16
c_avx_eps_w        REAL4 0.000001, 0.000001, 0.000001, 0.000001, 0.000001, 0.000001, 0.000001, 0.000001
c_avx_eps_near     REAL4 0.00001,  0.00001,  0.00001,  0.00001,  0.00001,  0.00001,  0.00001,  0.00001
c_avx_one          REAL4 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0
c_avx_half         REAL4 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5

; Permutation masks for 8 corners:
; corner indices: 0=(-x,-y,-z), 1=(+x,-y,-z), 2=(-x,+y,-z), 3=(+x,+y,-z)
;                 4=(-x,-y,+z), 5=(+x,-y,+z), 6=(-x,+y,+z), 7=(+x,+y,+z)
c_sign_x           REAL4 -1.0,  1.0, -1.0,  1.0, -1.0,  1.0, -1.0,  1.0
c_sel_y            REAL4  0.0,  0.0,  1.0,  1.0,  0.0,  0.0,  1.0,  1.0  ; 0 = bottom, 1 = top
c_sign_z           REAL4 -1.0, -1.0, -1.0, -1.0,  1.0,  1.0,  1.0,  1.0

c_avx_pos_inf      REAL4 07F800000r
c_avx_neg_inf      REAL4 0FF800000r
c_avx_pad_256      REAL4 256.0
c_avx_neg_pad_256  REAL4 -256.0

ALIGN 16
g_edge_pairs_avx   BYTE 0, 1,  2, 3,  4, 5,  6, 7
                   BYTE 0, 2,  1, 3,  4, 6,  5, 7
                   BYTE 0, 4,  1, 5,  2, 6,  3, 7

.code

PUBLIC asm_ProjectAVX2

asm_ProjectAVX2 PROC FRAME
    push rbp
    .pushreg rbp
    mov rbp, rsp
    push rbx
    .pushreg rbx
    push rsi
    .pushreg rsi
    push rdi
    .pushreg rdi
    push r12
    .pushreg r12
    push r13
    .pushreg r13
    push r14
    .pushreg r14
    push r15
    .pushreg r15
    sub rsp, 488
    .allocstack 488
    ; Save non-volatile XMM registers (XMM6-XMM13)
    movdqu [rsp + 352], xmm6
    .savexmm128 xmm6, 352
    movdqu [rsp + 368], xmm7
    .savexmm128 xmm7, 368
    movdqu [rsp + 384], xmm8
    .savexmm128 xmm8, 384
    movdqu [rsp + 400], xmm9
    .savexmm128 xmm9, 400
    movdqu [rsp + 416], xmm10
    .savexmm128 xmm10, 416
    movdqu [rsp + 432], xmm11
    .savexmm128 xmm11, 432
    movdqu [rsp + 448], xmm12
    .savexmm128 xmm12, 448
    movdqu [rsp + 464], xmm13
    .savexmm128 xmm13, 464
    .endprolog

    ; Local stack layout:
    ; [rsp + 0..63]    : ViewProj matrix (16 REAL4)
    ; [rsp + 64..95]   : ClipX[8] (REAL4)
    ; [rsp + 96..127]  : ClipY[8] (REAL4)
    ; [rsp + 128..159] : ClipZ[8] (REAL4)
    ; [rsp + 160..191] : ClipW[8] (REAL4)
    ; [rsp + 192]      : outBox ptr (RDX)
    ; [rsp + 200]      : params ptr (RCX)
    ; [rsp + 208]      : res_x (REAL4)
    ; [rsp + 212]      : res_y (REAL4)
    ; [rsp + 216]      : res_right (REAL4)
    ; [rsp + 220]      : res_bottom (REAL4)
    ; [rsp + 224]      : valid_count (DWORD)
    ; [rsp + 232]      : center_x (REAL4)
    ; [rsp + 236]      : center_y (REAL4)
    ; [rsp + 240]      : center_z (REAL4)
    ; [rsp + 244]      : halfX (REAL4)
    ; [rsp + 248]      : halfZ (REAL4)
    ; [rsp + 252]      : bottom (REAL4)
    ; [rsp + 256]      : top (REAL4)

    mov [rsp + 192], rdx
    mov [rsp + 200], rcx

    ; 1. Check viewport dimensions (viewport[2] > 0 && viewport[3] > 0)
    mov r8d, dword ptr [rcx + 256 + 8]   ; viewport[2] (width)
    mov r9d, dword ptr [rcx + 256 + 12]  ; viewport[3] (height)
    test r8d, r8d
    jle fail_avx
    test r9d, r9d
    jle fail_avx

    ; 2. Pre-multiply ViewProj = Projection * ModelView (FMA column-major)
    ; Projection: [rcx + 192]
    ; ModelView:  [rcx + 128]
    lea rsi, [rcx + 192]                 ; rsi = Projection
    lea rdi, [rcx + 128]                 ; rdi = ModelView
    lea rbx, [rsp + 0]                   ; rbx = ViewProj destination

    ; Load 4 columns of Projection into xmm0..xmm3
    movups xmm0, [rsi + 0*16]            ; P_col0
    movups xmm1, [rsi + 1*16]            ; P_col1
    movups xmm2, [rsi + 2*16]            ; P_col2
    movups xmm3, [rsi + 3*16]            ; P_col3

    ; For each column c of ModelView (c = 0..3):
    xor eax, eax                         ; c = 0
matmul_loop:
    shl eax, 4                           ; eax = c * 16
    vbroadcastss xmm4, dword ptr [rdi + rax + 0*4]
    vmulps xmm5, xmm0, xmm4
    vbroadcastss xmm4, dword ptr [rdi + rax + 1*4]
    vfmadd231ps xmm5, xmm1, xmm4
    vbroadcastss xmm4, dword ptr [rdi + rax + 2*4]
    vfmadd231ps xmm5, xmm2, xmm4
    vbroadcastss xmm4, dword ptr [rdi + rax + 3*4]
    vfmadd231ps xmm5, xmm3, xmm4
    movups [rbx + rax], xmm5             ; store VP_col_c
    shr eax, 4
    inc eax
    cmp eax, 4
    jl matmul_loop

    ; 3. Center and Extents
    ; partialTicks clamped to [0.0, 1.0]:
    movss xmm0, dword ptr [rcx + 120]
    xorps xmm1, xmm1
    maxss xmm0, xmm1
    mov eax, 3f800000h
    movd xmm1, eax
    minss xmm0, xmm1
    cvtss2sd xmm0, xmm0                 ; p in xmm0 (double)

    ; center.x:
    movsd xmm1, qword ptr [rcx + 48]
    subsd xmm1, qword ptr [rcx + 72]
    mulsd xmm1, xmm0
    addsd xmm1, qword ptr [rcx + 72]
    subsd xmm1, qword ptr [rcx + 96]
    cvtsd2ss xmm1, xmm1
    movss dword ptr [rsp + 232], xmm1   ; center_x (float)

    ; center.y:
    movsd xmm2, qword ptr [rcx + 56]
    subsd xmm2, qword ptr [rcx + 80]
    mulsd xmm2, xmm0
    addsd xmm2, qword ptr [rcx + 80]
    subsd xmm2, qword ptr [rcx + 104]
    movsd xmm10, xmm2                   ; save center.y in xmm10 (double)
    cvtsd2ss xmm2, xmm2
    movss dword ptr [rsp + 236], xmm2   ; center_y (float)

    ; center.z:
    movsd xmm3, qword ptr [rcx + 64]
    subsd xmm3, qword ptr [rcx + 88]
    mulsd xmm3, xmm0
    addsd xmm3, qword ptr [rcx + 88]
    subsd xmm3, qword ptr [rcx + 112]
    cvtsd2ss xmm3, xmm3
    movss dword ptr [rsp + 240], xmm3   ; center_z (float)

    ; halfX = (maxX - minX) / 1.5 + 0.15
    movsd xmm4, qword ptr [rcx + 24]
    subsd xmm4, qword ptr [rcx + 0]
    mov rax, 3ff8000000000000h          ; 1.5
    movq xmm5, rax
    divsd xmm4, xmm5
    mov rax, 3fc3333333333333h          ; 0.15
    movq xmm5, rax
    addsd xmm4, xmm5
    cvtsd2ss xmm4, xmm4
    movss dword ptr [rsp + 244], xmm4   ; halfX (float)

    ; halfZ = (maxZ - minZ) / 1.5 + 0.15
    movsd xmm5, qword ptr [rcx + 40]
    subsd xmm5, qword ptr [rcx + 16]
    mov rax, 3ff8000000000000h          ; 1.5
    movq xmm6, rax
    divsd xmm5, xmm6
    mov rax, 3fc3333333333333h          ; 0.15
    movq xmm6, rax
    addsd xmm5, xmm6
    cvtsd2ss xmm5, xmm5
    movss dword ptr [rsp + 248], xmm5   ; halfZ (float)

    ; bottom = center.y - 0.15
    movsd xmm6, xmm10                   ; center.y (double)
    mov rax, 3fc3333333333333h          ; 0.15
    movq xmm7, rax
    subsd xmm6, xmm7
    cvtsd2ss xmm6, xmm6
    movss dword ptr [rsp + 252], xmm6   ; bottom (float)

    ; top = center.y + (maxY - minY) + (sneaking ? -0.3 : 0.18) + 0.15
    movsd xmm7, qword ptr [rcx + 32]
    subsd xmm7, qword ptr [rcx + 8]
    addsd xmm7, xmm10                   ; + center.y
    cmp dword ptr [rcx + 124], 0
    jne avx_sneak
    mov rax, 3fc70a3d70a3d70ah          ; 0.18
    movq xmm8, rax
    addsd xmm7, xmm8
    jmp avx_sneak_done
avx_sneak:
    mov rax, 0bfd3333333333333h         ; -0.3
    movq xmm8, rax
    addsd xmm7, xmm8
avx_sneak_done:
    mov rax, 3fc3333333333333h          ; 0.15
    movq xmm8, rax
    addsd xmm7, xmm8
    cvtsd2ss xmm7, xmm7
    movss dword ptr [rsp + 256], xmm7   ; top (float)

    ; 4. Form 8 corners in SIMD vectors:
    ; ymm0 = X corners: center_x + halfX * c_sign_x
    vbroadcastss ymm0, dword ptr [rsp + 244] ; halfX
    vmovups ymm3, ymmword ptr [c_sign_x]
    vmulps ymm0, ymm0, ymm3
    vbroadcastss ymm1, dword ptr [rsp + 232] ; center_x
    vaddps ymm0, ymm0, ymm1                  ; ymm0 = 8 corner X values

    ; ymm1 = Y corners: bottom + (top - bottom) * c_sel_y
    vbroadcastss ymm1, dword ptr [rsp + 256] ; top
    vbroadcastss ymm2, dword ptr [rsp + 252] ; bottom
    vsubps ymm1, ymm1, ymm2                  ; top - bottom
    vmovups ymm3, ymmword ptr [c_sel_y]
    vfmadd213ps ymm1, ymm3, ymm2             ; ymm1 = 8 corner Y values

    ; ymm2 = Z corners: center_z + halfZ * c_sign_z
    vbroadcastss ymm2, dword ptr [rsp + 248] ; halfZ
    vmovups ymm3, ymmword ptr [c_sign_z]
    vmulps ymm2, ymm2, ymm3
    vbroadcastss ymm3, dword ptr [rsp + 240] ; center_z
    vaddps ymm2, ymm2, ymm3                  ; ymm2 = 8 corner Z values

    ; 5. Transform all 8 corners by ViewProj (stored at [rsp + 0])
    ; Row 0: ClipX = VP00*X + VP10*Y + VP20*Z + VP30*1.0
    lea rbx, [rsp + 0]                       ; rbx = ViewProj
    vbroadcastss ymm4, dword ptr [rbx + 12*4]
    vbroadcastss ymm8, dword ptr [rbx + 0*4]
    vfmadd231ps ymm4, ymm8, ymm0
    vbroadcastss ymm8, dword ptr [rbx + 4*4]
    vfmadd231ps ymm4, ymm8, ymm1
    vbroadcastss ymm8, dword ptr [rbx + 8*4]
    vfmadd231ps ymm4, ymm8, ymm2             ; ymm4 = ClipX[0..7]

    ; Row 1: ClipY = VP01*X + VP11*Y + VP21*Z + VP31*1.0
    vbroadcastss ymm5, dword ptr [rbx + 13*4]
    vbroadcastss ymm8, dword ptr [rbx + 1*4]
    vfmadd231ps ymm5, ymm8, ymm0
    vbroadcastss ymm8, dword ptr [rbx + 5*4]
    vfmadd231ps ymm5, ymm8, ymm1
    vbroadcastss ymm8, dword ptr [rbx + 9*4]
    vfmadd231ps ymm5, ymm8, ymm2             ; ymm5 = ClipY[0..7]

    ; Row 2: ClipZ = VP02*X + VP12*Y + VP22*Z + VP32*1.0
    vbroadcastss ymm6, dword ptr [rbx + 14*4]
    vbroadcastss ymm8, dword ptr [rbx + 2*4]
    vfmadd231ps ymm6, ymm8, ymm0
    vbroadcastss ymm8, dword ptr [rbx + 6*4]
    vfmadd231ps ymm6, ymm8, ymm1
    vbroadcastss ymm8, dword ptr [rbx + 10*4]
    vfmadd231ps ymm6, ymm8, ymm2             ; ymm6 = ClipZ[0..7]

    ; Row 3: ClipW = VP03*X + VP13*Y + VP23*Z + VP33*1.0
    vbroadcastss ymm7, dword ptr [rbx + 15*4]
    vbroadcastss ymm8, dword ptr [rbx + 3*4]
    vfmadd231ps ymm7, ymm8, ymm0
    vbroadcastss ymm8, dword ptr [rbx + 7*4]
    vfmadd231ps ymm7, ymm8, ymm1
    vbroadcastss ymm8, dword ptr [rbx + 11*4]
    vfmadd231ps ymm7, ymm8, ymm2             ; ymm7 = ClipW[0..7]

    ; Store 8 transformed clip coordinates for potential edge clipping:
    vmovups [rsp + 64],  ymm4                ; ClipX[8]
    vmovups [rsp + 96],  ymm5                ; ClipY[8]
    vmovups [rsp + 128], ymm6                ; ClipZ[8]
    vmovups [rsp + 160], ymm7                ; ClipW[8]

    ; 6. Fast Near-Plane Cull: da = ClipZ + ClipW
    vaddps ymm8, ymm6, ymm7                  ; ymm8 = da[0..7]
    vmovmskps eax, ymm8                      ; eax = 8 sign bits of da
    cmp eax, 0FFh                            ; All 8 corners behind near plane?
    je fail_avx

    ; Initialize bounding box:
    mov eax, dword ptr [c_avx_pos_inf]
    mov dword ptr [rsp + 208], eax           ; res_x = +INF
    mov dword ptr [rsp + 212], eax           ; res_y = +INF
    mov eax, dword ptr [c_avx_neg_inf]
    mov dword ptr [rsp + 216], eax           ; res_right = -INF
    mov dword ptr [rsp + 220], eax           ; res_bottom = -INF
    mov dword ptr [rsp + 224], 0             ; valid_count = 0

    ; 7. Add all 8 corners:
    xor r12d, r12d
avx_add_corners_loop:
    movss xmm0, dword ptr [rsp + 64  + r12*4] ; ClipX[i]
    movss xmm1, dword ptr [rsp + 96  + r12*4] ; ClipY[i]
    movss xmm2, dword ptr [rsp + 128 + r12*4] ; ClipZ[i]
    movss xmm3, dword ptr [rsp + 160 + r12*4] ; ClipW[i]
    call avx_add_single_point
    inc r12d
    cmp r12d, 8
    jl avx_add_corners_loop

    ; 8. Near-plane edge clipping (12 edges):
    lea r14, [g_edge_pairs_avx]
    xor r13d, r13d
avx_clip_edges_loop:
    movzx eax, byte ptr [r14 + r13*2 + 0] ; index a
    movzx ecx, byte ptr [r14 + r13*2 + 1] ; index b

    ; da = az + aw
    movss xmm0, dword ptr [rsp + 128 + rax*4]
    addss xmm0, dword ptr [rsp + 160 + rax*4] ; da
    ; db = bz + bw
    movss xmm1, dword ptr [rsp + 128 + rcx*4]
    addss xmm1, dword ptr [rsp + 160 + rcx*4] ; db

    ; Check if sign bits differ:
    movd edx, xmm0
    movd r8d, xmm1
    xor edx, r8d
    test edx, edx
    jns avx_next_edge

    ; t = da / (da - db)
    movss xmm2, xmm0
    subss xmm2, xmm1
    divss xmm0, xmm2                         ; t in xmm0

    ; P = a + (b - a) * t
    ; x:
    movss xmm1, dword ptr [rsp + 64 + rcx*4]
    subss xmm1, dword ptr [rsp + 64 + rax*4]
    vfmadd213ss xmm1, xmm0, dword ptr [rsp + 64 + rax*4] ; P.x

    ; y:
    movss xmm2, dword ptr [rsp + 96 + rcx*4]
    subss xmm2, dword ptr [rsp + 96 + rax*4]
    vfmadd213ss xmm2, xmm0, dword ptr [rsp + 96 + rax*4] ; P.y

    ; z:
    movss xmm3, dword ptr [rsp + 128 + rcx*4]
    subss xmm3, dword ptr [rsp + 128 + rax*4]
    vfmadd213ss xmm3, xmm0, dword ptr [rsp + 128 + rax*4] ; P.z

    ; w:
    movss xmm4, dword ptr [rsp + 160 + rcx*4]
    subss xmm4, dword ptr [rsp + 160 + rax*4]
    vfmadd213ss xmm4, xmm0, dword ptr [rsp + 160 + rax*4] ; P.w

    movaps xmm0, xmm1
    movaps xmm1, xmm2
    movaps xmm2, xmm3
    movaps xmm3, xmm4
    call avx_add_single_point

avx_next_edge:
    inc r13d
    cmp r13d, 12
    jl avx_clip_edges_loop

    ; 9. Final ScreenBox checks & clamp:
    cmp dword ptr [rsp + 224], 0
    jle fail_avx

    movss xmm0, dword ptr [rsp + 208]        ; res_x
    movss xmm1, dword ptr [rsp + 212]        ; res_y
    movss xmm2, dword ptr [rsp + 216]        ; res_right
    movss xmm3, dword ptr [rsp + 220]        ; res_bottom

    ; isfinite(res_x)
    movd eax, xmm0
    and eax, 7f800000h
    cmp eax, 7f800000h
    je fail_avx

    ; res_right < 0 || res_bottom < 0
    xorps xmm4, xmm4
    ucomiss xmm2, xmm4
    jb fail_avx
    ucomiss xmm3, xmm4
    jb fail_avx

    ; res_x > vp[2] + vp[0]
    mov rcx, [rsp + 200]
    mov eax, dword ptr [rcx + 256]           ; vp[0]
    add eax, dword ptr [rcx + 264]           ; vp[0] + vp[2]
    cvtsi2ss xmm5, eax
    ucomiss xmm0, xmm5
    ja fail_avx

    ; res_y > fbHeight
    cvtsi2ss xmm6, dword ptr [rcx + 272]     ; fbHeight
    ucomiss xmm1, xmm6
    ja fail_avx

    ; Clamp:
    movss xmm7, dword ptr [c_avx_neg_pad_256]
    maxss xmm0, xmm7
    maxss xmm1, xmm7

    movss xmm8, dword ptr [c_avx_pad_256]
    addss xmm5, xmm8
    minss xmm2, xmm5

    addss xmm6, xmm8
    minss xmm3, xmm6

    ; res_right > res_x && res_bottom > res_y
    ucomiss xmm2, xmm0
    jbe fail_avx
    ucomiss xmm3, xmm1
    jbe fail_avx

    ; Success
    mov rdx, [rsp + 192]                     ; outBox
    movss dword ptr [rdx + 0], xmm0
    movss dword ptr [rdx + 4], xmm1
    movss dword ptr [rdx + 8], xmm2
    movss dword ptr [rdx + 12], xmm3

    vzeroupper
    mov eax, 1
    jmp exit_avx

fail_avx:
    vzeroupper
    xor eax, eax

exit_avx:
    ; Restore non-volatile XMM registers (XMM6-XMM13)
    movdqu xmm6,  [rsp + 352]
    movdqu xmm7,  [rsp + 368]
    movdqu xmm8,  [rsp + 384]
    movdqu xmm9,  [rsp + 400]
    movdqu xmm10, [rsp + 416]
    movdqu xmm11, [rsp + 432]
    movdqu xmm12, [rsp + 448]
    movdqu xmm13, [rsp + 464]

    add rsp, 488
    pop r15
    pop r14
    pop r13
    pop r12
    pop rdi
    pop rsi
    pop rbx
    pop rbp
    ret

; -----------------------------------------------------------------------------
; Internal helper: avx_add_single_point
; Inputs:
;   xmm0 = vx (float)
;   xmm1 = vy (float)
;   xmm2 = vz (float)
;   xmm3 = vw (float)
; Modifies: xmm4-xmm6, eax
; -----------------------------------------------------------------------------
avx_add_single_point:
    ; if (vw < 0.000001f) return
    ucomiss xmm3, dword ptr [c_avx_eps_w]
    jb avx_add_ret

    ; if (vz < -vw - 0.00001f) return
    xorps xmm4, xmm4
    subss xmm4, xmm3
    subss xmm4, dword ptr [c_avx_eps_near]
    ucomiss xmm2, xmm4
    jb avx_add_ret

    ; if (vz > vw) return
    ucomiss xmm2, xmm3
    ja avx_add_ret

    ; Perspective division:
    divss xmm0, xmm3                         ; ndc_x = vx / vw
    divss xmm1, xmm3                         ; ndc_y = vy / vw

    ; Screen transform:
    mov rcx, [rsp + 200 + 8]                 ; params ptr
    addss xmm0, dword ptr [c_avx_one]        ; ndc_x + 1.0f
    cvtsi2ss xmm4, dword ptr [rcx + 264]     ; vp[2] (w)
    mulss xmm0, xmm4
    mulss xmm0, dword ptr [c_avx_half]       ; * 0.5f
    cvtsi2ss xmm4, dword ptr [rcx + 256]     ; vp[0] (x)
    addss xmm0, xmm4                         ; screen_x in xmm0

    addss xmm1, dword ptr [c_avx_one]        ; ndc_y + 1.0f
    cvtsi2ss xmm4, dword ptr [rcx + 268]     ; vp[3] (h)
    mulss xmm1, xmm4
    mulss xmm1, dword ptr [c_avx_half]       ; * 0.5f
    cvtsi2ss xmm4, dword ptr [rcx + 260]     ; vp[1] (y)
    addss xmm1, xmm4
    cvtsi2ss xmm4, dword ptr [rcx + 272]     ; fbHeight
    subss xmm4, xmm1                         ; screen_y in xmm4

    ; isfinite
    movd eax, xmm0
    and eax, 7f800000h
    cmp eax, 7f800000h
    je avx_add_ret
    movd eax, xmm4
    and eax, 7f800000h
    cmp eax, 7f800000h
    je avx_add_ret

    ; Save screen_x and screen_y in xmm5, xmm6
    movaps xmm5, xmm0
    movaps xmm6, xmm4

    ; Min update:
    minss xmm0, dword ptr [rsp + 208 + 8]
    movss dword ptr [rsp + 208 + 8], xmm0
    minss xmm4, dword ptr [rsp + 212 + 8]
    movss dword ptr [rsp + 212 + 8], xmm4

    ; Max update:
    maxss xmm5, dword ptr [rsp + 216 + 8]
    movss dword ptr [rsp + 216 + 8], xmm5
    maxss xmm6, dword ptr [rsp + 220 + 8]
    movss dword ptr [rsp + 220 + 8], xmm6

    inc dword ptr [rsp + 224 + 8]            ; valid_count++

avx_add_ret:
    ret

asm_ProjectAVX2 ENDP

END
