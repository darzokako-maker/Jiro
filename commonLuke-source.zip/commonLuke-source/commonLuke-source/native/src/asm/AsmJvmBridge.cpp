#include "asm/AsmJvm.hpp"
#include <excpt.h>

namespace client::asm_jvm {

bool DecodePointer(std::uintptr_t fieldAddress, bool compressed,
    std::uintptr_t narrowBase, unsigned narrowShift, bool nullIsZero,
    std::uintptr_t* out)
{
    if (!out) return false;
    auto& c = debugCounters;
    c.decodeCalls.fetch_add(1, std::memory_order_relaxed);
    if (!fieldAddress) c.decodeNullAddress.fetch_add(1, std::memory_order_relaxed);
    if (compressed && narrowShift > 16) c.decodeInvalidConfig.fetch_add(1, std::memory_order_relaxed);
    __try {
        const int rc = asm_DecodePointer(fieldAddress, compressed ? 1u : 0u, narrowBase,
            static_cast<std::uint32_t>(narrowShift), nullIsZero ? 1u : 0u, out);
        if (rc != 0) {
            c.decodeFailures.fetch_add(1, std::memory_order_relaxed);
            return false;
        }
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        c.decodeFailures.fetch_add(1, std::memory_order_relaxed);
        c.decodeExceptions.fetch_add(1, std::memory_order_relaxed);
        return false;
    }
}

std::uint32_t InstanceWalk(std::uintptr_t klass, std::uintptr_t superOffset,
    const std::uintptr_t* targets, std::uint32_t count)
{
    if (!targets || !count || count > 32) return 0;
    auto& c = debugCounters;
    c.walkCalls.fetch_add(1, std::memory_order_relaxed);
    __try {
        const std::uint32_t bits = asm_InstanceWalk(klass, superOffset, targets, count);
        if (bits) c.walkMatched.fetch_add(1, std::memory_order_relaxed);
        else c.walkZeroMask.fetch_add(1, std::memory_order_relaxed);
        return bits;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        c.walkExceptions.fetch_add(1, std::memory_order_relaxed);
        return 0;
    }
}

bool GatherFields(const GatherJob* job, std::uint32_t tag)
{
    if (!job || !job->ops || !job->out) return false;
    auto& c = debugCounters;
    c.gatherCalls.fetch_add(1, std::memory_order_relaxed);
    if (tag == 1) c.gatherEntityCalls.fetch_add(1, std::memory_order_relaxed);
    else if (tag == 2) c.gatherBoxCalls.fetch_add(1, std::memory_order_relaxed);
    bool seh = false;
    int rc = 1;
    __try {
        rc = asm_GatherFields(job);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        seh = true;
    }
    if (!seh && rc == 0) {
        c.gatherOk.fetch_add(1, std::memory_order_relaxed);
        if (tag == 1) c.gatherEntityOk.fetch_add(1, std::memory_order_relaxed);
        else if (tag == 2) c.gatherBoxOk.fetch_add(1, std::memory_order_relaxed);
        return true;
    }
    if (seh) c.gatherExceptions.fetch_add(1, std::memory_order_relaxed);
    else c.gatherInvalidOp.fetch_add(1, std::memory_order_relaxed);
    if (tag == 1) c.gatherEntityFail.fetch_add(1, std::memory_order_relaxed);
    else if (tag == 2) c.gatherBoxFail.fetch_add(1, std::memory_order_relaxed);
    return false;
}

AsmDebugSnapshot TakeAsmDebug()
{
    auto& c = debugCounters;
    auto take = [](std::atomic<std::uint64_t>& v) {
        return v.exchange(0, std::memory_order_relaxed);
    };
    return {
        take(c.decodeCalls), take(c.decodeFailures), take(c.decodeExceptions),
        take(c.decodeNullAddress), take(c.decodeInvalidConfig),
        take(c.walkCalls), take(c.walkExceptions), take(c.walkZeroMask), take(c.walkMatched),
        take(c.gatherCalls), take(c.gatherOk), take(c.gatherInvalidOp), take(c.gatherExceptions),
        take(c.gatherEntityCalls), take(c.gatherEntityOk), take(c.gatherEntityFail),
        take(c.gatherBoxCalls), take(c.gatherBoxOk), take(c.gatherBoxFail)
    };
}

bool SelfTest()
{
    bool ok = true;

    // asm_DecodePointer: wide pointer roundtrip through a stack cell.
    std::uintptr_t source = 0x0123456789ABCDEFull;
    std::uintptr_t decoded = 0;
    ok &= DecodePointer(reinterpret_cast<std::uintptr_t>(&source), false, 0, 0, true, &decoded)
        && decoded == source;

    // asm_InstanceWalk: fabricated two-node super chain on the stack.
    struct Node { std::uintptr_t pad[4]; std::uintptr_t super; };
    Node a{}, b{};
    a.super = reinterpret_cast<std::uintptr_t>(&b);
    const std::uintptr_t target = reinterpret_cast<std::uintptr_t>(&b);
    ok &= InstanceWalk(reinterpret_cast<std::uintptr_t>(&a),
        static_cast<std::uintptr_t>(offsetof(Node, super)), &target, 1) == 1;

    // asm_GatherFields: single 8-byte copy op from a fabricated source.
    struct Source { std::uint8_t pad[16]; std::uint64_t value; };
    Source src{};
    src.value = 0xFEDCBA9876543210ull;
    std::uint64_t out = 0;
    const FieldOp op{16, 0, 8, OpCopy};
    GatherJob job{};
    job.oop = reinterpret_cast<std::uintptr_t>(&src);
    job.ops = &op;
    job.count = 1;
    job.out = &out;
    job.outSize = static_cast<std::uint32_t>(sizeof(out));
    ok &= GatherFields(&job) && out == src.value;

    return ok;
}

} // namespace client::asm_jvm
