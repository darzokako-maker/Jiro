; =============================================================================
; AOKI Client — Pure x64 MASM JVM Field Access Kernels
; Two leaf kernels sharing one file:
;
; 1) asm_DecodePointer — compressed-oop / compressed-klass reference decode.
;    int asm_DecodePointer(uintptr_t fieldAddress, uint32_t compressed,
;                          uintptr_t narrowBase, uint32_t narrowShift,
;                          uint32_t nullIsZero, uintptr_t* out)
;    RCX = fieldAddress, EDX = compressed, R8 = narrowBase, R9D = narrowShift
;    [RSP+28h] = nullIsZero, [RSP+30h] = out   (stack args, no pushes used)
;    Returns EAX = 0; *out always written on success path.
;
; 2) asm_GatherFields — table-driven multi-field gather from a JVM oop.
;    int asm_GatherFields(const AsmGatherJob* job)   RCX = job
;    Job layout (see asm/AsmJvm.hpp, static_assert'ed):
;      +00 oop(u64) +08 ops(ptr) +10 count(u32) +14 pad
;      +18 out(ptr) +20 outSize(u32) +24 refCompressed(u32)
;      +28 refBase(u64) +30 refShift(u32) +34 refNullIsZero(u32)
;    Op layout: +00 offset(u32) +04 dest(u32) +08 size(u32) +0C kind(u32)
;    kind 0 = raw copy (size 1/2/4/8), kind 1 = ref decode -> u64.
;    Returns EAX: 0 ok, 1 invalid op.
;
; Both kernels perform unguarded JVM reads by design; the C++ bridge wraps
; each call in a single SEH region. No calls into the JVM, no allocations.
; NOTE: native threads are not safepoint participants (OpenJDK 8u492
; safepoint.cpp), so a moving GC may relocate objects while these run. Raw
; oops must be re-resolved from JNI handles immediately before each call;
; see asm/AsmJvm.hpp for the full safety contract.
; =============================================================================

OPTION CASEMAP:NONE

.code

PUBLIC asm_DecodePointer
PUBLIC asm_GatherFields

; -----------------------------------------------------------------------------
asm_DecodePointer PROC
    ; Leaf function: no pushes, so stack args stay at entry offsets.
    mov r10, qword ptr [rsp+30h]  ; out
    mov r11d, dword ptr [rsp+28h] ; nullIsZero

    test edx, edx
    jz @wide

    ; compressed reference: u32 narrow at [fieldAddress]
    mov eax, dword ptr [rcx]
    test eax, eax
    jz @nullnarrow
    mov ecx, r9d                  ; shift count
    shl rax, cl
    add rax, r8                   ; narrowBase + (narrow << shift)
    jmp @store

@nullnarrow:
    test r11d, r11d               ; nullIsZero
    jne @zero
    mov rax, r8                   ; klass semantics: base + (0 << shift) = base
    jmp @store
@zero:
    xor eax, eax
    jmp @store

@wide:
    mov rax, qword ptr [rcx]

@store:
    mov qword ptr [r10], rax
    xor eax, eax
    ret
asm_DecodePointer ENDP

; -----------------------------------------------------------------------------
asm_GatherFields PROC FRAME
    push rbp
    .pushreg rbp
    mov rbp, rsp
    push rbx
    .pushreg rbx
    push rsi
    .pushreg rsi
    push rdi
    .pushreg rdi
    push r12
    .pushreg r12
    push r13
    .pushreg r13
    push r14
    .pushreg r14
    push r15
    .pushreg r15
    .endprolog

    mov rbx, rcx                  ; job
    mov rsi, qword ptr [rbx]      ; oop
    mov rdi, qword ptr [rbx+8]    ; ops cursor
    mov r12d, dword ptr [rbx+10h] ; count
    mov r13, qword ptr [rbx+18h]  ; out
    mov r14d, dword ptr [rbx+20h] ; outSize
    xor r15d, r15d                ; index

@loop:
    cmp r15, r12
    jae @done

    mov eax, dword ptr [rdi]      ; op.offset
    mov ecx, dword ptr [rdi+4]    ; op.dest
    mov edx, dword ptr [rdi+8]    ; op.size
    mov r8d, dword ptr [rdi+0Ch]  ; op.kind

    cmp r8d, 1
    ja @fail                      ; kinds are 0 (copy) and 1 (ref) only
    jne @sized
    mov edx, 8                    ; ref ops always write a full pointer
@sized:
    ; bounds: dest + writeSize <= outSize (64-bit compare)
    lea r9, [rcx+rdx]
    cmp r9, r14
    ja @fail

    lea r9, [rsi+rax]             ; src = oop + offset
    lea r10, [r13+rcx]            ; dst = out + dest

    cmp r8d, 1
    je @doref

    ; ---- kind 0: raw copy, size in {1,2,4,8} ----
    cmp edx, 8
    je @c8
    cmp edx, 4
    je @c4
    cmp edx, 2
    je @c2
    cmp edx, 1
    je @c1
    jmp @fail

@c8:
    mov rax, qword ptr [r9]
    mov qword ptr [r10], rax
    jmp @next
@c4:
    mov eax, dword ptr [r9]
    mov dword ptr [r10], eax
    jmp @next
@c2:
    mov ax, word ptr [r9]
    mov word ptr [r10], ax
    jmp @next
@c1:
    mov al, byte ptr [r9]
    mov byte ptr [r10], al
    jmp @next

    ; ---- kind 1: object reference decode ----
@doref:
    cmp dword ptr [rbx+24h], 0    ; refCompressed
    je @refwide
    mov eax, dword ptr [r9]       ; narrow u32
    test eax, eax
    jz @refnull
    mov ecx, dword ptr [rbx+30h]  ; refShift
    shl rax, cl
    add rax, qword ptr [rbx+28h]  ; refBase
    jmp @refstore
@refnull:
    cmp dword ptr [rbx+34h], 0    ; refNullIsZero
    jne @refzero
    mov rax, qword ptr [rbx+28h]  ; base + (0 << shift) = base
    jmp @refstore
@refzero:
    xor eax, eax
    jmp @refstore
@refwide:
    mov rax, qword ptr [r9]
@refstore:
    mov qword ptr [r10], rax

@next:
    add rdi, 10h                  ; sizeof(FieldOp)
    inc r15
    jmp @loop

@done:
    xor eax, eax
    jmp @out
@fail:
    mov eax, 1
@out:
    pop r15
    pop r14
    pop r13
    pop r12
    pop rdi
    pop rsi
    pop rbx
    pop rbp
    ret
asm_GatherFields ENDP

END
