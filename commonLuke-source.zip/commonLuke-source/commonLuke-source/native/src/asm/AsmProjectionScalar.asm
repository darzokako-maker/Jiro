; =============================================================================
; AOKI Client — Pure x64 MASM Scalar Projection Engine
; Implements the exact double-precision mathematical pipeline of Esp.cpp::Project
; Calling convention: Microsoft x64 ABI
;
; int asm_ProjectScalar(const AsmProjectParams* params, AsmScreenBox* outBox)
; RCX = params
; RDX = outBox
; Returns EAX: 1 if visible & valid box written, 0 otherwise
; =============================================================================

OPTION CASEMAP:NONE

.const
ALIGN 16
c_one_point_five       REAL8 1.5
c_zero_point_one_five  REAL8 0.15
c_neg_zero_point_three REAL8 -0.3
c_zero_point_one_eight REAL8 0.18
c_one_double           REAL8 1.0
c_zero_double          REAL8 0.0
c_half_double          REAL8 0.5
c_eps_w                REAL8 0.000001
c_eps_near             REAL8 0.00001
c_clamp_pad            REAL4 256.0
c_neg_clamp_pad        REAL4 -256.0
c_pos_inf              REAL4 07F800000r  ; +Infinity (float)
c_neg_inf              REAL4 0FF800000r  ; -Infinity (float)

; 12 edge pairs: (a, b) where each index is 0..7
ALIGN 16
g_edge_pairs BYTE 0, 1,  2, 3,  4, 5,  6, 7
             BYTE 0, 2,  1, 3,  4, 6,  5, 7
             BYTE 0, 4,  1, 5,  2, 6,  3, 7

.code

PUBLIC asm_ProjectScalar

asm_ProjectScalar PROC FRAME
    push rbp
    .pushreg rbp
    mov rbp, rsp
    push rbx
    .pushreg rbx
    push rsi
    .pushreg rsi
    push rdi
    .pushreg rdi
    push r12
    .pushreg r12
    push r13
    .pushreg r13
    push r14
    .pushreg r14
    push r15
    .pushreg r15
    sub rsp, 488
    .allocstack 488
    .endprolog

    ; Local stack assignments relative to rsp:
    ; [rsp + 0..255]   : 8 corners (each 4 REAL8: x, y, z, w = 32 bytes)
    ; [rsp + 256..287] : temp eye vector (4 REAL8 = 32 bytes)
    ; [rsp + 288]      : outBox ptr (RDX)
    ; [rsp + 296]      : params ptr (RCX)
    ; [rsp + 304]      : res_x (REAL4)
    ; [rsp + 308]      : res_y (REAL4)
    ; [rsp + 312]      : res_right (REAL4)
    ; [rsp + 316]      : res_bottom (REAL4)
    ; [rsp + 320]      : valid_count (DWORD)
    ; [rsp + 328]      : center_x (REAL8)
    ; [rsp + 336]      : center_y (REAL8)
    ; [rsp + 344]      : center_z (REAL8)
    ; [rsp + 352]      : halfX (REAL8)
    ; [rsp + 360]      : halfZ (REAL8)
    ; [rsp + 368]      : bottom (REAL8)
    ; [rsp + 376]      : top (REAL8)

    mov [rsp + 288], rdx
    mov [rsp + 296], rcx

    ; 1. Check viewport dimensions (viewport[2] > 0 && viewport[3] > 0)
    mov r8d, dword ptr [rcx + 264]       ; viewport[2] (width)
    mov r9d, dword ptr [rcx + 268]       ; viewport[3] (height)
    test r8d, r8d
    jle fail_early
    test r9d, r9d
    jle fail_early

    ; 2. Clamp partialTicks: p = std::clamp(partial, 0.0f, 1.0f)
    movss xmm0, dword ptr [rcx + 120]   ; partial (float)
    xorps xmm1, xmm1
    maxss xmm0, xmm1                    ; max(partial, 0.0f)
    mov eax, 3f800000h                  ; 1.0f
    movd xmm1, eax
    minss xmm0, xmm1                    ; min(..., 1.0f)
    cvtss2sd xmm0, xmm0                 ; p in xmm0 (double)

    ; 3. Center calculation:
    ; center.x = lastX + (posX - lastX) * p - camX
    movsd xmm1, qword ptr [rcx + 48]    ; posX
    subsd xmm1, qword ptr [rcx + 72]    ; posX - lastX
    mulsd xmm1, xmm0                    ; * p
    addsd xmm1, qword ptr [rcx + 72]    ; + lastX
    subsd xmm1, qword ptr [rcx + 96]    ; - camX
    movsd qword ptr [rsp + 328], xmm1   ; center_x

    ; center.y = lastY + (posY - lastY) * p - camY
    movsd xmm2, qword ptr [rcx + 56]    ; posY
    subsd xmm2, qword ptr [rcx + 80]    ; posY - lastY
    mulsd xmm2, xmm0                    ; * p
    addsd xmm2, qword ptr [rcx + 80]    ; + lastY
    subsd xmm2, qword ptr [rcx + 104]   ; - camY
    movsd qword ptr [rsp + 336], xmm2   ; center_y

    ; center.z = lastZ + (posZ - lastZ) * p - camZ
    movsd xmm3, qword ptr [rcx + 64]    ; posZ
    subsd xmm3, qword ptr [rcx + 88]    ; posZ - lastZ
    mulsd xmm3, xmm0                    ; * p
    addsd xmm3, qword ptr [rcx + 88]    ; + lastZ
    subsd xmm3, qword ptr [rcx + 112]   ; - camZ
    movsd qword ptr [rsp + 344], xmm3   ; center_z

    ; 4. halfX = (maxX - minX) / 1.5 + 0.15
    movsd xmm4, qword ptr [rcx + 24]    ; maxX
    subsd xmm4, qword ptr [rcx + 0]     ; maxX - minX
    divsd xmm4, qword ptr [c_one_point_five]
    addsd xmm4, qword ptr [c_zero_point_one_five]
    movsd qword ptr [rsp + 352], xmm4   ; halfX

    ; halfZ = (maxZ - minZ) / 1.5 + 0.15
    movsd xmm5, qword ptr [rcx + 40]    ; maxZ
    subsd xmm5, qword ptr [rcx + 16]    ; maxZ - minZ
    divsd xmm5, qword ptr [c_one_point_five]
    addsd xmm5, qword ptr [c_zero_point_one_five]
    movsd qword ptr [rsp + 360], xmm5   ; halfZ

    ; bottom = center.y - 0.15
    movsd xmm6, xmm2
    subsd xmm6, qword ptr [c_zero_point_one_five]
    movsd qword ptr [rsp + 368], xmm6   ; bottom

    ; top = center.y + (maxY - minY) + (sneaking ? -0.3 : 0.18) + 0.15
    movsd xmm7, xmm2
    movsd xmm8, qword ptr [rcx + 32]    ; maxY
    subsd xmm8, qword ptr [rcx + 8]     ; maxY - minY
    addsd xmm7, xmm8
    cmp dword ptr [rcx + 124], 0        ; sneaking != 0?
    jne is_sneaking
    addsd xmm7, qword ptr [c_zero_point_one_eight]
    jmp sneaking_done
is_sneaking:
    addsd xmm7, qword ptr [c_neg_zero_point_three]
sneaking_done:
    addsd xmm7, qword ptr [c_zero_point_one_five]
    movsd qword ptr [rsp + 376], xmm7   ; top

    ; 5. Generate 8 corners and transform by ModelView and Projection
    ; Each corner i (0..7):
    ; px = center_x + ((i & 1) ? halfX : -halfX)
    ; py = (i & 2) ? top : bottom
    ; pz = center_z + ((i & 4) ? halfZ : -halfZ)
    ; pw = 1.0
    xor r12d, r12d                      ; r12d = corner index i (0..7)

corner_gen_loop:
    mov rcx, [rsp + 296]               ; params ptr
    ; compute px:
    movsd xmm10, qword ptr [rsp + 328] ; center_x
    movsd xmm11, qword ptr [rsp + 352] ; halfX
    test r12d, 1
    jnz add_hx
    subsd xmm10, xmm11
    jmp px_done
add_hx:
    addsd xmm10, xmm11
px_done:
    ; compute py:
    test r12d, 2
    jnz py_top
    movsd xmm11, qword ptr [rsp + 368] ; bottom
    jmp py_done
py_top:
    movsd xmm11, qword ptr [rsp + 376] ; top
py_done:
    ; compute pz:
    movsd xmm12, qword ptr [rsp + 344] ; center_z
    movsd xmm13, qword ptr [rsp + 360] ; halfZ
    test r12d, 4
    jnz pz_pos
    subsd xmm12, xmm13
    jmp pz_done
pz_pos:
    addsd xmm12, xmm13
pz_done:
    movsd xmm13, qword ptr [c_one_double] ; pw = 1.0

    ; Multiply by model matrix (offset 128, column-major):
    ; Veye.x = m[0]*px + m[4]*py + m[8]*pz + m[12]*pw
    ; Veye.y = m[1]*px + m[5]*py + m[9]*pz + m[13]*pw
    ; Veye.z = m[2]*px + m[6]*py + m[10]*pz + m[14]*pw
    ; Veye.w = m[3]*px + m[7]*py + m[11]*pz + m[15]*pw
    lea rsi, [rcx + 128]               ; rsi = model matrix

    ; row 0:
    cvtss2sd xmm0, dword ptr [rsi + 0*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rsi + 4*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 8*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 12*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rsp + 256 + 0], xmm0 ; temp_eye.x

    ; row 1:
    cvtss2sd xmm0, dword ptr [rsi + 1*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rsi + 5*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 9*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 13*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rsp + 256 + 8], xmm0 ; temp_eye.y

    ; row 2:
    cvtss2sd xmm0, dword ptr [rsi + 2*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rsi + 6*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 10*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 14*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rsp + 256 + 16], xmm0 ; temp_eye.z

    ; row 3:
    cvtss2sd xmm0, dword ptr [rsi + 3*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rsi + 7*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 11*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rsi + 15*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rsp + 256 + 24], xmm0 ; temp_eye.w

    ; Multiply temp_eye by projection matrix (offset 192, column-major):
    lea rdi, [rcx + 192]               ; rdi = projection matrix
    movsd xmm10, qword ptr [rsp + 256 + 0]  ; eye.x
    movsd xmm11, qword ptr [rsp + 256 + 8]  ; eye.y
    movsd xmm12, qword ptr [rsp + 256 + 16] ; eye.z
    movsd xmm13, qword ptr [rsp + 256 + 24] ; eye.w

    mov eax, r12d
    shl eax, 5                         ; eax = i * 32
    lea rbx, [rsp + rax]               ; rbx = &corners[i]

    ; clip row 0:
    cvtss2sd xmm0, dword ptr [rdi + 0*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rdi + 4*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 8*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 12*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rbx + 0], xmm0    ; corners[i].x

    ; clip row 1:
    cvtss2sd xmm0, dword ptr [rdi + 1*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rdi + 5*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 9*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 13*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rbx + 8], xmm0    ; corners[i].y

    ; clip row 2:
    cvtss2sd xmm0, dword ptr [rdi + 2*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rdi + 6*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 10*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 14*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rbx + 16], xmm0   ; corners[i].z

    ; clip row 3:
    cvtss2sd xmm0, dword ptr [rdi + 3*4]
    mulsd xmm0, xmm10
    cvtss2sd xmm1, dword ptr [rdi + 7*4]
    mulsd xmm1, xmm11
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 11*4]
    mulsd xmm1, xmm12
    addsd xmm0, xmm1
    cvtss2sd xmm1, dword ptr [rdi + 15*4]
    mulsd xmm1, xmm13
    addsd xmm0, xmm1
    movsd qword ptr [rbx + 24], xmm0   ; corners[i].w

    inc r12d
    cmp r12d, 8
    jl corner_gen_loop

    ; 6. Initialize ScreenBox bounds:
    ; result.x = +INF, result.y = +INF, result.right = -INF, result.bottom = -INF
    mov eax, dword ptr [c_pos_inf]
    mov dword ptr [rsp + 304], eax     ; res_x
    mov dword ptr [rsp + 308], eax     ; res_y
    mov eax, dword ptr [c_neg_inf]
    mov dword ptr [rsp + 312], eax     ; res_right
    mov dword ptr [rsp + 316], eax     ; res_bottom
    mov dword ptr [rsp + 320], 0       ; valid_count = 0

    ; 7. Add all 8 corners
    xor r12d, r12d                     ; r12d = corner index 0..7
add_corners_loop:
    mov eax, r12d
    shl eax, 5                         ; i * 32
    lea rbx, [rsp + rax]
    movsd xmm0, qword ptr [rbx + 0]    ; vx
    movsd xmm1, qword ptr [rbx + 8]    ; vy
    movsd xmm2, qword ptr [rbx + 16]   ; vz
    movsd xmm3, qword ptr [rbx + 24]   ; vw
    call scalar_add_vertex
    inc r12d
    cmp r12d, 8
    jl add_corners_loop

    ; 8. Near-plane edge clipping (12 edges):
    ; for (i = 0; i < 8; ++i) for (bit : {1, 2, 4}) if (!(i & bit))
    lea r14, [g_edge_pairs]
    xor r13d, r13d                     ; r13d = edge pair index (0..11)
clip_edges_loop:
    movzx eax, byte ptr [r14 + r13*2 + 0] ; index a
    movzx ecx, byte ptr [r14 + r13*2 + 1] ; index b
    shl eax, 5
    shl ecx, 5
    lea rsi, [rsp + rax]               ; &corners[a]
    lea rdi, [rsp + rcx]               ; &corners[b]

    ; da = a.z + a.w
    movsd xmm0, qword ptr [rsi + 16]
    addsd xmm0, qword ptr [rsi + 24]   ; xmm0 = da
    ; db = b.z + b.w
    movsd xmm1, qword ptr [rdi + 16]
    addsd xmm1, qword ptr [rdi + 24]   ; xmm1 = db

    ; Check if (da < 0) != (db < 0) by testing sign bit of XOR:
    movq rax, xmm0
    movq rdx, xmm1
    xor rax, rdx
    test rax, rax
    jns next_edge                      ; bit 63 == 0 -> same signs -> does not cross

    ; t = da / (da - db)
    movsd xmm2, xmm0
    subsd xmm2, xmm1                   ; da - db
    divsd xmm0, xmm2                   ; t = da / (da - db) in xmm0

    ; Intersected point: P = a + (b - a) * t
    ; x = a.x + (b.x - a.x) * t
    movsd xmm1, qword ptr [rdi + 0]
    subsd xmm1, qword ptr [rsi + 0]
    mulsd xmm1, xmm0
    addsd xmm1, qword ptr [rsi + 0]    ; xmm1 = P.x

    ; y = a.y + (b.y - a.y) * t
    movsd xmm2, qword ptr [rdi + 8]
    subsd xmm2, qword ptr [rsi + 8]
    mulsd xmm2, xmm0
    addsd xmm2, qword ptr [rsi + 8]    ; xmm2 = P.y

    ; z = a.z + (b.z - a.z) * t
    movsd xmm3, qword ptr [rdi + 16]
    subsd xmm3, qword ptr [rsi + 16]
    mulsd xmm3, xmm0
    addsd xmm3, qword ptr [rsi + 16]   ; xmm3 = P.z

    ; w = a.w + (b.w - a.w) * t
    movsd xmm4, qword ptr [rdi + 24]
    subsd xmm4, qword ptr [rsi + 24]
    mulsd xmm4, xmm0
    addsd xmm4, qword ptr [rsi + 24]   ; xmm4 = P.w

    movsd xmm0, xmm1                   ; xmm0 = vx
    movsd xmm1, xmm2                   ; xmm1 = vy
    movsd xmm2, xmm3                   ; xmm2 = vz
    movsd xmm3, xmm4                   ; xmm3 = vw
    call scalar_add_vertex

next_edge:
    inc r13d
    cmp r13d, 12
    jl clip_edges_loop

    ; 9. Final ScreenBox checks:
    ; if (valid_count == 0) return 0
    cmp dword ptr [rsp + 320], 0
    jle fail_early

    ; Load bounds:
    movss xmm0, dword ptr [rsp + 304]  ; res_x
    movss xmm1, dword ptr [rsp + 308]  ; res_y
    movss xmm2, dword ptr [rsp + 312]  ; res_right
    movss xmm3, dword ptr [rsp + 316]  ; res_bottom

    ; Check isfinite(res_x)
    movd eax, xmm0
    and eax, 7f800000h
    cmp eax, 7f800000h
    je fail_early

    ; Check: res_right < 0 || res_bottom < 0
    xorps xmm4, xmm4
    ucomiss xmm2, xmm4
    jb fail_early
    ucomiss xmm3, xmm4
    jb fail_early

    ; Check: res_x > vp[2] + vp[0]
    mov rcx, [rsp + 296]               ; params
    mov eax, dword ptr [rcx + 256]     ; vp[0]
    add eax, dword ptr [rcx + 264]     ; vp[0] + vp[2]
    cvtsi2ss xmm5, eax
    ucomiss xmm0, xmm5
    ja fail_early

    ; Check: res_y > framebufferHeight
    cvtsi2ss xmm6, dword ptr [rcx + 272] ; fbHeight
    ucomiss xmm1, xmm6
    ja fail_early

    ; Clamping:
    ; res_x = max(res_x, -256.0f)
    movss xmm7, dword ptr [c_neg_clamp_pad]
    maxss xmm0, xmm7
    ; res_y = max(res_y, -256.0f)
    maxss xmm1, xmm7

    ; res_right = min(res_right, (vp[2] + vp[0]) + 256.0f)
    movss xmm8, dword ptr [c_clamp_pad]
    addss xmm5, xmm8
    minss xmm2, xmm5

    ; res_bottom = min(res_bottom, fbHeight + 256.0f)
    addss xmm6, xmm8
    minss xmm3, xmm6

    ; Final test: res_right > res_x && res_bottom > res_y
    ucomiss xmm2, xmm0
    jbe fail_early
    ucomiss xmm3, xmm1
    jbe fail_early

    ; Success: write to outBox
    mov rdx, [rsp + 288]               ; outBox ptr
    movss dword ptr [rdx + 0], xmm0    ; x
    movss dword ptr [rdx + 4], xmm1    ; y
    movss dword ptr [rdx + 8], xmm2    ; right
    movss dword ptr [rdx + 12], xmm3   ; bottom

    mov eax, 1
    jmp exit_scalar

fail_early:
    xor eax, eax

exit_scalar:
    add rsp, 488
    pop r15
    pop r14
    pop r13
    pop r12
    pop rdi
    pop rsi
    pop rbx
    pop rbp
    ret

; -----------------------------------------------------------------------------
; Internal helper: scalar_add_vertex
; Inputs:
;   xmm0 = vx (REAL8)
;   xmm1 = vy (REAL8)
;   xmm2 = vz (REAL8)
;   xmm3 = vw (REAL8)
; Modifies: xmm4-xmm9, eax
; -----------------------------------------------------------------------------
scalar_add_vertex:
    ; if (vw < 0.000001) return
    ucomisd xmm3, qword ptr [c_eps_w]
    jb add_return

    ; if (vz < -vw - 0.00001) return
    xorpd xmm4, xmm4
    subsd xmm4, xmm3
    subsd xmm4, qword ptr [c_eps_near]
    ucomisd xmm2, xmm4
    jb add_return

    ; if (vz > vw) return
    ucomisd xmm2, xmm3
    ja add_return

    ; Perspective division:
    ; ndc_x = vx / vw
    ; ndc_y = vy / vw
    divsd xmm0, xmm3
    divsd xmm1, xmm3

    ; Screen transform:
    ; x = vp[0] + (ndc_x + 1.0) * vp[2] * 0.5
    ; y = fbHeight - (vp[1] + (ndc_y + 1.0) * vp[3] * 0.5)
    mov rcx, [rsp + 296 + 8]           ; params ptr (+8 because call pushed return PC)
    addsd xmm0, qword ptr [c_one_double]
    cvtsi2sd xmm4, dword ptr [rcx + 264] ; vp[2]
    mulsd xmm0, xmm4
    mulsd xmm0, qword ptr [c_half_double]
    cvtsi2sd xmm4, dword ptr [rcx + 256] ; vp[0]
    addsd xmm0, xmm4
    cvtsd2ss xmm5, xmm0                ; float screen_x in xmm5

    addsd xmm1, qword ptr [c_one_double]
    cvtsi2sd xmm4, dword ptr [rcx + 268] ; vp[3]
    mulsd xmm1, xmm4
    mulsd xmm1, qword ptr [c_half_double]
    cvtsi2sd xmm4, dword ptr [rcx + 260] ; vp[1]
    addsd xmm1, xmm4
    cvtsi2sd xmm4, dword ptr [rcx + 272] ; fbHeight
    subsd xmm4, xmm1
    cvtsd2ss xmm6, xmm4                ; float screen_y in xmm6

    ; isfinite(screen_x) && isfinite(screen_y)
    movd eax, xmm5
    and eax, 7f800000h
    cmp eax, 7f800000h
    je add_return
    movd eax, xmm6
    and eax, 7f800000h
    cmp eax, 7f800000h
    je add_return

    ; Update min/max:
    ; res_x = min(res_x, screen_x)
    minss xmm5, dword ptr [rsp + 304 + 8]
    movss dword ptr [rsp + 304 + 8], xmm5

    ; res_y = min(res_y, screen_y)
    minss xmm6, dword ptr [rsp + 308 + 8]
    movss dword ptr [rsp + 308 + 8], xmm6

    ; Need screen_x and screen_y for max:
    ; re-extract or re-evaluate:
    cvtsd2ss xmm5, xmm0
    cvtsd2ss xmm6, xmm4
    maxss xmm5, dword ptr [rsp + 312 + 8]
    movss dword ptr [rsp + 312 + 8], xmm5

    maxss xmm6, dword ptr [rsp + 316 + 8]
    movss dword ptr [rsp + 316 + 8], xmm6

    inc dword ptr [rsp + 320 + 8]      ; valid_count++

add_return:
    ret

asm_ProjectScalar ENDP

END

