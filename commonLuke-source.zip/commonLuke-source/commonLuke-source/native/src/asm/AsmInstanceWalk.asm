; =============================================================================
; AOKI Client — Pure x64 MASM JVM Instanceof Walk Kernel
; Single super-chain walk testing membership against up to 32 target klasses.
; Mirrors client::mapping::InstanceMask / Instance semantics exactly:
;   - starts at the decoded runtime klass
;   - compares each level against every target
;   - follows Klass.super at most 64 levels
;   - early-outs when all targets matched
; Calling convention: Microsoft x64 ABI (leaf function, no calls)
;
; uint32_t asm_InstanceWalk(uintptr_t klass, uintptr_t superOffset,
;                           const uintptr_t* targets, uint32_t count)
; RCX = klass          (decoded runtime Klass pointer, nonzero)
; RDX = superOffset    (Klass.super member offset)
; R8  = targets        (uintptr_t array, count <= 32)
; R9D = count
; Returns EAX: bitmask of matched target indices
; =============================================================================

OPTION CASEMAP:NONE

.code

PUBLIC asm_InstanceWalk

asm_InstanceWalk PROC FRAME
    push rbp
    .pushreg rbp
    mov rbp, rsp
    push rbx
    .pushreg rbx
    .endprolog

    xor r11d, r11d               ; bits = 0
    test r9d, r9d
    jz short @done               ; count == 0 -> no targets

    ; remaining = (1 << count) - 1   (count <= 32; shl masks to 6 bits so
    ; count == 32 yields r10 = 0xFFFFFFFF after dec)
    ; RCX holds the live klass pointer: save it while CL carries the count.
    mov rax, rcx
    mov ecx, r9d
    mov r10d, 1
    shl r10, cl
    dec r10
    mov rcx, rax

    mov ebx, 64                  ; max depth, matches C++ i < 64

@level:
    test rcx, rcx                ; klass == nullptr -> chain ended
    jz short @done

    xor eax, eax                 ; target index
@inner:
    cmp eax, r9d
    jae short @next
    cmp qword ptr [r8 + rax*8], rcx
    jne short @inner_next
    bts r11, rax                 ; bits |= 1 << index
    btr r10, rax                 ; remaining &= ~(1 << index)
@inner_next:
    inc eax
    jmp short @inner

@next:
    test r10, r10                ; all targets found -> early out
    jz short @done
    mov rcx, [rcx + rdx]         ; klass = klass->super (Klass.super offset)
    dec ebx
    jnz short @level

@done:
    mov eax, r11d
    pop rbx
    pop rbp
    ret
asm_InstanceWalk ENDP

END
