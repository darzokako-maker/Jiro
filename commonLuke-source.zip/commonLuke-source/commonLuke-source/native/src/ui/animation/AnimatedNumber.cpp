#include "ui/animation/AnimatedNumber.hpp"
#include "ui/font/FontManager.hpp"
#include <algorithm>
#include <cmath>
namespace client::ui {
float Spring::Update(float target,float dt,float stiffness,float damping) {
 if(!initialized_) { value_=target; initialized_=true; return value_; }
 dt=std::clamp(dt,0.f,.1f);
 while(dt>0.f) {
  const float step=std::min(dt,1.f/240.f);
  velocity_+=(stiffness*(target-value_)-damping*velocity_)*step;
  value_+=velocity_*step; dt-=step;
 }
 if(std::abs(target-value_)<.001f && std::abs(velocity_)<.01f) { value_=target; velocity_=0.f; }
 return value_;
}
void AnimatedNumber::Update(int value,float dt,const FontManager& fonts,float size) {
 value_=std::max(value,0); digits_=1;
 for(int v=value_;v>=10;v/=10) ++digits_;
 if(metricsFont_!=fonts.Get(FontWeight::Medium)||metricsSize_!=size) {
  metricsFont_=fonts.Get(FontWeight::Medium);metricsSize_=size;column_=0.f;
  for(char c='0';c<='9';++c){glyphWidths_[c-'0']=fonts.Measure(std::string_view(&c,1),size,FontWeight::Medium).x;column_=std::max(column_,glyphWidths_[c-'0']);}
 }
 const float w=width_.Update(column_*digits_,dt);
 drawingDigits_=std::max(digits_,static_cast<int>(std::ceil(w/column_-.01f)));
 double divisor=1.;
 for(int i=0;i<10;++i) { places_[i].Update(static_cast<float>(std::floor(value_/divisor)),dt); divisor*=10.; }
}
void AnimatedNumber::Draw(const FontManager& fonts,ImDrawList& list,ImVec2 pos,float size,ImU32 color) const {
 list.PushClipRect({pos.x,pos.y-1.f},{pos.x+Width(),pos.y+size+1.f},true);
 for(int exp=0;exp<drawingDigits_ && exp<10;++exp) {
  float phase=std::fmod(places_[exp].Value(),10.f); if(phase<0.f) phase+=10.f;
  for(int digit=0;digit<10;++digit) {
   float offset=std::fmod(10.f+digit-phase,10.f); if(offset>5.f) offset-=10.f;
   if(std::abs(offset)>=1.f) continue;
   const int alpha=static_cast<int>(((color>>24)&255)*(1.f-std::abs(offset)));
   if(alpha<=5) continue;
   char c=static_cast<char>('0'+digit);
   const float glyph=glyphWidths_[digit];
   fonts.Draw(list,std::string_view(&c,1),{pos.x+Width()-(exp+1)*column_+(column_-glyph)*.5f,pos.y+offset*size},size,
       (color&0x00ffffff)|(static_cast<ImU32>(alpha)<<24),FontWeight::Medium);
  }
 }
 list.PopClipRect();
}
}
