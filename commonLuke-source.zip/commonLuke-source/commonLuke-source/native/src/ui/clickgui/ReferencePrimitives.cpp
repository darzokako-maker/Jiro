#include "ui/clickgui/ReferencePrimitives.hpp"
#include "render/GlApi.hpp"
#include "client/Logger.hpp"
#include <unordered_map>

namespace client::ui::clickgui {
namespace {
// Harakiri rise/shader/vertex.vsh and rq.frag. Keep the original logical-size
// distance field and one-unit smoothstep edge, rather than ImGui tessellation.
constexpr const char* vertex=R"(#version 120
void main(){gl_TexCoord[0]=gl_MultiTexCoord0;gl_Position=gl_ModelViewProjectionMatrix*gl_Vertex;})";
constexpr const char* fragment=R"(#version 120
uniform vec2 u_size;
uniform float u_radius;
uniform vec4 u_color;
uniform vec4 u_edges;
void main(void){
 vec2 tex_coord=gl_TexCoord[0].st;
 if(tex_coord.x<0.5&&tex_coord.y>0.5&&u_edges.x==0.0||tex_coord.x>0.5&&tex_coord.y>0.5&&u_edges.y==0.0||tex_coord.x>0.5&&tex_coord.y<0.5&&u_edges.z==0.0||tex_coord.x<0.5&&tex_coord.y<0.5&&u_edges.w==0.0)
  gl_FragColor=u_color;
 else gl_FragColor=vec4(u_color.rgb,u_color.a*smoothstep(1.0,0.0,length(max((abs(tex_coord-0.5)+0.5)*u_size-u_size+u_radius,0.0))-u_radius+0.5));
})";
constexpr const char* imageFragment=R"(#version 120
uniform sampler2D u_texture;
uniform vec2 u_size,u_uv0,u_uv1;
uniform float u_radius;
uniform vec4 u_tint;
void main(void){
 vec2 tc=gl_TexCoord[0].st;
 float mask=smoothstep(1.0,0.0,length(max((abs(tc-0.5)+0.5)*u_size-u_size+u_radius,0.0))-u_radius+0.5);
 vec4 pixel=texture2D(u_texture,mix(u_uv0,u_uv1,tc))*u_tint;
 gl_FragColor=vec4(pixel.rgb,pixel.a*mask);
})";
constexpr const char* waveFragment=R"(#version 120
uniform vec2 u_size;
uniform float u_amplitude,u_wavelength,u_thickness,u_phase;
uniform vec4 u_color;
void main(void){
 vec2 tc=gl_TexCoord[0].st;
 float x=tc.x*u_size.x;
 float y=(tc.y-0.5)*u_size.y;
 float envelope=0.35+0.65*sin(3.14159265*tc.x);
 float wave=sin(x/u_wavelength*6.2831853+u_phase)*u_amplitude*envelope;
 float alpha=smoothstep(1.0,0.0,abs(y-wave)-u_thickness+0.5);
 gl_FragColor=vec4(u_color.rgb,u_color.a*alpha);
})";
using render::gl;
struct Program {GLuint id=0;GLint size=-1,radius=-1,color=-1,edges=-1;};
struct ImageProgram {GLuint id=0;GLint texture=-1,size=-1,radius=-1,uv0=-1,uv1=-1,tint=-1;};
struct WaveProgram {GLuint id=0;GLint size=-1,amplitude=-1,wavelength=-1,thickness=-1,phase=-1,color=-1;};
std::unordered_map<HGLRC,Program> programs;
std::unordered_map<HGLRC,ImageProgram> imagePrograms;
std::unordered_map<HGLRC,WaveProgram> wavePrograms;
GLuint Compile(GLenum type,const char* source){
 const auto shader=gl.CreateShader(type);gl.ShaderSource(shader,1,&source,nullptr);gl.CompileShader(shader);
 GLint ok=0;gl.GetShaderiv(shader,0x8b81,&ok);if(!ok){char message[1024]{};gl.GetShaderInfoLog(shader,sizeof(message),nullptr,message);AOKI_LOG("Reference RQ shader: %s",message);gl.DeleteShader(shader);return 0;}return shader;
}
Program* Current(){
 const auto context=wglGetCurrentContext();if(!context)return nullptr;
 auto [at,inserted]=programs.try_emplace(context);auto& p=at->second;if(!inserted)return p.id?&p:nullptr;
 const auto vs=Compile(0x8b31,vertex),fs=Compile(0x8b30,fragment);
 if(!vs||!fs){if(vs)gl.DeleteShader(vs);if(fs)gl.DeleteShader(fs);return nullptr;}
 p.id=gl.CreateProgram();gl.AttachShader(p.id,vs);gl.AttachShader(p.id,fs);gl.LinkProgram(p.id);gl.DeleteShader(vs);gl.DeleteShader(fs);
 GLint ok=0;gl.GetProgramiv(p.id,0x8b82,&ok);if(!ok){gl.DeleteProgram(p.id);p.id=0;return nullptr;}
 p.size=gl.GetUniformLocation(p.id,"u_size");p.radius=gl.GetUniformLocation(p.id,"u_radius");p.color=gl.GetUniformLocation(p.id,"u_color");p.edges=gl.GetUniformLocation(p.id,"u_edges");return &p;
}
template<class T> bool Link(T& p,const char* source){
 const auto vs=Compile(0x8b31,vertex),fs=Compile(0x8b30,source);if(!vs||!fs){if(vs)gl.DeleteShader(vs);if(fs)gl.DeleteShader(fs);return false;}
 p.id=gl.CreateProgram();gl.AttachShader(p.id,vs);gl.AttachShader(p.id,fs);gl.LinkProgram(p.id);gl.DeleteShader(vs);gl.DeleteShader(fs);GLint ok=0;gl.GetProgramiv(p.id,0x8b82,&ok);if(!ok){gl.DeleteProgram(p.id);p.id=0;return false;}return true;
}
ImageProgram* CurrentImage(){
 const auto context=wglGetCurrentContext();if(!context)return nullptr;auto [at,inserted]=imagePrograms.try_emplace(context);auto& p=at->second;if(!inserted)return p.id?&p:nullptr;if(!Link(p,imageFragment))return nullptr;
 p.texture=gl.GetUniformLocation(p.id,"u_texture");p.size=gl.GetUniformLocation(p.id,"u_size");p.radius=gl.GetUniformLocation(p.id,"u_radius");p.uv0=gl.GetUniformLocation(p.id,"u_uv0");p.uv1=gl.GetUniformLocation(p.id,"u_uv1");p.tint=gl.GetUniformLocation(p.id,"u_tint");return &p;
}
WaveProgram* CurrentWave(){
 const auto context=wglGetCurrentContext();if(!context)return nullptr;auto [at,inserted]=wavePrograms.try_emplace(context);auto& p=at->second;if(!inserted)return p.id?&p:nullptr;if(!Link(p,waveFragment))return nullptr;
 p.size=gl.GetUniformLocation(p.id,"u_size");p.amplitude=gl.GetUniformLocation(p.id,"u_amplitude");p.wavelength=gl.GetUniformLocation(p.id,"u_wavelength");p.thickness=gl.GetUniformLocation(p.id,"u_thickness");p.phase=gl.GetUniformLocation(p.id,"u_phase");p.color=gl.GetUniformLocation(p.id,"u_color");return &p;
}
struct Rectangle {Program program;ImVec2 position;float width,height,radius,scale;ImU32 color;ImVec2 display;};
void Draw(const ImDrawList*,const ImDrawCmd* command){
 const auto& r=*static_cast<const Rectangle*>(command->UserCallbackData);
 GLint previousProgram=0,matrixMode=0;glGetIntegerv(0x8b8d,&previousProgram);glGetIntegerv(GL_MATRIX_MODE,&matrixMode);
 glPushAttrib(GL_ALL_ATTRIB_BITS);glDisable(GL_CULL_FACE);glDisable(GL_DEPTH_TEST);glDisable(GL_ALPHA_TEST);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
 glEnable(GL_SCISSOR_TEST);const auto clip=command->ClipRect;
 glScissor(static_cast<int>(clip.x),static_cast<int>(r.display.y-clip.w),static_cast<int>(clip.z-clip.x),static_cast<int>(clip.w-clip.y));
 glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,r.display.x,r.display.y,0,-1,1);
 glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
 const auto& p=r.program;gl.UseProgram(p.id);gl.Uniform2f(p.size,r.width,r.height);gl.Uniform1f(p.radius,r.radius);
 gl.Uniform4f(p.edges,1,1,1,1);gl.Uniform4f(p.color,(r.color&255)/255.f,((r.color>>8)&255)/255.f,((r.color>>16)&255)/255.f,(r.color>>24)/255.f);
 const float x=r.position.x,y=r.position.y,w=r.width*r.scale,h=r.height*r.scale;
 glBegin(GL_QUADS);glTexCoord2f(0,0);glVertex2f(x,y+h);glTexCoord2f(1,0);glVertex2f(x+w,y+h);glTexCoord2f(1,1);glVertex2f(x+w,y);glTexCoord2f(0,1);glVertex2f(x,y);glEnd();
 gl.UseProgram(previousProgram);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(matrixMode);glPopAttrib();
}
struct Image {ImageProgram program;GLuint texture;ImVec2 position;float width,height,radius;ImVec2 uv0,uv1;ImU32 tint;ImVec2 display;};
void DrawImage(const ImDrawList*,const ImDrawCmd* command){
 const auto& r=*static_cast<const Image*>(command->UserCallbackData);GLint previousProgram=0,matrixMode=0,activeTexture=0;glGetIntegerv(0x8b8d,&previousProgram);glGetIntegerv(GL_MATRIX_MODE,&matrixMode);glGetIntegerv(0x84e0,&activeTexture);
 glPushAttrib(GL_ALL_ATTRIB_BITS);glDisable(GL_CULL_FACE);glDisable(GL_DEPTH_TEST);glDisable(GL_ALPHA_TEST);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glEnable(GL_SCISSOR_TEST);const auto clip=command->ClipRect;glScissor(static_cast<int>(clip.x),static_cast<int>(r.display.y-clip.w),static_cast<int>(clip.z-clip.x),static_cast<int>(clip.w-clip.y));
 glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,r.display.x,r.display.y,0,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();const auto& p=r.program;gl.UseProgram(p.id);gl.ActiveTexture(render::Texture0);glBindTexture(GL_TEXTURE_2D,r.texture);gl.Uniform1i(p.texture,0);gl.Uniform2f(p.size,r.width,r.height);gl.Uniform1f(p.radius,r.radius);gl.Uniform2f(p.uv0,r.uv0.x,r.uv0.y);gl.Uniform2f(p.uv1,r.uv1.x,r.uv1.y);gl.Uniform4f(p.tint,(r.tint&255)/255.f,((r.tint>>8)&255)/255.f,((r.tint>>16)&255)/255.f,(r.tint>>24)/255.f);
 const float x=r.position.x,y=r.position.y,w=r.width,h=r.height;glBegin(GL_QUADS);glTexCoord2f(0,1);glVertex2f(x,y+h);glTexCoord2f(1,1);glVertex2f(x+w,y+h);glTexCoord2f(1,0);glVertex2f(x+w,y);glTexCoord2f(0,0);glVertex2f(x,y);glEnd();gl.UseProgram(previousProgram);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(matrixMode);glPopAttrib();gl.ActiveTexture(activeTexture);
}
struct Wave {WaveProgram program;ImVec2 position;float width,height,amplitude,wavelength,thickness,phase;ImU32 color;ImVec2 display;};
void DrawWave(const ImDrawList*,const ImDrawCmd* command){
 const auto& r=*static_cast<const Wave*>(command->UserCallbackData);GLint previousProgram=0,matrixMode=0;glGetIntegerv(0x8b8d,&previousProgram);glGetIntegerv(GL_MATRIX_MODE,&matrixMode);glPushAttrib(GL_ALL_ATTRIB_BITS);glDisable(GL_CULL_FACE);glDisable(GL_DEPTH_TEST);glDisable(GL_ALPHA_TEST);glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glEnable(GL_SCISSOR_TEST);const auto clip=command->ClipRect;glScissor(static_cast<int>(clip.x),static_cast<int>(r.display.y-clip.w),static_cast<int>(clip.z-clip.x),static_cast<int>(clip.w-clip.y));glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,r.display.x,r.display.y,0,-1,1);glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();const auto& p=r.program;gl.UseProgram(p.id);gl.Uniform2f(p.size,r.width,r.height);gl.Uniform1f(p.amplitude,r.amplitude);gl.Uniform1f(p.wavelength,r.wavelength);gl.Uniform1f(p.thickness,r.thickness);gl.Uniform1f(p.phase,r.phase);gl.Uniform4f(p.color,(r.color&255)/255.f,((r.color>>8)&255)/255.f,((r.color>>16)&255)/255.f,(r.color>>24)/255.f);const float x=r.position.x,y=r.position.y;glBegin(GL_QUADS);glTexCoord2f(0,1);glVertex2f(x,y+r.height);glTexCoord2f(1,1);glVertex2f(x+r.width,y+r.height);glTexCoord2f(1,0);glVertex2f(x+r.width,y);glTexCoord2f(0,0);glVertex2f(x,y);glEnd();gl.UseProgram(previousProgram);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(matrixMode);glPopAttrib();
}
}
bool ReferenceRectangle(ImDrawList& list,ImVec2 position,float width,float height,float radius,float scale,ImU32 color){
 const auto* p=Current();if(!p)return false;
 Rectangle rectangle{*p,position,width,height,radius,scale,color,ImGui::GetIO().DisplaySize};list.AddCallback(&Draw,&rectangle,sizeof(rectangle));return true;
}
bool ReferenceImageRounded(ImDrawList& list,unsigned int texture,ImVec2 position,float width,float height,float radius,ImVec2 uv0,ImVec2 uv1,ImU32 tint){const auto* p=CurrentImage();if(!p||!texture)return false;Image image{*p,texture,position,width,height,radius,uv0,uv1,tint,ImGui::GetIO().DisplaySize};list.AddCallback(&DrawImage,&image,sizeof(image));return true;}
bool ReferenceWave(ImDrawList& list,ImVec2 position,float width,float height,float amplitude,float wavelength,float thickness,float phase,ImU32 color){const auto* p=CurrentWave();if(!p||width<=0||height<=0)return false;Wave wave{*p,position,width,height,amplitude,wavelength,thickness,phase,color,ImGui::GetIO().DisplaySize};list.AddCallback(&DrawWave,&wave,sizeof(wave));return true;}
void ReleaseReferencePrimitives(){const auto context=wglGetCurrentContext();if(const auto at=programs.find(context);at!=programs.end()){if(at->second.id)gl.DeleteProgram(at->second.id);programs.erase(at);}if(const auto at=imagePrograms.find(context);at!=imagePrograms.end()){if(at->second.id)gl.DeleteProgram(at->second.id);imagePrograms.erase(at);}if(const auto at=wavePrograms.find(context);at!=wavePrograms.end()){if(at->second.id)gl.DeleteProgram(at->second.id);wavePrograms.erase(at);}}
}
