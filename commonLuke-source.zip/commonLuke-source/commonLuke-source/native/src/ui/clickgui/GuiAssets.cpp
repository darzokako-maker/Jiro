#include "ui/clickgui/GuiAssets.hpp"
#include "GuiLogo.hpp"
#include "ClickGuiBackground.hpp"
#include <Windows.h>
#include <wincodec.h>
#include <wrl/client.h>
#include "render/GlApi.hpp"
#include <algorithm>
#include <cmath>
#include <vector>
namespace client::ui::clickgui {
namespace {
GLuint UploadLogo(const BYTE* pixels, UINT width, UINT height) {
 constexpr GLint clampToEdge=0x812f;
 GLuint texture=0;
 glGenTextures(1,&texture);
 glBindTexture(GL_TEXTURE_2D,texture);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,clampToEdge);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,clampToEdge);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
 return texture;
}

GLuint LoadPngTexture(const unsigned char* png, DWORD size, UINT filteredHeight, GLuint* bloomTexture=nullptr) {
 GLuint texture=0;
 const HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
 using Microsoft::WRL::ComPtr;
 ComPtr<IWICImagingFactory> factory;ComPtr<IWICStream> stream;ComPtr<IWICBitmapDecoder> decoder;
 ComPtr<IWICBitmapFrameDecode> frame;ComPtr<IWICBitmapScaler> scaler;ComPtr<IWICFormatConverter> converter;
 bool ok=SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory)));
 ok=ok && SUCCEEDED(factory->CreateStream(&stream));
 ok=ok && SUCCEEDED(stream->InitializeFromMemory(const_cast<BYTE*>(png),size));
 ok=ok && SUCCEEDED(factory->CreateDecoderFromStream(stream.Get(),nullptr,WICDecodeMetadataCacheOnLoad,&decoder));
 ok=ok && SUCCEEDED(decoder->GetFrame(0,&frame));
 UINT sourceWidth=0,sourceHeight=0;
 if(ok)ok=SUCCEEDED(frame->GetSize(&sourceWidth,&sourceHeight))&&sourceWidth&&sourceHeight;
 const UINT filteredWidth=sourceHeight?std::max<UINT>(1,static_cast<UINT>(std::lround(static_cast<double>(filteredHeight)*sourceWidth/sourceHeight))):0;
 ok=ok && SUCCEEDED(factory->CreateBitmapScaler(&scaler));
 ok=ok && SUCCEEDED(scaler->Initialize(frame.Get(),filteredWidth,filteredHeight,WICBitmapInterpolationModeFant));
 ok=ok && SUCCEEDED(factory->CreateFormatConverter(&converter));
 ok=ok && SUCCEEDED(converter->Initialize(scaler.Get(),GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom));
 UINT w=0,h=0;if(ok)ok=SUCCEEDED(converter->GetSize(&w,&h)) && w && h && w<=4096 && h<=4096;
 if(ok) {
  std::vector<BYTE> pixels(w*h*4);
  ok=SUCCEEDED(converter->CopyPixels(nullptr,w*4,static_cast<UINT>(pixels.size()),pixels.data()));
  if(ok) {
   GLint previous=0,alignment=0,row=0;
   glGetIntegerv(GL_TEXTURE_BINDING_2D,&previous);
   glGetIntegerv(GL_UNPACK_ALIGNMENT,&alignment);
   glGetIntegerv(GL_UNPACK_ROW_LENGTH,&row);
   glPixelStorei(GL_UNPACK_ALIGNMENT,1);
   glPixelStorei(GL_UNPACK_ROW_LENGTH,0);

   if(bloomTexture) {
    // Remove dark artwork from the visible watermark as well as its glow.
    for(std::size_t i=0;i<pixels.size();i+=4) {
     auto* rgba=pixels.data()+i;
     const int brightness=std::max({rgba[0],rgba[1],rgba[2]});
     // Keep the inner mark and discard the separate perimeter ring.
     const float x=std::abs((static_cast<float>((i/4)%w)+.5f)/w-.5f);
     const float y=std::abs((static_cast<float>((i/4)/w)+.5f)/h-.5f);
     const bool inside=x<.39f&&y+.52f*x<.44f;
     rgba[3]=inside?static_cast<BYTE>(rgba[3]*std::clamp(brightness-144,0,64)/64):0;
     if(brightness<208)rgba[0]=rgba[1]=rgba[2]=255;
    }
   }
   texture=UploadLogo(pixels.data(),w,h);
   if(bloomTexture) {
    // The glow can only brighten the scene. Keep dark outlines out of its mask.
    for(std::size_t i=0;i<pixels.size();i+=4) {
     auto* rgba=pixels.data()+i;
     const int brightness=std::max({rgba[0],rgba[1],rgba[2]});
     rgba[3]=static_cast<BYTE>(rgba[3]*std::max(0,brightness-128)/127);
     rgba[0]=rgba[1]=rgba[2]=255;
    }
    *bloomTexture=UploadLogo(pixels.data(),w,h);
   }

   glBindTexture(GL_TEXTURE_2D,previous);
   glPixelStorei(GL_UNPACK_ALIGNMENT,alignment);
   glPixelStorei(GL_UNPACK_ROW_LENGTH,row);
  }
 }
 converter.Reset();scaler.Reset();frame.Reset();decoder.Reset();stream.Reset();factory.Reset();
 if(SUCCEEDED(com))CoUninitialize();
 return texture;
}
} // namespace

ImTextureID BackgroundPattern() {
 // Downsample the source with an area filter, then let GL interpolate it at draw size.
 static const auto texture=LoadPngTexture(kClickGuiBackground,static_cast<DWORD>(kClickGuiBackgroundSize),96);
 return texture;
}

WatermarkTextures WatermarkLogo() {
 static const auto textures=[] {
  GLuint glow=0;
  const auto image=LoadPngTexture(kWatermarkLogo,sizeof(kWatermarkLogo),128,&glow);
  return WatermarkTextures{image,glow};
 }();
 return textures;
}
}
