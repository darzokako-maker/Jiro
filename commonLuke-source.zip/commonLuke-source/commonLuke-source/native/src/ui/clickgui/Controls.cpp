#include "ui/clickgui/Controls.hpp"
#include "ui/clickgui/Palette.hpp"
#include "ui/animation/AnimatedNumber.hpp"
#include "ui/clickgui/ReferenceMotion.hpp"
#include <array>
#include <cstdio>
#include <string>
#include <unordered_map>
#include <vector>
#include <cctype>
#include <cstring>

namespace client::ui::clickgui {
namespace {
using namespace palette;
struct DropdownState {
 const void* identity=nullptr;
 std::vector<std::string> labels;
 std::function<void(int)> select;
 bool open=false,initialize=false;ImVec2 anchor{};int active=0,selected=0,scroll=0;OptionSpring pop,highlight;
} dropdown;
struct ColorState {ImU32* value=nullptr;bool open=false;ImVec2 anchor{};OptionSpring pop;} color;
struct SliderState {OptionSpring hover,overflow;std::array<std::unordered_map<int,OptionSpring>,2> digits;bool second=false;};
std::unordered_map<std::string,SliderState> sliders;
float Dt(){return ImGui::GetIO().DeltaTime;}
bool Inside(ImVec2 a,ImVec2 b){return ImGui::IsMouseHoveringRect(a,b);}
std::string Shorten(const Canvas& c,std::string text,float width,float size,FontWeight weight) {
 if(c.Measure(text,size,weight).x<=width*c.scale)return text;
 while(!text.empty()&&c.Measure(text+"...",size,weight).x>width*c.scale) {
  auto at=text.size()-1;while(at>0&&(static_cast<unsigned char>(text[at])&0xc0)==0x80)--at;text.erase(at);
 }
 return text+"...";
}
int VisibleOptions(float rowY) {
 const int below=static_cast<int>(std::floor((526-(rowY+36)-8)/29));
 const int above=static_cast<int>(std::floor(((rowY-6)-142-8)/29));
 return std::min(static_cast<int>(dropdown.labels.size()),std::min(6,std::max({1,below,above})));
}
void Shadow(const Canvas& c,float x,float y,float w,float h,float opacity=18,float radius=6) {
 for(float margin=0;margin<=5;margin+=.5f)c.Rect(x-margin/2,y-margin/2,w+margin,h+margin,
  IM_COL32(0,0,0,static_cast<int>(std::max(.5f,(opacity-margin*1.2f)/5.5f))),radius);
}
void Hex(const Canvas& c,float x,float y,float halfWidth,float halfHeight,ImU32 fill) {
 ImVec2 points[6];
 for(int i=0;i<6;++i) {const float angle=-1.5707963268f+i*1.0471975512f;points[i]=c.P(x+std::cos(angle)*halfWidth/.8660254f,y+std::sin(angle)*halfHeight);}
 c.draw->AddConvexPolyFilled(points,6,c.Fade(fill));
}
bool InHex(const Canvas& c,float x,float y) {
 const auto mouse=ImGui::GetIO().MousePos;
 const float dx=std::abs((mouse.x-c.origin.x)/c.scale-x),dy=std::abs((mouse.y-c.origin.y)/c.scale-y);
 return dx<=7 && dy<=8.1f-dx*8.1f/14.f;
}
void PaletteHex(const Canvas& c,const char* group,int index,float x,float y,unsigned rgb) {
 const ImU32 fill=IM_COL32((rgb>>16)&255,(rgb>>8)&255,rgb&255,255);
 const bool hovered=color.open && InHex(c,x,y);
 const bool selected=(*color.value&0xffffff)==(fill&0xffffff);
 if(selected||hovered) {Hex(c,x,y,9,10.2f,IM_COL32(255,255,255,48));Hex(c,x,y,8,9.2f,background);}
 Hex(c,x,y,7,8.1f,fill);
 if(color.open) {
  ImGui::PushID(group);ImGui::PushID(index);c.Button("hex",x-7,y-8.1f,14,16.2f);
  if(hovered && ImGui::IsItemClicked()) {*color.value=(fill&0xffffff)|(*color.value&0xff000000);color.open=false;}
  ImGui::PopID();ImGui::PopID();
 }
}
void DrawDropdown(const Canvas& c) {
 if(!dropdown.identity)return;
 const float pop=std::clamp(dropdown.pop.Update(dropdown.open?1.f:0.f,Dt(),650,50),0.f,1.f);
 if(pop<.015f && !dropdown.open){dropdown.identity=nullptr;dropdown.select={};return;}
 const float rowY=(dropdown.anchor.y-c.origin.y)/c.scale;
 const int visible=VisibleOptions(rowY),count=static_cast<int>(dropdown.labels.size());
 const float height=8+visible*29.f;
 if(dropdown.initialize){dropdown.scroll=std::clamp(dropdown.selected-visible+1,0,count-visible);dropdown.highlight.Reset(static_cast<float>(dropdown.selected-dropdown.scroll));dropdown.initialize=false;}
 dropdown.scroll=std::clamp(dropdown.scroll,0,count-visible);
 const float menuY=rowY+36+height<=526?rowY+36:std::max(142.f,rowY-6-height);
 const bool above=menuY+height<=rowY;
 const float animatedHeight=std::max(2.f,height*pop),animatedY=above?menuY+height-animatedHeight:menuY;
 Canvas p=c;p.alpha*=pop;
 Shadow(c,423,animatedY,145,animatedHeight);p.Rect(423,animatedY,145,animatedHeight,overlay,std::min(10.f,animatedHeight*.5f));
 if(animatedHeight>2)p.Rect(424,animatedY+1,143,animatedHeight-2,background,std::min(9.f,(animatedHeight-2)*.5f));
 const bool inside=Inside(c.P(423,menuY),c.P(568,menuY+height));
 if(dropdown.open && ImGui::IsMouseClicked(0) && !inside && !Inside(dropdown.anchor,{dropdown.anchor.x+145*c.scale,dropdown.anchor.y+30*c.scale}))dropdown.open=false;
 if(dropdown.open) {
  const auto& io=ImGui::GetIO();bool keyboard=false;
  if(inside&&io.MouseWheel!=0)dropdown.scroll=std::clamp(dropdown.scroll-static_cast<int>(io.MouseWheel),0,count-visible);
  if(ImGui::IsKeyPressed(ImGuiKey_DownArrow)){dropdown.active=std::min(count-1,dropdown.active+1);keyboard=true;}
  if(ImGui::IsKeyPressed(ImGuiKey_UpArrow)){dropdown.active=std::max(0,dropdown.active-1);keyboard=true;}
  if(ImGui::IsKeyPressed(ImGuiKey_Home)){dropdown.active=0;keyboard=true;}
  if(ImGui::IsKeyPressed(ImGuiKey_End)){dropdown.active=count-1;keyboard=true;}
  for(const auto character:io.InputQueueCharacters)if(character<128&&std::isprint(static_cast<unsigned char>(character))) {
   for(int step=1;step<=count;++step){const int index=(dropdown.active+step)%count;
    if(!dropdown.labels[index].empty()&&std::tolower(static_cast<unsigned char>(dropdown.labels[index][0]))==std::tolower(static_cast<unsigned char>(character))){dropdown.active=index;keyboard=true;break;}}
  }
  if(keyboard){if(dropdown.active<dropdown.scroll)dropdown.scroll=dropdown.active;if(dropdown.active>=dropdown.scroll+visible)dropdown.scroll=dropdown.active-visible+1;}
  const bool pointerMoved=io.MouseDelta.x!=0||io.MouseDelta.y!=0||io.MouseWheel!=0;
  if(!keyboard&&pointerMoved&&Inside(c.P(427,menuY+4),c.P(564,menuY+height-4)))
   dropdown.active=dropdown.scroll+std::clamp(static_cast<int>((io.MousePos.y-c.P(0,menuY+4).y)/(29*c.scale)),0,visible-1);
  if(ImGui::IsKeyPressed(ImGuiKey_Enter)||ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)){dropdown.select(dropdown.active);dropdown.selected=dropdown.active;dropdown.open=false;}
  if(ImGui::IsKeyPressed(ImGuiKey_Escape))dropdown.open=false;
 }
 const float highlight=dropdown.highlight.Update(static_cast<float>(dropdown.active-dropdown.scroll),Dt(),550,48);
 c.draw->PushClipRect(c.P(424,animatedY),c.P(567,animatedY+animatedHeight),true);
 if(dropdown.active>=dropdown.scroll&&dropdown.active<dropdown.scroll+visible)p.Rect(427,menuY+4+highlight*29,137,28,IM_COL32(255,255,255,22),7);
 for(int row=0;row<visible;++row) {
  const int index=dropdown.scroll+row;const float y=menuY+4+row*29.f;
  if(dropdown.open) {ImGui::PushID(index);c.Button("dropdownOption",427,y,137,28);if(ImGui::IsItemClicked()){dropdown.select(index);dropdown.selected=index;dropdown.open=false;}ImGui::PopID();}
  const auto text=Shorten(p,dropdown.labels[index],104,13,FontWeight::Medium);
  p.Text(text.c_str(),434,y+8,13,ink,FontWeight::Medium);
  if(index==dropdown.selected)p.Rect(548,y+10,7,7,ink,3.5f);
 }
 c.draw->PopClipRect();
}
void DrawColor(const Canvas& c) {
 if(!color.value)return;
 const float pop=std::clamp(color.pop.Update(color.open?1.f:0.f,Dt(),650,48),0.f,1.f);
 if(pop<.015f&&!color.open){color.value=nullptr;return;}
 const float rowY=(color.anchor.y-c.origin.y)/c.scale;
 const float y=rowY+34+238<=609?rowY+34:std::max(8.f,rowY-238-6);
 Canvas p=c;p.alpha*=pop;
 if(pop>.08f)Shadow(c,354,y,214,238,17,8);p.Rect(354,y,214,238,background,8);
 for(unsigned row=0;row<std::size(kPaletteColorsRows);++row) {
  const auto data=kPaletteColorsRows[row];
  const float start=354+107-data.count*7.f+7;
  for(unsigned col=0;col<data.count;++col)PaletteHex(p,"color",static_cast<int>(data.offset+col),start+col*14.f,y+24.1f+row*12.17f,kPaletteColors[data.offset+col]);
 }
 for(unsigned row=0;row<std::size(kPaletteGreysRows);++row) {
  const auto data=kPaletteGreysRows[row];
  for(unsigned col=0;col<data.count;++col)PaletteHex(p,"grey",static_cast<int>(data.offset+col),354+38+col*14.f,y+202.1f+row*12.17f,kPaletteGreys[data.offset+col]);
 }
 Hex(p,354+171,y+208,12,14,*color.value);
 if(color.open && ImGui::IsMouseClicked(0) && !Inside(c.P(354,y),c.P(568,y+238)) && !Inside(color.anchor,{color.anchor.x+52*c.scale,color.anchor.y+28*c.scale}))color.open=false;
}
}
namespace {
std::string NumberText(float value) {
 char text[48];std::snprintf(text,sizeof(text),"%.2f",value);
 std::string result=text;while(result.size()>1&&result.back()=='0')result.pop_back();if(result.back()=='.')result.pop_back();return result;
}
void RollingNumber(const Canvas& c,std::unordered_map<int,OptionSpring>& digits,const std::string& text,float x,float y) {
 const double magnitude=std::abs(std::strtod(text.c_str(),nullptr));
 const auto dot=text.find('.');
 const float digitHeight=std::max(13.f,c.Measure("ABCDEFGHOKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",12,FontWeight::Medium).y/c.scale+2);
 for(std::size_t i=0;i<text.size();++i) {
  const char ch=text[i];
  if(ch>='0'&&ch<='9') {
   const int exponent=dot==std::string::npos?static_cast<int>(text.size()-i-1):i<dot?static_cast<int>(dot-i-1):-static_cast<int>(i-dot);
   const double target=std::floor(magnitude/std::pow(10.,exponent)+1e-8);
   const auto [at,inserted]=digits.try_emplace(exponent,target);
   const float phase=std::fmod(at->second.Update(target,Dt(),300,23)+10.f,10.f);
   for(int digit=0;digit<10;++digit) {
    float offset=std::fmod(10+digit-phase,10.f);if(offset>5)offset-=10;
    if(std::abs(offset)<=1.25f){const char glyph[]={static_cast<char>('0'+digit),0};c.Text(glyph,x,y+offset*digitHeight,12,muted,FontWeight::Medium);}
   }
  } else {const char glyph[]={ch,0};c.Text(glyph,x,y,12,muted,FontWeight::Medium);}
  x+=c.Measure(std::string_view(&ch,1),12,FontWeight::Medium).x/c.scale;
 }
}
void NumberSlider(const Canvas& c,const char* label,float& first,float* second,float minimum,float maximum,float step,float y) {
 c.Text(label,32,y,14);c.Text("Drag to adjust the value.",32,y+19,13,muted);
 auto& motion=sliders[label];
 const std::string id=std::string("slider##")+label;
 c.Button(id.c_str(),408,y-4,160,38);
 const bool held=ImGui::IsItemActive()&&ImGui::IsMouseDown(0);
 const bool hovered=Inside(c.P(408,y+1),c.P(532,y+31));
 const float mouse=(ImGui::GetIO().MousePos.x-c.origin.x)/c.scale;
 const float span=std::max(.0001f,maximum-minimum);
 auto progress=[&](float value){return std::clamp((value-minimum)/span,0.f,1.f);};
 if(ImGui::IsItemActivated())motion.second=second&&std::abs(mouse-(418+104*progress(*second)))<std::abs(mouse-(418+104*progress(first)));
 if(held) {
  const float raw=minimum+std::clamp((mouse-418)/104.f,0.f,1.f)*(maximum-minimum);
  const float next=std::clamp(std::round(raw/step)*step,minimum,maximum);
  if(motion.second&&second)*second=next;else first=next;
 }
 const float hover=motion.hover.Update(hovered||held?1.f:0.f,Dt(),460,25);
 const float outside=held?std::max({0.f,418-mouse,mouse-522}):0.f;
 const float elastic=50*(2/(1+std::exp(-outside/50))-1);
 const float stretch=std::min(motion.overflow.Update(elastic,Dt(),380,17),18.f);
 const float trackX=418-(mouse<418?stretch:0),trackWidth=104+stretch,trackHeight=(4+4*hover)*(1-stretch/250);
 const float p1=progress(first),p2=second?progress(*second):0;
 c.Rect(trackX,y+16-trackHeight*.5f,trackWidth,trackHeight,overlay,trackHeight*.5f);
 c.Rect(trackX+(second?std::min(p1,p2):0)*trackWidth,y+16-trackHeight*.5f,
        (second?std::abs(p2-p1):p1)*trackWidth,trackHeight,ink,trackHeight*.5f);
 const float knob=12+3*hover;
 if(second)c.Rect(trackX+p2*trackWidth-knob*.5f,y+16-knob*.5f,knob,knob,ink,knob*.5f);
 c.Rect(trackX+p1*trackWidth-knob*.5f,y+16-knob*.5f,knob,knob,ink,knob*.5f);
 const auto firstText=NumberText(first),secondText=second?NumberText(*second):std::string{};
 const auto shown=firstText+(second?" - "+secondText:"");
 const float width=c.Measure(shown,12,FontWeight::Medium).x/c.scale;
 const float x=568-width;
 c.draw->PushClipRect(c.P(x-2,y-5),c.P(570,y+11),true);
 RollingNumber(c,motion.digits[0],firstText,x,y-4);
 if(second){const float next=x+c.Measure(firstText,12,FontWeight::Medium).x/c.scale;
  c.Text(" - ",next,y-4,12,muted,FontWeight::Medium);
  RollingNumber(c,motion.digits[1],secondText,next+c.Measure(" - ",12,FontWeight::Medium).x/c.scale,y-4);}
 c.draw->PopClipRect();
}
}
void Slider(const Canvas& c,const char* label,float& value,float minimum,float maximum,float step,float y) {NumberSlider(c,label,value,nullptr,minimum,maximum,step,y);}
void RangeSlider(const Canvas& c,const char* label,float& first,float& second,float minimum,float maximum,float step,float y) {NumberSlider(c,label,first,&second,minimum,maximum,step,y);}
void ResetOptionControls(){dropdown={};color={};sliders.clear();}
void Dropdown(const Canvas& c,const char* label,bool& value,const char* first,const char* second,float y) {
 const char* names[]={first,second};
 Dropdown(c,label,&value,value?1:0,std::span<const char* const>(names,2),[&value](int selected){value=selected==1;},y);
}
void Dropdown(const Canvas& c,const char* label,const void* identity,int selected,
              std::span<const char* const> names,std::function<void(int)> onSelect,float y) {
 if(names.empty())return;
 selected=std::clamp(selected,0,static_cast<int>(names.size())-1);
 c.Text(label,32,y,14);c.Text("Choose an option.",32,y+19,13,muted);
 const std::string id=std::string("dropdown##")+label;
 if(c.Button(id.c_str(),32,y-4,536,38)) {
  const bool same=dropdown.identity==identity && dropdown.open;
  color.open=false;
  if(!same){
   dropdown.identity=identity;dropdown.labels.clear();for(const auto name:names)dropdown.labels.emplace_back(name);
   dropdown.active=selected;dropdown.initialize=true;dropdown.pop.Reset(0);
  }
  dropdown.open=!same;
 }
 if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(1))onSelect((selected+static_cast<int>(names.size())-1)%static_cast<int>(names.size()));
 if(dropdown.identity==identity){dropdown.selected=selected;dropdown.select=std::move(onSelect);dropdown.anchor=c.P(423,y);}
 const bool open=dropdown.identity==identity&&dropdown.open;
 c.Rect(423,y,145,30,open?ink:border,8);c.Rect(424,y+1,143,28,open?secondary:background,7);
 const auto text=Shorten(c,names[selected],107,13,FontWeight::Medium);c.Text(text.c_str(),434,y+9,13,ink,FontWeight::Medium);
 const ImVec2 points[]={c.P(547,y+11),c.P(551,y+15),c.P(555,y+11)};
 c.draw->AddPolyline(points,3,c.Fade(muted),0,1.5f*c.scale);
}
void TextOption(const Canvas& c,const char* label,std::string& value,float y) {
 c.Text(label,32,y,14);c.Text("Click the field to edit the text.",32,y+19,13,muted);
 c.Rect(396,y,172,31,border,8);c.Rect(397,y+1,170,29,background,7);
 char text[2048]{};std::strncpy(text,value.c_str(),sizeof(text)-1);
 ImGui::PushID(label);ImGui::SetCursorScreenPos(c.P(397,y+1));ImGui::SetNextItemWidth(170*c.scale);
 ImGui::PushFont(c.fonts.Get(FontWeight::Regular),13*c.scale);
 ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,{9*c.scale,8*c.scale});
 ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize,0);
 ImGui::PushStyleColor(ImGuiCol_FrameBg,0);ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,0);ImGui::PushStyleColor(ImGuiCol_FrameBgActive,0);ImGui::PushStyleColor(ImGuiCol_Text,ink);
 if(ImGui::InputText("##text",text,sizeof(text)))value=text;
 ImGui::PopStyleColor(4);ImGui::PopStyleVar(2);ImGui::PopFont();ImGui::PopID();
}
void ColorOption(const Canvas& c,const char* label,ImU32& value,float y) {
 c.Text(label,32,y,14);c.Text("Click the swatch to edit the color.",32,y+19,13,muted);
 const std::string id=std::string("swatch##")+label;
 if(c.Button(id.c_str(),32,y-4,536,38)) {
  const bool same=color.value==&value&&color.open;dropdown.open=false;color.value=&value;
  if(!same)color.pop.Reset(0);color.open=!same;
 }
 c.Rect(516,y,52,28,border,8);c.Rect(518,y+2,48,24,value,6);
 if(color.value==&value)color.anchor=c.P(516,y);
}
void DrawControlOverlays(const Canvas& c){
 if(!dropdown.identity&&!color.value)return;
 // A parent's draw list is submitted before its scroll children regardless of
 // call order. A separate root window puts both visuals AND input over those rows.
 const bool interactive=ControlOverlayOpen();
 ImGui::SetNextWindowPos(c.origin);ImGui::SetNextWindowSize({600*c.scale,617*c.scale});
 if(interactive)ImGui::SetNextWindowFocus();
 ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});
 const auto flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoSavedSettings|
  ImGuiWindowFlags_NoNav|ImGuiWindowFlags_NoFocusOnAppearing|
  (interactive?0:ImGuiWindowFlags_NoInputs);
 ImGui::Begin("##controlOverlays",nullptr,flags);
 const Canvas top{c.origin,c.scale,ImGui::GetWindowDrawList(),c.fonts,c.alpha,c.reference};
 DrawDropdown(top);DrawColor(top);
 ImGui::End();ImGui::PopStyleVar();
}
void CloseControlOverlays(){dropdown.open=false;color.open=false;}
bool ControlOverlayOpen(){return dropdown.open||color.open;}
}
