#include "ui/clickgui/InputBridge.hpp"
#include "ui/hud/HudState.hpp"
#include "ui/clickgui/ClickGui.hpp"
#include "ui/input/KeybindManager.hpp"
#include <imgui.h>
#include <MinHook.h>
#include <atomic>
#include <mutex>
#include <vector>
#include <memory>
#include <algorithm>

namespace client::ui::input {
namespace {
std::atomic<bool> open=false, toggle=false;
std::atomic<void(*)()> entityClickHandler{nullptr};
struct GameplayFilter {std::string owner;GameplayKeyFilter key;GameplayMouseFilter mouse;int priority;};
using GameplayFilters=std::vector<GameplayFilter>;
std::atomic<std::shared_ptr<const GameplayFilters>> gameplayFilters{std::make_shared<const GameplayFilters>()};
std::mutex gameplayFilterMutex;
bool SuppressMouse(int button){const auto filters=gameplayFilters.load();for(const auto& filter:*filters)if(filter.mouse&&filter.mouse(button))return true;return false;}
HWND handle=nullptr;
WNDPROC previousProc=nullptr;
void* gameWindow=nullptr;
using SetMode=void(*)(void*,int,int);
using GetMode=int(*)(void*,int);
using GetButton=int(*)(void*,int);
using Cursor=void(*)(void*,double*,double*);
using SetCursor=void(*)(void*,double,double);
SetMode setMode=nullptr;
GetMode getMode=nullptr;
GetButton getKey=nullptr,getButton=nullptr;
Cursor getCursor=nullptr;
SetCursor setCursor=nullptr;
int oldMode=0x34003,oldRaw=0;
double anchorX=0,anchorY=0;
std::mutex eventMutex;
std::vector<unsigned int> characters;
float wheel=0;
int pressed=0;bool keyDown[256]{};
Snapshot snapshot;
bool previousMouse[5]{};
void HookMode(void* window,int mode,int value) {
 if(open && window==gameWindow) { if(mode==0x33001) value=0x34001; if(mode==0x33005) value=0; }
 setMode(window,mode,value);
}
int HookKey(void* window,int key) {
 int value=open&&window==gameWindow?0:getKey(window,key);
 if(!open&&window==gameWindow){const auto filters=gameplayFilters.load();for(const auto& filter:*filters)if(filter.key)value=filter.key(window,key,value,getKey);}
 return value;
}
int HookButton(void* window,int key) {
 if(window==gameWindow && (open || (key==0&&entityClickHandler.load())))return 0;
 if(window==gameWindow&&!open&&SuppressMouse(key))return 0;
 return getButton(window,key);
}
void HookCursor(void* window,double* x,double* y) {
 if(open && window==gameWindow) { if(x)*x=anchorX;if(y)*y=anchorY;return; } getCursor(window,x,y);
}
void HookSetCursor(void* window,double x,double y) { if(!(open && window==gameWindow)) setCursor(window,x,y); }
LRESULT CALLBACK Procedure(HWND window,UINT message,WPARAM w,LPARAM l) {
 if(!open&&(message==WM_RBUTTONDOWN||message==WM_RBUTTONUP||message==WM_RBUTTONDBLCLK||message==WM_LBUTTONDOWN||message==WM_LBUTTONUP||message==WM_LBUTTONDBLCLK))
  if(SuppressMouse(message==WM_RBUTTONDOWN||message==WM_RBUTTONUP||message==WM_RBUTTONDBLCLK?1:0))return 0;
 if(!open && GetForegroundWindow()==window && entityClickHandler.load()
    && (message==WM_LBUTTONDOWN || message==WM_LBUTTONUP || message==WM_LBUTTONDBLCLK)) {
  if(message==WM_LBUTTONDOWN)if(const auto handler=entityClickHandler.load())handler();
  return 0;
 }
 if((open||!client::ui::IsChatOpen())&&(message==WM_KEYDOWN||message==WM_SYSKEYDOWN) && (w==VK_RSHIFT || w==VK_INSERT || (w==VK_SHIFT && (l&(1<<24))==0 && ((l>>16)&255)==0x36))) {
  if(!(l&(1<<30))) toggle=true;
  return 0;
 }
 if(open) {
  if(message==WM_KEYDOWN && w==VK_ESCAPE) { toggle=true;return 0; }
  if(message==WM_CHAR) { std::lock_guard lock(eventMutex);characters.push_back(static_cast<unsigned>(w));return 0; }
  if(message==WM_MOUSEWHEEL) { std::lock_guard lock(eventMutex);wheel+=GET_WHEEL_DELTA_WPARAM(w)/120.f;return 0; }
  if(message==WM_SETCURSOR) { ::SetCursor(LoadCursorW(nullptr,MAKEINTRESOURCEW(32512)));return TRUE; }
  if((message>=WM_MOUSEFIRST && message<=WM_MOUSELAST) || message==WM_INPUT ||
     (message>=WM_KEYFIRST && message<=WM_KEYLAST)) return 0;
 }
 return CallWindowProcW(previousProc,window,message,w,l);
}
template<class T> void Hook(HMODULE module,const char* name,void* replacement,T& original) {
 const auto target=reinterpret_cast<void*>(GetProcAddress(module,name));
 if(target && MH_CreateHook(target,replacement,reinterpret_cast<void**>(&original))==MH_OK) MH_EnableHook(target);
}
}
int PressedKey() { return pressed; }
void SetEntityClickHandler(void (*handler)()) {entityClickHandler=handler;}
void SetGameplayFilters(std::string owner,GameplayKeyFilter key,GameplayMouseFilter mouse,int priority){
 std::lock_guard lock(gameplayFilterMutex);auto next=std::make_shared<GameplayFilters>(*gameplayFilters.load());
 const auto at=std::find_if(next->begin(),next->end(),[&](const auto& f){return f.owner==owner;});
 if(at==next->end())next->push_back({std::move(owner),key,mouse,priority});else *at={std::move(owner),key,mouse,priority};
 std::stable_sort(next->begin(),next->end(),[](const auto& a,const auto& b){return a.priority<b.priority;});gameplayFilters.store(std::move(next));
}
const Snapshot& State(){return snapshot;}
bool MenuTogglePending(){return toggle.load();}
void Poll() {
 pressed=0;snapshot={};snapshot.focused=handle&&GetForegroundWindow()==handle;
 for(int key=1;key<256;++key) {
  const bool down=(GetAsyncKeyState(key)&0x8000)!=0;
  snapshot.down[key]=snapshot.focused&&down;
  snapshot.pressed[key]=snapshot.focused&&down&&!keyDown[key];
  if(snapshot.pressed[key]&&!pressed&&(bindings::Bindable(key)||key==VK_ESCAPE))pressed=key;
  keyDown[key]=down;
 }
}
bool IsOpen() { return open.load(); }
void SetOpen(bool value) {
 if(value==open.load()) return;
 if(value && handle) {
  // Release held game inputs before swallowing events, avoiding sticky movement.
  for(int key=1;key<256;++key) if(GetAsyncKeyState(key)&0x8000)
   SendMessageW(handle,WM_KEYUP,key,static_cast<LPARAM>(MapVirtualKeyW(key,MAPVK_VK_TO_VSC))<<16 | 0xC0000000);
  SendMessageW(handle,WM_LBUTTONUP,0,0);SendMessageW(handle,WM_RBUTTONUP,0,0);
  if(getMode && gameWindow) { oldMode=getMode(gameWindow,0x33001);oldRaw=getMode(gameWindow,0x33005); }
  if(getCursor && gameWindow) getCursor(gameWindow,&anchorX,&anchorY);
 }
 open=value;
 if(!value && oldMode==0x34003 && setCursor && gameWindow) setCursor(gameWindow,anchorX,anchorY);
 if(handle && setMode && gameWindow) {
  setMode(gameWindow,0x33005,value?0:oldRaw);
  setMode(gameWindow,0x33001,value?0x34001:oldMode);
 }
 if(value) { ReleaseCapture();ClipCursor(nullptr); }
}
void Install(HWND window,void* glfwWindow) {
 if(handle || !window) return;
 handle=window;gameWindow=glfwWindow;
 for(const auto name:{L"glfw.dll",L"glfw3.dll",L"lwjgl_glfw.dll"}) if(const auto module=GetModuleHandleW(name)) {
  if(!GetProcAddress(module,"glfwSetInputMode")) continue;
  getMode=reinterpret_cast<GetMode>(GetProcAddress(module,"glfwGetInputMode"));
  Hook(module,"glfwSetInputMode",reinterpret_cast<void*>(&HookMode),setMode);
  Hook(module,"glfwGetKey",reinterpret_cast<void*>(&HookKey),getKey);
  Hook(module,"glfwGetMouseButton",reinterpret_cast<void*>(&HookButton),getButton);
  Hook(module,"glfwGetCursorPos",reinterpret_cast<void*>(&HookCursor),getCursor);
  Hook(module,"glfwSetCursorPos",reinterpret_cast<void*>(&HookSetCursor),setCursor);
  break;
 }
 previousProc=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(window,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(&Procedure)));
}
void NewFrame() {
 // The game hook polls once before keybind dispatch and clip capture. Standalone
 // previews have no installed game window and can poll here instead.
 if(!handle)Poll();
 if(toggle.exchange(false) && (open||!client::ui::IsChatOpen()) && !(open && clickgui::RequestClose())) SetOpen(!open);
 auto& io=ImGui::GetIO();
 io.MouseDrawCursor=false;
 if(handle && GetForegroundWindow()!=handle) { SetOpen(false);return; }
 if(!open&&!client::ui::IsScreenOpen()) return;
 POINT position{};
 if(handle && GetCursorPos(&position) && ScreenToClient(handle,&position)) io.AddMousePosEvent(static_cast<float>(position.x),static_cast<float>(position.y));
 const int buttons[]={VK_LBUTTON,VK_RBUTTON,VK_MBUTTON,VK_XBUTTON1,VK_XBUTTON2};
 for(int i=0;i<5;++i) {
  const bool down=(GetAsyncKeyState(buttons[i])&0x8000)!=0;
  if(previousMouse[i]!=down) { io.AddMouseButtonEvent(i,down);previousMouse[i]=down; }
 }
 if(!open)return;
 const struct { int vk; ImGuiKey key; } keys[]={
  {VK_BACK,ImGuiKey_Backspace},{VK_DELETE,ImGuiKey_Delete},{VK_LEFT,ImGuiKey_LeftArrow},{VK_RIGHT,ImGuiKey_RightArrow},
  {VK_HOME,ImGuiKey_Home},{VK_END,ImGuiKey_End},{VK_RETURN,ImGuiKey_Enter},{VK_TAB,ImGuiKey_Tab},
  {VK_UP,ImGuiKey_UpArrow},{VK_DOWN,ImGuiKey_DownArrow},
  {'A',ImGuiKey_A},{'C',ImGuiKey_C},{'V',ImGuiKey_V},{'X',ImGuiKey_X},{'Z',ImGuiKey_Z}};
 for(auto key:keys) io.AddKeyEvent(key.key,(GetAsyncKeyState(key.vk)&0x8000)!=0);
 io.AddKeyEvent(ImGuiMod_Ctrl,(GetAsyncKeyState(VK_CONTROL)&0x8000)!=0);
 io.AddKeyEvent(ImGuiMod_Shift,(GetAsyncKeyState(VK_SHIFT)&0x8000)!=0);
 std::lock_guard lock(eventMutex);
 for(auto character:characters) io.AddInputCharacterUTF16(static_cast<ImWchar16>(character));
 characters.clear();if(wheel) { io.AddMouseWheelEvent(0,wheel);wheel=0; }
}
}

