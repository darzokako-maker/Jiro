#include "ui/clickgui/ClickGui.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "ui/input/KeybindManager.hpp"
#include "ui/config/ConfigStore.hpp"
#include "ui/clickgui/GuiAssets.hpp"
#include "ui/clickgui/Controls.hpp"
#include "ui/clickgui/ReferenceMotion.hpp"
#include <functional>
#include <vector>
#include "ui/font/FontManager.hpp"
#include "features/visual/esp/Esp.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/visual/freecam/FreeCam.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/visual/dragon_wings/DragonWings.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/target_hud/TargetHud.hpp"
#include "features/visual/cosmetics/Cosmetics.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "features/combat/velocity/Velocity.hpp"
#include "features/combat/aim_assist/AimAssist.hpp"
#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "features/visual/ambiance/Ambiance.hpp"
#include "features/visual/xray/Xray.hpp"
#include "features/utility/auto_miner/AutoMiner.hpp"
#include "ui/animation/AnimatedNumber.hpp"
#include "ui/hud/Notifications.hpp"
#include "ui/hud/HudState.hpp"
#include <cstdio>
#include <imgui.h>
#include <Windows.h>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <string>
#include <unordered_map>
#include <cmath>

namespace client::ui::clickgui {
namespace {
namespace modules=features::modules;
bool draftMcf=true;
bool draftPacketLogger=false;
bool draftHud=true,draftNotifications=true;
features::wings::Settings draftWings;
features::velocity::Settings draftVelocity;
features::norotate::Settings draftNoRotate;
features::nojump::Settings draftNoJump;
features::spotify::Settings draftSpotify;
features::inventory_hud::Settings draftInventoryHud;
features::targethud::Settings draftTargetHud;
features::cosmetics::Settings draftCosmetics;
features::seeddumper::Settings draftSeedDumper;
features::disconnect::Settings draftDisconnect;
features::aimassist::Settings draftAimAssist;
features::xray::Settings draftXray;
features::autominer::Settings draftAutoMiner;
std::array<features::extras::Settings,static_cast<int>(features::extras::Kind::Count)> draftExtras;
int ExtraIndex(int id){const auto kind=features::extras::FromModuleIndex(id);return kind?static_cast<int>(*kind):-1;}
int category=0,selected=-1,tab=0,binding=0;
bindings::Config draftBindings;
float opacity=0;
float settingsOpacity=0;
OptionFade settingsFade;
ImVec2 settingsPosition{},settingsDragOffset{};
bool settingsFresh=true,settingsDragging=false;
int presentedSettings=-1;
float cardReveal=1.f;
int renderedCategory=0;
double confirmUntil=0;
char search[128]{};
features::esp::Settings draft;
features::item_esp::Settings draftItemEsp;
features::freecam::Settings draftFreeCam;
features::ambiance::Settings draftAmbiance;
features::scaffold::Settings draftScaffold;
using namespace palette;

ImU32 Blend(ImU32 a,ImU32 b,float t) {
 t=std::clamp(t,0.f,1.f);ImU32 result=0;
 for(int i=0;i<32;i+=8)result|=static_cast<ImU32>(((a>>i)&255)*(1-t)+((b>>i)&255)*t)<<i;
 return result;
}
void Toggle(const Canvas& c,const char* id,float x,float y,float width,float height,bool value,float stiffness=450,float damping=28) {
 static std::unordered_map<std::string,Spring> animations;
 const float t=std::clamp(animations[id].Update(value?1.f:0.f,ImGui::GetIO().DeltaTime,stiffness,damping),0.f,1.f);
 const float knob=height*.5714286f,padding=(height-knob)*.5f;
 c.Rect(x,y,width,height,Blend(border,ink,t),height*.5f);
 c.Rect(x+padding+(width-knob-padding*2)*t,y+padding,knob,knob,background,knob*.5f);
}
// Figma frame 2:642 is 1201 × 69. Scale all its measurements together.
constexpr float headerWidth=400.f;
constexpr float headerUnit=headerWidth/1201.f;
constexpr float headerHeight=69.f*headerUnit;
constexpr float headerGap=13.f*headerUnit;

constexpr float bodyHeight=250.f;
constexpr float sidebarWidth=headerHeight;
constexpr float contentX=sidebarWidth+headerGap;
constexpr float contentWidth=headerWidth-contentX;

struct Scroll {
 float value=0,target=0,maximum=0,dragOffset=0;
 void Step(const Canvas& c,float top,float height,bool wheel=true) {
  const auto& io=ImGui::GetIO();
  if(wheel && ImGui::IsMouseHoveringRect(c.P(contentX,top),c.P(headerWidth,top+height))) target-=io.MouseWheel*60.f;
  target=std::clamp(target,0.f,maximum);
  value+=(target-value)*(wheel?1.f-std::pow(.99f,std::min(io.DeltaTime,.5f)*1000.f):.24f);
  if(!wheel&&std::abs(target-value)<.1f)value=target;
 }
 void Bar(const Canvas& c,const char* id,float x,float y,float height,float minimum,float hitWidth=18.f) {
  if(maximum<=0) return;
  const float thumb=std::clamp(height*height/(height+maximum),minimum,height);
  const float travel=height-thumb,thumbY=y+value/maximum*travel;
  c.Button(id,x-hitWidth*.5f,y,hitWidth,height);
  const float mouse=(ImGui::GetIO().MousePos.y-c.origin.y)/c.scale;
  if(ImGui::IsItemActivated()) dragOffset=mouse>=thumbY && mouse<=thumbY+thumb?mouse-thumbY:thumb*.5f;
  if(ImGui::IsItemActive() && ImGui::IsMouseDown(0) && travel>0) {
   target=std::clamp((mouse-y-dragOffset)/travel,0.f,1.f)*maximum;value=target;
  }
  c.Rect(x-.5f,y,1,height,IM_COL32(0,0,0,25),.5f);
  c.Rect(x-.5f,y+value/maximum*travel,1,thumb,ink,.5f);
 }
};
Scroll settingsScroll,mainScroll,configScroll;
std::vector<configs::Entry> configEntries;
bool configsLoaded=false;
static std::unordered_map<std::string,Spring> entryAnimations;

void SyncConfigs(bool animateNew=true){
 auto currentList=configs::List();
 if(!configsLoaded){
  configEntries=std::move(currentList);
  for(const auto& e:configEntries)entryAnimations[e.name].Reset(1.f);
  configsLoaded=true;
  configScroll.target=configScroll.value=0;
  return;
 }
 bool changed=false;
 for(const auto& item:currentList){
  const bool exists=std::any_of(configEntries.begin(),configEntries.end(),[&](const configs::Entry& e){return _stricmp(e.name.c_str(),item.name.c_str())==0;});
  if(!exists){
   changed=true;
   if(animateNew)entryAnimations[item.name].Reset(0.f);
   else entryAnimations[item.name].Reset(1.f);
  }
 }
 if(!changed&&currentList.size()!=configEntries.size())changed=true;
 if(changed){
  configEntries=std::move(currentList);
  for(const auto& e:configEntries){
   if(entryAnimations.find(e.name)==entryAnimations.end())
    entryAnimations[e.name].Reset(animateNew?0.f:1.f);
  }
  for(auto it=entryAnimations.begin();it!=entryAnimations.end();){
   const bool exists=std::any_of(configEntries.begin(),configEntries.end(),[&](const configs::Entry& e){return _stricmp(e.name.c_str(),it->first.c_str())==0;});
   if(!exists)it=entryAnimations.erase(it);
   else ++it;
  }
 }
}
void RefreshConfigs(){SyncConfigs(false);configScroll.target=configScroll.value=0;}
void ConfigPage(const Canvas& source,float reveal) {
 if(!configsLoaded)RefreshConfigs();
 static bool wasGameFocused=true;
 const bool gameFocused=input::State().focused;
 const bool gainedFocus=gameFocused&&!wasGameFocused;
 wasGameFocused=gameFocused;
 static double lastSyncCheck=0;
 const double now=ImGui::GetTime();
 if(gainedFocus||(now-lastSyncCheck>0.5)){
  lastSyncCheck=now;
  SyncConfigs(true);
 }
 const Canvas c{source.origin,source.scale,source.draw,source.fonts,source.alpha*reveal};
 constexpr float u=4.f,columnGap=u;
 constexpr float left=contentX+3*u,width=contentWidth-6*u;
 constexpr float cardW=(width-columnGap)*.5f,cardH=9*u,rowPitch=10*u;
 constexpr float titleY=2*u,subtitleY=5.25f*u,createY=7.75f*u,controlH=5*u,controlGap=u,createW=14*u,inputW=width-createW-controlGap;
 constexpr float statusY=14*u,locationY=16*u,listTop=18.25f*u,footerTextY=250.f*548.f/607.f,footerBaseFont=250.f*13.f/607.f,listHeight=34.75f*u;
 static char name[65]{};static std::string status;static bool error=false;static std::string pendingDelete;static double deleteUntil=0;
 static std::unordered_map<std::string,Spring> hoverAnimations;
 const auto feedback=[&](std::string text,bool failed){status=std::move(text);error=failed;};
 c.Text("Configs",left,titleY,10,ink,FontWeight::SemiBold);c.Text("Module and keybind snapshots",left,subtitleY,6,muted);
 ImGui::PushID("ConfigPage");ImGui::SetCursorScreenPos(c.P(left,createY));ImGui::SetNextItemWidth(inputW*c.scale);ImGui::PushFont(c.fonts.Get(FontWeight::Medium),8*c.scale);
 ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,{2*u*c.scale,(controlH-8)*.5f*c.scale});ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,1.75f*u*c.scale);ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize,0);
 ImGui::PushStyleColor(ImGuiCol_FrameBg,ImGui::ColorConvertU32ToFloat4(c.Fade(secondary)));ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,ImGui::ColorConvertU32ToFloat4(c.Fade(overlay)));ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImGui::ColorConvertU32ToFloat4(c.Fade(overlay)));ImGui::PushStyleColor(ImGuiCol_Text,ImGui::ColorConvertU32ToFloat4(c.Fade(ink)));
 const bool enter=ImGui::InputTextWithHint("##ConfigName","Config name",name,sizeof(name),ImGuiInputTextFlags_EnterReturnsTrue);
 ImGui::PopStyleColor(4);ImGui::PopStyleVar(3);ImGui::PopFont();
 const float createX=left+inputW+controlGap;if(c.Button("Create",createX,createY,createW,controlH)||enter){std::string message;if(configs::Save(name,false,message)){feedback("Config created",false);name[0]=0;SyncConfigs(true);}else feedback(message,true);}
 c.Rect(createX,createY,createW,controlH,ImGui::IsItemHovered()?overlay:ink,1.75f*u);c.Center("Create",createX,createY+(controlH-7)*.5f,createW,7,ImGui::IsItemHovered()?ink:background);
 if(!status.empty())c.Text(status.c_str(),left,statusY,6,error?IM_COL32(255,142,142,255):muted,FontWeight::Medium);
 else c.Text(configEntries.empty()?"No saved configs":"Saved configs",left,statusY,6,muted,FontWeight::Medium);
 const std::string location="Saved to: "+configs::StorageLocation();const float locationBaseFont=5.5f;const float locationWidth=c.Measure(location,locationBaseFont).x/c.scale;const float locationFont=locationBaseFont*std::min(1.f,width/std::max(1.f,locationWidth));c.Text(location.c_str(),left,locationY,locationFont,muted);
 configScroll.Step(c,listTop,listHeight);configScroll.maximum=std::max(0.f,std::ceil(configEntries.size()/2.f)*rowPitch-listHeight);
 ImGui::PushClipRect(c.P(left,listTop),c.P(left+width,listTop+listHeight),true);
 const auto active=configs::Current();
 for(std::size_t i=0;i<configEntries.size();++i){const auto& entry=configEntries[i];const float x=left+(i%2)*(cardW+columnGap),y=listTop+(i/2)*rowPitch-configScroll.value;if(y+cardH<listTop||y>listTop+listHeight)continue;const bool activeEntry=_stricmp(active.c_str(),entry.name.c_str())==0;
  const bool cardHovered=ImGui::IsMouseHoveringRect(c.P(x,y),c.P(x+cardW,y+cardH));const float highlight=hoverAnimations[entry.name].Update(cardHovered?1.f:0.f,ImGui::GetIO().DeltaTime,450,32);
  const float itemProgress=std::clamp(entryAnimations[entry.name].Update(1.f,ImGui::GetIO().DeltaTime,350.f,26.f),0.f,1.f);
  const float totalProgress=reveal*itemProgress;
  const float cardZoom=.7f+.3f*totalProgress;
  const Canvas card{c.P(x+cardW*.5f*(1-cardZoom),y+cardH*.5f*(1-cardZoom)),c.scale*cardZoom,c.draw,c.fonts,source.alpha*totalProgress};
  card.Rect(0,0,cardW,cardH,Blend(activeEntry?overlay:secondary,palette::hoveredSurface,highlight),1.75f*u);
  std::string displayName=entry.name;while(displayName.size()>1&&card.Measure(displayName,7,FontWeight::SemiBold).x/card.scale>29*u)displayName.pop_back();card.Text(displayName.c_str(),1.75f*u,1.25f*u,7,activeEntry?ink:muted,FontWeight::SemiBold);
  constexpr float buttonW=8.75f*u,buttonGap=.75f*u,buttonY=4.75f*u,buttonH=3*u;const float loadX=x+1.75f*u,saveX=loadX+buttonW+buttonGap,deleteX=saveX+buttonW+buttonGap;
  ImGui::PushID(static_cast<int>(i));
  const bool loadClicked=c.Button("Load",loadX,y+buttonY,buttonW,buttonH),loadHovered=ImGui::IsItemHovered();if(totalProgress>.5f&&loadClicked){std::string message;if(configs::Load(entry.name,message))feedback("Loaded "+entry.name,false);else feedback(message,true);}card.Rect(1.75f*u,buttonY,buttonW,buttonH,loadHovered?border:overlay,1.5f*u);card.Center("Load",1.75f*u,buttonY+(buttonH-6)*.5f,buttonW,6,ink);
  const bool saveClicked=c.Button("Save",saveX,y+buttonY,buttonW,buttonH),saveHovered=ImGui::IsItemHovered();if(totalProgress>.5f&&saveClicked){std::string message;if(configs::Save(entry.name,true,message)){feedback("Saved "+entry.name,false);SyncConfigs(false);}else feedback(message,true);}card.Rect(1.75f*u+buttonW+buttonGap,buttonY,buttonW,buttonH,saveHovered?border:overlay,1.5f*u);card.Center("Save",1.75f*u+buttonW+buttonGap,buttonY+(buttonH-6)*.5f,buttonW,6,ink);
  const bool confirming=pendingDelete==entry.name&&ImGui::GetTime()<deleteUntil;const bool deleteClicked=c.Button("Delete",deleteX,y+buttonY,buttonW,buttonH),deleteHovered=ImGui::IsItemHovered();if(totalProgress>.5f&&deleteClicked){if(confirming){std::string message;if(configs::Remove(entry.name,message)){feedback("Deleted "+entry.name,false);pendingDelete.clear();SyncConfigs(false);ImGui::PopID();break;}feedback(message,true);}else{pendingDelete=entry.name;deleteUntil=ImGui::GetTime()+2;feedback("Press Sure? to delete",false);}}card.Rect(1.75f*u+2*(buttonW+buttonGap),buttonY,buttonW,buttonH,deleteHovered?border:overlay,1.5f*u);card.Center(confirming?"Sure?":"Delete",1.75f*u+2*(buttonW+buttonGap),buttonY+(buttonH-6)*.5f,buttonW,6,confirming?IM_COL32(255,142,142,255):ink);ImGui::PopID();
 }
 ImGui::PopClipRect();configScroll.Bar(c,"configScrollbar",headerWidth-u,listTop,listHeight,5*u);
 constexpr const char* signature="hihiheiehihihieheuehihej>:] the0nlyavavuv i dont play da gamez tht othrs do";const float measured=c.Measure(signature,footerBaseFont).x/c.scale;const float footerFont=footerBaseFont*std::min(1.f,width/std::max(1.f,measured));c.Text(signature,left+width*10.f/645.f,footerTextY,footerFont,muted);
 ImGui::PopID();
}

bool Search(const Canvas& c,float x,float y,float width,float height) {
 constexpr float fontSize=21.f*headerUnit;
 const float centerX=x+width*.5f,centerY=y+height*.5f;
 const char* placeholder="Start typing to search...";
 struct Edit {int cursor=0;bool end=false;} edit;
 edit.end=ImGui::IsMouseHoveringRect(c.P(x,y),c.P(x+width,y+height)) && ImGui::IsMouseClicked(0);
 ImGui::SetCursorScreenPos(c.P(x,y));ImGui::SetNextItemWidth(width*c.scale);
 ImGui::PushFont(c.fonts.Get(FontWeight::Regular),fontSize*c.scale);
 ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,{0,(height-fontSize)*.5f*c.scale});
 ImGui::PushStyleColor(ImGuiCol_FrameBg,{0,0,0,0});ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,{0,0,0,0});
 ImGui::PushStyleColor(ImGuiCol_FrameBgActive,{0,0,0,0});ImGui::PushStyleColor(ImGuiCol_Text,{0,0,0,0});ImGui::PushStyleColor(ImGuiCol_TextSelectedBg,{0,0,0,0});
 ImGui::PushStyleColor(ImGuiCol_InputTextCursor,IM_COL32(0,0,0,0));
 if(selected<0 && ImGui::GetIO().InputQueueCharacters.Size && !ImGui::IsAnyItemActive())ImGui::SetKeyboardFocusHere();
 ImGui::InputText("##search",search,sizeof(search),ImGuiInputTextFlags_CallbackAlways,
  [](ImGuiInputTextCallbackData* data) {auto& e=*static_cast<Edit*>(data->UserData);if(e.end)data->CursorPos=data->SelectionStart=data->SelectionEnd=data->BufTextLen;e.cursor=data->CursorPos;return 0;},&edit);
 const bool activated=ImGui::IsItemActivated();
 const bool active=ImGui::IsItemActive();ImGui::PopStyleColor(6);ImGui::PopStyleVar();ImGui::PopFont();
 const char* displayed=search[0]?search:placeholder;
 const float textWidth=c.Measure(displayed,fontSize).x/c.scale;
 static float positionOffset=0;static float cursor=0;
 const float weight=1.f-std::pow(.95f,std::min(ImGui::GetIO().DeltaTime,.5f)*1000.f);
 positionOffset+=(-textWidth*.5f-positionOffset)*weight;
 const float position=centerX+positionOffset;
 const auto prefix=std::string_view(search,static_cast<size_t>(std::clamp(edit.cursor,0,static_cast<int>(std::strlen(search)))));
 const float offset=c.Measure(prefix,fontSize).x/c.scale;
 cursor+=(offset-cursor)*weight;
 const auto baked=c.fonts.Get(FontWeight::Regular)->GetFontBaked(fontSize*c.scale);
 const float rasterScale=fontSize*c.scale/baked->Size;
 float inkTop=INFINITY,inkBottom=-INFINITY;
 for(const unsigned char* p=reinterpret_cast<const unsigned char*>(displayed);*p;++p) if(*p!=' ') if(const auto glyph=baked->FindGlyph(*p)) {
  inkTop=std::min(inkTop,glyph->Y0*rasterScale);inkBottom=std::max(inkBottom,glyph->Y1*rasterScale);
 }
 if(!std::isfinite(inkTop)) {
  inkTop=0.f;
  inkBottom=fontSize*c.scale;
 }
 const auto center=c.P(position,centerY);
 const float textY=std::round(center.y-(inkTop+inkBottom)*.5f);
 c.draw->PushClipRect(c.P(x+height,y),c.P(x+width-height*.25f,y+height),true);
 c.fonts.Draw(*c.draw,displayed,{center.x,textY},fontSize*c.scale,c.Fade(search[0]?ink:muted));
 if(active) {
  const float caretHeight=(inkBottom-inkTop)/c.scale+2;
  c.Rect(position+cursor,centerY-caretHeight*.5f,.65f,caretHeight,
      IM_COL32(237,237,239,static_cast<int>((std::sin(ImGui::GetTime()/.15)+1)*127.5)),.325f);
 }
 c.draw->PopClipRect();
 return activated;
}
void WelcomeHeader(const Canvas& header,ImDrawList& blurMask,float width) {
 constexpr float radius=headerHeight*.5f;
 constexpr float inset=40.f*headerUnit;
 const float horizontalUnit=width/1201.f;
 const float searchX=407.f*horizontalUnit,searchWidth=440.f*horizontalUnit;
 constexpr float searchHeight=39.f*headerUnit,searchY=(headerHeight-searchHeight)*.5f;
 constexpr float iconSize=14.6f*headerUnit;
 constexpr float logoSize=iconSize*1.18f;
 constexpr float logoY=(headerHeight-logoSize)*.5f;
 constexpr float welcomeX=inset+2.f*logoSize;
 const float welcomeEnd=searchX-inset;
 constexpr float welcomeFont=20.f*headerUnit;
 blurMask.AddRectFilled(header.P(0,0),header.P(width,headerHeight),
  header.Fade(IM_COL32_WHITE),radius*header.scale);
 header.Rect(0,0,width,headerHeight,glass,radius);
 header.draw->AddRect(header.P(0,0),header.P(width,headerHeight),header.Fade(border),radius*header.scale);

 if(const auto logo=WatermarkLogo().bloom) {
  header.draw->AddImage(logo,header.P(inset,logoY),header.P(inset+logoSize,logoY+logoSize),
   {0,0},{1,1},header.Fade(IM_COL32_WHITE));
 }
 auto name=GetHudPlayerName();
 if(name.empty())name="Player";
 const auto welcome="Welcome, "+name;
 const float measured=header.Measure(welcome,welcomeFont,FontWeight::SemiBold).x/header.scale;
 const float welcomeSize=welcomeFont*std::min(1.f,(welcomeEnd-welcomeX)/std::max(1.f,measured));
 header.Text(welcome.c_str(),welcomeX,(headerHeight-welcomeSize)*.5f,welcomeSize,ink,FontWeight::SemiBold);

 header.Rect(searchX,searchY,searchWidth,searchHeight,secondary,searchHeight*.5f);
 header.RowIcon(0xeb1c,searchX+searchHeight*.5f,headerHeight*.5f,iconSize);
 if(Search(header,searchX,searchY,searchWidth,searchHeight))category=0;

 SYSTEMTIME now{};
 GetLocalTime(&now);
 constexpr const char* weekdays[]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
 constexpr const char* months[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
 char time[24]{},date[36]{};
 std::snprintf(time,sizeof(time),"%02u:%02u",static_cast<unsigned>(now.wHour),static_cast<unsigned>(now.wMinute));
 std::snprintf(date,sizeof(date),"%s, %u %s %u",weekdays[now.wDayOfWeek],static_cast<unsigned>(now.wDay),months[now.wMonth-1],static_cast<unsigned>(now.wYear));
 const float right=width-inset;
 constexpr float timeSize=20.f*headerUnit,dateSize=16.f*headerUnit;
 constexpr float timeLine=24.f*headerUnit,dateLine=19.f*headerUnit;
 constexpr float groupY=(headerHeight-timeLine-dateLine)*.5f;
 header.Text(time,right-header.Measure(time,timeSize,FontWeight::SemiBold).x/header.scale,
  groupY+(timeLine-timeSize)*.5f,timeSize,ink,FontWeight::SemiBold);
 header.Text(date,right-header.Measure(date,dateSize).x/header.scale,
  groupY+timeLine+(dateLine-dateSize)*.5f,dateSize,muted);
}
bool Dirty() {
 if(draftBindings!=bindings::Options(static_cast<modules::Id>(selected<0?0:selected)))return true;
 if(selected==modules::Velocity)return draftVelocity!=features::velocity::Options();
 if(selected==modules::AimAssist)return draftAimAssist!=features::aimassist::Options();
 if(const int extra=ExtraIndex(selected);extra>=0)return draftExtras[extra]!=features::extras::Options(static_cast<features::extras::Kind>(extra));
 if(selected==modules::AutoDisconnect)return draftDisconnect!=features::disconnect::Options();
 if(selected==modules::NoJumpCooldown)return draftNoJump!=features::nojump::Options();
 if(selected==modules::SpotifyWidget)return draftSpotify!=features::spotify::Options();
 if(selected==modules::InventoryHud)return draftInventoryHud!=features::inventory_hud::Options();
 if(selected==modules::TargetHud)return draftTargetHud!=features::targethud::Options();
 if(selected==modules::Cosmetics)return draftCosmetics!=features::cosmetics::Options();
 if(selected==modules::FreeCam)return draftFreeCam!=features::freecam::Options();
 if(selected==modules::Mcf)return draftMcf!=modules::Enabled(modules::Mcf);
 if(selected==modules::PacketLogger)return draftPacketLogger!=modules::Enabled(modules::PacketLogger);
 if(selected==modules::Scaffold)return draftScaffold!=features::scaffold::Options();
 if(selected==modules::Ambiance)return draftAmbiance!=features::ambiance::Options();
 if(selected==modules::SeedDumper)return draftSeedDumper!=features::seeddumper::Options();
 if(selected==modules::Xray)return draftXray!=features::xray::Options();
 if(selected==modules::AutoMiner)return draftAutoMiner!=features::autominer::Options();
 if(selected==modules::NoRotate)return draftNoRotate!=features::norotate::Options();
 if(selected==modules::Hud)return draftHud!=modules::Enabled(modules::Hud)||draftNotifications!=notifications::State().Enabled();
 if(selected==modules::DragonWings){const auto& s=features::wings::Options();return draftWings.enabled!=s.enabled||draftWings.scale!=s.scale||draftWings.color!=s.color;}
 if(selected==modules::ItemEsp){
  const auto& s=features::item_esp::Options();
  return draftItemEsp.enabled!=s.enabled || draftItemEsp.box!=s.box || draftItemEsp.boxPostprocess!=s.boxPostprocess ||
   draftItemEsp.minecraftFont!=s.minecraftFont || draftItemEsp.nametags!=s.nametags || draftItemEsp.formattedTags!=s.formattedTags ||
   draftItemEsp.tagPostprocess!=s.tagPostprocess || draftItemEsp.tagBackground!=s.tagBackground || draftItemEsp.redBackground!=s.redBackground ||
   draftItemEsp.roundedTags!=s.roundedTags || draftItemEsp.customColor!=s.customColor || draftItemEsp.rainbow!=s.rainbow ||
   draftItemEsp.tagScale!=s.tagScale || draftItemEsp.color!=s.color || draftItemEsp.alternate!=s.alternate;
 }
 const auto& s=features::esp::Options();
 // Compare named members; never compare struct padding.
 return
 draft.enabled!=s.enabled || draft.players!=s.players || draft.invisibles!=s.invisibles || draft.animals!=s.animals || draft.mobs!=s.mobs || draft.box!=s.box || draft.boxPostprocess!=s.boxPostprocess ||
 draft.minecraftFont!=s.minecraftFont || draft.heldItem!=s.heldItem || draft.equipment!=s.equipment || draft.healthBar!=s.healthBar || draft.healthText!=s.healthText || draft.healthByValue!=s.healthByValue ||
 draft.nametags!=s.nametags || draft.redTags!=s.redTags || draft.formattedTags!=s.formattedTags || draft.tagPostprocess!=s.tagPostprocess || draft.tagHealth!=s.tagHealth || draft.tagBackground!=s.tagBackground ||
 draft.redBackground!=s.redBackground || draft.roundedTags!=s.roundedTags || draft.customColor!=s.customColor || draft.rainbow!=s.rainbow || draft.tagScale!=s.tagScale || draft.color!=s.color || draft.alternate!=s.alternate || draft.friends!=s.friends;
}
void OpenSettings(int module) { for(int i=0;i<static_cast<int>(features::extras::Kind::Count);++i)draftExtras[i]=features::extras::Options(static_cast<features::extras::Kind>(i));selected=module;draftMcf=modules::Enabled(modules::Mcf);draftPacketLogger=modules::Enabled(modules::PacketLogger);draftSeedDumper=features::seeddumper::Options();draftXray=features::xray::Options();draftAutoMiner=features::autominer::Options();draftVelocity=features::velocity::Options();draftAimAssist=features::aimassist::Options();draftNoRotate=features::norotate::Options();draftDisconnect=features::disconnect::Options();draftNoJump=features::nojump::Options();draftSpotify=features::spotify::Options();draftInventoryHud=features::inventory_hud::Options();draftTargetHud=features::targethud::Options();draftCosmetics=features::cosmetics::Options();draftFreeCam=features::freecam::Options();draftAmbiance=features::ambiance::Options();draftScaffold=features::scaffold::Options();draftItemEsp=features::item_esp::Options();draft=features::esp::Options();draftWings=features::wings::Options();draftHud=modules::Enabled(modules::Hud);draftNotifications=notifications::State().Enabled();draftBindings=bindings::Options(static_cast<modules::Id>(module));tab=0;binding=0;confirmUntil=0;settingsScroll={};ResetOptionControls();settingsFade.Reset();settingsFresh=true; }
bool CloseSettings() {
 if(ControlOverlayOpen()) {CloseControlOverlays();return true;}
 if(selected<0)return false;
 if(Dirty() && ImGui::GetTime()>confirmUntil) {confirmUntil=ImGui::GetTime()+3;return true;}
 selected=-1;binding=0;return true;
}
void Switch(const Canvas& c,const char* name,bool& value,float y) {
 static std::unordered_map<std::string,OptionSpring> switches;
 c.Text(name,32,y+8,14);
 const std::string id=std::string("##switch")+name;
 if(c.Button(id.c_str(),32,y-4,536,38))value=!value;
 const float amount=std::clamp(switches.try_emplace(id,value?1.:0.).first->second.Update(value?1:0,ImGui::GetIO().DeltaTime,430,30),0.f,1.f);
 c.Rect(516,y+1,52,28,Blend(border,ink,amount),14);c.Rect(522+24*amount,y+7,16,16,background,8);
}
struct OptionRow {std::function<void(const Canvas&,float)> draw;};
std::vector<OptionRow> OptionRows(int module) {
 std::vector<OptionRow> result;
 auto add=[&](int kind,std::function<void(const Canvas&,float)> draw){if(tab==5||tab==kind)result.push_back({std::move(draw)});};
 auto boolean=[&](const char* label,bool& value){add(0,[label,&value](const Canvas& c,float y){Switch(c,label,value,y);});};
 auto number=[&](const char* label,float& value,float lo,float hi,float step){add(2,[=,&value](const Canvas& c,float y){Slider(c,label,value,lo,hi,step,y);});};
 auto range=[&](const char* label,float& first,float& second,float lo,float hi,float step){add(2,[=,&first,&second](const Canvas& c,float y){RangeSlider(c,label,first,second,lo,hi,step,y);});};
 auto choice=[&]<class E,std::size_t N>(const char* label,E& value,const char* const(&names)[N]){add(1,[label,&value,&names](const Canvas& c,float y){Dropdown(c,label,value,names,y);});};
 auto pair=[&](const char* label,bool& value,const char* first,const char* second){add(1,[=,&value](const Canvas& c,float y){Dropdown(c,label,value,first,second,y);});};
 auto files=[&](const char* label,std::string& value,std::function<std::vector<std::string>()> choices){add(1,[label,&value,choices=std::move(choices)](const Canvas& c,float y){auto names=choices();int selectedFile=0;std::vector<const char*> labels;labels.reserve(names.size());for(std::size_t i=0;i<names.size();++i){labels.push_back(names[i].c_str());if(names[i]==value)selectedFile=static_cast<int>(i);}Dropdown(c,label,&value,selectedFile,labels,[&value,names=std::move(names)](int index){value=index>0&&index<static_cast<int>(names.size())?names[index]:"";},y);});};
 auto color=[&](const char* label,ImU32& value){add(3,[label,&value](const Canvas& c,float y){ColorOption(c,label,value,y);});};
 auto text=[&](const char* label,std::string& value){add(4,[label,&value](const Canvas& c,float y){TextOption(c,label,value,y);});};
 auto key=[&](const char* label,int field,int& value){add(0,[=,&value](const Canvas& c,float y){
  c.Text(label,32,y,14);c.Text("Click to change the key.",32,y+19,13,muted);ImGui::PushID(field);
  if(c.Button("binding",32,y-4,536,38))binding=field;
  if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(2)){value=0;binding=0;}
  c.Rect(492,y,76,30,binding==field?palette::hoveredSurface:secondary,8);
  auto name=binding==field?std::string("..."):bindings::KeyName(value);
  while(name.size()>3&&c.Measure(name,13,FontWeight::Medium).x>64*c.scale)name.pop_back();
  c.Center(name.c_str(),492,y+9,76,13);ImGui::PopID();
 });};
 const int extraIndex=ExtraIndex(module);
 bool* enabled=module==modules::Mcf?&draftMcf:module==modules::PacketLogger?&draftPacketLogger:extraIndex>=0?&draftExtras[extraIndex].enabled:module==modules::AimAssist?&draftAimAssist.enabled:module==modules::Velocity?&draftVelocity.enabled:module==modules::NoRotate?&draftNoRotate.enabled:module==modules::AutoDisconnect?&draftDisconnect.enabled:module==modules::NoJumpCooldown?&draftNoJump.enabled:module==modules::SpotifyWidget?&draftSpotify.enabled:module==modules::InventoryHud?&draftInventoryHud.enabled:module==modules::TargetHud?&draftTargetHud.enabled:module==modules::Cosmetics?&draftCosmetics.enabled:module==modules::SeedDumper?&draftSeedDumper.enabled:module==modules::FreeCam?&draftFreeCam.enabled:module==modules::Scaffold?&draftScaffold.enabled:module==modules::Ambiance?&draftAmbiance.enabled:module==modules::ItemEsp?&draftItemEsp.enabled:module==modules::Hud?&draftHud:
  module==modules::DragonWings?&draftWings.enabled:module==modules::Xray?&draftXray.enabled:module==modules::AutoMiner?&draftAutoMiner.enabled:&draft.enabled;
 boolean("Enabled",*enabled);key("Keybind",1,draftBindings.module.key);
 boolean("Keybind Hold",draftBindings.module.hold);
 if(bindings::SupportsAction(static_cast<modules::Id>(module))){key("Action Key",2,draftBindings.action.key);boolean("Action Hold",draftBindings.action.hold);}
 if(extraIndex>=0) {
  auto& s=draftExtras[extraIndex];
  if(module==modules::FastUse)number("Speed",s.speed,1,24,1);
  else if(module==modules::Spammer){text("Message",s.message);number("Delay",s.delay,0,20000,1);}
  else if(module==modules::AutoClicker){number("CPS",s.cps,1,20,1);boolean("Right Click",s.right);boolean("Left Click",s.left);boolean("Break Blocks",s.breakBlocks);boolean("Disable on UI",s.disableOnUi);}
  else if(module==modules::Aimbot){number("Range",s.range,1,6,.1f);number("FOV",s.fov,1,180,1);boolean("Visible Only",s.visibleOnly);boolean("Limit Items",s.limitItems);boolean("Player",s.players);boolean("Invisibles",s.invisibles);boolean("Animals",s.animals);boolean("Mobs",s.mobs);boolean("Player Teammates",s.teammates);}
  else if(module==modules::AimBacktrack){range("Latency",s.delay,s.history,0,500,5);boolean("Render Server Position",s.bedBox);if(s.bedBox)color("Color",s.outlineColor);}
  else if(module==modules::Eagle){number("Edge Speed %",s.speed,20,100,5);boolean("Only Block",s.blocksOnly);}
  else if(module==modules::NoFall){static const char* modes[]={"MLG","SpoofGround"};choice("Mode",s.mode,modes);}
  else if(module==modules::FakeLag){static const char* modes[]={"Latency","Dynamic","Repel"};choice("Mode",s.mode,modes);number("Delay",s.delay,1,1000,10);if(s.mode==1)number("Transmission Offset",s.history,0,50,1);}
 } else if(module==modules::AimAssist) {
  static const char* modes[]={"Simple","Adaptive"};static const char* priorities[]={"Yaw","Distance","Armor","Threat","Health"};static const char* areas[]={"Center","Closest"};
  choice("Mode",draftAimAssist.mode,modes);choice("Target Priority",draftAimAssist.targetMode,priorities);choice("Target Area",draftAimAssist.targetArea,areas);
  number("Horizontal Speed",draftAimAssist.horizontalSpeed,1,10,.5f);if(draftAimAssist.aimVertically)number("Vertical Speed",draftAimAssist.verticalSpeed,1,10,.5f);number("Max Angle",draftAimAssist.maxAngle,1,360,1);number("Distance",draftAimAssist.distance,1,8,.1f);
  boolean("Require Mouse Down",draftAimAssist.requireMouseDown);boolean("Aim Vertically",draftAimAssist.aimVertically);boolean("Strafe Increase",draftAimAssist.strafeIncrease);boolean("Check Block Break",draftAimAssist.checkBlockBreak);boolean("Limit To Swords",draftAimAssist.limitItems);boolean("Visible Only",draftAimAssist.visibleOnly);boolean("Players",draftAimAssist.players);boolean("Invisibles",draftAimAssist.invisibles);boolean("Animals",draftAimAssist.animals);boolean("Mobs",draftAimAssist.mobs);boolean("Player Teammates",draftAimAssist.teammates);
 } else if(module==modules::AutoDisconnect) {
  boolean("Low Health",draftDisconnect.lowHealth);if(draftDisconnect.lowHealth){number("Health",draftDisconnect.health,1,20,1);boolean("Count Absorption",draftDisconnect.countAbsorption);}
 } else if(module==modules::NoRotate) {
  static const char* modes[]={"Cancel","Edit"};choice("Mode",draftNoRotate.mode,modes);
 } else if(module==modules::Velocity) {
  number("Horizontal %",draftVelocity.horizontal,0,100,1);number("Vertical %",draftVelocity.vertical,0,100,1);number("Chance %",draftVelocity.chance,0,100,1);number("Ticks",draftVelocity.ticks,0,10,1);boolean("Only When Targeting",draftVelocity.onlyWhenTargeting);boolean("Water Check",draftVelocity.waterCheck);boolean("Explosions",draftVelocity.explosions);
 } else if(module==modules::Cosmetics) {
  static const char* models[]={"Original","Classic","Slim"};choice("Player Model",draftCosmetics.model,models);files("Skin PNG",draftCosmetics.skin,features::cosmetics::SkinChoices);files("Cape PNG / GIF",draftCosmetics.cape,features::cosmetics::CapeChoices);
 } else if(module==modules::SeedDumper) {
  add(0,[](const Canvas& c,float y){const auto status=features::seeddumper::CurrentStatus();c.Text(status.message.c_str(),32,y,13,muted);const auto count=std::string("Saved snapshots: ")+std::to_string(status.saved);c.Text(count.c_str(),32,y+19,13,muted);});
  add(0,[](const Canvas& c,float y){c.Text("Only loaded chunks are recorded. Ores may be obfuscated.",32,y,12,muted);c.Text("Output: .sonoyuncu/commonLuke/seed-dumps (APPDATA)",32,y+19,12,muted);});
 } else if(module==modules::FreeCam) {
  number("Speed",draftFreeCam.speed,.1f,5.f,.1f);
 } else if(module==modules::Scaffold) {
  static const char* mode[]={"Normal","Telly"};
  static const char* rayCast[]={"Off","Normal","Strict"};
  static const char* sameY[]={"Off","On","Auto Jump"};
  choice("Mode",draftScaffold.mode,mode);
  choice("Ray Cast",draftScaffold.rayCast,rayCast);
  choice("Same Y",draftScaffold.sameY,sameY);
  range("Rotation Speed",draftScaffold.rotationMin,draftScaffold.rotationMax,0,10,1);
  range("Place Delay",draftScaffold.delayMin,draftScaffold.delayMax,0,5,1);
  number("Expand",draftScaffold.expand,0,4,1);
  boolean("Safe Walk",draftScaffold.safeWalk);
  boolean("Movement Correction",draftScaffold.movementCorrection);
 } else if(module==modules::Ambiance) {
  boolean("Lyrics",draftAmbiance.lyrics);
  if(draftAmbiance.lyrics)boolean("3D Lyrics",draftAmbiance.lyrics3d);
  if(draftAmbiance.lyrics&&draftAmbiance.lyrics3d){
   color("Lyrics Color",draftAmbiance.lyrics3dColor.color);
   number("Brightness",draftAmbiance.lyrics3dColor.brightness,0,2,.05f);
   number("Glow",draftAmbiance.lyrics3dColor.glow,0,2,.05f);
   number("Distance",draftAmbiance.lyrics3dColor.distance,4,30,1);
   number("H Offset",draftAmbiance.lyrics3dColor.hOffset,-15,15,1);
   number("V Offset",draftAmbiance.lyrics3dColor.vOffset,-4,25,1);
   number("Scale",draftAmbiance.lyrics3dColor.scale,0.4f,2.f,0.05f);
   boolean("Follow Player",draftAmbiance.lyrics3dColor.follow);
   boolean("Billboard",draftAmbiance.lyrics3dColor.billboard);
  }
  number("Lyrics Offset (ms)",draftAmbiance.offsetMs,-5000,5000,50);
 } else if(module==modules::ItemEsp) {
  boolean("Entity Glow",draftItemEsp.box);
  boolean("Nametags",draftItemEsp.nametags);
  if(draftItemEsp.nametags){
   boolean("Formatted Tags",draftItemEsp.formattedTags);
   boolean("Add PostProcessing",draftItemEsp.tagPostprocess);
   boolean("Background",draftItemEsp.tagBackground);
   boolean("Red Background",draftItemEsp.redBackground);
   boolean("Round",draftItemEsp.roundedTags);
  }
  pair("Glow Mode",draftItemEsp.customColor,"White","Custom");
  number("Tag Scale",draftItemEsp.tagScale,.35f,1.f,.05f);
  color("Glow Color",draftItemEsp.color);
  color("Secondary Glow",draftItemEsp.alternate);
  boolean("Rainbow",draftItemEsp.rainbow);
 } else if(module==modules::Xray) {
  boolean("Boxes",draftXray.boxes);boolean("Tracers",draftXray.tracers);boolean("Labels",draftXray.labels);
  number("Radius",draftXray.radius,8,40,1);number("Line Width",draftXray.lineWidth,.5f,4,.1f);
  boolean("Exposed Only",draftXray.filter.exposedOnly);number("Min Cluster",draftXray.filter.minCluster,1,6,1);boolean("Vanilla Y Range",draftXray.filter.yRange);
  boolean("Diamond",draftXray.ores.diamond);boolean("Emerald",draftXray.ores.emerald);boolean("Gold",draftXray.ores.gold);boolean("Iron",draftXray.ores.iron);boolean("Coal",draftXray.ores.coal);boolean("Lapis",draftXray.ores.lapis);boolean("Redstone",draftXray.ores.redstone);boolean("Quartz",draftXray.ores.quartz);boolean("Copper",draftXray.ores.copper);boolean("Titanium",draftXray.ores.titanium);
 } else if(module==modules::AutoMiner) {
  number("Range",draftAutoMiner.range,2,6,.1f);number("Scan Interval",draftAutoMiner.scanIntervalMs,50,1000,10);boolean("Rotate",draftAutoMiner.rotate);boolean("Swing",draftAutoMiner.swing);
  boolean("Navigate",draftAutoMiner.nav);if(draftAutoMiner.nav){number("Search Radius",draftAutoMiner.searchRadius,4,24,1);number("Move Speed",draftAutoMiner.moveSpeed,.05f,.5f,.01f);}
  boolean("Exposed Only",draftAutoMiner.filter.exposedOnly);number("Min Cluster",draftAutoMiner.filter.minCluster,1,6,1);boolean("Vanilla Y Range",draftAutoMiner.filter.yRange);
  boolean("Diamond",draftAutoMiner.ores.diamond);boolean("Emerald",draftAutoMiner.ores.emerald);boolean("Gold",draftAutoMiner.ores.gold);boolean("Iron",draftAutoMiner.ores.iron);boolean("Coal",draftAutoMiner.ores.coal);boolean("Lapis",draftAutoMiner.ores.lapis);boolean("Redstone",draftAutoMiner.ores.redstone);boolean("Quartz",draftAutoMiner.ores.quartz);boolean("Copper",draftAutoMiner.ores.copper);boolean("Titanium",draftAutoMiner.ores.titanium);
 } else if(module==modules::Esp) {
  boolean("Players",draft.players);boolean("Invisibles",draft.invisibles);boolean("Animals",draft.animals);boolean("Mobs",draft.mobs);boolean("Entity Glow",draft.box);
  boolean("Item Held Text",draft.heldItem);boolean("Equipment",draft.equipment);
  boolean("Health Bar",draft.healthBar);if(draft.healthBar)boolean("Health Bar Text",draft.healthText);boolean("Nametags",draft.nametags);
  if(draft.nametags){boolean("Red Tags",draft.redTags);boolean("Formatted Tags",draft.formattedTags);boolean("Add PostProcessing",draft.tagPostprocess);boolean("Health Text",draft.tagHealth);boolean("Background",draft.tagBackground);boolean("Red Background",draft.redBackground);boolean("Round",draft.roundedTags);}
  pair("Glow Mode",draft.customColor,"White","Custom");pair("Health Bar Mode",draft.healthByValue,"Color","Health");number("Tag Scale",draft.tagScale,.35f,1,.05f);
  color("Glow Color",draft.color);color("Secondary Glow",draft.alternate);boolean("Rainbow",draft.rainbow);text("Friends",draft.friends);
 } else if(module==modules::Hud)boolean("Bildirimler",draftNotifications);
 else if(module==modules::DragonWings){number("Scale",draftWings.scale,.75f,1.25f,.25f);color("Color",draftWings.color);}

 return result;
}
void DrawGlass(const Canvas& c,ImDrawList& blurMask,float width,float height,float radius) {
 const auto min=c.P(0,0),max=c.P(width,height);
 blurMask.AddRectFilled(min,max,c.Fade(IM_COL32_WHITE),radius*c.scale);
 c.Rect(0,0,width,height,glass,radius);
 if(const auto texture=BackgroundPattern()) {
  constexpr float imageAspect=3126.f/1885.f;
  const float panelAspect=width/height;
  const float cropX=(1.f-std::min(1.f,panelAspect/imageAspect))*.5f;
  const float cropY=(1.f-std::min(1.f,imageAspect/panelAspect))*.5f;
  c.draw->AddImageRounded(texture,min,max,{cropX,cropY},{1.f-cropX,1.f-cropY},
   c.Fade(IM_COL32(255,255,255,176)),radius*c.scale);
 }
}

void Settings(const FontManager& fonts,ImDrawList& blurMask) {
 if(selected>=0)presentedSettings=selected;
 const float target=selected>=0?1.f:0.f;
 settingsOpacity=settingsFade.Update(target,ImGui::GetTime());
 if(settingsOpacity<.01f && selected<0)return;
 const int module=presentedSettings;
 const auto display=ImGui::GetIO().DisplaySize;
 const float baseScale=std::min({1.f,(display.x-24)/600.f,(display.y-24)/617.f});
 const float scale=baseScale;
 if(settingsFresh){settingsPosition={(display.x-600*scale)/2,(display.y-617*scale)/2};settingsDragging=false;}
 if(settingsDragging&&ImGui::IsMouseDown(0))settingsPosition={ImGui::GetIO().MousePos.x-settingsDragOffset.x,ImGui::GetIO().MousePos.y-settingsDragOffset.y};
 else settingsDragging=false;
 settingsPosition.x=std::clamp(settingsPosition.x,4.f,std::max(4.f,display.x-600*scale-4));
 settingsPosition.y=std::clamp(settingsPosition.y,4.f,std::max(4.f,display.y-617*scale-4));
 ImGui::SetNextWindowSize({600*baseScale,617*baseScale},ImGuiCond_Always);
 ImGui::SetNextWindowPos(settingsPosition,ImGuiCond_Always);
 ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,12*scale);
 ImGui::PushStyleVar(ImGuiStyleVar_Alpha,ImGui::GetStyle().Alpha*settingsOpacity);
 ImGui::Begin("##DetachedModuleSettings",nullptr,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|(selected<0?ImGuiWindowFlags_NoInputs:0));
 const auto windowPosition=ImGui::GetWindowPos();
 const Canvas c{{windowPosition.x+300*(baseScale-scale),windowPosition.y+308.5f*(baseScale-scale)},scale,ImGui::GetWindowDrawList(),fonts,opacity*settingsOpacity,true};
 ImGui::PushStyleVar(ImGuiStyleVar_DisabledAlpha,1.f);ImGui::BeginDisabled(ControlOverlayOpen());
 for(float margin=0;margin<=9;margin+=.5f)c.Rect(-margin/2,-margin/2,600+margin,617+margin,
  IM_COL32(0,0,0,static_cast<int>(std::max(.5f,(28-margin*1.2f)/5.5f))),12);
 DrawGlass(c,blurMask,600,617,12);
 c.draw->AddRect(c.P(0,0),c.P(600,617),c.Fade(border),12*scale);
 const std::string title=std::string(modules::Catalog[module].name)+" Settings";
 c.Text(title.c_str(),32,32,24,ink,FontWeight::Medium);
 if(c.Button("closeSettings",536,32,32,32))CloseSettings();
 if(ImGui::IsItemHovered())c.Rect(536,32,32,32,overlay,8);
 constexpr float arm=5.656854249f;
 c.draw->AddLine(c.P(552-arm,48-arm),c.P(552+arm,48+arm),c.Fade(ink),2*scale);
 c.draw->AddLine(c.P(552-arm,48+arm),c.P(552+arm,48-arm),c.Fade(ink),2*scale);
 c.Button("dragSettings",32,20,488,54);
 if(ImGui::IsItemActivated()){settingsDragging=true;settingsDragOffset={ImGui::GetIO().MousePos.x-settingsPosition.x,ImGui::GetIO().MousePos.y-settingsPosition.y};}
 const char* tabs[]={"General","Modes","Values","Colors","Text","All"};
 const float widths[]={118,74,89,81,67,107};float x=32;
 static OptionSpring tabWidth[6],tabHeight[6],tabPush[6];
 if(settingsFresh){for(int i=0;i<6;++i){tabWidth[i].Reset(tab==i?1.08:.96);tabHeight[i].Reset(tab==i?1.04:.96);tabPush[i].Reset(0);}settingsFresh=false;}
 for(int i=0;i<6;++i) {
  const float dt=ImGui::GetIO().DeltaTime;
  const float w=(widths[i]-4)*tabWidth[i].Update(tab==i?1.08f:.96f,dt,580,19);
  const float h=32*tabHeight[i].Update(tab==i?1.04f:.96f,dt,450,18);
  const float push=tabPush[i].Update(tab==i?0.f:(i<tab?-5.f:5.f),dt,580,20);
  const float left=x+widths[i]*.5f+push-w*.5f;
  ImGui::PushID(i);if(c.Button("tab",x,87,widths[i],36)) {tab=i;settingsScroll={};CloseControlOverlays();}
  c.Rect(left,105-h*.5f,w,h,tab==i?palette::hoveredSurface:secondary,9);
  c.Center(tabs[i],x+push,99,widths[i],14);ImGui::PopID();x+=widths[i];
 }
 const auto options=OptionRows(module);
 const bool secondSection=(tab==0||tab==5)&&options.size()>2;
 auto rowTop=[&](std::size_t index){return secondSection&&index>=2?368.f+static_cast<float>(index-2)*55:198.f+static_cast<float>(index)*55;};
 const float contentBottom=options.empty()?198:rowTop(options.size()-1)+32;
 settingsScroll.maximum=std::max(0.f,contentBottom-521);
 if(!ControlOverlayOpen() && ImGui::IsMouseHoveringRect(c.P(32,153),c.P(568,522))){settingsScroll.target-=ImGui::GetIO().MouseWheel*48;if(ImGui::GetIO().MouseWheel!=0)confirmUntil=0;}
 settingsScroll.Step(c,152,371,false);
 ImGui::SetCursorScreenPos(c.P(32,152));ImGui::SetNextWindowScroll({0,settingsScroll.value*scale});
 ImGui::BeginChild("settingsScroll",{536*scale,371*scale},ImGuiChildFlags_None,ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse);
 const Canvas rows{{c.P(0,152).x,c.P(0,152).y-ImGui::GetScrollY()},scale,ImGui::GetWindowDrawList(),fonts,c.alpha,true};
 rows.Text(tab==0||tab==5?"General":tabs[tab],32,8,16);
 if(options.empty())rows.Text("No settings in this section.",32,46,14,muted);
 for(std::size_t i=0;i<options.size();++i){
  if(i==2&&secondSection){rows.Rect(32,155,532,1,border);rows.Text(tab==0?"Options":"Module options",32,180,16);}
  options[i].draw(rows,rowTop(i)-152);
 }
 if(binding&&input::PressedKey()){
  auto& key=binding==1?draftBindings.module.key:draftBindings.action.key;
  if(input::PressedKey()==VK_ESCAPE){key=0;binding=0;}else if(bindings::Bindable(input::PressedKey())){key=input::PressedKey();binding=0;}
 }
 const float bottom=options.empty()?198:rowTop(options.size()-1)+32;
 ImGui::SetCursorScreenPos(rows.P(32,bottom-152));ImGui::Dummy({1,1});ImGui::EndChild();
 settingsScroll.maximum=std::max(0.f,bottom-521);
 settingsScroll.Bar(c,"settingsScrollbar",584,164,347,28);
 if(confirmUntil>ImGui::GetTime()) {c.Rect(32,525,536,19,overlay,6);c.Text("Unsaved changes. Close again within 3s to discard.",40,529,12);}
 if(c.Button("cancel",388,548,88,36))CloseSettings();
 const bool cancelHover=ImGui::IsItemHovered();
 c.Rect(388,548,88,36,border,8);c.Rect(389,549,86,34,cancelHover?secondary:background,7);c.Center("Cancel",388,560,88,14);
 if(c.Button("save",492,548,76,36)) {
  if(module==modules::Velocity)features::velocity::SetOptions(draftVelocity);
  else if(module==modules::AimAssist)features::aimassist::SetOptions(draftAimAssist);
  else if(module==modules::NoRotate)features::norotate::SetOptions(draftNoRotate);
   else if(const int extra=ExtraIndex(module);extra>=0)features::extras::SetOptions(static_cast<features::extras::Kind>(extra),draftExtras[extra]);
  else if(module==modules::AutoDisconnect)features::disconnect::SetOptions(draftDisconnect);
  else if(module==modules::NoJumpCooldown)features::nojump::SetOptions(draftNoJump);
  else if(module==modules::SpotifyWidget)features::spotify::SetOptions(draftSpotify);
  else if(module==modules::InventoryHud)features::inventory_hud::SetOptions(draftInventoryHud);
  else if(module==modules::TargetHud)features::targethud::SetOptions(draftTargetHud);
  else if(module==modules::Cosmetics)features::cosmetics::SetOptions(draftCosmetics);
  else if(module==modules::SeedDumper)features::seeddumper::SetOptions(draftSeedDumper);
  else if(module==modules::Hud){notifications::State().SetEnabled(draftNotifications);modules::SetEnabled(modules::Hud,draftHud);}
  else if(module==modules::DragonWings)features::wings::SetOptions(draftWings);
  else if(module==modules::ItemEsp)features::item_esp::SetOptions(draftItemEsp);
  else if(module==modules::FreeCam)features::freecam::SetOptions(draftFreeCam);
  else if(module==modules::Mcf)modules::SetEnabled(modules::Mcf,draftMcf);
  else if(module==modules::PacketLogger)modules::SetEnabled(modules::PacketLogger,draftPacketLogger);
  else if(module==modules::Scaffold)features::scaffold::SetOptions(draftScaffold);
  else if(module==modules::Xray)features::xray::SetOptions(draftXray);
  else if(module==modules::AutoMiner)features::autominer::SetOptions(draftAutoMiner);
  else if(module==modules::Ambiance)features::ambiance::SetOptions(draftAmbiance);
  else features::esp::SetOptions(draft);
  bindings::SetOptions(static_cast<modules::Id>(module),draftBindings);selected=-1;binding=0;CloseControlOverlays();
 }
 c.Rect(492,548,76,36,ImGui::IsItemHovered()?IM_COL32(199,199,205,255):ink,8);c.Center("Save",492,560,76,14,background);
 ImGui::EndDisabled();ImGui::PopStyleVar();DrawControlOverlays(c);
 ImGui::End();ImGui::PopStyleVar(3);
}
}
bool HudEnabled() { return modules::Enabled(modules::Hud); }
void OpenModuleSettings(int module) { if(modules::Available(static_cast<modules::Id>(module))) OpenSettings(module); }
void OpenConfigs() {selected=-1;category=7;}
bool RequestClose() {
 if(binding) { (binding==1?draftBindings.module.key:draftBindings.action.key)=0;binding=0;return true; }
 return CloseSettings();
}
void Draw(const FontManager& fonts,ImDrawList& blurMask) {
 const bool open=input::IsOpen();
 static bool previouslyOpen=false;
 if(!previouslyOpen&&open)cardReveal=0;
 if(previouslyOpen && !open) {selected=-1;binding=0;}
 previouslyOpen=open;
 opacity+=(static_cast<float>(open)-opacity)*std::min(1.f,ImGui::GetIO().DeltaTime*14.f);
 if(opacity<.01f)return;
 auto& style=ImGui::GetStyle();style.WindowBorderSize=0;style.FrameRounding=7;style.PopupRounding=8;style.ScrollbarSize=3;
 style.Colors[ImGuiCol_WindowBg]=ImGui::ColorConvertU32ToFloat4(background);style.Colors[ImGuiCol_PopupBg]=ImGui::ColorConvertU32ToFloat4(secondary);
 style.Colors[ImGuiCol_Text]=ImGui::ColorConvertU32ToFloat4(ink);style.Colors[ImGuiCol_FrameBg]=ImGui::ColorConvertU32ToFloat4(secondary);
 style.Colors[ImGuiCol_FrameBgHovered]=ImGui::ColorConvertU32ToFloat4(overlay);style.Colors[ImGuiCol_CheckboxSelectedBg]=ImGui::ColorConvertU32ToFloat4(overlay);
 style.Colors[ImGuiCol_Button]=ImGui::ColorConvertU32ToFloat4(secondary);style.Colors[ImGuiCol_ButtonHovered]=ImGui::ColorConvertU32ToFloat4(overlay);style.Colors[ImGuiCol_ButtonActive]=ImGui::ColorConvertU32ToFloat4(border);style.Colors[ImGuiCol_CheckMark]=ImGui::ColorConvertU32ToFloat4(ink);
 style.Colors[ImGuiCol_HeaderHovered]=ImGui::ColorConvertU32ToFloat4(overlay);style.Colors[ImGuiCol_Header]=ImGui::ColorConvertU32ToFloat4(border);
 style.Colors[ImGuiCol_SliderGrab]=ImGui::ColorConvertU32ToFloat4(muted);style.Colors[ImGuiCol_SliderGrabActive]=ImGui::ColorConvertU32ToFloat4(ink);
 style.Colors[ImGuiCol_FrameBgActive]=ImGui::ColorConvertU32ToFloat4(overlay);style.Colors[ImGuiCol_HeaderActive]=ImGui::ColorConvertU32ToFloat4(border);style.Colors[ImGuiCol_TextSelectedBg]={1,1,1,.22f};style.Colors[ImGuiCol_ScrollbarBg]={0,0,0,0};style.Colors[ImGuiCol_ScrollbarGrab]={1,1,1,.3f};style.Colors[ImGuiCol_Border]=ImGui::ColorConvertU32ToFloat4(border);
 ImGui::PushStyleVar(ImGuiStyleVar_Alpha,opacity);ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::PushFont(fonts.Get(),14.f);
 constexpr float headerSpace=headerHeight+headerGap,windowHeight=bodyHeight+headerSpace;
 const auto display=ImGui::GetIO().DisplaySize;const float scale=std::min({2.f,(display.x-32)/400.f,(display.y-32)/windowHeight});
 ImGui::SetNextWindowSize({400*scale,windowHeight*scale},ImGuiCond_Always);ImGui::SetNextWindowPos({display.x*.5f,display.y*.5f},ImGuiCond_FirstUseEver,{.5f,.5f});
 const auto flags=ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoScrollbar|
  ImGuiWindowFlags_NoScrollWithMouse|((!open||selected>=0)?ImGuiWindowFlags_NoInputs:0);
 ImGui::Begin("##HarakiriClickGUI",nullptr,flags);
 const auto windowPosition=ImGui::GetWindowPos();
 const float zoom=.90f+.10f*opacity;
 const Canvas header{{windowPosition.x+200*scale*(1-zoom),windowPosition.y+windowHeight*.5f*scale*(1-zoom)},scale*zoom,ImGui::GetWindowDrawList(),fonts,opacity};
 const Canvas c{header.P(0,headerSpace),header.scale,header.draw,fonts,opacity};
 const Canvas content{c.P(contentX,0),c.scale,c.draw,c.fonts,c.alpha};
 constexpr float contentRadius=headerGap*1.5f;
 DrawGlass(content,blurMask,contentWidth,bodyHeight,contentRadius);
 content.draw->AddRect(content.P(0,0),content.P(contentWidth,bodyHeight),content.Fade(border),contentRadius*c.scale);
 if(selected<0&&category!=0&&ImGui::GetIO().InputQueueCharacters.Size&&!ImGui::IsAnyItemActive())category=0;
 constexpr float toolbarInset=sidebarWidth;
 constexpr float toolbarWidth=contentWidth-2.f*toolbarInset;
 const Canvas toolbar{header.P(contentX+toolbarInset,0),header.scale,header.draw,header.fonts,header.alpha};
 WelcomeHeader(toolbar,blurMask,toolbarWidth);
 constexpr const char* categories[]={"Search","Combat","Movement","Player","Render","Exploit","Ghost","Configs"};
 constexpr ImWchar icons[]={0xeb1c,0xf132,0xec82,0xef68,0xea9a,0xea38,0xeb8e,0xf910};
 constexpr int categoryCount=static_cast<int>(std::size(categories));
 constexpr float sidebarHeight=categoryCount*sidebarWidth;
 constexpr float sidebarTop=(bodyHeight-sidebarHeight)*.5f;
 constexpr float sidebarRadius=sidebarWidth*.5f;
 constexpr float buttonSize=sidebarWidth-headerGap*2.f;
 const Canvas sidebar{c.P(0,sidebarTop),c.scale,c.draw,c.fonts,c.alpha};
 blurMask.AddRectFilled(sidebar.P(0,0),sidebar.P(sidebarWidth,sidebarHeight),sidebar.Fade(IM_COL32_WHITE),sidebarRadius*c.scale);
 sidebar.Rect(0,0,sidebarWidth,sidebarHeight,glass,sidebarRadius);
 sidebar.draw->AddRect(sidebar.P(0,0),sidebar.P(sidebarWidth,sidebarHeight),sidebar.Fade(border),sidebarRadius*c.scale);
 static float selection[categoryCount]{};
 for(int i=0;i<categoryCount;++i) {
  const float y=sidebarWidth*i;
  const float desired=category==i?1.f:0.f;
  selection[i]+=(desired-selection[i])*std::min(1.f,ImGui::GetIO().DeltaTime*12.f);
  if(sidebar.Button(categories[i],0,y,sidebarWidth,sidebarWidth))category=i;
  const float highlight=std::max(selection[i],ImGui::IsItemHovered()?.45f:0.f);
  sidebar.Rect(headerGap,y+headerGap,buttonSize,buttonSize,IM_COL32(255,255,255,static_cast<int>(highlight*38)),buttonSize*.5f);
  sidebar.RowIcon(icons[i],sidebarRadius,y+sidebarRadius,buttonSize*.62f);
 }
 if(renderedCategory!=category) {renderedCategory=category;cardReveal=0;if(category==7)RefreshConfigs();}
 cardReveal=std::min(1.f,cardReveal+ImGui::GetIO().DeltaTime/.16f);
 const float visible=1.f-(1.f-cardReveal)*(1.f-cardReveal);
 constexpr int columns=3;
 constexpr float gridPadding=headerGap*2.f,cardGap=headerGap;
 constexpr float scrollbarX=headerWidth-headerGap;
 constexpr float gridLeft=contentX+gridPadding,gridRight=scrollbarX-headerGap;
 constexpr float gridHeight=bodyHeight-gridPadding*2.f;
 constexpr float cardWidth=(gridRight-gridLeft-(columns-1)*cardGap)/columns;
 constexpr float cardHeight=50.f,rowPitch=cardHeight+cardGap;
 mainScroll.Step(c,gridPadding,gridHeight);
 const bool render=category==0||std::any_of(modules::Catalog.begin(),modules::Catalog.end(),[](const auto& info){return modules::Available(info.id)&&info.category==category;});
 if(category==7)ConfigPage(c,visible);
 else if(render) {
  std::string query=search;std::transform(query.begin(),query.end(),query.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
  int index=0;
  ImGui::PushClipRect(c.P(gridLeft,gridPadding),c.P(gridRight,gridPadding+gridHeight),true);
  auto order=modules::Catalog;
  std::sort(order.begin(),order.end(),[](const auto& a,const auto& b){return std::strcmp(a.name,b.name)<0;});
  for(const auto& info:order) {
   const auto module=info.id;
   if(!modules::Available(module)||(category!=0&&info.category!=category))continue;
   const char* name=info.name;const char* description=info.description;
   std::string test=std::string(name)+" "+description;std::transform(test.begin(),test.end(),test.begin(),[](unsigned char ch){return static_cast<char>(std::tolower(ch));});
   if(category==0 && !query.empty() && test.find(query)==std::string::npos)continue;
   const float x=gridLeft+(index%columns)*(cardWidth+cardGap);
   const float y=gridPadding+(index/columns)*rowPitch-mainScroll.value;
   ++index;
   if(y+cardHeight<=gridPadding||y>=gridPadding+gridHeight)continue;
   ImGui::PushID(module);c.Button("card",x,y,cardWidth,cardHeight);
   const bool hover=ImGui::IsItemHovered();const bool enabled=modules::Enabled(module);
   static Spring hoverAmount[modules::Count];
   const float highlight=hoverAmount[module].Update(hover?1.f:0.f,ImGui::GetIO().DeltaTime,450,32);
   const float cardZoom=.7f+.3f*visible;
   const Canvas card{c.P(x+cardWidth*.5f*(1-cardZoom),y+cardHeight*.5f*(1-cardZoom)),c.scale*cardZoom,c.draw,fonts,c.alpha*visible};
   card.Rect(0,0,cardWidth,cardHeight,Blend(overlay,palette::hoveredSurface,highlight),contentRadius);
   card.Text(name,10,7,9,enabled?ink:muted,FontWeight::SemiBold);
   Toggle(card,info.name,cardWidth-32,6,22,12,enabled);
   card.Text(info.firstLine,10,24,6,muted);
   card.Text(info.secondLine,10,35,6,muted);
   for(int dot=0;dot<3;++dot)card.Rect(cardWidth-20.f+dot*4.f,39,2,2,muted,1);
   const bool dots=ImGui::IsMouseHoveringRect(c.P(x+cardWidth-24,y+30),c.P(x+cardWidth-6,y+47));
   if(visible>.5f && hover && ImGui::IsMouseClicked(0)) {
    if(dots)OpenSettings(module);
    else modules::Toggle(module);
   }
   if(visible>.5f && hover && ImGui::IsMouseClicked(1))OpenSettings(module);
   if(selected<0&&hover&&ImGui::IsMouseClicked(2)){auto config=bindings::Options(module);config.module.key=0;bindings::SetOptions(module,config);}
   ImGui::PopID();
  }
  ImGui::PopClipRect();
  const int rows=(index+columns-1)/columns;
  mainScroll.maximum=std::max(0.f,rows*rowPitch-cardGap-gridHeight);
  mainScroll.Bar(c,"moduleScrollbar",scrollbarX,gridPadding,gridHeight,22,headerGap*2.f);
 } else content.Center("No modules in this category",0,bodyHeight*.5f,contentWidth,9,muted);
 if(settingsOpacity>.01f) {
  const auto shade=IM_COL32(0,0,0,static_cast<int>(100*settingsOpacity));
  content.Rect(0,0,contentWidth,bodyHeight,shade,contentRadius);
  sidebar.Rect(0,0,sidebarWidth,sidebarHeight,shade,sidebarRadius);
 }
 ImGui::End();ImGui::PopStyleVar();Settings(fonts,blurMask);ImGui::PopFont();ImGui::PopStyleVar();
}
}

