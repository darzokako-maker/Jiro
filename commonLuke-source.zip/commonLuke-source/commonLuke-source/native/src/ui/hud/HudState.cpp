#include "ui/hud/HudState.hpp"
#include <mutex>
#include <chrono>
#include <atomic>
namespace client::ui {
namespace {
std::mutex mutex;
std::optional<HudPosition> current;
std::string playerName;
std::chrono::steady_clock::time_point updated;
std::atomic<bool> chatOpen{false};
std::atomic<bool> screenOpen{false};
}
void PublishHudPlayerName(std::string name) {
 std::lock_guard lock(mutex);
 playerName=std::move(name);
}
std::string GetHudPlayerName() {
 std::lock_guard lock(mutex);
 return playerName;
}
void SetChatOpen(bool open){chatOpen.store(open);}
bool IsChatOpen(){return chatOpen.load();}
void SetScreenOpen(bool open){screenOpen.store(open);}
bool IsScreenOpen(){return screenOpen.load();}
void PublishHudPosition(std::optional<HudPosition> position) {
 std::lock_guard lock(mutex);
 current=position; updated=std::chrono::steady_clock::now();
}
std::optional<HudPosition> GetHudPosition() {
 std::lock_guard lock(mutex);
 if(std::chrono::steady_clock::now()-updated>std::chrono::milliseconds(500)) return {};
 return current;
}
}
