#include "ui/hud/Notifications.hpp"
#include "ui/hud/HudLayout.hpp"
#include "ui/font/FontManager.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "render/Texture.hpp"
#include <algorithm>
#include <cmath>

namespace client::ui::notifications {
namespace {
Queue queue;
GLuint iconAtlas=0;
constexpr int IconSize=40,IconResolution=IconSize*4;
float Ease(float value){value=std::clamp(value,0.f,1.f);return 1-(1-value)*(1-value)*(1-value);}
ImU32 Fade(ImU32 color,float opacity){return (color&0xffffff)|(static_cast<ImU32>((color>>24)*std::clamp(opacity,0.f,1.f))<<24);}
float Height(const Toast& toast){return toast.message.find('\n')==std::string::npos?64.f:82.f;}
ImU32 Accent(Type type){return type==Type::Success?IM_COL32(0,223,128,255):type==Type::Info?IM_COL32(255,210,30,255):IM_COL32(240,66,72,255);}
float Capsule(float x,float y,float ax,float ay,float bx,float by,float radius) {
 const float dx=bx-ax,dy=by-ay;
 const float t=std::clamp(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0.f,1.f);
 return std::hypot(x-ax-t*dx,y-ay-t*dy)-radius;
}
float GlyphDistance(Type type,float x,float y) {
 const float circle=std::hypot(x,y);
 if(type==Type::Info)return std::min({std::abs(circle-9.1f)-.9f,
  std::hypot(x,y+4.2f)-1.1f,Capsule(x,y,0,-.8f,0,4.2f,1.f)});
 const float cutout=type==Type::Success?
  std::min(Capsule(x,y,-4,0,-1,3,.85f),Capsule(x,y,-1,3,4.5f,-3,.85f)):
  std::min(Capsule(x,y,-2.7f,-2.7f,2.7f,2.7f,.8f),Capsule(x,y,2.7f,-2.7f,-2.7f,2.7f,.8f));
 return std::max(circle-7.5f,-cutout);
}
GLuint CreateIconAtlas() {
 // Analytic distances produce a continuous one-screen-pixel coverage ramp.
 // Four texels per logical pixel retain that coverage at fractional positions;
 // round caps, joins and circles do not depend on polygon segment counts.
 constexpr int width=IconResolution*3;
 constexpr unsigned background[]={28,28,29};
 std::vector<unsigned char> pixels(width*IconResolution*4);
 for(int icon=0;icon<3;++icon) {
  const auto type=static_cast<Type>(icon);const auto accent=Accent(type);
  for(int row=0;row<IconResolution;++row)for(int col=0;col<IconResolution;++col) {
   const float x=(col+.5f)/4.f-IconSize*.5f,y=(row+.5f)/4.f-IconSize*.5f;
   const float disk=std::clamp(.5f-(std::hypot(x,y)-16),0.f,1.f);
   const float glyph=std::clamp(.5f-GlyphDistance(type,x,y),0.f,1.f);
   const auto index=(row*width+icon*IconResolution+col)*4;
   for(int channel=0;channel<3;++channel)pixels[index+channel]=static_cast<unsigned char>(
    std::lround(background[channel]*(1-glyph)+((accent>>(channel*8))&255)*glyph));
   pixels[index+3]=static_cast<unsigned char>(std::lround(disk*255));
  }
 }
 return render::UploadRgba(pixels,width,IconResolution);
}
void Icon(ImDrawList& list,Type type,ImVec2 center,float scale,float opacity) {
 if(!iconAtlas)return;
 const float half=IconSize*.5f*scale,u=static_cast<int>(type)/3.f;
 list.AddImage(static_cast<ImTextureID>(iconAtlas),{center.x-half,center.y-half},{center.x+half,center.y+half},
  {u,0},{u+1.f/3.f,1},Fade(IM_COL32_WHITE,opacity));
}
}
Queue& State(){return queue;}
void Queue::Push(Type type,std::string_view title,std::string_view message) {
 if(!enabled_)return;
 if(pending_.size()==MaxPending)pending_.pop_front();
 pending_.push_back({type,std::string(title),std::string(message)});
}
void Queue::Update(float dt,int capacity) {
 dt=std::isfinite(dt)?std::max(0.f,dt):0.f;
 for(auto& toast:active_)toast.age+=dt;
 std::erase_if(active_,[](const Toast& toast){return toast.age>=Lifetime;});
 capacity=std::clamp(capacity,1,static_cast<int>(MaxVisible));
 while(active_.size()<static_cast<std::size_t>(capacity)&&!pending_.empty()) {
  active_.push_back(std::move(pending_.front()));pending_.pop_front();
 }
}
void ModuleChanged(std::string_view name,bool enabled) {
 const std::string title=std::string(name)+(enabled?" açıldı":" kapatıldı");
 queue.Push(enabled?Type::Success:Type::Disabled,title,enabled?
  "Modül etkinleştirildi.\nAyarları menüden değiştirebilirsin.":"Modül devre dışı bırakıldı.");
}
bool InitializeGraphics() {
 if(!iconAtlas)iconAtlas=CreateIconAtlas();
 return iconAtlas!=0;
}
void Draw(const FontManager& fonts,ImDrawList& bloom,ImDrawList& front,float width,float height,float dt,std::vector<render::RoundedPanel>& panels) {
 if(!queue.Enabled()||!queue.Count())return;
 const float scale=std::min(1.f,std::max(.1f,(width-32)/343.f));
 const int capacity=std::clamp(static_cast<int>((height-16)/(94*scale)),1,3);
 queue.Update(dt,capacity);
 // Dynamic font baking can grow the atlas and move its white pixel. Bake every
 // toast's glyphs before emitting any panel/icon geometry that uses that pixel.
 for(const auto& toast:queue.Active()) {
  fonts.Measure(toast.title,17*scale);
  fonts.Measure(toast.message,13*scale,FontWeight::Regular);
 }
 float groupHeight=0;for(const auto& toast:queue.Active())groupHeight+=Height(toast)*scale+12*scale;if(groupHeight>0)groupHeight-=12*scale;
 const float cardWidth=343*scale;hud_layout::Report(hud_layout::Element::Notifications,cardWidth,std::max(38.f,groupHeight));const auto origin=hud_layout::Position(hud_layout::Element::Notifications,width,height);
 float bottom=origin.y+groupHeight;
 for(auto it=queue.Active().rbegin();it!=queue.Active().rend();++it) {
  auto& toast=*it;const float cardHeight=Height(toast)*scale;
  const float target=bottom-cardHeight;bottom=target-12*scale;
  if(toast.y<0)toast.y=target;else toast.y+=(target-toast.y)*(1-std::exp(-std::max(0.f,dt)*16));
  const float enter=Ease(toast.age/Queue::Enter),leave=Ease((toast.age-Queue::Enter-Queue::Hold)/Queue::Exit);
  const float opacity=enter*(1-leave);
  if(opacity<.005f)continue;
  const float x=origin.x+(1-enter+leave)*(cardWidth+16),y=toast.y;
  render::RoundedPanel panel{x,y,cardWidth,cardHeight,8*scale};
  panel.color=IM_COL32(20,20,21,255);panel.opacity=opacity;panel.blur=false;panel.border=false;
  panels.push_back(panel);
   const ImVec2 center{x+32*scale,y+cardHeight*.5f};
  Icon(front,toast.type,center,scale,opacity);
  // Subtle, actual Gaussian bloom around the status glyph; body text stays sharp.
  bloom.AddCircleFilled(center,6*scale,Fade(Accent(toast.type),opacity*.28f),24);
  const float textX=x+64*scale;
  front.PushClipRect({textX,y+6*scale},{x+cardWidth-16*scale,y+cardHeight-6*scale},true);
  fonts.Draw(front,toast.title,{textX,y+12*scale},17*scale,Fade(IM_COL32(237,237,239,255),opacity));
  const auto split=toast.message.find('\n');
  fonts.Draw(front,std::string_view(toast.message).substr(0,split),{textX,y+34*scale},13*scale,Fade(IM_COL32(153,153,158,255),opacity),FontWeight::Regular);
  if(split!=std::string::npos)fonts.Draw(front,std::string_view(toast.message).substr(split+1),{textX,y+52*scale},13*scale,Fade(IM_COL32(153,153,158,255),opacity),FontWeight::Regular);
  front.PopClipRect();
 }
}
}
