#include "ui/hud/Hud.hpp"
#include "ui/hud/HudLayout.hpp"
#include "ui/font/FontManager.hpp"
#include "ui/clickgui/GuiAssets.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
namespace client::ui {
namespace {
constexpr ImU32 white=IM_COL32(255,255,255,255);
constexpr ImU32 secondary=IM_COL32(230,230,230,255);
}
std::string FormatCoordinates(HudPosition position) {
 char text[160]{};
 std::snprintf(text,sizeof(text),"%.0f, %.0f, %.0f",std::floor(position.x),std::floor(position.y),std::floor(position.z));
 return text;
}
void DrawHud(const FontManager& fonts,ImDrawList& bloom,
             ImDrawList& foreground,float width,float height,
             std::vector<render::RoundedPanel>& panels) {
 if(width<220.f || height<100.f) return;
 constexpr float logoSize=88.f;
 hud_layout::Report(hud_layout::Element::Watermark,logoSize,logoSize);
 if(const auto logo=clickgui::WatermarkLogo();logo.image) {
  const auto position=hud_layout::Position(hud_layout::Element::Watermark,width,height);
  const ImVec2 min(position.x,position.y);
  const ImVec2 max(position.x+logoSize,position.y+logoSize);
  if(logo.bloom)bloom.AddImage(logo.bloom,min,max);
  foreground.AddImage(logo.image,min,max);
 }

 struct Entry {const char* name;float width;};
 std::array<Entry,features::modules::Count> entries{};
 int count=0;
 for(const auto& module:features::modules::Catalog)
  if(features::modules::Enabled(module.id))entries[count++].name=module.name;

 if(count) {
  constexpr float baseFont=14.f,basePillHeight=20.f,baseGap=4.f,basePadding=10.f;
  const float fullHeight=count*basePillHeight+(count-1)*baseGap;
  const float scale=std::min(1.f,(height-16.f)/fullHeight);
  const float fontSize=baseFont*scale,pillHeight=basePillHeight*scale;
  const float gap=baseGap*scale,padding=basePadding*scale;
  constexpr auto weight=FontWeight::Medium;
  for(int i=0;i<count;++i)entries[i].width=fonts.Measure(entries[i].name,fontSize,weight).x;
  std::sort(entries.begin(),entries.begin()+count,[](const Entry& a,const Entry& b){return a.width>b.width;});

  const float widest=std::ceil(entries[0].width+2.f*padding);
  hud_layout::Report(hud_layout::Element::ArrayList,widest,fullHeight*scale);
  const auto position=hud_layout::Position(hud_layout::Element::ArrayList,width,height);
  const float right=position.x+widest;
  auto* baked=fonts.Get(weight)->GetFontBaked(fontSize);
  const float glyphScale=fontSize/baked->Size;
  for(int i=0;i<count;++i) {
   const float pillWidth=std::ceil(entries[i].width+2.f*padding);
   const float y=position.y+i*(pillHeight+gap);
   render::RoundedPanel panel{right-pillWidth,y,pillWidth,pillHeight,pillHeight*.25f};
   panel.color=IM_COL32(17,17,18,216);
   panels.push_back(panel);
   float top=fontSize,bottom=0.f;
   for(const unsigned char* ch=reinterpret_cast<const unsigned char*>(entries[i].name);*ch;++ch) {
    if(const auto* glyph=baked->FindGlyph(*ch);glyph&&glyph->Visible) {
     top=std::min(top,glyph->Y0*glyphScale);
     bottom=std::max(bottom,glyph->Y1*glyphScale);
    }
   }
   const ImVec2 label(right-(pillWidth+entries[i].width)*.5f,
    std::round(y+(pillHeight-top-bottom)*.5f));
   fonts.Draw(foreground,entries[i].name,label,fontSize,IM_COL32(237,237,239,255),weight);
  }
 }

 if(IsChatOpen())return;
 const auto position=GetHudPosition();
 if(!position) return;
 const std::string coordinates=FormatCoordinates(*position);
 constexpr float size=17.f;
 const float labelWidth=fonts.Measure("XYZ",size).x;
 const float valueWidth=fonts.Measure(coordinates,size,FontWeight::Medium).x;
 const float coordinatesWidth=12.f+labelWidth+12.f+valueWidth+12.f;
 hud_layout::Report(hud_layout::Element::Coordinates,coordinatesWidth,36.f);const auto lower=hud_layout::Position(hud_layout::Element::Coordinates,width,height);
 panels.push_back({lower.x,lower.y,coordinatesWidth,36.f,10.f});
 fonts.Draw(foreground,"XYZ",{lower.x+12.f,lower.y+10.f},size,white);
 fonts.Draw(foreground,coordinates,{lower.x+12.f+labelWidth+12.f,lower.y+10.f},size,secondary,FontWeight::Medium);
}
}
