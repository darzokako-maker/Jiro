#include "ui/hud/HudLayout.hpp"
#include <array>
#include <algorithm>
#include <cmath>
#include <vector>

namespace client::ui::hud_layout {
namespace {
constexpr float margin=8.f;
constexpr float widgetScale=.936f;
constexpr float widgetWidth=314.f*widgetScale;
constexpr float widgetHeight=151.f*widgetScale;
struct State {float first=NAN,second=NAN,width=80,height=20;bool right=false,bottom=false,reported=false;};
std::array<State,static_cast<int>(Element::Count)> states{{
 {NAN,NAN,80,52,false,false},
 {NAN,NAN,120,24,true,false},
 {NAN,NAN,150,36,false,true},
 {NAN,NAN,widgetWidth,widgetHeight,true,true},
 {NAN,NAN,343,82,true,true},
 {NAN,NAN,311,90,false,true},
 {NAN,NAN,widgetWidth,widgetHeight,true,true}
}};
Element dragging=Element::Count;float offsetX=0,offsetY=0;bool lastLeftDown=false;
GuideState guides;
float previousScreenWidth=NAN,previousScreenHeight=NAN;
State& At(Element element){return states[static_cast<int>(element)];}
void PrepareScreen(float screenWidth,float screenHeight){
 if(!std::isnan(previousScreenWidth))for(auto& state:states){if(state.right&&!std::isnan(state.first))state.first+=screenWidth-previousScreenWidth;if(state.bottom&&!std::isnan(state.second))state.second+=screenHeight-previousScreenHeight;}
 previousScreenWidth=screenWidth;previousScreenHeight=screenHeight;
}
void Initialize(State& state,float screenWidth,float screenHeight){if(std::isnan(state.first)){if(&state==&At(Element::TargetHud))state.first=(screenWidth-state.width)*.5f;else state.first=state.right?screenWidth-margin:margin;}if(std::isnan(state.second)){if(&state==&At(Element::TargetHud))state.second=screenHeight-24.f;else if(&state==&At(Element::Inventory))state.second=screenHeight-margin-At(Element::Spotify).height-margin;else state.second=state.bottom?screenHeight-margin:margin;}}
Point TopLeft(const State& state){return {state.right?state.first-state.width:state.first,state.bottom?state.second-state.height:state.second};}
bool Inside(float x,float y,const State& state){const auto p=TopLeft(state);return x>=p.x&&x<=p.x+state.width&&y>=p.y&&y<=p.y+state.height;}
bool SpotifyControl(float x,float y,const State& state){
 const auto p=TopLeft(state);const float scale=state.width/314.f,localX=x-p.x,localY=y-p.y;
 const auto box=[&](float left,float top,float right,float bottom){return localX>=left*scale&&localX<=right*scale&&localY>=top*scale&&localY<=bottom*scale;};
 return box(47,106,78,139)||box(232,59,299,101)||box(238,106,270,139);
}
float BestSnap(float origin,float size,const std::vector<float>& targets,float& guide,bool& snapped) {
 constexpr float threshold=6.f;float best=threshold+1.f,delta=0;
 for(const float offset:{0.f,size*.5f,size})for(const float target:targets){const float candidate=target-(origin+offset),distance=std::abs(candidate);if(distance<best){best=distance;delta=candidate;guide=target;}}
 snapped=best<=threshold;return snapped?delta:0.f;
}
}

void BeginFrame(){for(auto& state:states)state.reported=false;}
void Report(Element element,float width,float height){auto& state=At(element);state.reported=true;if(width>0)state.width=width;if(height>0)state.height=height;}
Point Position(Element element,float screenWidth,float screenHeight){PrepareScreen(screenWidth,screenHeight);auto& state=At(element);Initialize(state,screenWidth,screenHeight);return TopLeft(state);}
void UpdateEditor(float mouseX,float mouseY,float screenWidth,float screenHeight,bool leftDown) {
 PrepareScreen(screenWidth,screenHeight);
 for(auto& state:states)Initialize(state,screenWidth,screenHeight);
 const bool pressed=leftDown&&!lastLeftDown;
 if(pressed)for(const auto element:{Element::Watermark,Element::ArrayList,Element::Coordinates,Element::Inventory,Element::Spotify,Element::Notifications,Element::TargetHud}) {
  auto& state=At(element);if(!Inside(mouseX,mouseY,state)||(element==Element::Spotify&&SpotifyControl(mouseX,mouseY,state)))continue;dragging=element;offsetX=mouseX-state.first;offsetY=mouseY-state.second;break;
 }
 if(!leftDown){dragging=Element::Count;guides={};}
 if(dragging!=Element::Count&&leftDown) {
  auto& state=At(dragging);const float first=mouseX-offsetX,second=mouseY-offsetY;float left=state.right?first-state.width:first,top=state.bottom?second-state.height:second;
  std::vector<float> vertical{8.f,screenWidth*.5f,screenWidth-8.f},horizontal{8.f,screenHeight*.5f,screenHeight-8.f};
  for(int i=0;i<static_cast<int>(Element::Count);++i){const auto element=static_cast<Element>(i);const auto& other=At(element);if(element==dragging||!other.reported)continue;const auto p=TopLeft(other);vertical.insert(vertical.end(),{p.x,p.x+other.width*.5f,p.x+other.width});horizontal.insert(horizontal.end(),{p.y,p.y+other.height*.5f,p.y+other.height});}
  guides={};float guideX=0,guideY=0;bool snapX=false,snapY=false;const float dx=BestSnap(left,state.width,vertical,guideX,snapX),dy=BestSnap(top,state.height,horizontal,guideY,snapY);left+=dx;top+=dy;guides.vertical=snapX;guides.horizontal=snapY;guides.x=guideX;guides.y=guideY;
  const float snappedFirst=state.right?left+state.width:left,snappedSecond=state.bottom?top+state.height:top;
  state.first=state.right?std::clamp(snappedFirst,state.width+2.f,screenWidth-2.f):std::clamp(snappedFirst,0.f,std::max(0.f,screenWidth-state.width));
  state.second=state.bottom?std::clamp(snappedSecond,state.height+2.f,screenHeight-2.f):std::clamp(snappedSecond,dragging==Element::Watermark?0.f:2.f,std::max(dragging==Element::Watermark?0.f:2.f,screenHeight-state.height-(dragging==Element::Watermark?0.f:2.f)));
 }
 lastLeftDown=leftDown;
}
void EndEditor(){dragging=Element::Count;lastLeftDown=false;guides={};}
bool Dragging(Element element){return dragging==element;}
GuideState Guides(){return guides;}
}
