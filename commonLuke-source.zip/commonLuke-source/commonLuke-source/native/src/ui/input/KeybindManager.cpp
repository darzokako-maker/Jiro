#include "ui/input/KeybindManager.hpp"
#include "ui/input/KeybindRules.hpp"
#include "ui/hud/HudState.hpp"
#include "ui/hud/Notifications.hpp"
#include <array>

namespace client::ui::bindings {
namespace {
namespace modules=features::modules;
std::array<Config,modules::Count> configs{};
struct Runtime {
 bool owned=false,restore=false,moduleActive=false,actionActive=false,moduleBlocked=false,actionBlocked=false;
 std::uint64_t next=0;
};
std::array<Runtime,modules::Count> states{};
void Release(modules::Id id,Runtime& state) {
 if(state.owned){modules::SetEnabled(id,state.restore);state.owned=false;}
 state.moduleActive=state.actionActive=false;state.next=0;
}
}
bool Bindable(int key) {
 if(key==VK_MBUTTON||key==VK_XBUTTON1||key==VK_XBUTTON2)return true;
 return key>=8&&key<256&&key!=VK_ESCAPE&&key!=VK_INSERT&&key!=VK_RSHIFT&&key!=VK_SHIFT&&key!=VK_CONTROL&&key!=VK_MENU;
}
bool SupportsAction(features::modules::Id){return false;}
std::string KeyName(int key) {
 switch(key){case 0:return "None";case VK_MBUTTON:return "Mouse 3";case VK_XBUTTON1:return "Mouse 4";case VK_XBUTTON2:return "Mouse 5";default:break;}
 auto scan=MapVirtualKeyW(key,MAPVK_VK_TO_VSC);
 switch(key){case VK_RCONTROL:case VK_RMENU:case VK_PRIOR:case VK_NEXT:case VK_END:case VK_HOME:case VK_LEFT:case VK_UP:case VK_RIGHT:case VK_DOWN:case VK_DELETE:case VK_DIVIDE:case VK_NUMLOCK:scan|=0x100;break;default:break;}
 wchar_t name[64]{};if(!GetKeyNameTextW(static_cast<LONG>(scan<<16),name,64))return "Unknown";
 char utf8[256]{};WideCharToMultiByte(CP_UTF8,0,name,-1,utf8,sizeof(utf8),nullptr,nullptr);return utf8;
}
const Config& Options(features::modules::Id id){return configs[id];}
void SetOptions(features::modules::Id id,Config config) {
 if(!modules::Available(id))return;
 if(!Bindable(config.module.key))config.module.key=0;
 if(!SupportsAction(id)||!Bindable(config.action.key))config.action.key=0;
 if(configs[id]==config)return;
 const bool removed=rules::ModuleKeyRemoved(configs[id].module.key,config.module.key);
 auto& state=states[id];Release(id,state);configs[id]=config;state={};
 // A key held while editing must be released before it can fire in gameplay.
 state.moduleBlocked=state.actionBlocked=true;
 if(removed&&id>=0&&id<modules::Count){
  const auto title=std::string(modules::Catalog[id].name)+" keybind silindi";
  ui::notifications::State().Push(ui::notifications::Type::Info,title,"Modül tuş ataması kaldırıldı.");
 }
}
bool NeedsGameCheck(const input::Snapshot& input) {
 for(int i=0;i<modules::Count;++i)if(states[i].owned||states[i].actionActive||
  (configs[i].module.key&&input.down[configs[i].module.key])||(configs[i].action.key&&input.down[configs[i].action.key]))return true;
 return false;
}
bool Holding(features::modules::Id id){return states[id].owned||states[id].actionActive;}
void Update(const input::Snapshot& input,bool allowed,std::uint64_t) {
 if(IsChatOpen())allowed=false;
 for(int i=0;i<modules::Count;++i) {
  const auto id=static_cast<modules::Id>(i);const auto& config=configs[i];auto& state=states[i];
  if(!allowed||!input.focused){Release(id,state);state.moduleBlocked=state.actionBlocked=true;continue;}
  const bool moduleDown=config.module.key&&input.down[config.module.key];
  if(!moduleDown){state.moduleBlocked=false;state.moduleActive=false;}
  const bool modulePress=moduleDown&&!state.moduleBlocked&&input.pressed[config.module.key];
  if(modulePress&&config.module.hold)state.moduleActive=true;
  const bool holdModule=(config.module.hold&&state.moduleActive);
  if(holdModule&&!state.owned){state.restore=modules::Enabled(id);state.owned=true;modules::SetEnabled(id,true);state.next=0;}
  if(!holdModule&&state.owned){modules::SetEnabled(id,state.restore);state.owned=false;state.next=0;}
  if(modulePress&&!config.module.hold)modules::Toggle(id);
 }
}
}
