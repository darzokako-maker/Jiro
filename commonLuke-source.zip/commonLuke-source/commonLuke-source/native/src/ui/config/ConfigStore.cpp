#include "ui/config/ConfigStore.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "features/visual/esp/Esp.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/visual/freecam/FreeCam.hpp"
#include "features/combat/auto_harm/AutoHarm.hpp"
#include "features/visual/dragon_wings/DragonWings.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/target_hud/TargetHud.hpp"
#include "features/visual/cosmetics/Cosmetics.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/combat/velocity/Velocity.hpp"
#include "features/combat/aim_assist/AimAssist.hpp"
#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/movement/ncp/NcpMovement.hpp"
#include "features/movement/fly/Fly.hpp"
#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/movement/clips/Clips.hpp"
#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "features/visual/ambiance/Ambiance.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/utility/auto_miner/AutoMiner.hpp"
#include "features/visual/xray/Xray.hpp"
#include "ui/input/KeybindManager.hpp"
#include "ui/hud/Notifications.hpp"
#include <Windows.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cstdio>
#include <filesystem>
#include <limits>
#include <type_traits>

namespace client::ui::configs {
namespace {
namespace modules=features::modules;
constexpr std::array<unsigned char,8> magic{'A','O','K','I','C','F','G','1'};
constexpr std::size_t maxFile=1024*1024;
std::string current;

struct Snapshot {
 bool mcf=true;
 bool hud=true,notifications=true;
 features::esp::Settings esp;
 features::item_esp::Settings itemEsp;
 features::freecam::Settings freeCam;
 features::autoharm::Settings autoHarm;
 features::wings::Settings wings;
 std::array<features::clips::Settings,3> clips;
 features::aura::Settings aura;
 features::velocity::Settings velocity;
 features::norotate::Settings noRotate;
 std::array<features::movement::Settings,2> movement;
 features::nojump::Settings noJump;
 features::spotify::Settings spotify;
 features::inventory_hud::Settings inventoryHud;
 features::targethud::Settings targetHud;
 features::cosmetics::Settings cosmetics;
 features::disconnect::Settings disconnect;
 features::ambiance::Settings ambiance;
 features::scaffold::Settings scaffold;
 features::fly::Settings fly;
 features::aimassist::Settings aimAssist;
 features::xray::Settings xray;
 features::autominer::Settings autoMiner;
 std::array<features::extras::Settings,static_cast<int>(features::extras::Kind::Count)> extras;
 std::array<bindings::Config,modules::Count> bindings;
};

void Put32(std::vector<unsigned char>& out,std::uint32_t value){for(int i=0;i<4;++i)out.push_back(static_cast<unsigned char>(value>>(i*8)));}
std::uint32_t Hash(const unsigned char* data,std::size_t size){std::uint32_t value=2166136261u;for(std::size_t i=0;i<size;++i){value^=data[i];value*=16777619u;}return value;}

struct Writer {
 std::vector<unsigned char> data;
 template<class T>void operator()(T& value){
  if constexpr(std::is_same_v<T,bool>)data.push_back(value?1:0);
  else if constexpr(std::is_enum_v<T>){std::int32_t raw=static_cast<std::int32_t>(value);(*this)(raw);}
  else if constexpr(std::is_same_v<T,float>){auto raw=std::bit_cast<std::uint32_t>(value);Put32(data,raw);}
  else if constexpr(std::is_integral_v<T>&&sizeof(T)<=4)Put32(data,static_cast<std::uint32_t>(value));
  else static_assert(!sizeof(T),"unsupported config field");
 }
 void operator()(std::string& value){const auto size=static_cast<std::uint32_t>(std::min<std::size_t>(value.size(),4096));Put32(data,size);data.insert(data.end(),value.begin(),value.begin()+size);}
};
struct Reader {
 const unsigned char* data=nullptr;std::size_t size=0,at=0;bool ok=true;
 bool U32(std::uint32_t& value){if(!ok||at+4>size){ok=false;return false;}value=0;for(int i=0;i<4;++i)value|=static_cast<std::uint32_t>(data[at++])<<(i*8);return true;}
 template<class T>void operator()(T& value){
  if constexpr(std::is_same_v<T,bool>){if(at>=size){ok=false;return;}const auto raw=data[at++];if(raw>1){ok=false;return;}value=raw!=0;}
  else if constexpr(std::is_enum_v<T>){std::int32_t raw=0;(*this)(raw);value=static_cast<T>(raw);}
  else if constexpr(std::is_same_v<T,float>){std::uint32_t raw=0;if(U32(raw))value=std::bit_cast<float>(raw);}
  else if constexpr(std::is_integral_v<T>&&sizeof(T)<=4){std::uint32_t raw=0;if(U32(raw))value=static_cast<T>(raw);}
  else static_assert(!sizeof(T),"unsupported config field");
 }
 void operator()(std::string& value){std::uint32_t length=0;if(!U32(length)||length>4096||at+length>size){ok=false;return;}value.assign(reinterpret_cast<const char*>(data+at),length);at+=length;}
 bool Done()const{return ok&&at==size;}
};
template<class A,class... T>void Fields(A& archive,T&... values){(archive(values),...);}

template<class A>void Serialize(A& a,features::esp::Settings& s){Fields(a,s.enabled,s.players,s.animals,s.mobs,s.box,s.boxPostprocess,s.invisibles,s.minecraftFont,s.heldItem,s.equipment,s.healthBar,s.healthText,s.nametags,s.redTags,s.formattedTags,s.tagPostprocess,s.tagHealth,s.tagBackground,s.redBackground,s.roundedTags,s.healthByValue,s.customColor,s.rainbow,s.tagScale,s.color,s.alternate,s.friends);}
template<class A>void Serialize(A& a,features::item_esp::Settings& s){Fields(a,s.enabled,s.box,s.boxPostprocess,s.minecraftFont,s.nametags,s.formattedTags,s.tagPostprocess,s.tagBackground,s.redBackground,s.roundedTags,s.customColor,s.rainbow,s.tagScale,s.color,s.alternate);}
template<class A>void Serialize(A& a,features::freecam::Settings& s){Fields(a,s.enabled,s.speed);}
template<class A>void Serialize(A& a,features::autoharm::Settings& s){Fields(a,s.enabled,s.targetMaxHealth,s.minSafeDistance,s.maxDistance,s.delayMin,s.delayMax,s.rotationSpeedMin,s.rotationSpeedMax,s.preferTrapped,s.checkSelfHealth,s.protectVelocity,s.autoRefill,s.refillSlot,s.silentSwing,s.notifications);}
template<class A>void Serialize(A& a,features::wings::Settings& s){Fields(a,s.enabled,s.scale,s.color);}
template<class A>void Serialize(A& a,features::clips::Settings& s){Fields(a,s.enabled,s.smart,s.effects,s.humanize,s.paperBypass,s.distance);}
template<class A>void Serialize(A& a,features::aura::Settings& s){Fields(a,s.enabled,s.attackMode,s.blockMode,s.sorting,s.clickMode,s.rotationMode,s.movementFix,s.targetEsp,s.fullBox,s.rightClickOnly,s.preventBlocking,s.keepSprint,s.bloom,s.rayCast,s.throughWalls,s.advanced,s.noSwing,s.autoDisable,s.badPacketsCheck,s.showTargets,s.criticals,s.criticalDelay,s.players,s.invisibles,s.animals,s.mobs,s.teammates,s.range,s.cpsMin,s.cpsMax,s.rotationMin,s.rotationMax,s.switchMin,s.switchMax,s.friends,s.priorityTargets,s.bots);}
template<class A>void Serialize(A& a,features::velocity::Settings& s){Fields(a,s.enabled,s.horizontal,s.vertical,s.explosions);}
template<class A>void Serialize(A& a,features::aimassist::Settings& s){Fields(a,s.enabled,s.mode,s.targetMode,s.targetArea,s.requireMouseDown,s.aimVertically,s.strafeIncrease,s.checkBlockBreak,s.limitItems,s.visibleOnly,s.players,s.invisibles,s.animals,s.mobs,s.teammates,s.horizontalSpeed,s.verticalSpeed,s.maxAngle,s.distance);}
template<class A>void Serialize(A& a,features::norotate::Settings& s){Fields(a,s.enabled,s.mode);}
template<class A>void Serialize(A& a,features::movement::Settings& s){Fields(a,s.enabled,s.jumpMotion,s.groundSpeed,s.bunnySlope,s.damageBoost,s.customBoost,s.lowHop,s.yPort,s.boostSpeed,s.hurtTime,s.bunnyFriction,s.jumpSpeed,s.glide,s.autoDisable,s.fakeDamage,s.disableOnTeleport,s.stopOnDisable);}
template<class A>void Serialize(A& a,features::fly::Settings& s){Fields(a,s.enabled,s.mode,s.speed,s.verticalSpeed,s.disableY);}
template<class A>void Serialize(A& a,features::nojump::Settings& s){a(s.enabled);}
template<class A>void Serialize(A& a,features::spotify::Settings& s){a(s.enabled);}
template<class A>void Serialize(A& a,features::inventory_hud::Settings& s){a(s.enabled);}
template<class A>void Serialize(A& a,features::targethud::Settings& s){a(s.enabled);}
template<class A>void Serialize(A& a,features::cosmetics::Settings& s){Fields(a,s.enabled,s.model,s.skin,s.cape);}
template<class A>void Serialize(A& a,features::disconnect::Settings& s){Fields(a,s.enabled,s.lowHealth,s.countAbsorption,s.health);}
template<class A>void Serialize(A& a,features::scaffold::Settings& s){Fields(a,s.enabled,s.rayCast,s.sameY,s.rotationMin,s.rotationMax,s.delayMin,s.delayMax,s.expand,s.safeWalk,s.movementCorrection);}
template<class A>void Serialize(A& a,features::ambiance::Settings& s){bool legacySkybox=false;Fields(a,s.enabled,s.lyrics,s.lyrics3d,legacySkybox,s.offsetMs);}
template<class A>void Serialize(A& a,features::xray::Settings& s){Fields(a,s.enabled,s.ores.diamond,s.ores.emerald,s.ores.gold,s.ores.iron,s.ores.coal,s.ores.lapis,s.ores.redstone,s.ores.quartz,s.ores.copper,s.ores.titanium,s.radius,s.boxes,s.tracers,s.labels,s.lineWidth);}
template<class A>void Serialize(A& a,features::autominer::Settings& s){Fields(a,s.enabled,s.ores.diamond,s.ores.emerald,s.ores.gold,s.ores.iron,s.ores.coal,s.ores.lapis,s.ores.redstone,s.ores.quartz,s.ores.copper,s.ores.titanium,s.range,s.scanIntervalMs,s.rotate,s.swing);}
template<class A>void Serialize(A& a,features::ambiance::Lyrics3DColor& s){bool legacySkybox=false;Fields(a,legacySkybox,s.color,s.brightness,s.glow,s.follow,s.distance,s.hOffset,s.vOffset,s.scale,s.billboard);}
template<class A>void Serialize(A& a,features::extras::Settings& s){Fields(a,s.enabled,s.range,s.speed,s.delay,s.fov,s.history,s.cps,s.mode,s.holdJump,s.speedOnly,s.thirdPerson,s.circle,s.behind,s.right,s.left,s.breakBlocks,s.disableOnUi,s.requireSwing,s.sticky,s.requireMouse,s.limitItems,s.aimOnTarget,s.targets,s.visibleOnly,s.players,s.invisibles,s.animals,s.mobs,s.teammates,s.blocksOnly,s.bed,s.keepProgress,s.cancelVelocity,s.throughWalls,s.emptySurrounding,s.rotate,s.importantRotations,s.whitelistBed,s.slowInAir,s.bedBox,s.defenseLayers,s.breakingOutline,s.bloom,s.boxAlpha,s.layerCount,s.scanRange,s.outlineWidth,s.outlineColor,s.message);}
template<class A>void Serialize(A& a,bindings::Binding& s){Fields(a,s.key,s.hold);}
template<class A>void Serialize(A& a,bindings::Config& s){Serialize(a,s.module);Serialize(a,s.action);}
template<class A>void SerializeBase(A& a,Snapshot& s){Fields(a,s.hud,s.notifications);Serialize(a,s.esp);Serialize(a,s.wings);for(auto& value:s.clips)Serialize(a,value);Serialize(a,s.aura);Serialize(a,s.velocity);Serialize(a,s.noRotate);for(auto& value:s.movement)Serialize(a,value);Serialize(a,s.noJump);Serialize(a,s.spotify);Serialize(a,s.targetHud);Serialize(a,s.disconnect);for(int i=0;i<=static_cast<int>(features::extras::Kind::InventoryMove);++i)Serialize(a,s.extras[i]);}
void Serialize(Writer& a,Snapshot& s){SerializeBase(a,s);for(int i=0;i<modules::Cosmetics;++i)Serialize(a,s.bindings[i]);Serialize(a,s.cosmetics);Serialize(a,s.bindings[modules::Cosmetics]);Serialize(a,s.bindings[modules::SeedDumper]);Serialize(a,s.itemEsp);Serialize(a,s.bindings[modules::ItemEsp]);Fields(a,s.aura.slowSwing,s.aura.slowSwingSpeed);Serialize(a,s.freeCam);Serialize(a,s.bindings[modules::FreeCam]);Serialize(a,s.autoHarm);Serialize(a,s.bindings[modules::AutoHarm]);Serialize(a,s.ambiance);Serialize(a,s.bindings[modules::Ambiance]);Serialize(a,s.ambiance.lyrics3dColor);Serialize(a,s.scaffold);Serialize(a,s.bindings[modules::Scaffold]);Fields(a,s.scaffold.mode,s.mcf);Serialize(a,s.bindings[modules::Mcf]);Serialize(a,s.fly);Serialize(a,s.bindings[modules::Fly]);Serialize(a,s.inventoryHud);Serialize(a,s.bindings[modules::InventoryHud]);Serialize(a,s.extras[static_cast<int>(features::extras::Kind::NoFall)]);Serialize(a,s.bindings[modules::NoFall]);Serialize(a,s.extras[static_cast<int>(features::extras::Kind::FastPlace)]);Serialize(a,s.bindings[modules::FastPlace]);Serialize(a,s.aimAssist);Serialize(a,s.bindings[modules::AimAssist]);Serialize(a,s.extras[static_cast<int>(features::extras::Kind::FakeLag)]);Serialize(a,s.bindings[modules::FakeLag]);Fields(a,s.velocity.chance,s.velocity.ticks,s.velocity.waterCheck,s.velocity.onlyWhenTargeting);Serialize(a,s.xray);Serialize(a,s.bindings[modules::Xray]);Serialize(a,s.autoMiner);Serialize(a,s.bindings[modules::AutoMiner]);}
void Serialize(Reader& a,Snapshot& s){SerializeBase(a,s);for(int i=0;i<modules::Cosmetics;++i)Serialize(a,s.bindings[i]);if(a.Done())return;Serialize(a,s.cosmetics);Serialize(a,s.bindings[modules::Cosmetics]);if(a.Done())return;Serialize(a,s.bindings[modules::SeedDumper]);if(a.Done())return;Serialize(a,s.itemEsp);Serialize(a,s.bindings[modules::ItemEsp]);if(a.Done())return;Fields(a,s.aura.slowSwing,s.aura.slowSwingSpeed);if(a.Done())return;Serialize(a,s.freeCam);Serialize(a,s.bindings[modules::FreeCam]);if(a.Done())return;Serialize(a,s.autoHarm);if(a.Done())return;Serialize(a,s.bindings[modules::AutoHarm]);if(a.Done())return;Serialize(a,s.ambiance);Serialize(a,s.bindings[modules::Ambiance]);if(a.Done())return;
 // Tolerant tail: try the full lyrics3d block, then the legacy 5-field and
 // 4-field variants; keep defaults instead of failing the whole load.
 {const auto mark=a.at;const bool wasOk=a.ok;
  Serialize(a,s.ambiance.lyrics3dColor);
  if(!a.ok){a.ok=wasOk;a.at=mark;s.ambiance.lyrics3dColor=features::ambiance::Lyrics3DColor{};
   bool legacyLyricsSkybox=false;
   Fields(a,legacyLyricsSkybox,s.ambiance.lyrics3dColor.color,
          s.ambiance.lyrics3dColor.brightness,s.ambiance.lyrics3dColor.glow,
          s.ambiance.lyrics3dColor.follow);
   if(!a.ok){a.ok=wasOk;a.at=mark;s.ambiance.lyrics3dColor=features::ambiance::Lyrics3DColor{};
    legacyLyricsSkybox=false;
    Fields(a,legacyLyricsSkybox,s.ambiance.lyrics3dColor.color,
           s.ambiance.lyrics3dColor.brightness,s.ambiance.lyrics3dColor.glow);
    if(!a.ok){a.ok=wasOk;a.at=mark;s.ambiance.lyrics3dColor=features::ambiance::Lyrics3DColor{};}}}}
 if(a.Done())return;
 Serialize(a,s.scaffold);Serialize(a,s.bindings[modules::Scaffold]);
 if(!a.Done()) Fields(a,s.scaffold.mode);
 if(!a.Done()){Fields(a,s.mcf);Serialize(a,s.bindings[modules::Mcf]);}
 if(a.Done())return;
 Serialize(a,s.fly);Serialize(a,s.bindings[modules::Fly]);
 if(a.Done())return;
 Serialize(a,s.inventoryHud);Serialize(a,s.bindings[modules::InventoryHud]);
 if(a.Done())return;
 Serialize(a,s.extras[static_cast<int>(features::extras::Kind::NoFall)]);Serialize(a,s.bindings[modules::NoFall]);
 if(a.Done())return;
 Serialize(a,s.extras[static_cast<int>(features::extras::Kind::FastPlace)]);Serialize(a,s.bindings[modules::FastPlace]);
 if(a.Done())return;
 Serialize(a,s.aimAssist);Serialize(a,s.bindings[modules::AimAssist]);
 if(a.Done())return;
 Serialize(a,s.extras[static_cast<int>(features::extras::Kind::FakeLag)]);Serialize(a,s.bindings[modules::FakeLag]);
 if(a.Done())return;
 Fields(a,s.velocity.chance,s.velocity.ticks,s.velocity.waterCheck,s.velocity.onlyWhenTargeting);
 if(a.Done())return;
 Serialize(a,s.xray);
 if(a.Done())return;
 Serialize(a,s.bindings[modules::Xray]);
 if(a.Done())return;
 Serialize(a,s.autoMiner);
 if(a.Done())return;
 Serialize(a,s.bindings[modules::AutoMiner]);
}

Snapshot Capture(){
 Snapshot s;s.mcf=modules::Enabled(modules::Mcf);s.hud=modules::Enabled(modules::Hud);s.notifications=notifications::State().Enabled();s.esp=features::esp::Options();s.itemEsp=features::item_esp::Options();s.freeCam=features::freecam::Options();s.autoHarm=features::autoharm::Options();s.wings=features::wings::Options();
 for(int i=0;i<3;++i)s.clips[i]=features::clips::Options(static_cast<features::clips::Kind>(i));s.aura=features::aura::Options();s.velocity=features::velocity::Options();s.noRotate=features::norotate::Options();
 for(int i=0;i<2;++i)s.movement[i]=features::movement::Options(static_cast<features::movement::Kind>(i));s.noJump=features::nojump::Options();s.spotify=features::spotify::Options();s.inventoryHud=features::inventory_hud::Options();s.targetHud=features::targethud::Options();s.cosmetics=features::cosmetics::Options();s.disconnect=features::disconnect::Options();s.ambiance=features::ambiance::Options();s.scaffold=features::scaffold::Options();s.fly=features::fly::Options();s.aimAssist=features::aimassist::Options();s.xray=features::xray::Options();s.autoMiner=features::autominer::Options();
 for(int i=0;i<static_cast<int>(features::extras::Kind::Count);++i)s.extras[i]=features::extras::Options(static_cast<features::extras::Kind>(i));for(int i=0;i<modules::Count;++i)s.bindings[i]=bindings::Options(static_cast<modules::Id>(i));return s;
}
void Apply(const Snapshot& value){
 auto s=value;notifications::State().SetEnabled(false);features::seeddumper::SetOptions({false});features::esp::SetOptions(s.esp);features::item_esp::SetOptions(s.itemEsp);features::freecam::SetOptions(s.freeCam);features::wings::SetOptions(s.wings);features::velocity::SetOptions(s.velocity);features::aimassist::SetOptions(s.aimAssist);features::norotate::SetOptions(s.noRotate);features::nojump::SetOptions(s.noJump);features::spotify::SetOptions(s.spotify);features::inventory_hud::SetOptions(s.inventoryHud);features::targethud::SetOptions(s.targetHud);features::cosmetics::SetOptions(s.cosmetics);features::disconnect::SetOptions(s.disconnect);features::ambiance::SetOptions(s.ambiance);features::scaffold::SetOptions(s.scaffold);features::xray::SetOptions(s.xray);features::autominer::SetOptions(s.autoMiner);for(int i=0;i<static_cast<int>(features::extras::Kind::Count);++i)if(modules::Available(static_cast<modules::Id>(features::extras::ModuleIndex(static_cast<features::extras::Kind>(i)))))features::extras::SetOptions(static_cast<features::extras::Kind>(i),s.extras[i]);for(int i=0;i<modules::Count;++i)if(modules::Available(static_cast<modules::Id>(i)))bindings::SetOptions(static_cast<modules::Id>(i),s.bindings[i]);modules::SetEnabled(modules::Hud,s.hud);modules::SetEnabled(modules::Mcf,s.mcf);notifications::State().SetEnabled(s.notifications);
}

std::wstring Environment(const wchar_t* key){const DWORD required=GetEnvironmentVariableW(key,nullptr,0);if(!required)return {};std::wstring value(required,L'\0');const DWORD written=GetEnvironmentVariableW(key,value.data(),required);if(!written||written>=required)return {};value.resize(written);return value;}
std::filesystem::path Root(){if(const auto override=Environment(L"AOKI_CONFIG_DIR");!override.empty())return override;auto appData=Environment(L"APPDATA");if(appData.empty())return {};return std::filesystem::path(appData)/L".sonoyuncu"/L"aoki"/L"configs";}
bool WideName(std::string_view input,std::wstring& output,std::string& error){
 while(!input.empty()&&input.front()==' ')input.remove_prefix(1);while(!input.empty()&&input.back()==' ')input.remove_suffix(1);if(input.empty()){error="Enter a config name";return false;}if(input.size()>64){error="Name is too long";return false;}
 const int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,input.data(),static_cast<int>(input.size()),nullptr,0);if(count<=0||count>32){error="Invalid config name";return false;}output.resize(count);MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,input.data(),static_cast<int>(input.size()),output.data(),count);
 if(output==L"."||output==L".."||output.back()==L'.'||output.back()==L' '||std::any_of(output.begin(),output.end(),[](wchar_t c){return c<32||wcschr(L"<>:\"/\\|?*",c);})) {error="Name contains invalid characters";return false;}return true;
}
std::string Utf8(std::wstring_view value){const int size=WideCharToMultiByte(CP_UTF8,0,value.data(),static_cast<int>(value.size()),nullptr,0,nullptr,nullptr);std::string result(size,'\0');if(size)WideCharToMultiByte(CP_UTF8,0,value.data(),static_cast<int>(value.size()),result.data(),size,nullptr,nullptr);return result;}
std::filesystem::path Path(std::string_view name,std::string& error){std::wstring wide;if(!WideName(name,wide,error))return {};return Root()/(wide+L".aoki");}
bool WriteFile(const std::filesystem::path& path,const std::vector<unsigned char>& bytes,std::string& error){
 std::error_code ec;std::filesystem::create_directories(path.parent_path(),ec);if(ec){error="Cannot create config directory";return false;}const auto temporary=path.wstring()+L".tmp";FILE* file=nullptr;if(_wfopen_s(&file,temporary.c_str(),L"wb")||!file){error="Cannot open config file";return false;}const bool body=std::fwrite(bytes.data(),1,bytes.size(),file)==bytes.size()&&std::fflush(file)==0;const bool closed=std::fclose(file)==0;if(!body||!closed){DeleteFileW(temporary.c_str());error="Cannot write config file";return false;}if(!MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(temporary.c_str());error="Cannot replace config file";return false;}return true;
}
bool ReadFile(const std::filesystem::path& path,std::vector<unsigned char>& bytes,std::string& error){FILE* file=nullptr;if(_wfopen_s(&file,path.c_str(),L"rb")||!file){error="Config not found";return false;}std::fseek(file,0,SEEK_END);const long length=std::ftell(file);std::rewind(file);if(length<16||length>static_cast<long>(maxFile)){std::fclose(file);error="Invalid config file size";return false;}bytes.resize(length);const bool read=std::fread(bytes.data(),1,bytes.size(),file)==bytes.size();std::fclose(file);if(!read){error="Cannot read config file";return false;}return true;}
}

std::vector<Entry> List(){std::vector<Entry> result;const auto root=Root();std::error_code ec;if(root.empty()||!std::filesystem::exists(root,ec))return result;for(const auto& item:std::filesystem::directory_iterator(root,ec)){if(ec)break;if(item.is_regular_file()&&_wcsicmp(item.path().extension().c_str(),L".aoki")==0)result.push_back({Utf8(item.path().stem().wstring())});}std::sort(result.begin(),result.end(),[](const Entry& a,const Entry& b){return _stricmp(a.name.c_str(),b.name.c_str())<0;});return result;}
bool Exists(std::string_view name){std::string error;const auto path=Path(name,error);return !path.empty()&&std::filesystem::exists(path);}
bool Save(std::string_view name,bool overwrite,std::string& error){
 error.clear();const auto path=Path(name,error);if(path.empty())return false;if(!overwrite&&std::filesystem::exists(path)){error="Config already exists";return false;}auto snapshot=Capture();Writer payload;Serialize(payload,snapshot);std::vector<unsigned char> file(magic.begin(),magic.end());Put32(file,static_cast<std::uint32_t>(payload.data.size()));Put32(file,Hash(payload.data.data(),payload.data.size()));file.insert(file.end(),payload.data.begin(),payload.data.end());if(!WriteFile(path,file,error))return false;current=Utf8(path.stem().wstring());return true;
}
bool Load(std::string_view name,std::string& error){
 error.clear();const auto path=Path(name,error);if(path.empty())return false;std::vector<unsigned char> file;if(!ReadFile(path,file,error))return false;if(!std::equal(magic.begin(),magic.end(),file.begin())){error="Unsupported config format";return false;}std::uint32_t length=0,checksum=0;for(int i=0;i<4;++i){length|=static_cast<std::uint32_t>(file[8+i])<<(i*8);checksum|=static_cast<std::uint32_t>(file[12+i])<<(i*8);}if(length!=file.size()-16||checksum!=Hash(file.data()+16,length)){error="Config checksum failed";return false;}Snapshot snapshot;Reader reader{file.data()+16,length};Serialize(reader,snapshot);if(!reader.Done()){error="Config data is incomplete";return false;}Apply(snapshot);current=Utf8(path.stem().wstring());return true;
}
bool Remove(std::string_view name,std::string& error){error.clear();const auto path=Path(name,error);if(path.empty())return false;if(!DeleteFileW(path.c_str())){error=GetLastError()==ERROR_FILE_NOT_FOUND?"Config not found":"Cannot delete config";return false;}if(_stricmp(current.c_str(),std::string(name).c_str())==0)current.clear();return true;}
std::string Current(){return current;}
std::string StorageLocation(){return Utf8(Root().wstring());}
}
