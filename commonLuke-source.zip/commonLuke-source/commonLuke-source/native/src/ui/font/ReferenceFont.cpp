#include "ui/font/ReferenceFont.hpp"
#include "ReferenceFonts.hpp"
#include "render/Texture.hpp"
#include <array>
#include <mutex>
#include <unordered_map>
#include <Windows.h>

namespace client::ui::reference_fonts {
namespace {
using Textures=std::array<GLuint,std::size(faces)>;
std::unordered_map<HGLRC,Textures> contexts;
std::mutex mutex;
std::size_t FaceIndex(int size,FontWeight weight){
 const int wanted=weight==FontWeight::Regular?0:1;
 for(std::size_t i=0;i<std::size(faces);++i)if(faces[i].size==size&&faces[i].weight==wanted)return i;
 return std::size(faces);
}
std::wstring Characters(std::string_view text){
 const int length=MultiByteToWideChar(CP_UTF8,0,text.data(),static_cast<int>(text.size()),nullptr,0);
 std::wstring result(length,0);if(length)MultiByteToWideChar(CP_UTF8,0,text.data(),static_cast<int>(text.size()),result.data(),length);return result;
}
unsigned Supported(unsigned character){
 switch(character){case 0x11f:return 'g';case 0x11e:return 'G';case 0x131:return 'i';case 0x130:return 'I';case 0x15f:return 's';case 0x15e:return 'S';default:return character<256?character:'?';}
}
}
ImVec2 Measure(std::string_view text,int size,FontWeight weight){
 const auto index=FaceIndex(size,weight);if(index==std::size(faces))return {};
 const auto& face=faces[index];const auto characters=Characters(text);int width=0;
 for(std::size_t i=0;i<characters.size();++i){if(characters[i]==0xa7){++i;continue;}width+=face.glyphs[Supported(characters[i])].width-8;}
 return {static_cast<float>(width/2),face.fontHeight};
}
bool Draw(ImDrawList& list,std::string_view text,ImVec2 position,int size,float scale,ImU32 color,FontWeight weight){
 const auto index=FaceIndex(size,weight);const auto context=wglGetCurrentContext();if(index==std::size(faces)||!context)return false;
 const auto& face=faces[index];GLuint texture;
 {std::lock_guard lock(mutex);auto& textures=contexts[context];if(!textures[index])textures[index]=render::LoadPngTexture({face.png,face.bytes});texture=textures[index];}
 if(!texture)return false;
 const auto characters=Characters(text);float x=position.x-2*scale,y=position.y-(2+face.fontHeight/10)*scale;
 const float startX=x;
 for(std::size_t i=0;i<characters.size();++i){
  const auto character=characters[i];if(character==0xa7){++i;continue;}if(character=='\n'){x=startX;y+=face.fontHeight*scale;continue;}
  const auto& glyph=face.glyphs[Supported(character)];
  list.AddImage(static_cast<ImTextureID>(texture),{x,y},{x+glyph.width*.5f*scale,y+glyph.height*.5f*scale},
   {static_cast<float>(glyph.x)/face.width,static_cast<float>(glyph.y)/face.height},
   {static_cast<float>(glyph.x+glyph.width)/face.width,static_cast<float>(glyph.y+glyph.height)/face.height},color);
  x+=(glyph.width-8)*.5f*scale;
 }
 return true;
}
void Release(){std::lock_guard lock(mutex);const auto at=contexts.find(wglGetCurrentContext());if(at==contexts.end())return;for(const auto texture:at->second)if(texture)glDeleteTextures(1,&texture);contexts.erase(at);}
}
