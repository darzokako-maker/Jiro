#include "ui/font/FontManager.hpp"
#include "EmbeddedFonts.hpp"
#include <cfloat>
#include <Windows.h>
namespace client::ui {
bool FontManager::Initialize() {
 ImFontConfig config;
 config.FontDataOwnedByAtlas = false;
 config.OversampleH = 2; config.OversampleV = 2;
 config.PixelSnapH = false;
 auto& atlas = *ImGui::GetIO().Fonts;
 auto add = [&](const unsigned char* bytes, int count) {
  config.MergeMode = false;
  ImFont* result = atlas.AddFontFromMemoryTTF(const_cast<unsigned char*>(bytes), count, 18.f, &config);
  return result;
 };
 fonts_[0] = add(kFredokaRegular, sizeof(kFredokaRegular));
 fonts_[1] = add(kFredokaMedium, sizeof(kFredokaMedium));
 fonts_[2] = add(kFredokaSemiBold, sizeof(kFredokaSemiBold));
 static const ImWchar iconRanges[]={0xea38,0xea38,0xea9a,0xea9a,0xeb1c,0xeb1c,0xeb8e,0xeb8e,0xec82,0xec82,0xef68,0xef68,0xf132,0xf132,0xf910,0xf910,0};
 config.MergeMode=false;icons_=atlas.AddFontFromMemoryTTF(const_cast<unsigned char*>(kTablerIcons),sizeof(kTablerIcons),18.f,&config,iconRanges);
 for(int i=0;i<3;++i){asciiComplete_[i]=fonts_[i]!=nullptr;for(int c=32;c<127&&asciiComplete_[i];++c)asciiComplete_[i]=fonts_[i]->IsGlyphInFont(static_cast<ImWchar>(c));}
 if (Get()) ImGui::GetIO().FontDefault = Get();
 return fonts_[0] && fonts_[1] && fonts_[2] && icons_;
}
bool FontManager::PlainAscii(std::string_view text,FontWeight weight) const {
 if(!asciiComplete_[static_cast<int>(weight)])return false;
 for(const unsigned char c:text)if((c<32||c>=127)&&c!='\n'&&c!='\r'&&c!='\t')return false;
 return true;
}
std::string FontManager::ResolveText(std::string_view text, FontWeight weight) const {
 ImFont* font = Get(weight);
 if (!font || text.empty()) return {};
 if(PlainAscii(text,weight))return std::string(text);
 const int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), nullptr, 0);
 if (!count) return "?";
 std::wstring source(count, L'\0'), resolved;
 MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), source.data(), count);
 for (size_t i=0; i<source.size(); ++i) {
  const wchar_t character=source[i];
  if (character==L'\n' || character==L'\r' || character==L'\t' || font->IsGlyphInFont(static_cast<ImWchar>(character))) {
   resolved+=character; continue;
  }
  // A UTF-16 surrogate pair is one unsupported character, not two question marks.
  if (character>=0xD800 && character<=0xDBFF && i+1<source.size() && source[i+1]>=0xDC00 && source[i+1]<=0xDFFF) {
   ++i; resolved+=L'?'; continue;
  }
  if (character==L'\x0131' && font->IsGlyphInFont('i')) { resolved+=L'i'; continue; }
  wchar_t decomposed[16]{};
  const int length=FoldStringW(MAP_COMPOSITE, &character, 1, decomposed, 16);
  std::wstring replacement;
  bool supported=length>0;
  for (int j=0;j<length;++j) {
   WORD type=0;
   GetStringTypeW(CT_CTYPE3,&decomposed[j],1,&type);
   if (type & (C3_NONSPACING|C3_DIACRITIC|C3_VOWELMARK)) continue;
   if (!font->IsGlyphInFont(static_cast<ImWchar>(decomposed[j]))) { supported=false; break; }
   replacement+=decomposed[j];
  }
  if (supported && !replacement.empty()) resolved+=replacement;
  else resolved+=L'?';
 }
 const int bytes=WideCharToMultiByte(CP_UTF8,0,resolved.data(),static_cast<int>(resolved.size()),nullptr,0,nullptr,nullptr);
 std::string result(bytes,'\0');
 if(bytes) WideCharToMultiByte(CP_UTF8,0,resolved.data(),static_cast<int>(resolved.size()),result.data(),bytes,nullptr,nullptr);
 return result;
}
ImVec2 FontManager::Measure(std::string_view text, float size, FontWeight weight) const {
 if (!Get(weight) || text.empty()) return {};
 std::string resolved;
 if(!PlainAscii(text,weight)){resolved=ResolveText(text,weight);text=resolved;}
 return Get(weight)->CalcTextSizeA(size, FLT_MAX, 0.f, text.data(), text.data()+text.size());
}
void FontManager::Draw(ImDrawList& list, std::string_view text, ImVec2 pos,
                       float size, ImU32 color, FontWeight weight) const {
 if (Get(weight) && !text.empty()) {
  std::string resolved;
  if(!PlainAscii(text,weight)){resolved=ResolveText(text,weight);text=resolved;}
  list.AddText(Get(weight),size,pos,color,text.data(),text.data()+text.size());
 }
}
}
