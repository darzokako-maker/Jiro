#include "client/Logger.hpp"
#include "client/ClassJarDumper.hpp"
#include "client/LwjglEnvHook.hpp"
#include "client/OffsetRepository.hpp"
#include "client/NativeScheduler.hpp"
#include "asm/AsmJvm.hpp"
#include "render/GlDiagnostics.hpp"

#include <Windows.h>
#include <process.h>
#include <roapi.h>

#include <cerrno>

using RtlPcToFileHeaderFunction = PVOID(NTAPI*)(PVOID, PVOID*);
struct ManualMapRuntimeContext {
    BYTE* imageBase;
    SIZE_T imageSize;
    RtlPcToFileHeaderFunction originalPcToFileHeader;
};

extern "C" {
__declspec(dllexport) ManualMapRuntimeContext AokiManualMapContext{};

__declspec(dllexport) PVOID NTAPI AokiRtlPcToFileHeader(
    PVOID programCounter, PVOID* imageBase)
{
    const auto address = reinterpret_cast<ULONG_PTR>(programCounter);
    const auto base = reinterpret_cast<ULONG_PTR>(AokiManualMapContext.imageBase);
    if (base && address >= base && address - base < AokiManualMapContext.imageSize) {
        if (imageBase) *imageBase = AokiManualMapContext.imageBase;
        return AokiManualMapContext.imageBase;
    }
    if (AokiManualMapContext.originalPcToFileHeader)
        return AokiManualMapContext.originalPcToFileHeader(programCounter, imageBase);
    if (imageBase) *imageBase = nullptr;
    return nullptr;
}
}

namespace {

constexpr DWORD kBootstrapTimeoutMs = 5000;

volatile LONG g_state = 0; // 0=stopped, 1=starting, 2=running
volatile LONG g_bootstrapResult = ERROR_GEN_FAILURE;
HANDLE g_readyEvent = nullptr;
HANDLE g_shutdownEvent = nullptr;
HANDLE g_workerThread = nullptr;

void PublishResult(DWORD result)
{
    InterlockedExchange(&g_bootstrapResult, static_cast<LONG>(result));
    SetEvent(g_readyEvent);
}

DWORD BootstrapThreadBody()
{
    const HRESULT apartment = RoInitialize(RO_INIT_MULTITHREADED);
    if (FAILED(apartment)) {
        PublishResult(static_cast<DWORD>(apartment));
        return static_cast<DWORD>(apartment);
    }

    DWORD result = 0;
    try {
#if defined(AOKI_ENABLE_LOGGING)
#if defined(AOKI_ENV_PROBE_ONLY)
        AOKI_LOG("[Probe] bootstrap: isolated probe only");
        AOKI_LOG("[CLASS-JAR] probe-only build; all other client startup is disabled");
#else
        {
            HMODULE module = nullptr;
            wchar_t modulePath[MAX_PATH]{};
            if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                    GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                    reinterpret_cast<LPCWSTR>(&AokiManualMapContext), &module) && module)
                GetModuleFileNameW(module, modulePath, MAX_PATH);
            AOKI_LOG("[ESP-DEBUG] dll: path=%ls imageBase=%p build=%s %s",
                modulePath[0] ? modulePath : L"(manual-mapped: file path unavailable)",
                AokiManualMapContext.imageBase, __DATE__, __TIME__);
            const auto profile = client::offsets::Get();
            AOKI_LOG("[ESP-DEBUG] jvm: profile=%s", profile ? profile->id.c_str() : "unavailable");
            AOKI_LOG("[ESP-DEBUG] asm: kernel selftest=%s", client::asm_jvm::SelfTest() ? "PASS" : "FAIL");
        }
#endif
#endif
#if !defined(AOKI_ENV_PROBE_ONLY)
        client::render::diagnostics::RegisterImage(AokiManualMapContext.imageBase,AokiManualMapContext.imageSize);
#endif
#if defined(AOKI_ENV_PROBE_ONLY)
        if (!client::lwjgl_env_hook::Install()) {
            AOKI_LOG("error: probe hook installation failed");
            result = ERROR_DLL_INIT_FAILED;
        }
#else
        if (!client::lwjgl_env_hook::Install()) {
            AOKI_LOG("error: hook installation failed");
            result = ERROR_DLL_INIT_FAILED;
        }
#endif
    } catch (...) {
        result = ERROR_UNHANDLED_EXCEPTION;
    }

    PublishResult(result);
    if (result == 0) {
        // Keep the MTA alive for COM/WinRT objects owned by this worker. Manual
        // mapped modules stay resident until process exit unless explicitly stopped.
        client::scheduler::Run(g_shutdownEvent);
    }
    RoUninitialize();
    return result;
}

unsigned __stdcall BootstrapThread(void*)
{
    DWORD result = ERROR_UNHANDLED_EXCEPTION;
    __try {
        result = BootstrapThreadBody();
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        result = static_cast<DWORD>(GetExceptionCode());
        if (WaitForSingleObject(g_readyEvent, 0) != WAIT_OBJECT_0)
            PublishResult(result);
    }
    return result;
}

void CloseBootstrapHandles()
{
    if (g_workerThread) { CloseHandle(g_workerThread); g_workerThread = nullptr; }
    if (g_shutdownEvent) { CloseHandle(g_shutdownEvent); g_shutdownEvent = nullptr; }
    if (g_readyEvent) { CloseHandle(g_readyEvent); g_readyEvent = nullptr; }
}

} // namespace

extern "C" __declspec(dllexport) DWORD WINAPI AokiInitialize([[maybe_unused]] const wchar_t* logPath)
{
    if (InterlockedCompareExchange(&g_state, 1, 0) != 0)
        return ERROR_ALREADY_INITIALIZED;

    AOKI_LOG_INITIALIZE(logPath);
    client::class_jar::ConfigureOutputPath(logPath);

    g_readyEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    g_shutdownEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!g_readyEvent || !g_shutdownEvent) {
        const DWORD error = GetLastError();
        CloseBootstrapHandles();
        InterlockedExchange(&g_state, 0);
        return error ? error : ERROR_NOT_ENOUGH_MEMORY;
    }

    InterlockedExchange(&g_bootstrapResult, static_cast<LONG>(ERROR_GEN_FAILURE));
    const uintptr_t thread = _beginthreadex(
        nullptr, 0, &BootstrapThread, nullptr, 0, nullptr);
    if (!thread) {
        const DWORD error = errno ? static_cast<DWORD>(errno) : GetLastError();
        CloseBootstrapHandles();
        InterlockedExchange(&g_state, 0);
        return error ? error : ERROR_NOT_ENOUGH_MEMORY;
    }
    g_workerThread = reinterpret_cast<HANDLE>(thread);

    const DWORD wait = WaitForSingleObject(g_readyEvent, kBootstrapTimeoutMs);
    DWORD result = static_cast<DWORD>(InterlockedCompareExchange(
        &g_bootstrapResult, 0, 0));
    if (wait != WAIT_OBJECT_0)
        result = wait == WAIT_TIMEOUT ? ERROR_TIMEOUT : GetLastError();

    if (result != 0) {
        SetEvent(g_shutdownEvent);
        const DWORD stopped = WaitForSingleObject(g_workerThread, kBootstrapTimeoutMs);
        if (stopped == WAIT_OBJECT_0) {
            CloseBootstrapHandles();
            InterlockedExchange(&g_state, 0);
        } else {
            // Preserve the handles and reject another start while the first
            // worker may still be executing mapped code.
            InterlockedExchange(&g_state, 2);
        }
        return result;
    }

    InterlockedExchange(&g_state, 2);
    return 0;
}

extern "C" __declspec(dllexport) DWORD WINAPI AokiShutdown(void*)
{
    if (InterlockedCompareExchange(&g_state, 1, 2) != 2)
        return ERROR_INVALID_STATE;
    SetEvent(g_shutdownEvent);
    const DWORD wait = WaitForSingleObject(g_workerThread, kBootstrapTimeoutMs);
    if (wait != WAIT_OBJECT_0) {
        InterlockedExchange(&g_state, 2);
        return wait == WAIT_TIMEOUT ? ERROR_TIMEOUT : GetLastError();
    }
    CloseBootstrapHandles();
    InterlockedExchange(&g_state, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE, DWORD, LPVOID)
{
    return TRUE;
}
