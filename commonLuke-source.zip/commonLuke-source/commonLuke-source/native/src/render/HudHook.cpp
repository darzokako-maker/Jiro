#include "client/HudHook.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "render/Renderer.hpp"
#include "render/GlDiagnostics.hpp"
#include "client/LwjglEnvHook.hpp"
#include "features/visual/esp/EspCapture.hpp"
#include "features/visual/xray/Xray.hpp"
#include "features/visual/target_hud/TargetHud.hpp"
#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/dragon_wings/DragonWingsCapture.hpp"
#include "features/visual/ambiance/ParticleLyrics.hpp"
#include "features/movement/clips/ClipsCapture.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "ui/input/KeybindManager.hpp"
#include "ui/hud/HudState.hpp"
#include "game/MappingRepository.hpp"
#include <MinHook.h>
#include <atomic>
#include <algorithm>
#include <chrono>

namespace {
using Swap = void (*)(void*);

Swap originalSwap = nullptr;
std::atomic<HGLRC> gameContext{nullptr};
#if !defined(AOKI_DISTRIBUTION)
void RecordCost(double capture,double render,double wings) {
 static double captureTotal=0,renderTotal=0,capturePeak=0,renderPeak=0,wingsTotal=0,wingsPeak=0;
 static unsigned frames=0;
 static auto interval=std::chrono::steady_clock::now();
 captureTotal+=capture;renderTotal+=render;capturePeak=std::max(capturePeak,capture);renderPeak=std::max(renderPeak,render);++frames;
 wingsTotal+=wings;wingsPeak=std::max(wingsPeak,wings);
 const auto now=std::chrono::steady_clock::now();
 if(now-interval<std::chrono::seconds(10))return;
 AOKI_LOG("[Perf] frames=%u ESP/Clips capture CPU avg=%.3fms peak=%.3fms; HUD/GUI submit CPU avg=%.3fms peak=%.3fms; DragonWings CPU avg=%.3fms peak=%.3fms (GPU time excluded)",
  frames,captureTotal/frames,capturePeak,renderTotal/frames,renderPeak,wingsTotal/frames,wingsPeak);
 captureTotal=renderTotal=capturePeak=renderPeak=wingsTotal=wingsPeak=0;frames=0;interval=now;
}
#endif
struct GameInputState {bool allowed=false,chat=false,screen=false;};
GameInputState ReadGameInputState(JNIEnv* env) {
 if(!env||env->ExceptionCheck()||env->PushLocalFrame(16)!=JNI_OK)return {};
 const auto mc=client::mapping::StaticObject(env,"Minecraft.theMinecraft");
 const auto player=mc?client::mapping::Object(env,mc,"Minecraft.thePlayer"):nullptr;
 const auto screen=mc?client::mapping::Object(env,mc,"Minecraft.currentScreen"):nullptr;
 static bool namePublished=false;
 static client::scheduler::Cursor nameCursor;
 const bool readName=player&&client::ui::input::IsOpen();
 client::scheduler::Configure(client::scheduler::Task::HudPlayerName,readName,1000);
 if(!player) {
  if(namePublished)client::ui::PublishHudPlayerName({});
  namePublished=false;
 } else if(readName&&(!namePublished||client::scheduler::Consume(
    client::scheduler::Task::HudPlayerName,nameCursor))) {
  client::ui::PublishHudPlayerName(client::mapping::String(env,player,"Entity.getName").value_or(""));
  namePublished=true;
 }
 const bool allowed=player&&client::mapping::Object(env,mc,"Minecraft.theWorld")&&
  !screen&&
  !client::mapping::Read<bool>(player,"Entity.isDead").value_or(true);
 const bool chat=screen&&client::mapping::Instance(screen,"GuiChat");
 env->PopLocalFrame(nullptr);return {allowed,chat,screen!=nullptr};
}

void HookedSwap(void* window)
{
    const HGLRC context = gameContext.load();
    if (context && wglGetCurrentContext() == context) {
        client::render::diagnostics::Install();
        client::render::diagnostics::Scope trace("glfwSwapBuffers / Aoki");
        RECT rectangle{};
        const HWND handle = WindowFromDC(wglGetCurrentDC());
        if (handle && GetClientRect(handle, &rectangle)) {
            client::ui::input::Install(handle,window);
#if !defined(AOKI_DISTRIBUTION)
            const auto start=std::chrono::steady_clock::now();
#endif
            const auto env=client::lwjgl_env_hook::CurrentEnvironment();
            const auto gameInput=ReadGameInputState(env);
            client::ui::SetChatOpen(gameInput.chat);
            client::ui::SetScreenOpen(gameInput.screen);
            client::ui::input::Poll();
            const auto& input=client::ui::input::State();
            const bool allowed=input.focused&&!client::ui::input::IsOpen()&&!client::ui::input::MenuTogglePending()&&
             gameInput.allowed;
            client::ui::bindings::Update(input,allowed,client::scheduler::Now());
            using client::scheduler::Task;
            static client::scheduler::Cursor espCursor,targetCursor,inventoryCursor,xrayCursor;
            client::scheduler::Configure(Task::EspCapture,true,1);
            client::scheduler::Configure(Task::TargetHudCapture,true,1);
            client::scheduler::Configure(Task::InventoryCapture,true,75);
            client::scheduler::Configure(Task::XrayCapture,true,1);
            if(client::scheduler::Consume(Task::EspCapture,espCursor))
                client::features::esp::Capture(env,rectangle.right,rectangle.bottom);
            if(client::scheduler::Consume(Task::TargetHudCapture,targetCursor))
                client::features::targethud::Capture(env,rectangle.right,rectangle.bottom);
            if(client::scheduler::Consume(Task::InventoryCapture,inventoryCursor))
                client::features::inventory_hud::Capture(env,rectangle.right,rectangle.bottom);
            if(client::scheduler::Consume(Task::XrayCapture,xrayCursor))
                client::features::xray::Capture(env,rectangle.right,rectangle.bottom);
            client::features::seeddumper::Capture(env);
#if !defined(AOKI_DISTRIBUTION)
            const auto captured=std::chrono::steady_clock::now();
#endif
            client::render::RenderHud(rectangle.right, rectangle.bottom);
#if !defined(AOKI_DISTRIBUTION)
            const auto submitted=std::chrono::steady_clock::now();
            RecordCost(std::chrono::duration<double,std::milli>(captured-start).count(),std::chrono::duration<double,std::milli>(submitted-captured).count(),client::features::wings::FrameMilliseconds());
#endif
        }
        client::render::diagnostics::Flush();
        client::features::wings::Present();
        client::features::ambiance::Lyrics3DPresent();
    }
    originalSwap(window);
}
}

namespace client::hud {
bool CaptureContext()
{
    HGLRC expected = nullptr;
    const HGLRC current = wglGetCurrentContext();
    if (current) {
        gameContext.compare_exchange_strong(expected, current);
        if(gameContext.load()==current){render::diagnostics::Install();return true;}
    }
    return false;
}

bool Install()
{
    void* target = nullptr;
    for (const wchar_t* name : {L"glfw.dll", L"glfw3.dll", L"lwjgl_glfw.dll"}) {
        const HMODULE module = GetModuleHandleW(name);
        if (module) target = reinterpret_cast<void*>(GetProcAddress(module, "glfwSwapBuffers"));
        if (target) break;
    }
    if (!target) {
        AOKI_LOG("HUD: glfwSwapBuffers export not found; HUD hook not installed");
        return false;
    }
    const MH_STATUS created = MH_CreateHook(target, reinterpret_cast<void*>(&HookedSwap),
        reinterpret_cast<void**>(&originalSwap));
    if (created != MH_OK) {
        AOKI_LOG("HUD: MH_CreateHook failed: %d", static_cast<int>(created));
        return false;
    }
    const MH_STATUS enabled = MH_EnableHook(target);
    if (enabled != MH_OK) {
        MH_RemoveHook(target);
        AOKI_LOG("HUD: MH_EnableHook failed: %d", static_cast<int>(enabled));
        return false;
    }
    AOKI_LOG("HUD: glfwSwapBuffers hook installed at %p", target);
    return true;
}
}

