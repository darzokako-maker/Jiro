#include "render/LegacyGuiState.hpp"
#include "render/GlDiagnostics.hpp"

namespace client::render {
LegacyGuiState::LegacyGuiState() {
 diagnostics::Scope trace("LegacyGuiState.capture");
 glGetIntegerv(GL_MATRIX_MODE,&matrixMode_);
 glPushAttrib(GL_ALL_ATTRIB_BITS);
 gl.BindVertexArray(0);
 glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);
 BindClientArrays();
 glMatrixMode(GL_PROJECTION);glPushMatrix();
 glMatrixMode(GL_MODELVIEW);glPushMatrix();
}
void LegacyGuiState::BindClientArrays() {
 gl.BindVertexArray(0);
 gl.BindBuffer(0x8892,0); // GL_ARRAY_BUFFER: pointer arguments are CPU addresses.
 gl.BindBuffer(0x8893,0); // GL_ELEMENT_ARRAY_BUFFER belongs to VAO zero.
}
LegacyGuiState::~LegacyGuiState() {
 diagnostics::Scope trace("LegacyGuiState.restore");
 glMatrixMode(GL_MODELVIEW);glPopMatrix();
 glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(matrixMode_);
 // GL_COLOR_BUFFER_BIT/PIXEL_MODE_BIT restore draw/read selectors, but do not
 // restore FBO bindings. GL_BACK on an atlas FBO causes GL_INVALID_OPERATION.
 {diagnostics::Scope stage("Restore game framebuffers before glPopAttrib");saved_.RestoreFramebuffers();}
 gl.BindVertexArray(0);
 {diagnostics::Scope stage("glPopClientAttrib");glPopClientAttrib();}
 {diagnostics::Scope stage("glPopAttrib");glPopAttrib();}
 // saved_ restores the original VAO, buffers, program and other modern state.
}
}
