#include "render/GlApi.hpp"
#include "render/GlDiagnostics.hpp"
#include "client/Logger.hpp"
namespace client::render {
namespace {
PROC Resolve(const char* name) {
 const auto proc = wglGetProcAddress(name);
 const auto value = reinterpret_cast<ULONG_PTR>(proc);
 return value > 3 && value != static_cast<ULONG_PTR>(-1) ? proc : nullptr;
}
}
bool GlApi::Load() {
#define LOAD(returnType, name, args) name = reinterpret_cast<name##Fn>(Resolve("gl" #name)); if (!name) { AOKI_LOG("HUD: missing gl%s", #name); return false; }
 AOKI_GL_FUNCTIONS(LOAD)
#undef LOAD
 BindSampler = reinterpret_cast<decltype(BindSampler)>(Resolve("glBindSampler"));
 return true;
}
GlState::GlState(bool prepareUi) {
 diagnostics::Scope trace("GlState.capture");
 glGetIntegerv(0x8CA6, &draw); glGetIntegerv(0x8CAA, &read);
 gl.BindFramebuffer(DrawFramebuffer, 0); glGetIntegerv(GL_DRAW_BUFFER, &defaultDraw);
 gl.BindFramebuffer(ReadFramebuffer, 0); glGetIntegerv(GL_READ_BUFFER, &defaultRead);
 gl.BindFramebuffer(DrawFramebuffer, draw); gl.BindFramebuffer(ReadFramebuffer, read);
 glGetIntegerv(0x8B8D, &program); glGetIntegerv(0x85B5, &vao);
 glGetIntegerv(0x84E0, &active); glGetIntegerv(0x88EF, &unpack);
 glGetIntegerv(0x8894,&arrayBuffer);
 for (int i=0;i<2;++i) {
  gl.ActiveTexture(Texture0+i); glGetIntegerv(GL_TEXTURE_BINDING_2D,&textures[i]);
  if (gl.BindSampler) glGetIntegerv(0x8919,&samplers[i]);
 }
 gl.ActiveTexture(active);
 glGetIntegerv(GL_VIEWPORT,viewport); glGetIntegerv(GL_SCISSOR_BOX,scissor);
 glGetIntegerv(GL_POLYGON_MODE,polygon); glGetBooleanv(GL_COLOR_WRITEMASK,mask);
 glGetFloatv(GL_COLOR_CLEAR_VALUE,clearColor);
 glGetIntegerv(0x80C9,&srcRgb); glGetIntegerv(0x80C8,&dstRgb);
 glGetIntegerv(0x80CB,&srcAlpha); glGetIntegerv(0x80CA,&dstAlpha);
 glGetIntegerv(0x8009,&eqRgb); glGetIntegerv(0x883D,&eqAlpha);
 for (int i=0;i<10;++i) enabled[i]=glIsEnabled(caps[i]);
 GLint profile=0; glGetIntegerv(0x9126,&profile); compatibility=(profile&2)!=0;
 if(compatibility) { alphaTest=glIsEnabled(GL_ALPHA_TEST); if(prepareUi)glDisable(GL_ALPHA_TEST); }
 if(prepareUi){glDisable(GL_COLOR_LOGIC_OP); glDisable(0x809E);}
}
void GlState::RestoreFramebuffers() const {
 gl.BindFramebuffer(DrawFramebuffer,0); glDrawBuffer(defaultDraw);
 gl.BindFramebuffer(ReadFramebuffer,0); glReadBuffer(defaultRead);
 gl.BindFramebuffer(DrawFramebuffer,draw); gl.BindFramebuffer(ReadFramebuffer,read);
}
void GlState::RestoreTextures() const {
 for (int i=0;i<2;++i) {
  gl.ActiveTexture(Texture0+i); glBindTexture(GL_TEXTURE_2D,textures[i]);
  if (gl.BindSampler) gl.BindSampler(i,samplers[i]);
 }
 gl.ActiveTexture(active);
}
GlState::~GlState() {
 diagnostics::Scope trace("GlState.restore");
 RestoreFramebuffers();
 gl.UseProgram(program); gl.BindVertexArray(vao); gl.BindBuffer(0x88EC,unpack);
 gl.BindBuffer(0x8892,arrayBuffer);
 RestoreTextures();
 glViewport(viewport[0],viewport[1],viewport[2],viewport[3]);
 glScissor(scissor[0],scissor[1],scissor[2],scissor[3]);
 glPolygonMode(GL_FRONT_AND_BACK,polygon[0]);
 glColorMask(mask[0],mask[1],mask[2],mask[3]);
 glClearColor(clearColor[0],clearColor[1],clearColor[2],clearColor[3]);
 gl.BlendFuncSeparate(srcRgb,dstRgb,srcAlpha,dstAlpha);
 gl.BlendEquationSeparate(eqRgb,eqAlpha);
 for (int i=0;i<10;++i) { if (enabled[i]) glEnable(caps[i]); else glDisable(caps[i]); }
 if(compatibility) { if(alphaTest) glEnable(GL_ALPHA_TEST); else glDisable(GL_ALPHA_TEST); }
}
}
