#include "render/GlDiagnostics.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include <GL/gl.h>
#include <DbgHelp.h>
#include <array>
#include <atomic>
#include <cstring>
#include <intrin.h>

namespace client::render::diagnostics {
namespace {
using Callback=void(APIENTRY*)(GLenum,GLenum,GLuint,GLenum,GLsizei,const char*,const void*);
using SetCallback=void(APIENTRY*)(Callback,const void*);
using GetPointer=void(APIENTRY*)(GLenum,void**);
constexpr GLenum output=0x92E0,synchronous=0x8242,errorType=0x824C;
struct Trace {
 GLenum source{},severity{}; GLuint id{}; DWORD thread{}; unsigned occurrences=0;
 char message[512]{};
 std::array<void*,40> frames{}; USHORT depth=0;
 std::array<const char*,16> stages{}; unsigned stageCount=0;
 std::array<void*,16> stageCallSites{};
};
struct Seen {std::uint64_t hash=0; unsigned count=0; ULONGLONG last=0;};
std::array<Trace,16> pending;
std::array<Seen,64> seen;
Seen overflow;
unsigned pendingCount=0;
SRWLOCK queueLock=SRWLOCK_INIT;
std::atomic_flag inCallback=ATOMIC_FLAG_INIT;
std::atomic<std::uint64_t> errors{0};
std::atomic<std::uint32_t> lastDepth{0};
std::atomic<unsigned> dropped{0};
HGLRC context=nullptr;
DWORD owner=0;
const Scope* currentScope=nullptr;
SetCallback setCallback=nullptr;
GetPointer getPointer=nullptr;
Callback previous=nullptr;
const void* previousUser=nullptr;
bool attempted=false;
void* imageBase=nullptr;
std::size_t imageSize=0;
HANDLE symbols=nullptr;

PROC Resolve(const char* name) {
 const auto p=wglGetProcAddress(name);const auto n=reinterpret_cast<ULONG_PTR>(p);
 return n>3 && n!=static_cast<ULONG_PTR>(-1)?p:nullptr;
}
void APIENTRY OnMessage(GLenum source,GLenum type,GLuint id,GLenum severity,GLsizei length,const char* message,const void* user) {
 if(inCallback.test_and_set())return;
 if(type==errorType) {
  ++errors;
  Trace trace;trace.source=source;trace.severity=severity;trace.id=id;trace.thread=GetCurrentThreadId();
  if(message) {
   const auto size=length>0?static_cast<std::size_t>(length):std::strlen(message);
   std::memcpy(trace.message,message,(size<sizeof(trace.message)-1)?size:sizeof(trace.message)-1);
  }
  if(trace.thread==owner)for(auto* scope=currentScope;scope&&trace.stageCount<trace.stages.size();scope=scope->parent)
   {trace.stageCallSites[trace.stageCount]=scope->callSite;trace.stages[trace.stageCount++]=scope->label;}
  trace.depth=CaptureStackBackTrace(1,static_cast<DWORD>(trace.frames.size()),trace.frames.data(),nullptr);
  lastDepth=trace.depth;
  std::uint64_t hash=1469598103934665603ull;
  for(const auto* p=trace.message;*p;++p)hash=(hash^static_cast<unsigned char>(*p))*1099511628211ull;
  hash^=id;
  for(unsigned i=0;i<trace.stageCount;++i)hash=(hash^reinterpret_cast<std::uintptr_t>(trace.stages[i]))*1099511628211ull;
  // Some non-debug drivers return one generic message/id for all errors. Include
  // the native call site so unrelated errors in the same stage stay distinguishable.
  for(unsigned i=0;i<trace.depth;++i)hash=(hash^reinterpret_cast<std::uintptr_t>(trace.frames[i]))*1099511628211ull;
  if(!hash)hash=1;
  // No allocation, symbol engine, JVM calls, glGetError or blocking locks inside the driver.
  if(TryAcquireSRWLockExclusive(&queueLock)) {
   Seen* entry=nullptr;
   for(auto& item:seen)if(item.hash==hash){entry=&item;break;}
   if(!entry)for(auto& item:seen)if(!item.hash){entry=&item;item.hash=hash;break;}
   if(!entry)entry=&overflow;
   const auto now=client::scheduler::Now();
   ++entry->count;
   if(entry->count==1 || now-entry->last>=10000) {
    trace.occurrences=entry->count;
    if(pendingCount<pending.size()) {pending[pendingCount++]=trace;entry->last=now;}
    else ++dropped;
   }
   ReleaseSRWLockExclusive(&queueLock);
  } else ++dropped;
 }
 if(previous)previous(source,type,id,severity,length,message,previousUser);
 inCallback.clear();
 (void)user;
}
bool InitSymbols() {
 if(symbols)return true;
 HANDLE process=GetCurrentProcess();
 if(!DuplicateHandle(process,process,process,&symbols,0,FALSE,DUPLICATE_SAME_ACCESS))return false;
 // A private symbol session avoids sharing another component's DbgHelp session.
 SymSetOptions(SymGetOptions()|SYMOPT_LOAD_LINES|SYMOPT_UNDNAME|SYMOPT_FAIL_CRITICAL_ERRORS|SYMOPT_NO_PROMPTS);
 if(!SymInitialize(symbols,nullptr,FALSE)){CloseHandle(symbols);symbols=nullptr;return false;}
 if(imageBase && imageSize) {
#ifdef AOKI_IMAGE_PATH
  const auto loaded=SymLoadModuleEx(symbols,nullptr,AOKI_IMAGE_PATH,"commonLuke",reinterpret_cast<DWORD64>(imageBase),static_cast<DWORD>(imageSize),nullptr,0);
  AOKI_LOG("[GLTrace] Aoki symbols: %s; image=%p size=%zu",loaded?"loaded":"unavailable (module+offset still recorded)",imageBase,imageSize);
#endif
 }
 return true;
}
void PrintFrame(unsigned index,void* frame) {
 const auto address=reinterpret_cast<DWORD64>(frame);
 char path[MAX_PATH]{};HMODULE module=nullptr;
 const bool own=imageBase && address>=reinterpret_cast<DWORD64>(imageBase) && address-reinterpret_cast<DWORD64>(imageBase)<imageSize;
 DWORD64 base=own?reinterpret_cast<DWORD64>(imageBase):0;
 if(!own && GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCSTR>(frame),&module)) {
  base=reinterpret_cast<DWORD64>(module);GetModuleFileNameA(module,path,MAX_PATH);
  if(symbols && !SymGetModuleBase64(symbols,address))SymLoadModuleEx(symbols,nullptr,path,nullptr,base,0,nullptr,0);
 }
 const char* name=own?"commonLuke.dll":std::strrchr(path,'\\');name=own?name:name?name+1:*path?path:"JIT/unknown";
 alignas(SYMBOL_INFO) char buffer[sizeof(SYMBOL_INFO)+MAX_SYM_NAME]{};
 auto* symbol=reinterpret_cast<SYMBOL_INFO*>(buffer);symbol->SizeOfStruct=sizeof(SYMBOL_INFO);symbol->MaxNameLen=MAX_SYM_NAME;
 DWORD64 displacement=0;
 if(symbols && SymFromAddr(symbols,address,&displacement,symbol)) {
  IMAGEHLP_LINE64 line{};line.SizeOfStruct=sizeof(line);DWORD lineOffset=0;
  if(SymGetLineFromAddr64(symbols,address,&lineOffset,&line))
   AOKI_LOG("[GLTrace]   #%02u %s+0x%llx  %s+0x%llx (%s:%lu)",index,name,address-base,symbol->Name,displacement,line.FileName,line.LineNumber);
  else AOKI_LOG("[GLTrace]   #%02u %s+0x%llx  %s+0x%llx",index,name,address-base,symbol->Name,displacement);
 } else AOKI_LOG("[GLTrace]   #%02u %s+0x%llx [%p]",index,name,base?address-base:address,frame);
}
}
__declspec(noinline) Scope::Scope(const char* value):label(value),callSite(_ReturnAddress()) {
 active=GetCurrentThreadId()==owner;
 if(active){parent=currentScope;currentScope=this;}
}
Scope::~Scope(){if(active)currentScope=parent;}
void RegisterImage(void* base,std::size_t size){imageBase=base;imageSize=size;}
bool Install() {
 const auto current=wglGetCurrentContext();if(!current)return false;
 if(attempted && current!=context)return false; // One captured game context, never other app contexts.
 if(!attempted) {
  attempted=true;context=current;owner=GetCurrentThreadId();
  setCallback=reinterpret_cast<SetCallback>(Resolve("glDebugMessageCallback"));
  getPointer=reinterpret_cast<GetPointer>(Resolve("glGetPointerv"));
  if(!getPointer)getPointer=reinterpret_cast<GetPointer>(GetProcAddress(GetModuleHandleW(L"opengl32.dll"),"glGetPointerv"));
  GLint major=0,minor=0;glGetIntegerv(0x821B,&major);glGetIntegerv(0x821C,&minor);
  bool supported=major>4||(major==4&&minor>=3);
  if(!supported) {
   using GetStringi=const GLubyte*(APIENTRY*)(GLenum,GLuint);
   auto getStringi=reinterpret_cast<GetStringi>(Resolve("glGetStringi"));GLint count=0;
   if(getStringi){glGetIntegerv(0x821D,&count);for(GLint i=0;i<count;++i)if(std::strcmp(reinterpret_cast<const char*>(getStringi(0x1F03,i)),"GL_KHR_debug")==0)supported=true;}
  }
  if(!supported || !setCallback || !getPointer) {setCallback=nullptr;AOKI_LOG("[GLTrace] KHR_debug unavailable; driver call stacks cannot be captured");return false;}
  AOKI_LOG("[GLTrace] synchronous GL error tracing enabled; native stacks + render stages; duplicates limited to 10s. Java/JIT frames may be unresolved.");
 }
 if(!setCallback)return false;
 void* callback=nullptr;void* user=nullptr;
 getPointer(0x8244,&callback);getPointer(0x8245,&user);
 if(callback!=reinterpret_cast<void*>(&OnMessage)) {
  previous=reinterpret_cast<Callback>(callback);previousUser=user;setCallback(&OnMessage,nullptr);
  using Control=void(APIENTRY*)(GLenum,GLenum,GLenum,GLsizei,const GLuint*,GLboolean);
  if(auto control=reinterpret_cast<Control>(Resolve("glDebugMessageControl")))control(0x1100,errorType,0x1100,0,nullptr,GL_TRUE);
 }
 if(!glIsEnabled(output))glEnable(output);
 if(!glIsEnabled(synchronous))glEnable(synchronous);
 return true;
}
void Flush() {
 std::array<Trace,16> traces;unsigned count;
 AcquireSRWLockExclusive(&queueLock);count=pendingCount;
 for(unsigned i=0;i<count;++i)traces[i]=pending[i];pendingCount=0;
 ReleaseSRWLockExclusive(&queueLock);
 if(count)InitSymbols();
 for(unsigned i=0;i<count;++i) {
  const auto& t=traces[i];
  AOKI_LOG("[GLTrace] ERROR id=%u source=0x%x severity=0x%x thread=%lu occurrences=%u: %s",t.id,t.source,t.severity,t.thread,t.occurrences,t.message);
  AOKI_LOG("[GLTrace] stage tree (outer -> inner):");
  if(!t.stageCount)AOKI_LOG("[GLTrace]   Game / outside Aoki render scopes");
  for(unsigned j=t.stageCount;j>0;--j)AOKI_LOG("[GLTrace]   %*s%s",static_cast<int>((t.stageCount-j)*2),"",t.stages[j-1]);
  for(unsigned j=0;j<t.depth;++j)PrintFrame(j,t.frames[j]);
  if(!t.depth) {
   AOKI_LOG("[GLTrace] native unwind returned no frames; render-scope call sites follow (not the driver's full call stack):");
   for(unsigned j=0;j<t.stageCount;++j)if(t.stageCallSites[j])PrintFrame(j,t.stageCallSites[j]);
  }
 }
 if(const auto lost=dropped.exchange(0))AOKI_LOG("[GLTrace] dropped %u traces while busy; total GL errors=%llu",lost,errors.load());
}
std::uint64_t ErrorCount(){return errors.load();}
std::uint32_t LastStackDepth(){return lastDepth.load();}
}
