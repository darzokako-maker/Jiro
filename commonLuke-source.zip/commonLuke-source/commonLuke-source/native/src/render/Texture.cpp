#include "render/Texture.hpp"
#include <wincodec.h>
#include <wrl/client.h>
#include <vector>

namespace client::render {
GLuint UploadRgba(std::span<const unsigned char> pixels,int width,int height) {
 if(width<=0||height<=0||width>4096||height>4096||pixels.size()!=static_cast<std::size_t>(width)*height*4)return 0;
 GLint previous=0,unpack=0,values[4]{};
 constexpr GLenum stores[]={GL_UNPACK_ALIGNMENT,GL_UNPACK_ROW_LENGTH,GL_UNPACK_SKIP_PIXELS,GL_UNPACK_SKIP_ROWS};
 glGetIntegerv(GL_TEXTURE_BINDING_2D,&previous);glGetIntegerv(0x88EF,&unpack);
 for(int i=0;i<4;++i)glGetIntegerv(stores[i],&values[i]);
 gl.BindBuffer(0x88EC,0);
 for(int i=0;i<4;++i)glPixelStorei(stores[i],i==0?1:0);
 GLuint texture=0;glGenTextures(1,&texture);glBindTexture(GL_TEXTURE_2D,texture);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,0x812F);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,0x812F);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels.data());
 glBindTexture(GL_TEXTURE_2D,previous);gl.BindBuffer(0x88EC,unpack);
 for(int i=0;i<4;++i)glPixelStorei(stores[i],values[i]);
 return texture;
}
DecodedImage DecodeImageRgba(std::span<const unsigned char> bytes) {
 DecodedImage image;if(bytes.empty()||bytes.size()>MAXDWORD)return image;
 const HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
 using Microsoft::WRL::ComPtr;
 ComPtr<IWICImagingFactory> factory;ComPtr<IWICStream> stream;ComPtr<IWICBitmapDecoder> decoder;
 ComPtr<IWICBitmapFrameDecode> frame;ComPtr<IWICFormatConverter> converter;
 bool ok=SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory)));
 ok=ok&&SUCCEEDED(factory->CreateStream(&stream));
 ok=ok&&SUCCEEDED(stream->InitializeFromMemory(const_cast<BYTE*>(bytes.data()),static_cast<DWORD>(bytes.size())));
 ok=ok&&SUCCEEDED(factory->CreateDecoderFromStream(stream.Get(),nullptr,WICDecodeMetadataCacheOnLoad,&decoder));
 ok=ok&&SUCCEEDED(decoder->GetFrame(0,&frame));ok=ok&&SUCCEEDED(factory->CreateFormatConverter(&converter));
 ok=ok&&SUCCEEDED(converter->Initialize(frame.Get(),GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom));
 UINT width=0,height=0;if(ok)ok=SUCCEEDED(converter->GetSize(&width,&height))&&width&&height&&width<=4096&&height<=4096;
 if(ok) {
  image.pixels.resize(width*height*4);
  if(SUCCEEDED(converter->CopyPixels(nullptr,width*4,static_cast<UINT>(image.pixels.size()),image.pixels.data()))) {image.width=static_cast<int>(width);image.height=static_cast<int>(height);}
  else image.pixels.clear();
 }
 converter.Reset();frame.Reset();decoder.Reset();stream.Reset();factory.Reset();if(SUCCEEDED(com))CoUninitialize();
 return image;
}
GLuint LoadPngTexture(std::span<const unsigned char> bytes) {
 const auto image=DecodeImageRgba(bytes);
 return UploadRgba(image.pixels,image.width,image.height);
}
}
