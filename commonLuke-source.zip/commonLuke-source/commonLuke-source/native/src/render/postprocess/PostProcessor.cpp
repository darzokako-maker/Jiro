#include "render/postprocess/PostProcessor.hpp"
#include "render/GlDiagnostics.hpp"
#include "client/Logger.hpp"
#include "ui/clickgui/ReferencePrimitives.hpp"
#include <imgui_impl_opengl3.h>
#include <cmath>
#include <algorithm>

namespace client::render {
namespace {
constexpr const char* vertex = R"(#version 130
out vec2 uv;
void main() {
 vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));
 uv=p;
 gl_Position=vec4(p*2.0-1.0,0.0,1.0);
})";
// Harakiri blur.frag / bloom.frag math, adapted to GLSL 130 and two samplers.
// The reference's kernel has radius entries but samples <=radius. We explicitly
// supply a zero endpoint. Guard bloom's zero-alpha divide on transparent pixels.
constexpr const char* fragment = R"(#version 130
in vec2 uv;
out vec4 result;
uniform sampler2D sourceTexture, maskTexture;
uniform vec2 texel, direction;
uniform int radius, bloomMode;
uniform float weights[15];
uniform float bloomStrength;
void main() {
 bool vertical=direction.x==0.0;
 float maskAlpha=texture(maskTexture,uv).a;
 if (vertical && ((bloomMode==0 && maskAlpha==0.0) ||
                  (bloomMode==1 && maskAlpha>0.0))) discard;
 vec4 center=texture(sourceTexture,uv);
 vec4 color=center*weights[0];
 if (bloomMode==1) color.rgb*=color.a;
 for(int i=0;i<=14;++i) {
  if (i>radius) break;
  if (bloomMode==0 && i==0) continue;
  vec2 offset=float(i)*texel*direction;
  vec4 a=texture(sourceTexture,uv-offset), b=texture(sourceTexture,uv+offset);
  if(bloomMode==1) { a.rgb*=a.a; b.rgb*=b.a; }
  color+=(a+b)*weights[i];
 }
 if(bloomMode==1) result=vec4(color.a>0.000001?color.rgb/color.a:vec3(0.0),color.a*(vertical?bloomStrength:1.0));
 else result=vec4(color.rgb,vertical?maskAlpha:1.0);
})";
GLuint Compile(GLenum type, const char* source) {
 const GLuint shader=gl.CreateShader(type);
 gl.ShaderSource(shader,1,&source,nullptr); gl.CompileShader(shader);
 GLint ok=0; gl.GetShaderiv(shader,0x8B81,&ok);
 if(!ok) {
  char message[2048]{}; gl.GetShaderInfoLog(shader,sizeof(message),nullptr,message);
  AOKI_LOG("HUD shader compile: %s",message); gl.DeleteShader(shader); return 0;
 }
 return shader;
}
}
bool PostProcessor::Initialize() {
 diagnostics::Scope trace("PostProcessor.initialize");
 const GLuint vs=Compile(0x8B31,vertex), fs=Compile(0x8B30,fragment);
 if (!vs || !fs) { if(vs) gl.DeleteShader(vs); if(fs) gl.DeleteShader(fs); return false; }
 program_=gl.CreateProgram(); gl.AttachShader(program_,vs); gl.AttachShader(program_,fs);
 gl.LinkProgram(program_); gl.DeleteShader(vs); gl.DeleteShader(fs);
 GLint ok=0; gl.GetProgramiv(program_,0x8B82,&ok);
 if(!ok) {
  char message[2048]{}; gl.GetProgramInfoLog(program_,sizeof(message),nullptr,message);
  AOKI_LOG("HUD shader link: %s",message); Shutdown(); return false;
 }
 gl.GenVertexArrays(1,&vao_);
 uniforms_={gl.GetUniformLocation(program_,"sourceTexture"),gl.GetUniformLocation(program_,"maskTexture"),
  gl.GetUniformLocation(program_,"radius"),gl.GetUniformLocation(program_,"bloomMode"),gl.GetUniformLocation(program_,"bloomStrength"),
  gl.GetUniformLocation(program_,"texel"),gl.GetUniformLocation(program_,"direction"),gl.GetUniformLocation(program_,"weights")};
 auto kernel=[](std::array<float,15>& values,int radius) {
  float sum=0;const float sigma=radius/2.f;
  for(int i=0;i<radius;++i){const float v=i/sigma;values[i]=std::exp(-.5f*v*v)/(sigma*2.50662827463f);sum+=values[i]*(i?2.f:1.f);}
  for(float& weight:values)weight/=sum;
 };
 kernel(blurKernel_,12);kernel(bloomKernel_,14);
 return true;
}
void PostProcessor::Panels(std::span<const RoundedPanel> panels,int mode) {
 if(panels.empty())return;
 diagnostics::Scope trace("PostProcessor.panels / ImGui submission");
 ImDrawList list(ImGui::GetDrawListSharedData());
 list._ResetForNewFrame();
 list.PushTexture(ImGui::GetIO().Fonts->TexRef);
 list.PushClipRect({0,0},{static_cast<float>(width_),static_cast<float>(height_)});
 for(const auto& p:panels) {
  if(mode==0&&!p.blur)continue;
  const ImVec2 a(p.x,p.y), b(p.x+p.width,p.y+p.height);
  ImU32 color=mode==0 ? IM_COL32_WHITE :mode==1 ? IM_COL32(0,0,0,100) : p.color;
  color=(color&0xffffff)|(static_cast<ImU32>((color>>24)*std::clamp(p.opacity,0.f,1.f))<<24);
  if(!ui::clickgui::ReferenceRectangle(list,a,p.width,p.height,p.radius,1.f,color))list.AddRectFilled(a,b,color,p.radius);
  if(mode==2&&p.border) list.AddRect({a.x+.5f,a.y+.5f},{b.x-.5f,b.y-.5f},
                          IM_COL32(255,255,255,static_cast<int>(24*std::clamp(p.opacity,0.f,1.f))),p.radius-.5f);
 }
 ImDrawData data;
 data.Valid=true; data.DisplayPos={0,0};
 data.DisplaySize={static_cast<float>(width_),static_cast<float>(height_)};
 data.FramebufferScale={1,1}; data.OwnerViewport=ImGui::GetMainViewport();
 data.Textures=&ImGui::GetPlatformIO().Textures;
 data.AddDrawList(&list);
 ImGui_ImplOpenGL3_RenderDrawData(&data);
}
void PostProcessor::DeleteTarget(Target& target) {
 if(target.fbo) gl.DeleteFramebuffers(1,&target.fbo);
 if(target.texture) glDeleteTextures(1,&target.texture);
 target={};
}
bool PostProcessor::MakeTarget(Target& target) {
 glGenTextures(1,&target.texture); glBindTexture(GL_TEXTURE_2D,target.texture);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,0x812F);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,0x812F);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width_,height_,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
 gl.GenFramebuffers(1,&target.fbo); gl.BindFramebuffer(DrawFramebuffer,target.fbo);
 gl.FramebufferTexture2D(DrawFramebuffer,0x8CE0,GL_TEXTURE_2D,target.texture,0);
 glDrawBuffer(0x8CE0);
 if(gl.CheckFramebufferStatus(DrawFramebuffer)!=0x8CD5) {
  AOKI_LOG("HUD: incomplete framebuffer %dx%d",width_,height_); return false;
 }
 return true;
}
bool PostProcessor::Resize(int width,int height) {
 diagnostics::Scope trace("PostProcessor.resize");
 if(width_==width && height_==height) return true;
 DeleteTarget(scene_); DeleteTarget(mask_); DeleteTarget(scratch_); DeleteTarget(bloom_);
 width_=width; height_=height;
 const bool ok=MakeTarget(scene_) && MakeTarget(mask_) && MakeTarget(scratch_) && MakeTarget(bloom_);
 if(!ok) { DeleteTarget(scene_); DeleteTarget(mask_); DeleteTarget(scratch_); DeleteTarget(bloom_); width_=height_=0; }
 return ok;
}
void PostProcessor::Pass(GLuint source,GLuint mask,GLuint output,int radius,
                         float x,float y,bool bloom,bool composite,std::span<const PixelRect> regions) {
 if(regions.empty())return;
 diagnostics::Scope trace(bloom?(x?"Bloom.horizontal":"Bloom.vertical"):(x?"Blur.horizontal":"Blur.vertical"));
 gl.BindFramebuffer(DrawFramebuffer,output); glViewport(0,0,width_,height_);
 glDisable(GL_DEPTH_TEST); glDisable(GL_STENCIL_TEST); glDisable(GL_CULL_FACE);
 glDisable(GL_SCISSOR_TEST); glDisable(0x8C89); glDisable(0x8F9D);
 if(composite) {
  glEnable(GL_BLEND); gl.BlendEquationSeparate(0x8006,0x8006);
  gl.BlendFuncSeparate(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
 } else glDisable(GL_BLEND);
 gl.UseProgram(program_); gl.BindVertexArray(vao_);
 gl.ActiveTexture(Texture0); glBindTexture(GL_TEXTURE_2D,source);
 gl.ActiveTexture(Texture1); glBindTexture(GL_TEXTURE_2D,mask);
 if(gl.BindSampler) { gl.BindSampler(0,0); gl.BindSampler(1,0); }
 gl.Uniform1i(uniforms_.source,0);gl.Uniform1i(uniforms_.mask,1);
 gl.Uniform1i(uniforms_.radius,radius);gl.Uniform1i(uniforms_.bloom,bloom?1:0);
 gl.Uniform1f(uniforms_.strength,2.2f);gl.Uniform2f(uniforms_.texel,1.f/width_,1.f/height_);
 gl.Uniform2f(uniforms_.direction,x,y);
 gl.Uniform1fv(uniforms_.weights,15,(bloom?bloomKernel_:blurKernel_).data());
 // Vertical bloom reads neighboring scratch pixels: untouched pixels must be
 // transparent rather than stale data from a previous region/frame.
 if(!composite)glClear(GL_COLOR_BUFFER_BIT);
 glEnable(GL_SCISSOR_TEST);
 for(const auto& region:regions){glScissor(region.x,height_-region.bottom,region.right-region.x,region.bottom-region.y);glDrawArrays(GL_TRIANGLES,0,3);}
 glDisable(GL_SCISSOR_TEST);
}
void PostProcessor::Render(ImDrawData* mask,ImDrawData* bloom,ImDrawData* foreground,std::span<const RoundedPanel> panels) {
 diagnostics::Scope trace("PostProcessor.render");
 glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
 glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 glDisable(GL_SCISSOR_TEST); glDisable(0x8DB9); glDisable(0x8C89); glDisable(0x8F9D);
 glClearColor(0,0,0,0);
 EffectRegion blurArea(width_,height_),shadowArea(width_,height_),textArea(width_,height_);
 blurArea.Add(mask,40);textArea.Add(bloom,32);
 for(const auto& panel:panels) {
  if(panel.blur)blurArea.Add(panel.x,panel.y,panel.x+panel.width,panel.y+panel.height,40);
  shadowArea.Add(panel.x,panel.y,panel.x+panel.width,panel.y+panel.height,32);
 }
 const bool hasBlur=std::any_of(panels.begin(),panels.end(),[](const RoundedPanel& p){return p.blur;})||(mask&&mask->TotalIdxCount>0);
 const bool hasBloom=bloom&&bloom->TotalIdxCount>0;
 const auto blurRegions=blurArea.Rectangles(restrictWork_),shadowRegions=shadowArea.Rectangles(restrictWork_),textRegions=textArea.Rectangles(restrictWork_);
 if(hasBlur) {
  gl.BindFramebuffer(ReadFramebuffer,0);glReadBuffer(GL_BACK);gl.BindFramebuffer(DrawFramebuffer,scene_.fbo);
  for(const auto& r:blurRegions)gl.BlitFramebuffer(r.x,height_-r.bottom,r.right,height_-r.y,r.x,height_-r.bottom,r.right,height_-r.y,GL_COLOR_BUFFER_BIT,GL_NEAREST);
  gl.BindFramebuffer(DrawFramebuffer,mask_.fbo);glClear(GL_COLOR_BUFFER_BIT);
  Panels(panels,0);ImGui_ImplOpenGL3_RenderDrawData(mask);
  Pass(scene_.texture,mask_.texture,scratch_.fbo,12,3.f,0.f,false,false,blurRegions);
  gl.BindFramebuffer(DrawFramebuffer,0);glDrawBuffer(GL_BACK);
  Pass(scratch_.texture,mask_.texture,0,12,0.f,3.f,false,true,blurRegions);
 }
 gl.BindFramebuffer(DrawFramebuffer,0); glDrawBuffer(GL_BACK);
 if(!panels.empty()) {
  gl.BindFramebuffer(DrawFramebuffer,bloom_.fbo); glClear(GL_COLOR_BUFFER_BIT);Panels(panels,1);
  Pass(bloom_.texture,bloom_.texture,scratch_.fbo,14,2.f,0.f,true,false,shadowRegions);
  Pass(scratch_.texture,bloom_.texture,0,14,0.f,2.f,true,true,shadowRegions);
 }
 gl.BindFramebuffer(DrawFramebuffer,0);glDrawBuffer(GL_BACK);Panels(panels,2);
 // Text bloom is separate from panel shadows: its source mask contains glyphs
 // only, so glow can spread inside the panels instead of being discarded there.
 if(hasBloom) {
  gl.BindFramebuffer(DrawFramebuffer,bloom_.fbo); glClear(GL_COLOR_BUFFER_BIT);
  ImGui_ImplOpenGL3_RenderDrawData(bloom);
  Pass(bloom_.texture,bloom_.texture,scratch_.fbo,14,2.f,0.f,true,false,textRegions);
  Pass(scratch_.texture,bloom_.texture,0,14,0.f,2.f,true,true,textRegions);
 }
 gl.BindFramebuffer(DrawFramebuffer,0);glDrawBuffer(GL_BACK);
 gl.ActiveTexture(Texture0);
 ImGui_ImplOpenGL3_RenderDrawData(foreground);
}
void PostProcessor::Shutdown() {
 DeleteTarget(scene_); DeleteTarget(mask_); DeleteTarget(scratch_); DeleteTarget(bloom_);
 if(program_) gl.DeleteProgram(program_);
 if(vao_) gl.DeleteVertexArrays(1,&vao_);
 program_=vao_=0; width_=height_=0;
}
}
