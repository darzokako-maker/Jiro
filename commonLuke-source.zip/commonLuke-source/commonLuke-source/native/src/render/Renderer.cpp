#include "render/Renderer.hpp"
#include "render/GlApi.hpp"
#include "render/GlDiagnostics.hpp"
#include "render/postprocess/PostProcessor.hpp"
#include "ui/font/FontManager.hpp"
#include "ui/hud/Hud.hpp"
#include "ui/hud/HudLayout.hpp"
#include "ui/hud/HudState.hpp"
#include "ui/hud/Notifications.hpp"
#include "client/Logger.hpp"
#include "features/visual/esp/Esp.hpp"
#include "features/visual/xray/Xray.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/target_hud/TargetHud.hpp"
#include "ui/clickgui/ClickGui.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include <chrono>
#include <algorithm>
#include <memory>
#include <imgui.h>
#include <imgui_impl_opengl3.h>

namespace client::render {
namespace {
ImGuiContext* context=nullptr;
ui::FontManager fonts;
PostProcessor post;
std::unique_ptr<ImDrawList> maskList,bloomList,foregroundList;
ImDrawData maskData,bloomData,foregroundData;
std::vector<RoundedPanel> panels;
std::unique_ptr<ImDrawList> notificationBloom,notificationFront;
ImDrawData notificationBloomData,notificationFrontData;
std::vector<RoundedPanel> notificationPanels;
bool failed=false, loaded=false;
struct ContextScope {
 ImGuiContext* previous=ImGui::GetCurrentContext();
 ~ContextScope() { ImGui::SetCurrentContext(previous); }
};
void SetupList(ImDrawList& list,ImVec2 size) {
 list._ResetForNewFrame();
 list.PushTexture(ImGui::GetIO().Fonts->TexRef);
 list.PushClipRect({0,0},size);
}
void SetupData(ImDrawData& data,ImDrawList& list,ImVec2 size) {
 data.Clear();
 data.Valid=true; data.DisplayPos={0,0}; data.DisplaySize=size; data.FramebufferScale={1,1};
 data.OwnerViewport=ImGui::GetMainViewport();
 data.Textures=&ImGui::GetPlatformIO().Textures;
 data.AddDrawList(&list);
}
}
void RenderHud(int width,int height) {
 diagnostics::Scope trace("RenderHud");
 if(failed || width<128 || height<128) return;
 if(!loaded) { if(!gl.Load()) { failed=true; return; } loaded=true; }
 GlState state;
 ContextScope contextScope;
 // Our texture allocations must not interpret null pointers as PBO offsets.
 gl.BindBuffer(0x88EC,0); gl.ActiveTexture(Texture0);
 if(!context) {
  context=ImGui::CreateContext();
  ImGui::SetCurrentContext(context);
  auto& io=ImGui::GetIO(); io.IniFilename=nullptr; io.LogFilename=nullptr;
  if(!ImGui_ImplOpenGL3_Init("#version 130") || !fonts.Initialize() || !post.Initialize()) {
   AOKI_LOG("HUD: UI initialization failed");
   post.Shutdown();
   if(io.BackendRendererUserData) ImGui_ImplOpenGL3_Shutdown();
   ImGui::DestroyContext(context); context=nullptr; failed=true; return;
  }
  ImGui::GetStyle().AntiAliasedLines=true;
  ImGui::GetStyle().AntiAliasedFill=true;
  ImGui::GetStyle().CircleTessellationMaxError=.10f;
  ui::notifications::InitializeGraphics();
  AOKI_LOG("HUD: Fredoka SemiBold + Gaussian blur/bloom initialized; GL %s",glGetString(GL_VERSION));
 } else ImGui::SetCurrentContext(context);
 if(!post.Resize(width,height)) { failed=true; return; }
 auto& io=ImGui::GetIO(); io.DisplaySize={static_cast<float>(width),static_cast<float>(height)};
 io.DisplayFramebufferScale={1.f,1.f};
 static auto previousFrame=std::chrono::steady_clock::now();
 const auto now=std::chrono::steady_clock::now();
 io.DeltaTime=std::max(.000001f,std::chrono::duration<float>(now-previousFrame).count());
 previousFrame=now;
 ui::input::NewFrame();
 ImGui_ImplOpenGL3_NewFrame(); ImGui::NewFrame();
 if(ui::input::IsOpen()||ui::IsScreenOpen())ui::hud_layout::UpdateEditor(ImGui::GetIO().MousePos.x,ImGui::GetIO().MousePos.y,io.DisplaySize.x,io.DisplaySize.y,ImGui::IsMouseDown(0));
 else ui::hud_layout::EndEditor();
 ui::hud_layout::BeginFrame();
 // Bake every HUD face/size before constructing lists (atlas can grow).
 fonts.Get()->GetFontBaked(36.f); fonts.Get()->GetFontBaked(17.f);
 fonts.Get()->GetFontBaked(22.f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(16.f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(17.f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(12.f);
 fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(14.f);
 fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(13.104f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(11.232f);
 fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(14.508f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(12.636f);
 fonts.Get(ui::FontWeight::Medium)->GetFontBaked(9.36f);
 fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(10.92f);
 fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(9.36f);
 // ESP no longer uses Minecraft's FontRenderer. Bake its configurable native
 // tag sizes before draw-list construction so the atlas cannot grow mid-frame.
 const auto& espOptions=features::esp::Options();
 const auto& itemEspOptions=features::item_esp::Options();
 if(espOptions.enabled) {
  fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(20.f*espOptions.tagScale);
  fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(12.f);
  fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(13.f);
 }
 if(itemEspOptions.enabled)fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(20.f*itemEspOptions.tagScale);
 if(features::xray::Options().enabled)fonts.Get(ui::FontWeight::SemiBold)->GetFontBaked(13.f);
 if(ui::notifications::State().Count())fonts.Get(ui::FontWeight::Regular)->GetFontBaked(13.f);
 if(!maskList) {
  const auto shared=ImGui::GetDrawListSharedData();
  maskList=std::make_unique<ImDrawList>(shared);bloomList=std::make_unique<ImDrawList>(shared);foregroundList=std::make_unique<ImDrawList>(shared);
 }
 auto& mask=*maskList;auto& bloom=*bloomList;auto& foreground=*foregroundList;
 SetupList(mask,io.DisplaySize); SetupList(bloom,io.DisplaySize); SetupList(foreground,io.DisplaySize);
 features::esp::Draw(fonts,foreground,bloom);
 features::xray::Draw(fonts,foreground);
 panels.clear();
 features::inventory_hud::Draw(fonts,foreground,io.DisplaySize.x,io.DisplaySize.y,panels);
 features::spotify::Draw(fonts,foreground,io.DisplaySize.x,io.DisplaySize.y,panels);
 features::targethud::Draw(fonts,foreground,bloom,io.DisplaySize.x,io.DisplaySize.y,panels);
 if(ui::clickgui::HudEnabled()) ui::DrawHud(fonts,bloom,foreground,io.DisplaySize.x,io.DisplaySize.y,panels);
 const auto guides=ui::hud_layout::Guides();
 foreground.Flags|=ImDrawListFlags_AntiAliasedLines;
 if(guides.vertical){foreground.AddLine({guides.x,0},{guides.x,io.DisplaySize.y},IM_COL32(0,0,0,150),4.f);foreground.AddLine({guides.x,0},{guides.x,io.DisplaySize.y},IM_COL32(255,255,255,235),2.f);}
 if(guides.horizontal){foreground.AddLine({0,guides.y},{io.DisplaySize.x,guides.y},IM_COL32(0,0,0,150),4.f);foreground.AddLine({0,guides.y},{io.DisplaySize.x,guides.y},IM_COL32(255,255,255,235),2.f);}
 ui::clickgui::Draw(fonts,mask);
 bool drawNotifications=false;
 if(ui::notifications::State().Count()) {
  if(!notificationBloom){notificationBloom=std::make_unique<ImDrawList>(ImGui::GetDrawListSharedData());notificationFront=std::make_unique<ImDrawList>(ImGui::GetDrawListSharedData());}
  SetupList(*notificationBloom,io.DisplaySize);SetupList(*notificationFront,io.DisplaySize);notificationPanels.clear();
  ui::notifications::Draw(fonts,*notificationBloom,*notificationFront,io.DisplaySize.x,io.DisplaySize.y,io.DeltaTime,notificationPanels);
  drawNotifications=!notificationPanels.empty();
 }
 ImGui::Render();
 SetupData(maskData,mask,io.DisplaySize); SetupData(bloomData,bloom,io.DisplaySize); SetupData(foregroundData,foreground,io.DisplaySize);
 post.Render(&maskData,&bloomData,&foregroundData,panels);
 {diagnostics::Scope submit("ClickGUI / ImGui submission");ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());}
 if(drawNotifications) {
  diagnostics::Scope submit("Notifications / postprocess overlay");
  SetupData(notificationBloomData,*notificationBloom,io.DisplaySize);SetupData(notificationFrontData,*notificationFront,io.DisplaySize);
  post.Render(nullptr,&notificationBloomData,&notificationFrontData,notificationPanels);
 }
}
}



