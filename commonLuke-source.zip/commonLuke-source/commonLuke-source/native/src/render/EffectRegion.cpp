#include "render/EffectRegion.hpp"
#include <imgui.h>
#include <algorithm>
#include <cmath>

namespace client::render {
EffectRegion::EffectRegion(int width,int height):width_(width),height_(height),columns_((width+Tile-1)/Tile),rows_((height+Tile-1)/Tile),cells_(columns_*rows_,0){}
void EffectRegion::Add(float x,float y,float right,float bottom,float padding) {
 if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(right)||!std::isfinite(bottom)||right<=x||bottom<=y)return;
 x=std::clamp(x-padding,0.f,static_cast<float>(width_));y=std::clamp(y-padding,0.f,static_cast<float>(height_));
 right=std::clamp(right+padding,0.f,static_cast<float>(width_));bottom=std::clamp(bottom+padding,0.f,static_cast<float>(height_));
 if(right<=x||bottom<=y)return;
 const int firstX=static_cast<int>(x)/Tile,firstY=static_cast<int>(y)/Tile;
 const int lastX=std::min(columns_,static_cast<int>(std::ceil(right/Tile))),lastY=std::min(rows_,static_cast<int>(std::ceil(bottom/Tile)));
 for(int row=firstY;row<lastY;++row)for(int col=firstX;col<lastX;++col)cells_[row*columns_+col]=1;
}
void EffectRegion::Add(const ImDrawData* data,float padding) {
 if(!data)return;
 const auto origin=data->DisplayPos,scale=data->FramebufferScale;
 for(const auto* list:data->CmdLists)for(const auto& command:list->CmdBuffer) {
  if(command.UserCallback){Add(0,0,static_cast<float>(width_),static_cast<float>(height_),0);continue;}
  for(unsigned i=0;i+2<command.ElemCount;i+=3) {
   const ImDrawVert* v[3];
   for(int j=0;j<3;++j)v[j]=&list->VtxBuffer[command.VtxOffset+list->IdxBuffer[command.IdxOffset+i+j]];
   if(((v[0]->col|v[1]->col|v[2]->col)>>24)==0)continue;
   const float x=std::max(std::min({v[0]->pos.x,v[1]->pos.x,v[2]->pos.x}),command.ClipRect.x);
   const float y=std::max(std::min({v[0]->pos.y,v[1]->pos.y,v[2]->pos.y}),command.ClipRect.y);
   const float right=std::min(std::max({v[0]->pos.x,v[1]->pos.x,v[2]->pos.x}),command.ClipRect.z);
   const float bottom=std::min(std::max({v[0]->pos.y,v[1]->pos.y,v[2]->pos.y}),command.ClipRect.w);
   Add((x-origin.x)*scale.x,(y-origin.y)*scale.y,(right-origin.x)*scale.x,(bottom-origin.y)*scale.y,padding);
  }
 }
}
std::vector<PixelRect> EffectRegion::Rectangles(bool restrictWork) const {
 std::vector<PixelRect> result;
 if(!restrictWork){result.push_back({0,0,width_,height_});return result;}
 for(int row=0;row<rows_;++row)for(int col=0;col<columns_;) {
  if(!cells_[row*columns_+col]){++col;continue;}
  const int first=col;while(col<columns_&&cells_[row*columns_+col])++col;
  const int x=first*Tile,right=std::min(width_,col*Tile),y=row*Tile,bottom=std::min(height_,y+Tile);
  auto previous=std::find_if(result.begin(),result.end(),[&](const PixelRect& r){return r.x==x&&r.right==right&&r.bottom==y;});
  if(previous!=result.end())previous->bottom=bottom;else result.push_back({x,y,right,bottom});
 }
 return result;
}
}
