#include "client/JarReader.hpp"
#include "JarLoader.hpp"
#include <utility>

namespace client::jar {
namespace {
std::vector<ParsedClass> Convert(std::vector<JarLoader::ParsedClass> parsed) {
    std::vector<ParsedClass> result;
    result.reserve(parsed.size());
    for (auto& entry : parsed)
        result.push_back({std::move(entry.name), std::move(entry.bytecode),
                          std::move(entry.class_file)});
    return result;
}
}
std::vector<ParsedClass> Read(const std::string& path, bool allowNativeMethods)
{
    return Convert(JarLoader::LoadClassesFromJar(path, allowNativeMethods));
}
std::vector<ParsedClass> ReadMemory(const void* bytes,std::size_t size,bool allowNativeMethods) {
    return Convert(JarLoader::LoadClassesFromMemory(bytes,size,allowNativeMethods));
}
}
