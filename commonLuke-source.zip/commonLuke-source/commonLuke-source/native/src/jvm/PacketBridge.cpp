#include "client/PacketBridge.hpp"
#include "client/ClassRepository.hpp"
#include "client/MethodManager.hpp"
#include "client/Logger.hpp"
#include <atomic>
#include <mutex>
#include <algorithm>
#include <memory>
#include <optional>
#include <stdexcept>
#include <vector>

namespace client::packets {
namespace {
struct Filter {
    std::string owner;
    SendFilter send;
    ReceiveFilter receive;
    int priority;
    std::uint64_t order;
};
using Filters = std::vector<Filter>;
std::atomic<std::shared_ptr<const Filters>> filters{std::make_shared<const Filters>()};
std::mutex filterMutex;
std::uint64_t nextOrder = 0;
std::atomic<std::uint64_t> sent{0}, received{0}, cancelledSend{0}, cancelledReceive{0}, directSend{0};
std::mutex hookMutex;
jobject activeHook = nullptr;
std::optional<classes::ClassRecord> hookOwner;

struct Hook {
    jobject object = nullptr;
    std::optional<classes::ClassRecord> owner;
};
Hook LocalHook(JNIEnv* env) {
    std::lock_guard lock(hookMutex);
    return {activeHook ? env->NewLocalRef(activeHook) : nullptr, hookOwner};
}
methods::Argument Object(jobject value) { methods::Argument argument{methods::Type::Object};argument.value.l=value;return argument; }
jint JNICALL Version(JNIEnv*, jclass) { return 1; }
jobject JNICALL BeforeSend(JNIEnv* env, jclass, jobject packet) {
    ++sent;
    try {
        const auto snapshot = filters.load();
        for (const auto& filter : *snapshot) {
            if (filter.send) packet = filter.send(env, packet);
            if (!packet || env->ExceptionCheck()) { ++cancelledSend; return nullptr; }
        }
        return packet;
    } catch (...) { ++cancelledSend; return nullptr; }
}
jboolean JNICALL BeforeReceive(JNIEnv* env, jclass, jobject packet) {
    ++received;
    try {
        const auto snapshot = filters.load();
        for (const auto& filter : *snapshot) {
            if ((filter.receive && !filter.receive(env, packet)) || env->ExceptionCheck()) {
                ++cancelledReceive;
                return JNI_FALSE;
            }
        }
        return JNI_TRUE;
    } catch (...) { ++cancelledReceive; return JNI_FALSE; }
}
}
void SetFilter(std::string owner, SendFilter send, ReceiveFilter receive, int priority) {
    if (owner.empty()) throw std::invalid_argument("Packet filter owner must be nonempty");
    std::lock_guard lock(filterMutex);
    auto next = std::make_shared<Filters>(*filters.load());
    const auto found = std::find_if(next->begin(), next->end(), [&](const auto& value) { return value.owner == owner; });
    if (found != next->end()) *found = {std::move(owner), send, receive, priority, found->order};
    else next->push_back({std::move(owner), send, receive, priority, nextOrder++});
    std::sort(next->begin(), next->end(), [](const auto& a, const auto& b) {
        return a.priority != b.priority ? a.priority < b.priority : a.order < b.order;
    });
    filters.store(std::move(next));
}
bool RemoveFilter(const std::string& owner) {
    std::lock_guard lock(filterMutex);
    auto next = std::make_shared<Filters>(*filters.load());
    const auto removed = std::erase_if(*next, [&](const auto& value) { return value.owner == owner; });
    if (removed) filters.store(std::move(next));
    return removed != 0;
}
Counters GetCounters() { return {sent.load(), received.load(), cancelledSend.load(), cancelledReceive.load(), directSend.load()}; }

bool BindNativeCallbacks(JNIEnv* env, jclass payloadClass) {
    JNINativeMethod methods[]{
        {const_cast<char*>("nativeBridgeVersion"), const_cast<char*>("()I"), reinterpret_cast<void*>(&Version)},
        {const_cast<char*>("beforeSend"), const_cast<char*>("(Ljava/lang/Object;)Ljava/lang/Object;"), reinterpret_cast<void*>(&BeforeSend)},
        {const_cast<char*>("beforeReceive"), const_cast<char*>("(Ljava/lang/Object;)Z"), reinterpret_cast<void*>(&BeforeReceive)}
    };
    return env->RegisterNatives(payloadClass, methods, 3) == JNI_OK && !env->ExceptionCheck();
}
bool SetHook(JNIEnv* env, jobject hook, const classes::ClassRecord& owner) {
    std::lock_guard lock(hookMutex);
    if (activeHook || !hook) return false;
    activeHook = env->NewGlobalRef(hook);
    if (activeHook && !env->ExceptionCheck()) hookOwner = owner;
    else activeHook = nullptr;
    return activeHook && !env->ExceptionCheck();
}
jobject Send(JNIEnv* env, jobject packet) {
    if (!env || !packet || env->ExceptionCheck()) return nullptr;
    const auto hook = LocalHook(env);
    if (!hook.object || !hook.owner) return nullptr;
    auto result=methods::Invoke(env,hook.object,*hook.owner,"send","(Ljava/lang/Object;)Ljava/lang/Object;",{Object(packet)},true);
    const auto future=result.ok&&result.value.l?env->NewLocalRef(result.value.l):nullptr;
    result.Release(env);env->DeleteLocalRef(hook.object);
    if (!result.ok || env->ExceptionCheck()) return nullptr;
    ++directSend;
    return future;
}
bool Receive(JNIEnv* env,jobject packet) {
    if(!env||!packet||env->ExceptionCheck())return false;
    auto hook=LocalHook(env);
    if(!hook.object||!hook.owner)return false;
    const auto result=methods::Invoke(env,hook.object,*hook.owner,"receive","(Ljava/lang/Object;)V",{Object(packet)},true);
    env->DeleteLocalRef(hook.object);return result.ok&&!env->ExceptionCheck();
}
bool IsInstalled(JNIEnv* env) {
    const auto hook = LocalHook(env);
    if (!hook.object || !hook.owner) return false;
    const auto result=methods::Invoke(env,hook.object,*hook.owner,"isInstalled","()Z",{},true);
    env->DeleteLocalRef(hook.object);
    return result.ok && result.value.z && !env->ExceptionCheck();
}
bool Uninstall(JNIEnv* env) {
    const auto hook = LocalHook(env);
    if (!hook.object) return !env->ExceptionCheck();
    if (!hook.owner) { env->DeleteLocalRef(hook.object);return false; }
    const auto result=methods::Invoke(env,hook.object,*hook.owner,"close","()V",{},true);
    if (!result.ok || env->ExceptionCheck()) { env->DeleteLocalRef(hook.object); return false; }
    {
        std::lock_guard lock(hookMutex);
        if (activeHook && env->IsSameObject(activeHook, hook.object)) {
            env->DeleteGlobalRef(activeHook); activeHook = nullptr;hookOwner.reset();
        }
    }
    env->DeleteLocalRef(hook.object);
    return true;
}
}
