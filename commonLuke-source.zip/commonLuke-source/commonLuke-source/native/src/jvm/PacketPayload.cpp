#include "client/PacketPayload.hpp"
#include "client/ApiTestSequence.hpp"
#include "client/JarReader.hpp"
#include "client/PayloadClosure.hpp"
#include "client/PacketBridge.hpp"
#include "client/PacketChatLogger.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/combat/velocity/Velocity.hpp"
#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/movement/ncp/NcpMovement.hpp"
#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/movement/clips/ClipsCapture.hpp"
#include "features/visual/freecam/FreeCam.hpp"
#include "features/combat/auto_harm/AutoHarm.hpp"
#include "client/Logger.hpp"
#include "EmbeddedPacketHook.hpp"
#include "client/OffsetRepository.hpp"
#include "client/HotSpotAccess.hpp"
#include "client/MethodManager.hpp"
#include "client/ReferenceFieldPlan.hpp"
#include "JCFPNativeBridge.hpp"
#include "InjectionLayout.hpp"
#include <Windows.h>
#include <array>
#include <algorithm>
#include <cstring>
#include <limits>
#include <utility>

uintptr_t MethodInvoker::g_TlsIndexAddr = 0;
uintptr_t MethodInvoker::g_CallStubPtrAddr = 0;
uintptr_t MethodInvoker::g_SerializeMemAddr = 0;
uintptr_t MethodInvoker::g_GetEnvAddr = 0;

namespace client::payload {
namespace {
constexpr const char* mainName = "client/packethook/PacketHook";
constexpr const char* stages[]{
    "read/validate PacketHook JAR", "bind audited layout + verify game mappings/loader",
    "build real class constant pools + methods", "prepare InstanceKlass metadata",
    "link real class methods", "create dedicated mirrors + attach loader/hierarchy",
    "publish real dictionary entries", "warm arrays + initialize + execute payloadVersion",
    "RegisterNatives + native roundtrip", "install live packet proxies"
};
struct Record {
    jar::ParsedClass parsed;
    std::string name;
    std::vector<JCFPNativeBridge::BuiltMethod> methods;
    uintptr_t methodArray = 0, klass = 0;
};
struct State {
    jar_vm::ApiTestSequence sequence;
    std::vector<Record> classes;
    std::shared_ptr<const offsets::Profile> profile;
    HMODULE module = nullptr;
    uintptr_t base = 0, thread = 0, ownerCld = 0, object = 0;
    DWORD renderThread = 0;
    unsigned loaderHash = 0;
    jclass mainClass = nullptr;
    jobject loader = nullptr;
    jobject liveManager = nullptr;
    jclass minecraftClass = nullptr;
    jfieldID instanceField = nullptr, playerField = nullptr, worldField = nullptr, screenField = nullptr;
    ULONGLONG nextAutoTick = 0, nextNetworkTick = 0;
    unsigned lastAttempt = 0;
} state;

template<class T> T Read(uintptr_t p) { return hotspot::Read<T>(p).value_or(T{}); }
uintptr_t Api(const char* key) { return state.base + state.profile->rvas.at(key); }
uintptr_t Audited(const char* key) {
    for (const auto& r : fixed::rvas) if (std::strcmp(r.name,key)==0) return state.base + r.value;
    return 0;
}
bool Exception(JNIEnv* env, const char* where) {
    if (!env->ExceptionCheck()) return false;
    auto failure = env->ExceptionOccurred();
    env->ExceptionClear();
    // Keep error reporting free of Java dispatch on a possibly malformed result.
    AOKI_LOG("[PacketPayload] Java exception at %s: handle=%p oop=%p",where,failure,
        reinterpret_cast<void*>(failure?Read<uintptr_t>(reinterpret_cast<uintptr_t>(failure)):0));
    if(failure)env->DeleteLocalRef(failure);
    return true;
}
jclass Mirror(JNIEnv* env, uintptr_t klass) {
    const auto oop = Read<uintptr_t>(klass + JvmMapper::Klass::java_mirror);
    return oop ? static_cast<jclass>(env->NewLocalRef(reinterpret_cast<jobject>(const_cast<uintptr_t*>(&oop)))) : nullptr;
}
uintptr_t Find(const std::string& name) {
    for (const auto& rec : state.classes) if (rec.name==name && rec.klass) return rec.klass;
    return JvmApi::FindClass(name);
}
std::string ClassName(const jcfp::ClassFile& cf, jcfp::u2 index) {
    if (!index) return {};
    const auto& cp=cf.constant_pool;
    auto nameIndex=cp.get_entry(index).get<jcfp::ConstantPoolEntry::ClassInfo>().name_index;
    return cp.get_entry(nameIndex).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
}
const fixed::Field* Spec(const char* key) {
    for (const auto& f:fixed::fields) if(std::strcmp(f.key,key)==0) return &f;
    return nullptr;
}
const char* MappedClass(const char* key) {
    for (const auto& c:fixed::classes) if(std::strcmp(c.key,key)==0) return c.name;
    return "";
}
jobject FieldObject(JNIEnv* env,jobject receiver,const char* key) {
    const auto f=Spec(key); if(!f) return nullptr;
    auto cls=Mirror(env,Find(f->owner)); if(!cls) return nullptr;
    jobject result=nullptr;
    if(f->isStatic) {
        auto id=env->GetStaticFieldID(cls,f->name,f->descriptor);
        if(id) result=env->GetStaticObjectField(cls,id);
    } else if(receiver) {
        auto id=env->GetFieldID(cls,f->name,f->descriptor);
        if(id) result=env->GetObjectField(receiver,id);
    }
    env->DeleteLocalRef(cls); return result;
}
jobject NetworkManager(JNIEnv* env) {
    auto mc=FieldObject(env,nullptr,"Minecraft.instance"); if(!mc)return nullptr;
    auto player=FieldObject(env,mc,"Minecraft.thePlayer"); env->DeleteLocalRef(mc); if(!player)return nullptr;
    auto handler=FieldObject(env,player,"ClientPlayer.sendQueue"); env->DeleteLocalRef(player); if(!handler)return nullptr;
    auto manager=FieldObject(env,handler,"NetHandlerPlayClient.networkManager"); env->DeleteLocalRef(handler);
    return manager;
}
classes::ClassRecord Owner(const Record& rec) {
    classes::ClassRecord owner; owner.name=rec.name; owner.klass=rec.klass; owner.loaderData=state.ownerCld;
    for (const auto& built:rec.methods) {
        classes::MethodRecord item; item.metadata.name=built.name; item.metadata.signature=built.descriptor;
        item.metadata.method_ptr=built.method; item.metadata.access_flags=built.access_flags;
        owner.methods.push_back(std::move(item));
    }
    return owner;
}
bool ReadJar() {
    auto parsed=jar::ReadMemory(kEmbeddedPacketHook,kEmbeddedPacketHookSize,true);
    const std::array<std::string,4> expected{mainName,std::string(mainName)+"$Listener",
        std::string(mainName)+"$Handler",std::string(mainName)+"$NativeListener"};
    if(parsed.size()!=expected.size()) {
        AOKI_LOG("[PacketPayload] expected 4 classes, got %zu; rebuild Java payload",parsed.size());return false;
    }
    std::string missing;
    if(!ValidatePayloadClosure(parsed,missing)) {
        AOKI_LOG("[PacketPayload] missing payload dependency %s; rejecting before VM allocation",missing.c_str());
        return false;
    }
    std::vector<Record> pending;
    for(auto& entry:parsed) {
        auto name=ClassName(entry.class_file,entry.class_file.this_class);
        if(std::find(expected.begin(),expected.end(),name)==expected.end())return false;
        for(const auto& m:entry.class_file.methods) if(m.access_flags & 0x100) {
            const auto& cp=entry.class_file.constant_pool;
            auto method=cp.get_entry(m.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
            auto descriptor=cp.get_entry(m.descriptor_index).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
            const bool known=(name==mainName && (m.access_flags&8) &&
                ((method=="nativeBridgeVersion"&&descriptor=="()I") ||
                 (method=="beforeSend"&&descriptor=="(Ljava/lang/Object;)Ljava/lang/Object;") ||
                 (method=="beforeReceive"&&descriptor=="(Ljava/lang/Object;)Z")));
            if(!known) {AOKI_LOG("[PacketPayload] unexpected native declaration %s.%s",name.c_str(),method.c_str());return false;}
        }
        AOKI_LOG("[PacketPayload] parsed %s bytes=%zu methods=%zu fields=%zu",name.c_str(),
            entry.bytecode.size(),entry.class_file.methods.size(),entry.class_file.fields.size());
        pending.push_back({std::move(entry),std::move(name),{}});
    }
    while(!pending.empty()) {
        bool progressed=false;
        for(std::size_t i=0;i<pending.size();) {
            const auto& cf=pending[i].parsed.class_file;
            std::vector<std::string> dependencies{ClassName(cf,cf.super_class)};
            for(auto iface:cf.interfaces)dependencies.push_back(ClassName(cf,iface));
            bool waits=false;
            for(const auto& dependency:dependencies)
                for(const auto& other:pending)if(other.name==dependency)waits=true;
            if(waits){++i;continue;}
            state.classes.push_back(std::move(pending[i]));pending.erase(pending.begin()+i);progressed=true;
        }
        if(!progressed)return false;
    }
    return true;
}
bool Bind(JNIEnv* env) {
    state.profile=offsets::Get();state.module=GetModuleHandleW(L"jvm.dll");
    if(!state.profile||!state.module)return false;
    state.base=reinterpret_cast<uintptr_t>(state.module);
    state.thread=reinterpret_cast<uintptr_t>(env)-state.profile->members.at("JavaThread.jni_environment");
    state.renderThread=GetCurrentThreadId();
    fixed::BindLayout();
    MethodInvoker::g_SerializeMemAddr=Api("Thread.serialize");
    JvmApi::BindFixed(state.module,{
        Api("ClassLoaderDataGraph.head"),Audited("BootstrapCLD"),
        Api("ConstMethod.allocate"),Api("Method.allocate"),Api("Method.link"),Api("MetadataHandle.copy"),
        Api("ConstantPool.allocate"),Api("SymbolTable.lookup"),Api("SystemDictionary.update_dictionary"),
        Api("SystemDictionary.dictionary"),Audited("RestoreMirror"),Audited("CreateMirror"),Audited("KlassOopStore")
    });
    if(!Read<bool>(Api("UseCompressedOops")))return false;
    state.object=Find("java/lang/Object");
    const auto minecraft=Find(MappedClass("Minecraft"));
    state.ownerCld=minecraft?Read<uintptr_t>(minecraft+JvmMapper::Klass::class_loader_data):0;
    if(!state.object||!state.ownerCld)return false;
    auto mirror=Mirror(env,minecraft);
    if(!mirror)return false;
    // IDA JVM_GetClassLoader resolves the mirror's Klass/CLD itself and returns
    // a JNI local handle. Do not marshal this call through CallObjectMethodV.
    using GetLoader=jobject(JNICALL*)(JNIEnv*,jclass);
    AOKI_LOG("[PacketPayload] F2 JVM_GetClassLoader BEFORE fn=%p mirror=%p cld=%p",
        reinterpret_cast<void*>(Api("JVM.GetClassLoader")),mirror,reinterpret_cast<void*>(state.ownerCld));
    auto loader=reinterpret_cast<GetLoader>(Api("JVM.GetClassLoader"))(env,mirror);
    env->DeleteLocalRef(mirror);
    if(!loader||Exception(env,"game class loader"))return false;
    state.loader=env->NewGlobalRef(loader);env->DeleteLocalRef(loader);
    if(!state.loader||Exception(env,"loader global reference"))return false;
    const auto loaderOop=Read<uintptr_t>(reinterpret_cast<uintptr_t>(state.loader));
    const auto cldLoader=Read<uintptr_t>(state.ownerCld+JvmMapper::ClassLoaderData::class_loader);
    const auto snapshot=classes::GetSnapshot();
    uintptr_t actualKlass=0;
    if(Read<bool>(Api("UseCompressedClassPointers"))) {
        const auto narrow=Read<uint32_t>(loaderOop+state.profile->members.at("HeapObject.klass"));
        const auto shift=Read<unsigned>(Api("Universe.narrow_klass_shift"));
        if(shift>16)return false;
        actualKlass=Read<uintptr_t>(Api("Universe.narrow_klass_base"))+(uintptr_t(narrow)<<shift);
    } else actualKlass=Read<uintptr_t>(loaderOop+state.profile->members.at("HeapObject.klass"));
    const auto classLoader=Find("java/lang/ClassLoader");
    bool validLoader=false;
    for(auto klass=actualKlass,depth=uintptr_t(0);klass&&depth<128;++depth) {
        if(!snapshot||!snapshot->byKlass.contains(klass))break;
        if(klass==classLoader){validLoader=true;break;}
        klass=Read<uintptr_t>(klass+JvmMapper::Klass::super_klass);
    }
    AOKI_LOG("[PacketPayload] F2 loader handle=%p oop=%p cldOop=%p klass=%p validated=%d",
        state.loader,reinterpret_cast<void*>(loaderOop),reinterpret_cast<void*>(cldLoader),
        reinterpret_cast<void*>(actualKlass),static_cast<int>(validLoader&&loaderOop==cldLoader));
    if(!loaderOop||loaderOop!=cldLoader||!validLoader) {
        AOKI_LOG("[PacketPayload] F2 rejecting loader BEFORE identity hash; no class allocation performed");
        return false;
    }
    // Verified JNI-entry wrapper owns its VM transitions and resolves the JNI
    // handle. Never pass an oop or a ClassLoaderData pointer as that handle.
    using IdentityHash=jint(JNICALL*)(JNIEnv*,jobject);
    AOKI_LOG("[PacketPayload] F2 JVM_IHashCode BEFORE fn=%p loader=%p",
        reinterpret_cast<void*>(Api("JVM.IHashCode")),state.loader);
    state.loaderHash=static_cast<unsigned>(reinterpret_cast<IdentityHash>(Api("JVM.IHashCode"))(env,state.loader));
    AOKI_LOG("[PacketPayload] F2 JVM_IHashCode AFTER hash=0x%X",state.loaderHash);
    if(Exception(env,"loader identity hash"))return false;
    for(const auto& f:fixed::fields) {
        const auto klass=Find(f.owner); if(!klass)return false;
        bool match=false;
        for(const auto& actual:JvmApi::GetFields(klass))
            if(actual.name==f.name&&actual.signature==f.descriptor&&bool(actual.access_flags&8)==f.isStatic)match=true;
        AOKI_LOG("[PacketPayload] mapping %s = %s.%s %s verified=%d",f.key,f.owner,f.name,f.descriptor,static_cast<int>(match));
        if(!match)return false;
    }
    for(const auto& rec:state.classes)
        if(JvmApi::FindClass(rec.name)) {AOKI_LOG("[PacketPayload] duplicate class %s",rec.name.c_str());return false;}
    auto mcMirror=Mirror(env,minecraft);
    state.minecraftClass=static_cast<jclass>(env->NewGlobalRef(mcMirror));env->DeleteLocalRef(mcMirror);
    auto id=[&](const char* key) {
        const auto field=Spec(key);
        return field->isStatic?env->GetStaticFieldID(state.minecraftClass,field->name,field->descriptor)
            :env->GetFieldID(state.minecraftClass,field->name,field->descriptor);
    };
    if(!state.minecraftClass)return false;
    state.instanceField=id("Minecraft.instance");state.playerField=id("Minecraft.thePlayer");
    state.worldField=id("Minecraft.theWorld");state.screenField=id("Minecraft.currentScreen");
    if(!state.instanceField||!state.playerField||!state.worldField||!state.screenField||Exception(env,"input readiness fields"))return false;
    AOKI_LOG("[PacketPayload] game loader=%p ownerCLD=%p loaderHash=0x%X",state.loader,reinterpret_cast<void*>(state.ownerCld),state.loaderHash);
    return true;
}
bool BuildMethods(JNIEnv* env) {
    for(auto& rec:state.classes) {
        AOKI_LOG("[PacketPayload] methods BEFORE %s",rec.name.c_str());
        rec.methods=JCFPNativeBridge::BuildAllMethodsFromJCFP(state.module,state.ownerCld,
            reinterpret_cast<void*>(state.thread),rec.parsed.class_file,env);
        if(rec.methods.size()!=rec.parsed.class_file.methods.size() || Exception(env,"method build"))return false;
        const auto bytes=JvmMapper::Array::data+rec.methods.size()*sizeof(uintptr_t);
        rec.methodArray=reinterpret_cast<uintptr_t>(VirtualAlloc(nullptr,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
        if(!rec.methodArray)return false;
        *reinterpret_cast<int*>(rec.methodArray+JvmMapper::Array::length)=static_cast<int>(rec.methods.size());
        for(std::size_t i=0;i<rec.methods.size();++i)
            *reinterpret_cast<uintptr_t*>(rec.methodArray+JvmMapper::Array::data+i*8)=rec.methods[i].method;
        AOKI_LOG("[PacketPayload] methods AFTER %s count=%zu",rec.name.c_str(),rec.methods.size());
    }
    return true;
}
bool Prepare() {
    uint32_t staticBase=0;if(!DeriveReferenceMirrorStaticBase(staticBase))return false;
    for(auto& rec:state.classes) {
        auto& cf=rec.parsed.class_file;
        const auto parent=Find(ClassName(cf,cf.super_class));
        std::vector<uintptr_t> interfaces;
        for(auto index:cf.interfaces){auto klass=Find(ClassName(cf,index));if(!klass)return false;interfaces.push_back(klass);}
        RawInstanceFieldPlan plan{};
        if(!parent||!BuildReferenceFieldPlan(cf,parent,staticBase,plan))return false;
        rec.klass=KlassInjector::InjectClass(state.module,rec.name,state.object,rec.methodArray,
            reinterpret_cast<void*>(state.thread),parent,static_cast<uint32_t>(cf.access_flags),
            interfaces.data(),static_cast<int32_t>(interfaces.size()),&plan,state.ownerCld,true);
        AOKI_LOG("[PacketPayload] prepared %s klass=%p (not yet mirrored/published)",rec.name.c_str(),reinterpret_cast<void*>(rec.klass));
        if(!rec.klass)return false;
    }
    return true;
}
bool Link() {
    for(auto& rec:state.classes) {
        AOKI_LOG("[PacketPayload] linking %s",rec.name.c_str());
        if(!KlassInjector::LinkPreparedMethods(rec.klass,rec.methodArray,reinterpret_cast<void*>(state.thread)))return false;
    }
    return true;
}
bool Mirrors() {
    auto templateMirror=Read<uintptr_t>(state.object+JvmMapper::Klass::java_mirror);
    for(auto& rec:state.classes) {
        AOKI_LOG("[PacketPayload] mirror BEFORE %s (loader-list publication occurs here)",rec.name.c_str());
        if(!KlassInjector::InstallPreparedMirror(rec.klass,state.ownerCld,reinterpret_cast<void*>(state.thread),templateMirror))return false;
        KlassInjector::PublishPreparedHierarchy(rec.klass,Read<uintptr_t>(rec.klass+JvmMapper::Klass::super_klass));
        AOKI_LOG("[PacketPayload] mirror AFTER %s oop=%p",rec.name.c_str(),
            reinterpret_cast<void*>(Read<uintptr_t>(rec.klass+JvmMapper::Klass::java_mirror)));
    }
    return true;
}
bool Dictionaries() {
    using Update=void(__fastcall*)(int,unsigned,uintptr_t,uintptr_t,uintptr_t,uintptr_t*,void*);
    using FindEntry=uintptr_t(__fastcall*)(uintptr_t,int,unsigned,uintptr_t,uintptr_t);
    for(auto& rec:state.classes) {
        MethodInvoker::TransitionToVM(state.thread);
        auto dictionary=Read<uintptr_t>(Api("SystemDictionary.dictionary"));
        auto size=Read<unsigned>(dictionary+32);
        auto symbol=Read<uintptr_t>(rec.klass+JvmMapper::Klass::name);
        auto hash=Read<unsigned>(symbol+4)^state.loaderHash;
        if(!dictionary||!size){MethodInvoker::TransitionToNative(state.thread);return false;}
        auto bucket=static_cast<int>(hash%size);
        // Rooted JNI global handle remains valid if acquiring the dictionary lock safepoints.
        auto loaderArg=reinterpret_cast<uintptr_t*>(state.loader);
        reinterpret_cast<Update>(Api("SystemDictionary.update_dictionary"))(bucket,hash,0,0,
            rec.klass,loaderArg,reinterpret_cast<void*>(state.thread));
        auto registered=reinterpret_cast<FindEntry>(Api("Dictionary.find_class"))(Read<uintptr_t>(Api("SystemDictionary.dictionary")),
            bucket,hash,symbol,state.ownerCld);
        MethodInvoker::TransitionToNative(state.thread);
        AOKI_LOG("[PacketPayload] dictionary %s hash=0x%X bucket=%d expected=%p actual=%p",
            rec.name.c_str(),hash,bucket,reinterpret_cast<void*>(rec.klass),reinterpret_cast<void*>(registered));
        if(registered!=rec.klass)return false;
    }
    return true;
}
bool Initialize(JNIEnv* env) {
    for(auto& rec:state.classes) {
        auto mirror=Mirror(env,rec.klass);if(!mirror)return false;
        auto array=env->NewObjectArray(0,mirror,nullptr);env->DeleteLocalRef(mirror);
        if(!array||Exception(env,"array warmup"))return false;env->DeleteLocalRef(array);
        auto* init=reinterpret_cast<unsigned char*>(rec.klass+JvmMapper::InstanceKlass::init_state);
        auto owner=Owner(rec);
        auto clinit=std::find_if(rec.methods.begin(),rec.methods.end(),[](const auto& m){return m.name=="<clinit>"&&m.descriptor=="()V";});
        if(clinit!=rec.methods.end()) {
            *reinterpret_cast<uintptr_t*>(rec.klass+JvmMapper::InstanceKlass::init_thread)=state.thread;
            *init=3;
            const auto result=methods::Invoke(env,nullptr,owner,"<clinit>","()V",{},false,true);
            *reinterpret_cast<uintptr_t*>(rec.klass+JvmMapper::InstanceKlass::init_thread)=0;
            if(!result.ok){*init=5;AOKI_LOG("[PacketPayload] clinit failed %s: %s",rec.name.c_str(),result.error.c_str());return false;}
        }
        *init=4;
        if(rec.name==mainName) {
            auto local=Mirror(env,rec.klass);state.mainClass=static_cast<jclass>(env->NewGlobalRef(local));env->DeleteLocalRef(local);
        }
        AOKI_LOG("[PacketPayload] initialized %s",rec.name.c_str());
    }
    if(!state.mainClass)return false;
    const auto main=std::find_if(state.classes.begin(),state.classes.end(),[](const auto& rec){return rec.name==mainName;});
    if(main==state.classes.end())return false;
    const auto version=methods::Invoke(env,nullptr,Owner(*main),"payloadVersion","()I",{},false);
    AOKI_LOG("[PacketPayload] Java payloadVersion=%d ok=%d error=%s",version.value.i,
        static_cast<int>(version.ok),version.error.c_str());
    return version.ok&&!Exception(env,"payloadVersion")&&version.value.i==1;
}
bool BindCallbacks(JNIEnv* env) {
    // Register every Java-object packet consumer on the single proxy chain.
    // Individual callbacks remain inert until their module is enabled.
    packets::SetFilter("FreeCam", &features::freecam::BeforeSend, nullptr, 20);
    packets::SetFilter("AutoDisconnect", nullptr, &features::disconnect::BeforeReceive, 40);
    packets::SetFilter("ExtraModules", &features::extras::BeforeSend, &features::extras::BeforeReceive, 90);
    packets::SetFilter("Scaffold", &features::scaffold::BeforeSend, nullptr, 95);
    packets::SetFilter("Velocity", nullptr, &features::velocity::BeforeReceive, 200);
    packets::SetFilter("NoRotate", &features::norotate::BeforeSend, &features::norotate::BeforeReceive, 300);
    packets::SetFilter("PacketChat", nullptr, &packet_chat::BeforeReceive, 1000);
    if(!packets::BindNativeCallbacks(env,state.mainClass))return false;
    const auto main=std::find_if(state.classes.begin(),state.classes.end(),[](const auto& rec){return rec.name==mainName;});
    if(main==state.classes.end())return false;
    const auto version=methods::Invoke(env,nullptr,Owner(*main),"nativeBridgeVersion","()I",{},false);
    AOKI_LOG("[PacketPayload] Java -> native roundtrip version=%d ok=%d error=%s",version.value.i,
        static_cast<int>(version.ok),version.error.c_str());
    return version.ok&&!Exception(env,"nativeBridgeVersion")&&version.value.i==1;
}
bool ValidateObject(jobject handle,const char* expected,const char* label) {
    const auto oop=handle?Read<uintptr_t>(reinterpret_cast<uintptr_t>(handle)):0;
    uintptr_t klass=0;
    if(oop>=0x10000 && !(oop&7)) {
        const auto field=state.profile->members.at("HeapObject.klass");
        if(Read<bool>(Api("UseCompressedClassPointers"))) {
            const auto shift=Read<unsigned>(Api("Universe.narrow_klass_shift"));
            if(shift<=16)klass=Read<uintptr_t>(Api("Universe.narrow_klass_base"))
                +(uintptr_t(Read<uint32_t>(oop+field))<<shift);
        } else klass=Read<uintptr_t>(oop+field);
    }
    bool ok=false;const auto wanted=Find(expected);
    for(auto current=klass,depth=uintptr_t(0);current>=0x10000&&depth<128;++depth) {
        if(wanted && current==wanted){ok=true;break;}
        const auto parent=Read<uintptr_t>(current+JvmMapper::Klass::super_klass);
        if(parent==current)break;current=parent;
    }
    AOKI_LOG("[PacketPayload] F10 object %s handle=%p oop=%p klass=%p expected=%s valid=%d",label,handle,
        reinterpret_cast<void*>(oop),reinterpret_cast<void*>(klass),expected,static_cast<int>(ok));
    return ok;
}
bool Install(JNIEnv* env) {
    AOKI_LOG("[PacketPayload] F10 resolve NetworkManager BEFORE");
    auto manager=NetworkManager(env);
    if(Exception(env,"resolve NetworkManager") || !ValidateObject(manager,MappedClass("NetworkManager"),"manager"))return false;
    auto networkClass=Mirror(env,Find(MappedClass("NetworkManager")));
    auto packetClass=Mirror(env,Find(MappedClass("Packet")));
    if(!networkClass||!ValidateObject(packetClass,"java/lang/Class","packet type"))return false;
    const auto channel=Spec("NetworkManager.channel"),listener=Spec("NetworkManager.packetListener");
    AOKI_LOG("[PacketPayload] F10 reflected fields BEFORE");
    auto channelId=env->GetFieldID(networkClass,channel->name,channel->descriptor);
    auto listenerId=env->GetFieldID(networkClass,listener->name,listener->descriptor);
    if(Exception(env,"network field IDs"))return false;
    auto channelField=channelId?env->ToReflectedField(networkClass,channelId,JNI_FALSE):nullptr;
    auto listenerField=listenerId?env->ToReflectedField(networkClass,listenerId,JNI_FALSE):nullptr;
    if(Exception(env,"live packet fields") || !ValidateObject(channelField,"java/lang/reflect/Field","channel Field")
        || !ValidateObject(listenerField,"java/lang/reflect/Field","listener Field"))return false;
    const auto main=std::find_if(state.classes.begin(),state.classes.end(),[](const auto& rec){return rec.name==mainName;});
    if(main==state.classes.end())return false;
    auto owner=Owner(*main);
    std::vector<methods::Argument> args;
    for(const auto object:{manager,static_cast<jobject>(packetClass),channelField,listenerField}) {
        methods::Argument arg{methods::Type::Object};arg.value.l=object;args.push_back(arg);
    }
    AOKI_LOG("[PacketPayload] F10 installNative BEFORE: MethodDispatch, four typed object arguments");
    auto result=methods::Invoke(env,nullptr,owner,"installNative",
        "(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/reflect/Field;Ljava/lang/reflect/Field;)Lclient/packethook/PacketHook;",args,false);
    AOKI_LOG("[PacketPayload] F10 installNative AFTER: ok=%d hook=%p error=%s",static_cast<int>(result.ok),result.value.l,result.error.c_str());
    if(!result.ok || !ValidateObject(result.value.l,mainName,"returned hook")){result.Release(env);return false;}
    if(!packets::SetHook(env,result.value.l,owner)) {
        auto closed=methods::Invoke(env,result.value.l,owner,"close","()V",{},false);
        AOKI_LOG("[PacketPayload] F10 hook cleanup=%d",static_cast<int>(closed.ok));
        result.Release(env);return false;
    }
    result.Release(env);
    if(!packets::IsInstalled(env))return false;
    state.liveManager=env->NewGlobalRef(manager);
    if(!state.liveManager)return false;
    AOKI_LOG("[PacketPayload] AUTO installed; gameplay function keys are not reserved");
    return true;
}
bool Run(JNIEnv* env,unsigned step) {
    switch(step) {
    case 0:return ReadJar(); case 1:return Bind(env); case 2:return BuildMethods(env);
    case 3:return Prepare(); case 4:return Link(); case 5:return Mirrors();
    case 6:return Dictionaries(); case 7:return Initialize(env);
    case 8:return BindCallbacks(env);case 9:return Install(env);default:return false;
    }
}
}
void PrintHelp() {
    AOKI_LOG("[PacketPayload] REFERENCE metadata loader; automatic setup ON; no DefineClass/URLClassLoader");
    AOKI_LOG("[PacketPayload] waits for live connection");
    AOKI_LOG("[PacketPayload] automatic setup; gameplay function keys are not reserved");
}
void Poll(JNIEnv* env) {
    if(!state.sequence.Enabled()||state.sequence.Failed())return;
    if(state.renderThread&&state.renderThread!=GetCurrentThreadId())return;
    if(env->ExceptionCheck())return;
    const auto now=GetTickCount64();
    if(state.sequence.Next()==10) {
        if(env->PushLocalFrame(32)!=JNI_OK)return;
        if(now>=state.nextNetworkTick) {
            state.nextNetworkTick=now+250;
            auto manager=NetworkManager(env);
            if(Exception(env,"automatic network readiness")) {
                state.sequence.Complete(false);
            } else if(!env->IsSameObject(manager,state.liveManager)) {
                
                const bool detached=packets::Uninstall(env);
                if(state.liveManager){env->DeleteGlobalRef(state.liveManager);state.liveManager=nullptr;}
                if(!detached||Exception(env,"connection detach"))state.sequence.Complete(false);
                else if(manager) {
                    if(!Install(env)||Exception(env,"connection reinstall"))state.sequence.Complete(false);
                } else AOKI_LOG("[PacketPayload] connection ended; waiting for next NetworkManager");
            }
        }
        if(Exception(env,"automatic input readiness")){state.sequence.Complete(false);}
        env->PopLocalFrame(nullptr);return;
    }
    if(now<state.nextAutoTick)return;
    state.nextAutoTick=now+100;
    const auto step=state.sequence.Next();
    if(!state.sequence.CanRun(step))return;
    if(env->PushLocalFrame(128)!=JNI_OK)return;
    if(step==9) {
        // A missing player/connection is normal on menus; never fail or replay metadata.
        const auto manager=NetworkManager(env);
        const bool error=Exception(env,"wait for NetworkManager");
        if(!manager&&!error){env->PopLocalFrame(nullptr);state.nextAutoTick=now+250;return;}
        if(error){env->PopLocalFrame(nullptr);state.sequence.Complete(false);return;}
    }
    state.lastAttempt=step+1;const auto started=GetTickCount64();
    AOKI_LOG("[PacketPayload] AUTO stage=%u BEFORE %s",step+1,stages[step]);
    bool ok=false;
    try { ok=Run(env,step); }
    catch(const std::exception& e){AOKI_LOG("[PacketPayload] C++ error: %s",e.what());}
    if(Exception(env,stages[step]))ok=false;
    if(state.thread) {
        const auto threadState=Read<int>(state.thread+JvmMapper::JavaThread::thread_state);
        const auto pending=Read<uintptr_t>(state.thread+JvmMapper::JavaThread::pending_exception);
        AOKI_LOG("[PacketPayload] thread state=%d pending=%p",threadState,reinterpret_cast<void*>(pending));
        ok=ok&&threadState==4&&!pending;
    }
    env->PopLocalFrame(nullptr);
    state.sequence.Complete(ok);
    AOKI_LOG("[PacketPayload] AUTO stage=%u AFTER %s result=%s elapsed=%llums",step+1,stages[step],ok?"PASS":"FAIL",
        static_cast<unsigned long long>(GetTickCount64()-started));
    if(!ok)AOKI_LOG("[PacketPayload] STOPPED: no retry/reset and no metadata rollback");
}
}
