#include "client/HotSpotRuntime.hpp"

#include "client/HotSpotAccess.hpp"
#include "client/OffsetRepository.hpp"
#include "client/ThreadTransition.hpp"

#include <Windows.h>
#include <atomic>
#include <limits>

namespace client::hotspot::runtime {
namespace {

struct Context {
    std::shared_ptr<const offsets::Profile> profile;
    std::uintptr_t base = 0;
    std::uintptr_t thread = 0;
    volatile int* state = nullptr;
};

std::optional<std::uintptr_t> Rva(const offsets::Profile& profile, const char* key)
{
    const auto found = profile.rvas.find(key);
    return found == profile.rvas.end() ? std::nullopt : std::optional<std::uintptr_t>(found->second);
}

std::optional<std::uint32_t> Member(const offsets::Profile& profile, const char* key)
{
    const auto found = profile.members.find(key);
    return found == profile.members.end() ? std::nullopt : std::optional<std::uint32_t>(found->second);
}

std::optional<Context> Load(JNIEnv* env)
{
    if (!env) return std::nullopt;
    Context context;
    context.profile = offsets::Get();
    context.base = reinterpret_cast<std::uintptr_t>(GetModuleHandleW(L"jvm.dll"));
    if (!context.profile || !context.base) return std::nullopt;
    const auto environment = Member(*context.profile, "JavaThread.jni_environment");
    const auto state = Member(*context.profile, "JavaThread.state");
    if (!environment || !state || reinterpret_cast<std::uintptr_t>(env) < *environment) return std::nullopt;
    context.thread = reinterpret_cast<std::uintptr_t>(env) - *environment;
    context.state = reinterpret_cast<volatile int*>(context.thread + *state);
    return context;
}

class VmAccess {
public:
    explicit VmAccess(Context& context) : context_(context)
    {
        const int current = *context_.state;
        if (current == 6) {
            valid_ = true;
            return;
        }
        if (current != 4) return;
        if (!thread_transition::EnterVm(context_.base, *context_.profile,
                context_.thread, context_.state)) return;
        transitioned_ = true;
        valid_ = true;
    }

    ~VmAccess()
    {
        if (!transitioned_) return;
        thread_transition::LeaveVm(context_.base, *context_.profile,
            context_.thread, context_.state);
    }

    explicit operator bool() const { return valid_; }

private:
    Context& context_;
    bool valid_ = false;
    bool transitioned_ = false;
};

std::uintptr_t* RootSlot(jobject handle)
{
    if (!handle) return nullptr;
    auto address = reinterpret_cast<std::uintptr_t>(handle);
    if (address & 1) --address;
    return reinterpret_cast<std::uintptr_t*>(address);
}

jobject MakeGlobal(Context& context, std::uintptr_t* rootedOop)
{
    if (!rootedOop || !*rootedOop) return nullptr;
    const auto makeGlobal = Rva(*context.profile, "JNIHandles.make_global");
    if (!makeGlobal) return nullptr;
    VmAccess access(context);
    if (!access) return nullptr;
    using Make = jobject(__fastcall*)(std::uintptr_t*);
    return reinterpret_cast<Make>(context.base + *makeGlobal)(rootedOop);
}

} // namespace

std::uintptr_t Resolve(jobject handle)
{
    if (!handle) return 0;
    const auto profile = offsets::Get();
    const auto base = reinterpret_cast<std::uintptr_t>(GetModuleHandleW(L"jvm.dll"));
    const auto address = reinterpret_cast<std::uintptr_t>(handle);
    if (!(address & 1)) return hotspot::Read<std::uintptr_t>(address).value_or(0);
    if (!profile || !base) return 0;
    const auto resolveWeak = Rva(*profile, "JNIHandles.resolve_jweak");
    if (!resolveWeak) return 0;
    using ResolveWeak = std::uintptr_t(__fastcall*)(std::uintptr_t);
    return reinterpret_cast<ResolveWeak>(base + *resolveWeak)(address);
}

jobject Local(JNIEnv* env, std::uintptr_t oop)
{
    if (!env || !oop) return nullptr;
    const auto context = Load(env);
    if (!context) return nullptr;
    const auto makeLocal = Rva(*context->profile, "JNIHandles.make_local");
    if (!makeLocal) return nullptr;
    using Make = jobject(__fastcall*)(JNIEnv*, std::uintptr_t);
    return reinterpret_cast<Make>(context->base + *makeLocal)(env, oop);
}

jobject LocalFromRoot(JNIEnv* env, std::uintptr_t* rootedOop)
{
    if (!env || !rootedOop) return nullptr;
    auto context = Load(env);
    if (!context) return nullptr;
    const auto makeLocal = Rva(*context->profile, "JNIHandles.make_local");
    if (!makeLocal) return nullptr;
    VmAccess access(*context);
    if (!access || !*rootedOop) return nullptr;
    using Make = jobject(__fastcall*)(JNIEnv*, std::uintptr_t);
    return reinterpret_cast<Make>(context->base + *makeLocal)(env, *rootedOop);
}

jobject Global(JNIEnv* env, jobject source)
{
    auto context = Load(env);
    return context ? MakeGlobal(*context, RootSlot(source)) : nullptr;
}

jobject GlobalFromRoot(JNIEnv* env, std::uintptr_t* rootedOop)
{
    auto context = Load(env);
    return context ? MakeGlobal(*context, rootedOop) : nullptr;
}

bool DestroyGlobal(JNIEnv* env, jobject global)
{
    if (!global) return true;
    auto context = Load(env);
    if (!context) return false;
    const auto destroy = Rva(*context->profile, "JNIHandles.destroy_global");
    if (!destroy) return false;
    VmAccess access(*context);
    if (!access) return false;
    using Destroy = void(__fastcall*)(jobject);
    reinterpret_cast<Destroy>(context->base + *destroy)(global);
    return true;
}

jobject LoadObject(JNIEnv* env, jobject owner, std::uint32_t offset)
{
    if (!env || !owner) return nullptr;
    auto context = Load(env);
    const auto constants = hotspot::GetConstants();
    if (!context || !constants || !constants->compressedOops) return nullptr;
    const auto makeLocal = Rva(*context->profile, "JNIHandles.make_local");
    if (!makeLocal) return nullptr;
    VmAccess access(*context);
    if (!access) return nullptr;
    const auto ownerOop = Resolve(owner);
    if (!ownerOop || ownerOop > std::numeric_limits<std::uintptr_t>::max() - offset)
        return nullptr;
    const auto valueOop = hotspot::ReadObjectReference(ownerOop + offset).value_or(0);
    if (!valueOop) return nullptr;
    using Make = jobject(__fastcall*)(JNIEnv*, std::uintptr_t);
    return reinterpret_cast<Make>(context->base + *makeLocal)(env, valueOop);
}

bool LoadPrimitive(JNIEnv* env, jobject owner, std::uint32_t offset,
    void* output, std::size_t size)
{
    if (!env || !owner || !output || !size) return false;
    auto context = Load(env);
    if (!context) return false;
    VmAccess access(*context);
    if (!access) return false;
    const auto ownerOop = Resolve(owner);
    if (!ownerOop || ownerOop > std::numeric_limits<std::uintptr_t>::max() - offset)
        return false;
    return hotspot::ReadMemory(ownerOop + offset, output, size);
}

bool IsInstance(JNIEnv* env, jobject object, std::uintptr_t targetKlass,
    std::uint32_t superOffset)
{
    if (!env || !object || !targetKlass) return false;
    auto context = Load(env);
    const auto constants = hotspot::GetConstants();
    const auto klassOffset = context
        ? Member(*context->profile, "HeapObject.klass") : std::nullopt;
    if (!context || !constants || !constants->compressedKlass || !klassOffset)
        return false;
    VmAccess access(*context);
    if (!access) return false;
    const auto oop = Resolve(object);
    if (!oop) return false;
    std::uintptr_t klass = 0;
    if (!*constants->compressedKlass) {
        klass = hotspot::Read<std::uintptr_t>(oop + *klassOffset).value_or(0);
    }
    else {
        const auto shift = constants->narrowKlassShift.value_or(64);
        const auto narrow = hotspot::Read<std::uint32_t>(
            oop + *klassOffset).value_or(0);
        if (shift > 16 || !narrow) return false;
        klass = constants->narrowKlassBase.value_or(0) +
            (static_cast<std::uintptr_t>(narrow) << shift);
    }
    for (unsigned depth = 0; klass && depth < 64; ++depth) {
        if (klass == targetKlass) return true;
        klass = hotspot::Read<std::uintptr_t>(klass + superOffset).value_or(0);
    }
    return false;
}

bool StoreObject(JNIEnv* env, jobject owner, std::uint32_t offset, jobject value)
{
    if (!owner) return false;
    auto context = Load(env);
    const auto constants = hotspot::GetConstants();
    if (!context || !constants || !constants->compressedOops) return false;
    const auto store = Rva(*context->profile,
        *constants->compressedOops ? "Heap.store_oop_compressed" : "Heap.store_oop");
    if (!store) return false;
    VmAccess access(*context);
    if (!access) return false;
    const auto ownerOop = Resolve(owner);
    const auto valueOop = Resolve(value);
    if (!ownerOop || ownerOop > std::numeric_limits<std::uintptr_t>::max() - offset) return false;
    using Store = void(__fastcall*)(std::uintptr_t, std::uintptr_t);
    reinterpret_cast<Store>(context->base + *store)(ownerOop + offset, valueOop);
    return true;
}

} // namespace client::hotspot::runtime
