#include "BridgeCode.hpp"

namespace probe {
namespace {
void Bytes(std::vector<unsigned char>& output, std::initializer_list<unsigned char> bytes) {
    output.insert(output.end(), bytes);
}
void Address(std::vector<unsigned char>& output, std::uintptr_t address) {
    for (unsigned i = 0; i < 8; ++i) output.push_back(static_cast<unsigned char>(address >> (i * 8)));
}
void Jump(std::vector<unsigned char>& output, std::uintptr_t address) {
    Bytes(output, {0xFF,0x25,0,0,0,0}); Address(output,address);
}
}
std::vector<unsigned char> CompareThunk(std::span<const unsigned char> instruction,
    std::uintptr_t manualReturn, std::uintptr_t trampoline) {
    if (!manualReturn || !trampoline || instruction.size() < 3 || instruction[0] != 0x48) return {};
    std::vector<unsigned char> compare;
    if (instruction[1] == 0x3B) {
        if ((instruction.size() == 7 && instruction[2] == 0x0D) ||
            (instruction.size() == 3 && instruction[2] == 0xC8))
            Bytes(compare,{0x49,0x3B,0xCB}); // cmp rcx,r11
        else if (instruction.size() == 7 && instruction[2] == 0x3D)
            Bytes(compare,{0x49,0x3B,0xFB}); // cmp rdi,r11
        else if (instruction.size() == 3 && instruction[2] == 0xC1)
            Bytes(compare,{0x49,0x3B,0xC3}); // cmp rax,r11
    } else if (instruction[1] == 0x39) {
        if (instruction.size() == 4 && instruction[3] == 8) {
            if (instruction[2] == 0x43) Bytes(compare,{0x4C,0x39,0x5B,8});
            if (instruction[2] == 0x47) Bytes(compare,{0x4C,0x39,0x5F,8});
        } else if (instruction.size() == 5 && instruction[2] == 0x44 && instruction[3] == 0x24 &&
                   instruction[4] <= 0x77) {
            // The scratch push moves RSP down eight bytes. Use the original operand address.
            Bytes(compare,{0x4C,0x39,0x5C,0x24,static_cast<unsigned char>(instruction[4]+8)});
        }
    }
    if (compare.empty()) return {};
    std::vector<unsigned char> output;
    Bytes(output,{0x41,0x53,0x49,0xBB}); // push r11; mov r11, manualReturn
    Address(output,manualReturn);
    output.insert(output.end(),compare.begin(),compare.end());
    Bytes(output,{0x41,0x5B,0x74,0x0E}); // pop r11; je recognized
    Jump(output,trampoline); // Re-execute original CMP for every other PC.
    Jump(output,trampoline+instruction.size()); // Equality flags survive the POP/JMP.
    return output;
}
}
