#pragma once
#include <cstdint>
namespace probe {
bool InstallFrameHooks(std::uintptr_t jvm);
bool DisableFrameHooks();
}
