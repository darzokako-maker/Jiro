#pragma once
#include <cstdint>
#include <span>
#include <vector>

namespace probe {
// Preserve the original comparison for all PCs except our additional entry-frame PC.
std::vector<unsigned char> CompareThunk(std::span<const unsigned char> instruction,
    std::uintptr_t manualReturn, std::uintptr_t trampoline);
}
