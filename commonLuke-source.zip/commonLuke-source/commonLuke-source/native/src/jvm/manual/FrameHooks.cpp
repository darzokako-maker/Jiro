#include "FrameHooks.hpp"
#include "AuditSites.hpp"
#include "BridgeCode.hpp"
#include "ProbeMemory.hpp"
#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include <MinHook.h>
#include <cstring>
#include <vector>

extern "C" unsigned char ManualVmReturn, ManualVmCatch;
namespace probe {
namespace {
struct Hook {void* target; void* code;};
std::vector<Hook> hooks;
using ExceptionHandler=std::uintptr_t(__fastcall*)(std::uintptr_t,std::uintptr_t);
ExceptionHandler originalException1=nullptr,originalException2=nullptr;
std::uint32_t exceptionFlagOffset=0;
std::uintptr_t __fastcall Exception1(std::uintptr_t thread,std::uintptr_t pc) {
    if(pc==reinterpret_cast<std::uintptr_t>(&ManualVmReturn)) {
        Put<std::uint32_t>(thread+exceptionFlagOffset,0);
        return reinterpret_cast<std::uintptr_t>(&ManualVmCatch);
    }
    return originalException1(thread,pc);
}
std::uintptr_t __fastcall Exception2(std::uintptr_t thread,std::uintptr_t pc) {
    if(pc==reinterpret_cast<std::uintptr_t>(&ManualVmReturn)) {
        Put<std::uint32_t>(thread+exceptionFlagOffset,0);
        return reinterpret_cast<std::uintptr_t>(&ManualVmCatch);
    }
    return originalException2(thread,pc);
}
bool CheckExceptionEntry(std::uintptr_t address,const std::array<unsigned char,20>& prefix) {
    unsigned char bytes[20]{};
    return Copy(address,bytes,sizeof(bytes)) && std::memcmp(bytes,prefix.data(),sizeof(bytes))==0;
}
}
bool DisableFrameHooks() {
    bool ok=true;
    for(const auto& hook:hooks) if(MH_QueueDisableHook(hook.target)!=MH_OK) ok=false;
    if(MH_ApplyQueued()!=MH_OK) ok=false;
    AOKI_LOG("[Probe] frame/exception hooks disabled=%d count=%zu; code retained until process exit",int(ok),hooks.size());
    // Retain trampolines and executable allocations: a suspended other thread may still be in a thunk.
    return ok;
}
bool InstallFrameHooks(std::uintptr_t jvm) {
    if(!hooks.empty()) return false;
    const auto profile=client::offsets::Get();
    if(!profile || profile->id!=auditProfileId)return false;
    exceptionFlagOffset=profile->members.at("JavaThread.exception_dispatch_flag");
    // Validate the entire custom-build manifest before modifying any instruction.
    for(const auto& site:sites) {
        unsigned char actual[7]{};
        if(!Copy(jvm+site.rva,actual,site.length) || std::memcmp(actual,site.bytes.data(),site.length)!=0) {
            AOKI_LOG("[Probe] profile mismatch CMP RVA=0x%llX; no bridge installed",static_cast<unsigned long long>(site.rva));
            return false;
        }
    }
    for(const auto& site:exceptionSites)
        if(!CheckExceptionEntry(jvm+profile->rvas.at(site.key),site.prefix)) {
            AOKI_LOG("[ManualVM] exception handler profile mismatch key=%s",site.key); return false;
        }
    hooks.reserve(std::size(sites)+2);
    for(const auto& site:sites) {
        auto* page=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READ));
        auto* target=reinterpret_cast<void*>(jvm+site.rva);
        void* trampoline=nullptr;
        const auto status=page?MH_CreateHook(target,page,&trampoline):MH_ERROR_MEMORY_ALLOC;
        if(status!=MH_OK) {
            AOKI_LOG("[Probe] create CMP RVA=0x%llX failed=%s",static_cast<unsigned long long>(site.rva),MH_StatusToString(status));
            if(page)VirtualFree(page,0,MEM_RELEASE);
            return false; // All created hooks are still disabled.
        }
        hooks.push_back({target,page});
        const auto code=CompareThunk(std::span(site.bytes).first(site.length),
            reinterpret_cast<std::uintptr_t>(&ManualVmReturn),reinterpret_cast<std::uintptr_t>(trampoline));
        DWORD previous=0;
        if(code.empty() || !VirtualProtect(page,4096,PAGE_READWRITE,&previous)) return false;
        std::memcpy(page,code.data(),code.size());
        if(!VirtualProtect(page,4096,PAGE_EXECUTE_READ,&previous))return false;
        FlushInstructionCache(GetCurrentProcess(),page,code.size());
        AOKI_LOG("[Probe] prepared CMP RVA=0x%llX length=%u thunk=%p trampoline=%p",
            static_cast<unsigned long long>(site.rva),site.length,page,trampoline);
    }
    struct ExceptionSite {std::uintptr_t rva;void* replacement;ExceptionHandler* original;};
    const ExceptionSite exceptions[]{
        {profile->rvas.at(exceptionSites[0].key),reinterpret_cast<void*>(&Exception1),&originalException1},
        {profile->rvas.at(exceptionSites[1].key),reinterpret_cast<void*>(&Exception2),&originalException2}};
    for(const auto& site:exceptions) {
        auto* target=reinterpret_cast<void*>(jvm+site.rva);
        const auto status=MH_CreateHook(target,site.replacement,reinterpret_cast<void**>(site.original));
        if(status!=MH_OK) {AOKI_LOG("[Probe] exception hook failed=%s",MH_StatusToString(status));return false;}
        hooks.push_back({target,nullptr});
    }
    for(const auto& hook:hooks) if(MH_QueueEnableHook(hook.target)!=MH_OK) {
        DisableFrameHooks(); return false;
    }
    const auto applied=MH_ApplyQueued();
    if(applied!=MH_OK) {AOKI_LOG("[Probe] apply hooks failed=%s",MH_StatusToString(applied));DisableFrameHooks();return false;}
    AOKI_LOG("[Probe] installed %zu additive frame/exception hooks; original stub and global return PC untouched",hooks.size());
    return true;
}
}
