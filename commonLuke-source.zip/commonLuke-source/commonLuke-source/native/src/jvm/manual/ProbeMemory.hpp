#pragma once
#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <string>

namespace probe {
inline bool Copy(std::uintptr_t address, void* output, std::size_t size) {
    if (!address || !output || address + size < address) return false;
    __try { std::memcpy(output,reinterpret_cast<void*>(address),size); return true; }
    __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
}
template<class T> T Read(std::uintptr_t address) {
    T value{}; Copy(address,&value,sizeof(value)); return value;
}
template<class T> void Put(std::uintptr_t address, T value) {
    *reinterpret_cast<volatile T*>(address)=value;
}
inline std::string Symbol(std::uintptr_t symbol) {
    const auto length=Read<std::uint16_t>(symbol);
    if(!symbol || !length || length>1024) return {};
    std::string output(length,'\0');
    return Copy(symbol+8,output.data(),length)?output:std::string{};
}
}
