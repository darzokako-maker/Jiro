; Experimental Windows x64 -> HotSpot interpreter bridge.
; Own entry PC, own return PC, own exception landing pad. No JVM stub is called.
OPTION CASEMAP:NONE
include ManualVmOffsets.inc
.code
PUBLIC ManualVmEntry
PUBLIC ManualVmReturn
PUBLIC ManualVmCatch

; (wrapper, result, type, method, entry, slots, count, thread, heapBase)
ManualVmEntry PROC FRAME
    push rbp
    .pushreg rbp
    mov rbp, rsp
    sub rsp, 216
    .allocstack 216
    mov [rsp+208], rbx
    .savereg rbx, 208
    mov [rsp+200], rsi
    .savereg rsi, 200
    mov [rsp+192], rdi
    .savereg rdi, 192
    mov [rsp+184], r12
    .savereg r12, 184
    mov [rsp+176], r13
    .savereg r13, 176
    mov [rsp+168], r14
    .savereg r14, 168
    mov [rsp+160], r15
    .savereg r15, 160
    movdqu [rsp+144], xmm6
    .savexmm128 xmm6, 144
    movdqu [rsp+128], xmm7
    .savexmm128 xmm7, 128
    movdqu [rsp+112], xmm8
    .savexmm128 xmm8, 112
    movdqu [rsp+96], xmm9
    .savexmm128 xmm9, 96
    movdqu [rsp+80], xmm10
    .savexmm128 xmm10, 80
    movdqu [rsp+64], xmm11
    .savexmm128 xmm11, 64
    movdqu [rsp+48], xmm12
    .savexmm128 xmm12, 48
    movdqu [rsp+32], xmm13
    .savexmm128 xmm13, 32
    movdqu [rsp+16], xmm14
    .savexmm128 xmm14, 16
    movdqu [rsp], xmm15
    .savexmm128 xmm15, 0
    .endprolog
    ; Preserve HotSpot's entry-frame layout so GC can find our manually built wrapper.
    mov [rbp+16], rcx
    mov [rbp+24], rdx
    mov [rbp+32], r8d
    mov [rbp+40], r9
    mov r15, [rbp+72]
    mov r12, [rbp+80]
    mov r10d, [rbp+64]
    mov r11, [rbp+56]
    test r10d, r10d
    jz parameters_ready
parameters_loop:
    push qword ptr [r11]
    lea r11, [r11+8]
    dec r10d
    jnz parameters_loop
parameters_ready:
    mov rbx, [rbp+40]
    mov r13, rsp
    mov rdx, [rbp+48]
    call rdx
ManualVmReturn LABEL NEAR
    mov rcx, [rbp+24]
    mov edx, [rbp+32]
    cmp edx, 14
    je restore_registers
    cmp edx, 12
    je result_wide
    cmp edx, 11
    je result_wide
    cmp edx, 6
    je result_float
    cmp edx, 7
    je result_double
    mov dword ptr [rcx], eax
    jmp restore_registers
result_wide:
    mov qword ptr [rcx], rax
    jmp restore_registers
result_float:
    movss dword ptr [rcx], xmm0
    jmp restore_registers
result_double:
    movsd qword ptr [rcx], xmm0
restore_registers:
    lea rsp, [rbp-216]
    movdqu xmm15, [rsp]
    movdqu xmm14, [rsp+16]
    movdqu xmm13, [rsp+32]
    movdqu xmm12, [rsp+48]
    movdqu xmm11, [rsp+64]
    movdqu xmm10, [rsp+80]
    movdqu xmm9, [rsp+96]
    movdqu xmm8, [rsp+112]
    movdqu xmm7, [rsp+128]
    movdqu xmm6, [rsp+144]
    mov r15, [rsp+160]
    mov r14, [rsp+168]
    mov r13, [rsp+176]
    mov r12, [rsp+184]
    mov rdi, [rsp+192]
    mov rsi, [rsp+200]
    mov rbx, [rsp+208]
    add rsp, 216
    pop rbp
    ret
ManualVmEntry ENDP

; Java exception routing reaches us with RAX=exception oop and RBP=entry frame.
ManualVmCatch PROC
    mov [r15+THREAD_PENDING_EXCEPTION], rax
    mov qword ptr [r15+THREAD_EXCEPTION_FILE], 0
    mov dword ptr [r15+THREAD_EXCEPTION_LINE], 0
    xor eax, eax
    jmp ManualVmReturn
ManualVmCatch ENDP
END
