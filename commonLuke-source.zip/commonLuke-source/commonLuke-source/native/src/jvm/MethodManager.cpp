#include "client/MethodManager.hpp"
#include "client/HotSpotAccess.hpp"
#include "client/OffsetRepository.hpp"
#include "client/Logger.hpp"
#include "client/ThreadTransition.hpp"
#include "game/MappingRepository.hpp"
#include <Windows.h>
#include <intrin.h>
#include <vector>

namespace client::methods {
std::optional<std::string> InvokeString(JNIEnv* env, std::uintptr_t receiver, std::uintptr_t method)
{
    const auto p = offsets::Get();
    if (!env || !receiver || !method || !p) return {};
    const auto base = reinterpret_cast<std::uintptr_t>(GetModuleHandleW(L"jvm.dll"));
    const auto thread = reinterpret_cast<std::uintptr_t>(env) - p->members.at("JavaThread.jni_environment");
    auto* state = reinterpret_cast<int*>(thread + p->members.at("JavaThread.state"));
    auto* exception = reinterpret_cast<std::uintptr_t*>(thread + p->members.at("JavaThread.pending_exception"));
    if (*state != 4 || *exception) return {};
    const auto stub = hotspot::Read<std::uintptr_t>(base + p->rvas.at("StubRoutines.call_stub"));
    const auto entry = hotspot::Read<std::uintptr_t>(method + p->members.at("Method.from_interpreted_entry"));
    if (!stub || !*stub || !entry || !*entry) return {};
    // Root the receiver in the current JNI local frame before a safepoint.
    const auto rooted = env->NewLocalRef(reinterpret_cast<jobject>(&receiver));
    if (!rooted || env->ExceptionCheck()) return {};
    if (!thread_transition::EnterVm(base, *p, thread, state)) {
        env->DeleteLocalRef(rooted);
        return {};
    }
    struct Result { int type = 12; int padding = 0; std::uint64_t value = 0; } result;
    struct MetadataHandle { std::uintptr_t value, thread; };
    MetadataHandle source{method,thread},owned{};
    using Copy=MetadataHandle*(__fastcall*)(MetadataHandle*,const MetadataHandle*);
    if(reinterpret_cast<Copy>(base+p->rvas.at("MetadataHandle.copy"))(&owned,&source)!=&owned||owned.value!=method) {
        thread_transition::LeaveVm(base,*p,thread,state);env->DeleteLocalRef(rooted);return {};
    }
    alignas(16) std::uintptr_t wrapper[8]{};
    using Construct = void(__fastcall*)(void*, void*, void*, void*, std::uintptr_t);
    reinterpret_cast<Construct>(base + p->rvas.at("JavaCallWrapper.construct"))(
        wrapper, &owned, rooted, &result, thread);
    using Stub = void(__fastcall*)(void*, void*, int, std::uintptr_t, std::uintptr_t, void*, int, std::uintptr_t);
    if (!*exception) {
        std::uintptr_t arguments[]{wrapper[3]};
        reinterpret_cast<Stub>(*stub)(wrapper, &result.value, 12, method, *entry, arguments, 1, thread);
    }
    // Protect an object result while the wrapper releases temporary handles.
    auto* vmResult = reinterpret_cast<std::uintptr_t*>(thread + p->members.at("JavaThread.vm_result"));
    const auto savedResult = *vmResult;
    *vmResult = result.value;
    using Destroy = void(__fastcall*)(void*);
    reinterpret_cast<Destroy>(base + p->rvas.at("JavaCallWrapper.destroy"))(wrapper);
    result.value = *vmResult;
    *vmResult = savedResult;
    std::optional<std::string> output;
    const auto data = classes::GetSnapshot();
    if (!*exception && result.value && data) {
        const auto it = data->byName.find(std::string(mapping::ClassName("JavaString")));
        if (it != data->byName.end() && it->second.size() == 1) {
            const auto field = mapping::ResolveField("JavaString.value");
            if (field) {
                const auto chars = hotspot::ReadObjectReference(result.value + field->offset);
                if (chars && *chars) {
                    const auto length = hotspot::Read<int>(*chars + p->members.at("HeapArray.length"));
                    if (length && *length >= 0 && *length <= 32768) {
                        std::vector<wchar_t> utf16(static_cast<std::size_t>(*length));
                        if (!*length) output = std::string{};
                        else if (hotspot::ReadMemory(*chars + p->members.at("HeapArray.data"), utf16.data(), utf16.size() * sizeof(wchar_t))) {
                            const auto bytes = WideCharToMultiByte(CP_UTF8, 0, utf16.data(), *length, nullptr, 0, nullptr, nullptr);
                            if (bytes > 0) {
                                std::string text(bytes, '\0');
                                WideCharToMultiByte(CP_UTF8, 0, utf16.data(), *length, text.data(), bytes, nullptr, nullptr);
                                output = std::move(text);
                            }
                        }
                    }
                }
            }
        }
    }
    if (!thread_transition::LeaveVm(base, *p, thread, state)) {
        env->DeleteLocalRef(rooted);
        return {};
    }
    if (env->ExceptionCheck()) { env->ExceptionClear(); AOKI_LOG("error: getName Java exception"); }
    env->DeleteLocalRef(rooted);
    return output;
}
void TestPlayerName(JNIEnv* env, std::uintptr_t player)
{
    static bool attempted = false;
    if (attempted) return;
    const auto data = classes::GetSnapshot();
    if (!data) return;
    // Mapping owner: EntityPlayer. The selected body is an explicit instance call.
    const auto it = data->byName.find(std::string(mapping::ClassName("EntityPlayer")));
    if (it == data->byName.end() || it->second.size() != 1) return;
    const auto spec = mapping::Method("Entity.getName");
    if (!spec) return;
    const auto method = hotspot::FindMethod(data->classes[it->second.front()], std::string(spec->name), std::string(spec->descriptor));
    if (!method || method->access_flags & (8 | 0x400)) return;
    attempted = true;
    const auto receiver = env->NewLocalRef(reinterpret_cast<jobject>(&player));
    if (!receiver) { AOKI_LOG("error: player handle unavailable"); return; }
    auto result = Invoke(env, receiver, data->classes[it->second.front()],
        std::string(spec->name), std::string(spec->descriptor));
    env->DeleteLocalRef(receiver);
    if (result.ok && result.value.l) {
        const auto string = static_cast<jstring>(result.value.l);
        const char* text = env->GetStringUTFChars(string, nullptr);
        if (text) { AOKI_LOG("player: %s", text); env->ReleaseStringUTFChars(string, text); }
        else { env->ExceptionClear(); AOKI_LOG("error: player string unreadable"); }
    } else AOKI_LOG("error: getName %s", result.error.c_str());
    result.Release(env);
}
}
