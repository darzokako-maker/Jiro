#include "client/MethodManager.hpp"
#include "client/ThreadTransition.hpp"
#include "client/HotSpotAccess.hpp"
#include "client/HotSpotRuntime.hpp"
#include "client/ObjectResultLifecycle.hpp"
#include "client/OffsetRepository.hpp"
#include "client/Logger.hpp"
#include <Windows.h>
#include <intrin.h>
#include <atomic>
#include <deque>
#include <mutex>
#include <cstring>

namespace client::methods {
namespace {
void ReleaseHotSpotGlobal(JNIEnv* env,jobject value)
{
    hotspot::runtime::DestroyGlobal(env,value);
}
std::mutex queueMutex;
std::deque<std::function<void(JNIEnv*)>> queue;
std::atomic<DWORD> renderThread{0};
bool ParseType(const std::string& d, std::size_t& i, Type& type)
{
    if (i >= d.size()) return false;
    switch (d[i++]) {
    case 'V': type=Type::Void; return true;
    case 'Z': type=Type::Boolean; return true;
    case 'B': type=Type::Byte; return true;
    case 'C': type=Type::Char; return true;
    case 'S': type=Type::Short; return true;
    case 'I': type=Type::Int; return true;
    case 'J': type=Type::Long; return true;
    case 'F': type=Type::Float; return true;
    case 'D': type=Type::Double; return true;
    case 'L': { const auto end=d.find(';',i); if(end==std::string::npos || end==i) return false; i=end+1; type=Type::Object; return true; }
    case '[': { Type element; if(!ParseType(d,i,element)||element==Type::Void) return false; type=Type::Object; return true; }
    default: return false;
    }
}
std::optional<MethodInfo> FindInHierarchy(const classes::ClassRecord& owner,
    const classes::Snapshot& data,const offsets::Profile& profile,
    const std::string& name,const std::string& descriptor)
{
    // Injected payload classes are built after the repository snapshot. Their
    // methods therefore exist only in the explicit owner record passed here.
    if(auto method=hotspot::FindMethod(owner,name,descriptor))return method;
    if(name=="<init>" || name=="<clinit>")return {}; // These bodies are never inherited.
    auto klass=hotspot::Read<std::uintptr_t>(owner.klass+profile.members.at("Klass.super")).value_or(0);
    for(unsigned depth=0;klass&&depth<256;++depth) {
        const auto it=data.byKlass.find(klass);
        if(it!=data.byKlass.end())
            if(auto method=hotspot::FindMethod(data.classes[it->second],name,descriptor))return method;
        klass=hotspot::Read<std::uintptr_t>(klass+profile.members.at("Klass.super")).value_or(0);
    }
    return {};
}
bool Implements(std::uintptr_t klass,std::uintptr_t wanted,const offsets::Profile& profile)
{
    const auto array=hotspot::Read<std::uintptr_t>(klass+profile.members.at("Klass.secondary_supers")).value_or(0);
    if(!array)return false;
    const auto count=hotspot::Read<std::uint32_t>(array+profile.members.at("Array.length")).value_or(0);
    if(count>4096)return false;
    const auto data=array+profile.members.at("Array.data");
    for(std::uint32_t i=0;i<count;++i)
        if(hotspot::Read<std::uintptr_t>(data+i*sizeof(std::uintptr_t)).value_or(0)==wanted)return true;
    return false;
}
}
bool Enqueue(std::function<void(JNIEnv*)> task)
{
    if(!task) return false;
    std::lock_guard lock(queueMutex);
    if(queue.size()>=256) return false;
    queue.push_back(std::move(task)); return true;
}
void Drain(JNIEnv* env)
{
    if(!env) return;
    DWORD unset=0;
    renderThread.compare_exchange_strong(unset,GetCurrentThreadId());
    if(renderThread.load()!=GetCurrentThreadId()) return;
    std::deque<std::function<void(JNIEnv*)>> batch;
    { std::lock_guard lock(queueMutex); for(int i=0;i<16&&!queue.empty();++i) {batch.push_back(std::move(queue.front()));queue.pop_front();} }
    for(auto& task:batch) { try {task(env);} catch(...) {} }
}
Result Invoke(JNIEnv* env,jobject receiver,const classes::ClassRecord& owner,
    const std::string& name,const std::string& descriptor,const std::vector<Argument>& args,bool virtualCall,bool explicitClassInitializer)
{
    Result out;
    auto fail=[&](const char* error) {
        out.error=error;
#if defined(AOKI_ENABLE_LOGGING)
        static std::atomic<unsigned> failures{0};
        const auto count=++failures;
        if(count<=32 || (count&(count-1))==0)
            AOKI_LOG("[CallStub] FAIL count=%u method=%s%s reason=%s",count,name.c_str(),descriptor.c_str(),error);
#endif
        return out;
    };
    if(!env || renderThread.load()!=GetCurrentThreadId()) return fail("wrong thread");
    if(env->ExceptionCheck()) return fail("pending exception");
    std::size_t at=1;
    if(descriptor.empty()||descriptor[0]!='(') return fail("invalid descriptor");
    for(const auto& arg:args) {Type expected; if(!ParseType(descriptor,at,expected)||expected==Type::Void||expected!=arg.type) return fail("argument type mismatch");}
    if(at>=descriptor.size()||descriptor[at++]!=')'||!ParseType(descriptor,at,out.type)||at!=descriptor.size()) return fail("invalid descriptor");
    const auto p=offsets::Get(); const auto data=classes::GetSnapshot();
    if(!p||!data) return fail("repository unavailable");
    auto method=FindInHierarchy(owner,*data,*p,name,descriptor);
    const auto constants=hotspot::GetConstants();
    const auto base=constants?constants->jvmBase:0;
    if(!method) return fail("method not found");
    const bool isStatic=(method->access_flags&8)!=0;
    if(!isStatic&&!receiver) return fail("null receiver");
    // Resolve the override from actual receiver Klass and its super chain.
    if(!isStatic) {
        if((method->access_flags&2) || name=="<init>")virtualCall=false;
        const auto oop=hotspot::Read<std::uintptr_t>(reinterpret_cast<std::uintptr_t>(receiver));
        if(!oop||!*oop) return fail("invalid receiver handle");
        if(!constants || !constants->compressedKlass) return fail("klass encoding unavailable");
        std::uintptr_t klass=0;
        if(*constants->compressedKlass) {
            const auto narrow=hotspot::Read<std::uint32_t>(*oop+p->members.at("HeapObject.klass"));
            if(!narrow||!constants->narrowKlassBase||!constants->narrowKlassShift||*constants->narrowKlassShift>16)
                return fail("klass encoding invalid");
            klass=*constants->narrowKlassBase+(static_cast<std::uintptr_t>(*narrow)<<*constants->narrowKlassShift);
        } else klass=hotspot::Read<std::uintptr_t>(*oop+p->members.at("HeapObject.klass")).value_or(0);
        bool compatible=false; std::optional<MethodInfo> selected;
        for(unsigned depth=0;klass&&depth<256;++depth) {
            if(klass==owner.klass||Implements(klass,owner.klass,*p)) compatible=true;
            if(virtualCall && !selected) { const auto it=data->byKlass.find(klass); if(it!=data->byKlass.end()) {
                const auto candidate=hotspot::FindMethod(data->classes[it->second],name,descriptor);
                if(candidate && !(candidate->access_flags&(8|2)))selected=candidate;
            } }
            klass=hotspot::Read<std::uintptr_t>(klass+p->members.at("Klass.super")).value_or(0);
        }
        if(!compatible) return fail("receiver class mismatch");
        if(selected) method=selected;
    }
    if(method->access_flags&0x400) return fail("abstract method");
    if(isStatic) {
        // Class initialization is deliberately explicit; never bypass <clinit>.
        const auto initState=hotspot::Read<std::uint8_t>(owner.klass+p->members.at("InstanceKlass.init_state")).value_or(0);
        if(initState!=4 && !(explicitClassInitializer && initState==3 && name=="<clinit>" && descriptor=="()V")) return fail("class not initialized");
    }
    const auto thread=reinterpret_cast<std::uintptr_t>(env)-p->members.at("JavaThread.jni_environment");
    auto* state=reinterpret_cast<volatile int*>(thread+p->members.at("JavaThread.state"));
    auto* exception=reinterpret_cast<std::uintptr_t*>(thread+p->members.at("JavaThread.pending_exception"));
    const auto metadataHandles=hotspot::Read<std::uintptr_t>(thread+p->members.at("JavaThread.metadata_handles")).value_or(0);
    const int handlesBefore=metadataHandles?hotspot::Read<int>(metadataHandles).value_or(-1):-1;
    if(*state!=4||*exception) return fail("thread not native");
    const auto stub=hotspot::Read<std::uintptr_t>(base+p->rvas.at("StubRoutines.call_stub"));
    const auto entry=hotspot::Read<std::uintptr_t>(method->method_ptr+p->members.at("Method.from_interpreted_entry"));
    if(!stub||!*stub||!entry||!*entry) return fail("entry unavailable");
    std::vector<std::uintptr_t> slots;
    slots.reserve(1+args.size()*2);
    if(!isStatic) slots.push_back(0);
    for(const auto& arg:args) {
        std::uintptr_t bits=0;
        switch(arg.type) {
        case Type::Object: bits=reinterpret_cast<std::uintptr_t>(arg.value.l);break;
        case Type::Boolean: bits=arg.value.z?1:0;break;
        case Type::Byte: bits=static_cast<std::intptr_t>(arg.value.b);break;
        case Type::Short: bits=static_cast<std::intptr_t>(arg.value.s);break;
        case Type::Char: bits=arg.value.c;break;
        case Type::Int: bits=static_cast<std::intptr_t>(arg.value.i);break;
        case Type::Float: std::memcpy(&bits,&arg.value.f,4);break;
        case Type::Long: slots.push_back(0);std::memcpy(&bits,&arg.value.j,8);break;
        case Type::Double: slots.push_back(0);std::memcpy(&bits,&arg.value.d,8);break;
        default: return fail("invalid argument");
        }
        slots.push_back(bits);
    }
    if(slots.size()>255) return fail("too many slots");
#if defined(AOKI_ENABLE_LOGGING)
    static std::atomic<unsigned> calls{0};
    const auto callId=++calls;
    if(callId<=64)
        AOKI_LOG("[CallStub] BEFORE id=%u method=%s%s Method=%p entry=%p receiver=%p static=%d virtual=%d slots=%zu state=%d handles=%d",
            callId,name.c_str(),descriptor.c_str(),reinterpret_cast<void*>(method->method_ptr),reinterpret_cast<void*>(*entry),
            receiver,static_cast<int>(isStatic),static_cast<int>(virtualCall),slots.size(),*state,handlesBefore);
#endif
    if(!thread_transition::EnterVm(base,*p,thread,state))return fail("native to VM transition failed");
    struct JavaValue {int type;int pad;std::uint64_t bits;} value{static_cast<int>(out.type),0,0};
    struct MetadataHandle {std::uintptr_t value,thread;};
    MetadataHandle source{method->method_ptr,thread},owned{};
    using Copy=MetadataHandle*(__fastcall*)(MetadataHandle*,const MetadataHandle*);
    if(reinterpret_cast<Copy>(base+p->rvas.at("MetadataHandle.copy"))(&owned,&source)!=&owned||owned.value!=method->method_ptr) {
        thread_transition::LeaveVm(base,*p,thread,state);return fail("metadata handle allocation failed");
    }
    alignas(16) std::uintptr_t wrapper[8]{};
    using Construct=void(__fastcall*)(void*,void*,void*,void*,std::uintptr_t);
    reinterpret_cast<Construct>(base+p->rvas.at("JavaCallWrapper.construct"))(wrapper,&owned,receiver,&value,thread);
    std::size_t slot=isStatic?0:1;
    if(!isStatic) slots[0]=wrapper[3];
    for(const auto& arg:args) {
        if(arg.type==Type::Long||arg.type==Type::Double) ++slot;
        if(arg.type==Type::Object) slots[slot]=arg.value.l?*reinterpret_cast<std::uintptr_t*>(arg.value.l):0;
        ++slot;
    }
    using Stub=void(__fastcall*)(void*,void*,int,std::uintptr_t,std::uintptr_t,void*,int,std::uintptr_t);
    const int stubType=(out.type==Type::Boolean||out.type==Type::Byte||out.type==Type::Char||out.type==Type::Short)?10:static_cast<int>(out.type);
    if(!*exception) reinterpret_cast<Stub>(*stub)(wrapper,&value.bits,stubType,method->method_ptr,*entry,slots.data(),static_cast<int>(slots.size()),thread);
    auto* vmResult=reinterpret_cast<std::uintptr_t*>(thread+p->members.at("JavaThread.vm_result"));
    const auto saved=*vmResult;
    jobject objectResult=nullptr;
    using Destroy=void(__fastcall*)(void*);
    if(out.type==Type::Object) {
        // JavaCallWrapper keeps the thread in _thread_in_Java until its
        // destructor returns it to _thread_in_vm. Root the oop first, destroy
        // the wrapper, and only then enter JNIHandles::make_global.
        objectResult=FinalizeObjectResult(value.bits,vmResult,
            [&]{reinterpret_cast<Destroy>(base+p->rvas.at("JavaCallWrapper.destroy"))(wrapper);},
            [&](std::uintptr_t* root) {
                return !*exception?hotspot::runtime::GlobalFromRoot(env,root):nullptr;
            });
    } else reinterpret_cast<Destroy>(base+p->rvas.at("JavaCallWrapper.destroy"))(wrapper);
    const int handlesAfter=metadataHandles?hotspot::Read<int>(metadataHandles).value_or(-1):-1;
    if(handlesBefore>=0&&handlesAfter!=handlesBefore) {
        static std::atomic<bool> reported=false;
        if(!reported.exchange(true))AOKI_LOG("[CallStub] metadata handle imbalance before=%d after=%d method=%s%s",
            handlesBefore,handlesAfter,name.c_str(),descriptor.c_str());
        if(objectResult)hotspot::runtime::DestroyGlobal(env,objectResult);
        *vmResult=saved;thread_transition::LeaveVm(base,*p,thread,state);return fail("metadata handle imbalance");
    }
    *vmResult=saved;
    if(!thread_transition::LeaveVm(base,*p,thread,state))return fail("VM to native transition failed");
    if(env->ExceptionCheck()) {if(explicitClassInitializer)env->ExceptionDescribe();env->ExceptionClear();return fail("Java exception");}
    if(out.type==Type::Object) {
        if(value.bits&&!objectResult)return fail("global reference allocation failed");
        out.value.l=objectResult;out.releaser=&ReleaseHotSpotGlobal;
    } else std::memcpy(&out.value,&value.bits,sizeof(value.bits));
    out.ok=true;
#if defined(AOKI_ENABLE_LOGGING)
    if(callId<=64)
        AOKI_LOG("[CallStub] AFTER id=%u state=%d handles=%d/%d type=%d bits=0x%llX",callId,*state,
            handlesBefore,handlesAfter,static_cast<int>(out.type),static_cast<unsigned long long>(value.bits));
#endif
    return out;
}
}
