#include "client/ClassJarDumper.hpp"

#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include "reconstruction/ClassFileReconstructor.hpp"

#include <Windows.h>
#include <process.h>

#include <filesystem>
#include <iterator>
#include <string>

namespace {

wchar_t g_outputPath[32768] = L"output.jar";
wchar_t g_statusPath[32768] = L"output.jar.status.txt";
volatile LONG g_started = 0;

void WriteStatus(const std::string& text) noexcept
{
    const HANDLE file = CreateFileW(g_statusPath, GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return;
    DWORD written = 0;
    WriteFile(file, text.data(), static_cast<DWORD>(text.size()), &written, nullptr);
    CloseHandle(file);
}

void Progress(std::size_t processed, std::size_t total, std::size_t dumped)
{
    const std::string message = "Reconstructing classes: " +
        std::to_string(processed) + " / " + std::to_string(total) +
        "\r\nSuccessfully added: " + std::to_string(dumped) + "\r\n";
    WriteStatus(message);
    if (processed == total || processed % 250 == 0)
        AOKI_LOG("[CLASS-JAR] progress=%zu/%zu dumped=%zu",
            processed, total, dumped);
}

void BindLayout(const client::offsets::Profile& profile)
{
    const auto& m = profile.members;
    const auto member = [&](const char* key, std::uint32_t fallback) {
        const auto found = m.find(key);
        return static_cast<std::ptrdiff_t>(found == m.end() ? fallback : found->second);
    };
    const auto alias = [&](const char* key, const char* alternative,
                           std::uint32_t fallback) {
        const auto found = m.find(key);
        if (found != m.end()) return static_cast<std::ptrdiff_t>(found->second);
        const auto other = m.find(alternative);
        return static_cast<std::ptrdiff_t>(other == m.end() ? fallback : other->second);
    };

    // The compact 47-member runtime profile contains the offsets used by the
    // client. The remaining values are stable members of the same audited
    // 8u492 layout and match the extended injection-layout profile.
    JvmMapper::Symbol::length = member("Symbol.length", 0);
    JvmMapper::Symbol::body = member("Symbol.body", 8);
    JvmMapper::Array::length = member("Array.length", 0);
    JvmMapper::Array::data = member("Array.data", 8);
    JvmMapper::CompactU2Array::length = member("CompactU2Array.length", 0);
    JvmMapper::CompactU2Array::data = member("CompactU2Array.data", 4);
    JvmMapper::ClassLoaderData::klasses = member("ClassLoaderData.klasses", 40);
    JvmMapper::ClassLoaderData::next = member("ClassLoaderData.next", 72);
    JvmMapper::Klass::layout_helper = member("Klass.layout_helper", 8);
    JvmMapper::Klass::name = member("Klass.name", 16);
    JvmMapper::Klass::next_link = member("Klass.next_link", 136);
    JvmMapper::Klass::super_klass = alias("Klass.super_klass", "Klass.super", 112);
    JvmMapper::Klass::access_flags = member("Klass.access_flags", 156);
    JvmMapper::InstanceKlass::constants = member("InstanceKlass.constants", 200);
    JvmMapper::InstanceKlass::fields = member("InstanceKlass.fields", 400);
    JvmMapper::InstanceKlass::java_fields_count = member("InstanceKlass.java_fields_count", 246);
    JvmMapper::InstanceKlass::local_interfaces = member("InstanceKlass.local_interfaces", 416);
    JvmMapper::InstanceKlass::major_version = member("InstanceKlass.major_version", 260);
    JvmMapper::InstanceKlass::minor_version = member("InstanceKlass.minor_version", 258);
    JvmMapper::InstanceKlass::methods = member("InstanceKlass.methods", 440);
    JvmMapper::Method::access_flags = member("Method.access_flags", 48);
    JvmMapper::Method::const_method = member("Method.const_method", 24);
    JvmMapper::ConstMethod::bytecode = member("ConstMethod.bytecode", 112);
    JvmMapper::ConstMethod::code_size = member("ConstMethod.code_size", 80);
    JvmMapper::ConstMethod::const_method_size = alias("ConstMethod.const_method_size", "ConstMethod.size", 104);
    JvmMapper::ConstMethod::flags = member("ConstMethod.flags", 58);
    JvmMapper::ConstMethod::max_locals = member("ConstMethod.max_locals", 34);
    JvmMapper::ConstMethod::max_stack = member("ConstMethod.max_stack", 38);
    JvmMapper::ConstMethod::name_index = member("ConstMethod.name_index", 32);
    JvmMapper::ConstMethod::signature_index = member("ConstMethod.signature_index", 36);
    JvmMapper::ConstantPool::base = member("ConstantPool.base", 128);
    JvmMapper::ConstantPool::cache = member("ConstantPool.cache", 64);
    JvmMapper::ConstantPool::length = member("ConstantPool.length", 48);
    JvmMapper::ConstantPool::operands = member("ConstantPool.operands", 88);
    JvmMapper::ConstantPool::reference_map = member("ConstantPool.reference_map", 72);
    JvmMapper::ConstantPool::tags = member("ConstantPool.tags", 16);
    JvmMapper::ConstantPoolCache::entries = member("ConstantPoolCache.entries", 16);
    JvmMapper::ConstantPoolCache::length = member("ConstantPoolCache.length", 0);
    JvmMapper::ConstantPoolCacheEntry::indices = member("ConstantPoolCacheEntry.indices", 0);
    JvmMapper::ConstantPoolCacheEntry::size = member("ConstantPoolCacheEntry.size", 32);
}

unsigned __stdcall Worker(void*)
{
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    WriteStatus("Starting HotSpot class reconstruction...\r\n");

    std::wstring temporary = g_outputPath;
    temporary += L".tmp";
    std::error_code ec;
    std::filesystem::remove(temporary, ec);

    bool ok = false;
    try {
        const std::string path = std::filesystem::path(temporary).string();
        ok = ClassFileReconstructor::DumpJar(path.c_str(), &Progress);
    } catch (...) {
        ok = false;
    }

    if (ok) {
        ok = MoveFileExW(temporary.c_str(), g_outputPath,
            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != FALSE;
    }
    if (!ok) {
        DeleteFileW(temporary.c_str());
        WriteStatus("Class reconstruction failed. Check commonLuke.log.\r\n");
        AOKI_LOG("[CLASS-JAR] reconstruction failed output=%ls error=%lu",
            g_outputPath, GetLastError());
    } else {
        WriteStatus("Completed. output.jar is ready.\r\n");
        AOKI_LOG("[CLASS-JAR] completed output=%ls", g_outputPath);
    }
    return 0;
}

} // namespace

namespace client::class_jar {

void ConfigureOutputPath(const wchar_t* logPath) noexcept
{
    if (!logPath || !*logPath) return;
    const wchar_t* separator = wcsrchr(logPath, L'\\');
    if (!separator) return;
    const std::size_t directoryLength = static_cast<std::size_t>(separator + 1 - logPath);
    constexpr wchar_t outputName[] = L"output.jar";
    constexpr wchar_t statusName[] = L"output.jar.status.txt";
    if (directoryLength + std::size(outputName) <= std::size(g_outputPath)) {
        wmemcpy(g_outputPath, logPath, directoryLength);
        wmemcpy(g_outputPath + directoryLength, outputName, std::size(outputName));
    }
    if (directoryLength + std::size(statusName) <= std::size(g_statusPath)) {
        wmemcpy(g_statusPath, logPath, directoryLength);
        wmemcpy(g_statusPath + directoryLength, statusName, std::size(statusName));
    }
}

void Start() noexcept
{
    if (InterlockedCompareExchange(&g_started, 1, 0) != 0) return;
    const char* stage = "jvm module/profile";
    try {
        const HMODULE module = GetModuleHandleW(L"jvm.dll");
        if (!module || (!offsets::Get() && !offsets::LoadBuiltin()))
            throw 1;
        const auto profile = offsets::Get();
        stage = "HotSpot layout binding";
        BindLayout(*profile);

        stage = "CLD graph binding";
        JvmApi::FixedBindings bindings{};
        bindings.cldGraphHead = reinterpret_cast<std::uintptr_t>(module) +
            profile->rvas.at("ClassLoaderDataGraph.head");
        JvmApi::BindFixed(module, bindings);

        stage = "worker creation";
        const uintptr_t thread = _beginthreadex(nullptr, 0, &Worker, nullptr, 0, nullptr);
        if (!thread) throw 1;
        CloseHandle(reinterpret_cast<HANDLE>(thread));
        AOKI_LOG("[CLASS-JAR] background reconstruction started output=%ls",
            g_outputPath);
    } catch (...) {
        InterlockedExchange(&g_started, 0);
        WriteStatus("Could not start class reconstruction. Check commonLuke.log.\r\n");
        AOKI_LOG("[CLASS-JAR] start failed stage=%s", stage);
    }
}

} // namespace client::class_jar
