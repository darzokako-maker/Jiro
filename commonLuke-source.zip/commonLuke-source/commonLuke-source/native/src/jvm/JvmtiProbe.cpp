#include "client/JvmtiProbe.hpp"

#include "client/Logger.hpp"

#include <jni.h>
#include <jvmti.h>

#include <atomic>

namespace {

std::atomic_flag g_probeStarted = ATOMIC_FLAG_INIT;
std::atomic<jvmtiEnv*> g_environment{nullptr};

const char* PhaseName(jvmtiPhase phase)
{
    switch (phase) {
    case JVMTI_PHASE_ONLOAD:
        return "ONLOAD";
    case JVMTI_PHASE_PRIMORDIAL:
        return "PRIMORDIAL";
    case JVMTI_PHASE_START:
        return "START";
    case JVMTI_PHASE_LIVE:
        return "LIVE";
    case JVMTI_PHASE_DEAD:
        return "DEAD";
    default:
        return "UNKNOWN";
    }
}

void LogCapabilities(const char* label, const jvmtiCapabilities& capabilities)
{
    AOKI_LOG(
        "JVMTI %s capabilities: tag_objects=%u bytecodes=%u source_file=%u "
        "line_numbers=%u local_variables=%u constant_pool=%u suspend=%u",
        label,
        capabilities.can_tag_objects,
        capabilities.can_get_bytecodes,
        capabilities.can_get_source_file_name,
        capabilities.can_get_line_numbers,
        capabilities.can_access_local_variables,
        capabilities.can_get_constant_pool,
        capabilities.can_suspend);

    AOKI_LOG(
        "JVMTI %s class capabilities: redefine=%u redefine_any=%u "
        "retransform=%u retransform_any=%u all_class_hooks=%u",
        label,
        capabilities.can_redefine_classes,
        capabilities.can_redefine_any_class,
        capabilities.can_retransform_classes,
        capabilities.can_retransform_any_class,
        capabilities.can_generate_all_class_hook_events);

    AOKI_LOG(
        "JVMTI %s event capabilities: breakpoint=%u method_entry=%u "
        "method_exit=%u exception=%u native_bind=%u",
        label,
        capabilities.can_generate_breakpoint_events,
        capabilities.can_generate_method_entry_events,
        capabilities.can_generate_method_exit_events,
        capabilities.can_generate_exception_events,
        capabilities.can_generate_native_method_bind_events);
}

} // namespace

namespace client::jvmti_probe {

void Run(JavaVM* virtualMachine)
{
    if (virtualMachine == nullptr || g_probeStarted.test_and_set()) {
        return;
    }

    struct VersionCandidate {
        jint value;
        const char* name;
    };

    constexpr VersionCandidate candidates[] = {
        {JVMTI_VERSION_1_2, "1.2"},
        {JVMTI_VERSION_1_1, "1.1"},
        {JVMTI_VERSION_1_0, "1.0"},
    };

    jvmtiEnv* environment = nullptr;
    const char* acceptedVersion = nullptr;

    for (const auto& candidate : candidates) {
        environment = nullptr;
        const jint result = virtualMachine->GetEnv(
            reinterpret_cast<void**>(&environment), candidate.value);
        AOKI_LOG("JVMTI GetEnv request=%s value=0x%08X result=%d env=%p",
                   candidate.name,
                   static_cast<unsigned int>(candidate.value),
                   static_cast<int>(result),
                   static_cast<void*>(environment));

        if (result == JNI_OK && environment != nullptr) {
            acceptedVersion = candidate.name;
            break;
        }
    }

    if (environment == nullptr) {
        AOKI_LOG("JVMTI interface is unavailable through JavaVM::GetEnv");
        return;
    }

    AOKI_LOG("JVMTI acquired: env=%p functions=%p requested=%s",
               static_cast<void*>(environment),
               static_cast<const void*>(environment->functions),
               acceptedVersion);
    g_environment.store(environment);

    jint reportedVersion = 0;
    const jvmtiError versionError =
        environment->GetVersionNumber(&reportedVersion);
    AOKI_LOG("JVMTI GetVersionNumber: error=%d version=0x%08X",
               static_cast<int>(versionError),
               static_cast<unsigned int>(reportedVersion));

    jvmtiPhase phase = JVMTI_PHASE_DEAD;
    const jvmtiError phaseError = environment->GetPhase(&phase);
    AOKI_LOG("JVMTI GetPhase: error=%d phase=%d (%s)",
               static_cast<int>(phaseError),
               static_cast<int>(phase),
               PhaseName(phase));

    jvmtiCapabilities currentCapabilities{};
    const jvmtiError currentError =
        environment->GetCapabilities(&currentCapabilities);
    AOKI_LOG("JVMTI GetCapabilities: error=%d",
               static_cast<int>(currentError));
    if (currentError == JVMTI_ERROR_NONE) {
        LogCapabilities("current", currentCapabilities);
    }

    jvmtiCapabilities potentialCapabilities{};
    const jvmtiError potentialError =
        environment->GetPotentialCapabilities(&potentialCapabilities);
    AOKI_LOG("JVMTI GetPotentialCapabilities: error=%d",
               static_cast<int>(potentialError));
    if (potentialError == JVMTI_ERROR_NONE) {
        LogCapabilities("potential", potentialCapabilities);
    }
}

jvmtiEnv* Get()
{
    return g_environment.load();
}

} // namespace client::jvmti_probe
