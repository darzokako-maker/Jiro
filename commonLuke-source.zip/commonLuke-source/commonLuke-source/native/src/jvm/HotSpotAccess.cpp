#include "client/HotSpotAccess.hpp"
#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include "client/MethodManager.hpp"
#include "ui/hud/HudState.hpp"
#include "game/MappingRepository.hpp"
#include "asm/AsmJvm.hpp"
#include <Windows.h>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <mutex>

namespace client::hotspot {
namespace {
std::mutex g_constantsMutex;
std::atomic<std::shared_ptr<const JvmConstants>> g_constants;
std::optional<std::uintptr_t> Rva(const offsets::Profile& profile, const char* key)
{
    const auto it = profile.rvas.find(key);
    return it == profile.rvas.end() ? std::nullopt : std::optional<std::uintptr_t>(it->second);
}
}
std::shared_ptr<const JvmConstants> GetConstants()
{
    const auto profile = offsets::Get();
    if (!profile) return nullptr;
    if (const auto current = g_constants.load(); current && current->profile == profile.get())
        return current;
    std::lock_guard lock(g_constantsMutex);
    if (const auto current = g_constants.load(); current && current->profile == profile.get())
        return current;
    auto value = std::make_shared<JvmConstants>();
    value->profile = profile.get();
    value->jvmBase = reinterpret_cast<std::uintptr_t>(GetModuleHandleW(L"jvm.dll"));
    if (!value->jvmBase) return nullptr;
    const auto base = value->jvmBase;
    if (const auto rva = Rva(*profile, "UseCompressedOops"))
        if (const auto flag = Read<std::uint8_t>(base + *rva)) value->compressedOops = *flag != 0;
    if (const auto rva = Rva(*profile, "Universe.narrow_oop_base"))
        value->narrowOopBase = Read<std::uintptr_t>(base + *rva);
    if (const auto rva = Rva(*profile, "Universe.narrow_oop_shift"))
        value->narrowOopShift = Read<unsigned>(base + *rva);
    if (const auto rva = Rva(*profile, "UseCompressedClassPointers"))
        if (const auto flag = Read<std::uint8_t>(base + *rva)) value->compressedKlass = *flag != 0;
    if (const auto rva = Rva(*profile, "Universe.narrow_klass_base"))
        value->narrowKlassBase = Read<std::uintptr_t>(base + *rva);
    if (const auto rva = Rva(*profile, "Universe.narrow_klass_shift"))
        value->narrowKlassShift = Read<unsigned>(base + *rva);
    g_constants.store(value);
    return value;
}
std::optional<std::uintptr_t> ReadObjectReference(std::uintptr_t address)
{
    const auto constants = GetConstants();
    if (!constants || !constants->compressedOops) return {};
    std::uintptr_t decoded = 0;
    if (!*constants->compressedOops) {
        if (!asm_jvm::DecodePointer(address, false, 0, 0, true, &decoded)) return {};
        return decoded;
    }
    if (!constants->narrowOopBase || !constants->narrowOopShift || *constants->narrowOopShift > 16) return {};
    if (!asm_jvm::DecodePointer(address, true, *constants->narrowOopBase,
            *constants->narrowOopShift, true, &decoded)) return {};
    return decoded;
}
void PollCoordinates(JNIEnv*)
{
    // Read roots on the Java render thread; publish values, never heap pointers.
    static ULONGLONG previous = 0;
    const auto now = GetTickCount64();
    if (now - previous < 16) return;
    previous = now;
    const auto sample = []() -> std::optional<ui::HudPosition> {
        const auto data = classes::GetSnapshot();
        const auto profile = offsets::Get();
        if (!data || !profile) return {};
        const auto it = data->byName.find(std::string(mapping::ClassName("Minecraft")));
        if (it == data->byName.end() || it->second.size() != 1) return {};
        const auto& mc = data->classes[it->second.front()];
        const auto singleton = mapping::ResolveField("Minecraft.theMinecraft");
        const auto playerField = mapping::ResolveField("Minecraft.thePlayer");
        if (!singleton || !playerField) return {};
        const auto mirror = Read<std::uintptr_t>(mc.klass + profile->members.at("Klass.java_mirror"));
        if (!mirror || !*mirror) return {};
        const auto instance = ReadObjectReference(*mirror + singleton->offset);
        if (!instance || !*instance) return {};
        const auto player = ReadObjectReference(*instance + playerField->offset);
        if (!player || !*player) return {};
        const auto coords = ReadCoordinates(*player);
        if (!coords) return {};
        return ui::HudPosition{coords->x, coords->y, coords->z};
    }();
    ui::PublishHudPosition(sample);
}
std::optional<Coordinates> ReadCoordinates(std::uintptr_t playerOop)
{
    const auto data = classes::GetSnapshot();
    if (!data || !playerOop) return {};
    const auto found = data->byName.find(std::string(mapping::ClassName("Entity")));
    if (found == data->byName.end() || found->second.size() != 1) return {};
    const auto fx = mapping::ResolveField("Entity.posX");
    const auto fy = mapping::ResolveField("Entity.posY");
    const auto fz = mapping::ResolveField("Entity.posZ");
    if (!fx || !fy || !fz) return {};
    const auto x = Read<double>(playerOop + fx->offset);
    const auto y = Read<double>(playerOop + fy->offset);
    const auto z = Read<double>(playerOop + fz->offset);
    if (!x || !y || !z || !std::isfinite(*x) || !std::isfinite(*y) || !std::isfinite(*z)) return {};
    return Coordinates{*x, *y, *z};
}
void ResolvePlayerMapping()
{
    const auto data = classes::GetSnapshot();
    if (!data) return;
    const auto mc = data->byName.find(std::string(mapping::ClassName("Minecraft")));
    const auto entity = data->byName.find(std::string(mapping::ClassName("Entity")));
    if (mc == data->byName.end() || entity == data->byName.end() ||
        mc->second.size() != 1 || entity->second.size() != 1) {
        AOKI_LOG("error: player classes unmapped"); return;
    }
    const auto singleton = mapping::ResolveField("Minecraft.theMinecraft");
    const auto player = mapping::ResolveField("Minecraft.thePlayer");
    const auto x = mapping::ResolveField("Entity.posX"), y = mapping::ResolveField("Entity.posY"), z = mapping::ResolveField("Entity.posZ");
    if (!singleton || !(singleton->access_flags & 8) || !player || !x || !y || !z) {
        AOKI_LOG("error: player fields unmapped"); return;
    }
    AOKI_LOG("player mapping: singleton=%u player=%u xyz=%u/%u/%u",
        singleton->offset, player->offset, x->offset, y->offset, z->offset);
}
bool ReadMemory(std::uintptr_t address, void* output, std::size_t size)
{
    if (!address || !output || !size || address + size < address) return false;
    __try { std::memcpy(output, reinterpret_cast<const void*>(address), size); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
bool WriteMemory(std::uintptr_t address, const void* input, std::size_t size)
{
    if (!address || !input || !size || address + size < address) return false;
    __try { std::memcpy(reinterpret_cast<void*>(address), input, size); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
std::optional<FieldInfo> FindField(const classes::ClassRecord& owner,
    const std::string& name, const std::string& signature)
{
    for (const auto& field : owner.fields)
        if (field.name == name && field.signature == signature) return field;
    return {};
}
std::optional<MethodInfo> FindMethod(const classes::ClassRecord& owner,
    const std::string& name, const std::string& signature)
{
    for (const auto& method : owner.methods)
        if (method.metadata.name == name && method.metadata.signature == signature)
            return method.metadata;
    return {};
}
#if !defined(AOKI_DISTRIBUTION)
void DumpCoordinateCandidates()
{
    const auto data = classes::GetSnapshot();
    if (!data) return;
    FILE* file = nullptr;
    if (fopen_s(&file, AOKI_MAPPING_PATH, "w") || !file) {
        AOKI_LOG("error: mapping file unavailable"); return;
    }
    for (const auto& klass : data->classes) {
        bool candidate = klass.name.find("Minecraft") != std::string::npos ||
            klass.name.find("Player") != std::string::npos ||
            klass.name.find("Entity") != std::string::npos;
        unsigned doubles = 0;
        for (const auto& field : klass.fields) {
            if (field.signature == "D" && !(field.access_flags & 8)) ++doubles;
            if (field.name == "posX" || field.name == "field_70165_t") candidate = true;
        }
        if (!candidate && doubles < 3) continue;
        fprintf(file, "class %s loader=%p klass=%p\n", klass.name.c_str(),
            reinterpret_cast<void*>(klass.loaderData), reinterpret_cast<void*>(klass.klass));
        for (const auto& field : klass.fields)
            fprintf(file, " field %s %s offset=%u flags=%04X\n", field.name.c_str(),
                field.signature.c_str(), field.offset, field.access_flags);
        for (const auto& method : klass.methods)
            fprintf(file, " method %s %s flags=%04X\n", method.metadata.name.c_str(),
                method.metadata.signature.c_str(), method.metadata.access_flags);
    }
    fclose(file);
    AOKI_LOG("mapping: Aoki.mapping.txt");
}
#endif
}

