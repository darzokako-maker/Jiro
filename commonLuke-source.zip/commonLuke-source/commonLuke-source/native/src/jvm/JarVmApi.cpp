#include "client/JarVmApi.hpp"
#include "client/ApiTestSequence.hpp"
#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include "client/ClassRepository.hpp"
#include "client/HotSpotAccess.hpp"
#include "client/MethodManager.hpp"
#include "client/ThreadTransition.hpp"
#include <Windows.h>
#include <intrin.h>
#include <array>
#include <cstring>

namespace client::jar_vm {
namespace {
constexpr unsigned stepCount = 10;
constexpr const char* names[]{
    "Thread transition", "SymbolTable::lookup", "ConstantPool::allocate",
    "ConstMethod::allocate", "Method::allocate", "metadataHandle copy/destroy",
    "Method::link_method", "call_stub (probe returns 5)",
    "mirror restore (existing mirror branch)", "update_dictionary (existing entry branch)"
};
struct Session {
    ApiTestSequence sequence;
    unsigned lastAttempt = 0;
    DWORD ownerThread = 0;
    std::uintptr_t javaThread = 0;
    std::uintptr_t object = 0, cld = 0, symbols[3]{}, pool = 0, constMethod = 0, method = 0;
    ULONGLONG completedAt = 0;
    bool heartbeat = false;
} session;

// ABI copied from reference NativeMethodBuilder::InlineTableSizes.
struct InlineTableSizes { int values[10]{}; };
struct MetadataHandle { std::uintptr_t value, thread; };
static_assert(sizeof(InlineTableSizes) == 40 && sizeof(MetadataHandle) == 16);
using Profile = offsets::Profile;
struct Context {
    std::shared_ptr<const Profile> profile;
    std::uintptr_t base, thread;
    volatile int* state;
    std::uintptr_t* pending;
    std::uintptr_t Fn(const char* name) const { return base + profile->rvas.at(name); }
    unsigned Offset(const char* name) const { return profile->members.at(name); }
};
template<class T> T Read(std::uintptr_t address) { return hotspot::Read<T>(address).value_or(T{}); }
template<class T> void Put(std::uintptr_t address, T value) { *reinterpret_cast<T*>(address) = value; }
template<class Function> Function Api(const Context& c, const char* name) {
    return reinterpret_cast<Function>(c.Fn(name));
}
struct VmScope {
    const Context& c;
    bool entered = false;
    explicit VmScope(const Context& context) : c(context) {
        entered = thread_transition::EnterVm(c.base, *c.profile, c.thread, c.state);
    }
    ~VmScope() {
        if (entered) thread_transition::LeaveVm(c.base, *c.profile, c.thread, c.state);
    }
};
bool SymbolEquals(const Context& c, std::uintptr_t symbol, const char* text) {
    const auto length = std::strlen(text);
    if (!symbol || Read<std::uint16_t>(symbol + c.Offset("Symbol.length")) != length) return false;
    for (std::size_t i = 0; i < length; ++i) {
        auto value = hotspot::Read<char>(symbol + c.Offset("Symbol.body") + i);
        if (!value || *value != text[i]) return false;
    }
    return true;
}
int HandleCount(const Context& c) {
    const auto handles = Read<std::uintptr_t>(c.thread + c.Offset("JavaThread.metadata_handles"));
    return handles ? Read<int>(handles) : -1;
}
bool CheckConstMethod(const Context& c, std::uintptr_t cm) {
    const auto size = cm ? Read<int>(cm + c.Offset("ConstMethod.size")) : 0;
    return cm && Read<std::uint16_t>(cm + c.Offset("ConstMethod.code_size")) == 2
        && size >= 15 && size < 1024;
}
bool Run(unsigned step, JNIEnv* env, const Context& c) {
    switch (step) {
    case 0: {
        { VmScope vm(c); if (*c.state != 6) return false; }
        return *c.state == 4 && !*c.pending;
    }
    case 1: {
        using Lookup = std::uintptr_t(__fastcall*)(const char*, int, void*);
        const char* texts[]{"java/lang/Object", "aokiApiProbe", "()I"};
        {
            VmScope vm(c);
            for (unsigned i = 0; i < 3 && !*c.pending; ++i) {
                session.symbols[i] = Api<Lookup>(c, "SymbolTable.lookup")(
                    texts[i], static_cast<int>(std::strlen(texts[i])), reinterpret_cast<void*>(c.thread));
                AOKI_LOG("[JarVmApi] F2 lookup text=%s symbol=%p", texts[i], reinterpret_cast<void*>(session.symbols[i]));
            }
        }
        for (unsigned i = 0; i < 3; ++i)
            if (!SymbolEquals(c, session.symbols[i], texts[i])) return false;
        return session.symbols[0] == Read<std::uintptr_t>(session.object + c.Offset("Klass.name"));
    }
    case 2: {
        using Allocate = std::uintptr_t(__fastcall*)(std::uintptr_t, int, void*);
        {
            VmScope vm(c);
            session.pool = Api<Allocate>(c, "ConstantPool.allocate")(session.cld, 4, reinterpret_cast<void*>(c.thread));
            if (!session.pool || *c.pending) return false;
            const auto tags = Read<std::uintptr_t>(session.pool + c.Offset("ConstantPool.tags"));
            if (!tags || Read<int>(tags) != 4 || Read<int>(session.pool + c.Offset("ConstantPool.length")) != 4
                || Read<std::uintptr_t>(session.pool) != c.Fn("ConstantPool.vtable")) return false;
            for (unsigned i = 0; i < 4; ++i)
                if (Read<unsigned char>(tags + 4 + i) != 0) return false;
            // Isolated pool for an unpublished static method. Object itself is not modified.
            Put(session.pool + c.Offset("ConstantPool.pool_holder"), session.object);
            for (unsigned i = 1; i <= 3; ++i) {
                const auto symbol = session.symbols[i == 3 ? 0 : i];
                Put(session.pool + c.Offset("ConstantPool.base") + 8 * i, symbol);
                Put<unsigned char>(tags + 4 + i, 1); // CONSTANT_Utf8
            }
            AOKI_LOG("[JarVmApi] F3 pool=%p tags=%p length=4 holder=%p",
                reinterpret_cast<void*>(session.pool), reinterpret_cast<void*>(tags), reinterpret_cast<void*>(session.object));
        }
        return true;
    }
    case 3: {
        using Allocate = std::uintptr_t(__fastcall*)(std::uintptr_t, int, InlineTableSizes*, int, void*);
        InlineTableSizes sizes;
        {
            VmScope vm(c);
            session.constMethod = Api<Allocate>(c, "ConstMethod.allocate")(session.cld, 2, &sizes, 0, reinterpret_cast<void*>(c.thread));
        }
        AOKI_LOG("[JarVmApi] F4 constMethod=%p sizeWords=%d codeSize=%u",
            reinterpret_cast<void*>(session.constMethod),
            session.constMethod ? Read<int>(session.constMethod + c.Offset("ConstMethod.size")) : 0,
            session.constMethod ? Read<std::uint16_t>(session.constMethod + c.Offset("ConstMethod.code_size")) : 0);
        return CheckConstMethod(c, session.constMethod);
    }
    case 4: {
        using Allocate = std::uintptr_t(__fastcall*)(std::uintptr_t, int, int, InlineTableSizes*, int, void*);
        InlineTableSizes sizes;
        {
            VmScope vm(c);
            session.method = Api<Allocate>(c, "Method.allocate")(session.cld, 2, 0x0009, &sizes, 0, reinterpret_cast<void*>(c.thread));
            if (!session.method || *c.pending) return false;
            const auto cm = Read<std::uintptr_t>(session.method + c.Offset("Method.const_method"));
            if (!CheckConstMethod(c, cm) || Read<std::uintptr_t>(session.method) != c.Fn("Method.vtable")) return false;
            // Same field initialization as the reference NativeMethodBuilder.
            Put(cm + c.Offset("ConstMethod.constants"), session.pool);
            Put<std::uint16_t>(cm + c.Offset("ConstMethod.name_index"), 1);
            Put<std::uint16_t>(cm + c.Offset("ConstMethod.signature_index"), 2);
            Put<std::uint16_t>(cm + c.Offset("ConstMethod.max_stack"), 1);
            Put<std::uint16_t>(cm + c.Offset("ConstMethod.max_locals"), 0);
            Put<std::uint16_t>(cm + c.Offset("ConstMethod.size_of_parameters"), 0);
            Put<unsigned char>(cm + c.Offset("ConstMethod.result_type"), 10); // T_INT
            Put<unsigned char>(cm + c.Offset("ConstMethod.bytecode"), 0x08); // iconst_5
            Put<unsigned char>(cm + c.Offset("ConstMethod.bytecode") + 1, 0xAC); // ireturn
            AOKI_LOG("[JarVmApi] F5 method=%p constMethod=%p flags=0x%X bytecode=08 AC",
                reinterpret_cast<void*>(session.method), reinterpret_cast<void*>(cm),
                Read<unsigned>(session.method + c.Offset("Method.access_flags")));
        }
        return Read<unsigned>(session.method + c.Offset("Method.access_flags")) == 0x0009;
    }
    case 5: {
        using Copy = MetadataHandle*(__fastcall*)(MetadataHandle*, const MetadataHandle*);
        using Destroy = void(__fastcall*)(MetadataHandle*);
        MetadataHandle source{session.method, c.thread}, owned{};
        bool ok;
        {
            VmScope vm(c);
            const int before = HandleCount(c);
            auto* result = Api<Copy>(c, "MetadataHandle.copy")(&owned, &source);
            const int during = HandleCount(c);
            ok = result == &owned && owned.value == session.method && owned.thread == c.thread
                && before >= 0 && during == before + 1;
            // Pair registration with the verified destructor, before leaving this thread.
            if (owned.value && owned.thread == c.thread) Api<Destroy>(c, "MetadataHandle.destroy")(&owned);
            const int after = HandleCount(c);
            AOKI_LOG("[JarVmApi] F6 handles before=%d during=%d after=%d", before, during, after);
            ok = ok && before == after;
        }
        return ok;
    }
    case 6: {
        using Copy = MetadataHandle*(__fastcall*)(MetadataHandle*, const MetadataHandle*);
        using Link = void(__fastcall*)(std::uintptr_t, MetadataHandle*, void*);
        MetadataHandle source{session.method, c.thread}, owned{};
        bool balanced;
        {
            VmScope vm(c);
            const int before = HandleCount(c);
            Api<Copy>(c, "MetadataHandle.copy")(&owned, &source);
            // MSVC passes this by-value metadataHandle indirectly. link_method
            // consumes/destroys that copy internally (IDA sub_8119580).
            Api<Link>(c, "Method.link")(session.method, &owned, reinterpret_cast<void*>(c.thread));
            balanced = before >= 0 && HandleCount(c) == before;
        }
        const auto i2i = Read<std::uintptr_t>(session.method + c.Offset("Method.i2i_entry"));
        const auto adapter = Read<std::uintptr_t>(session.method + c.Offset("Method.adapter"));
        const auto compiled = Read<std::uintptr_t>(session.method + c.Offset("Method.from_compiled_entry"));
        const auto interpreted = Read<std::uintptr_t>(session.method + c.Offset("Method.from_interpreted_entry"));
        AOKI_LOG("[JarVmApi] F7 i2i=%p adapter=%p compiled=%p interpreted=%p handlesBalanced=%d",
            reinterpret_cast<void*>(i2i), reinterpret_cast<void*>(adapter),
            reinterpret_cast<void*>(compiled), reinterpret_cast<void*>(interpreted), static_cast<int>(balanced));
        return i2i && adapter && compiled && interpreted && balanced;
    }
    case 7: {
        // Reuse the existing call engine with a temporary native record.
        // No insertion into Object's real method array or dictionary.
        classes::ClassRecord owner;
        owner.name = "java/lang/Object"; owner.klass = session.object; owner.loaderData = session.cld;
        classes::MethodRecord method;
        method.metadata.name = "aokiApiProbe"; method.metadata.signature = "()I";
        method.metadata.method_ptr = session.method; method.metadata.access_flags = 0x0009;
        owner.methods.push_back(std::move(method));
        auto result = methods::Invoke(env, nullptr, owner, "aokiApiProbe", "()I");
        AOKI_LOG("[JarVmApi] F8 invoked=%d value=%d error=%s", static_cast<int>(result.ok), result.value.i, result.error.c_str());
        return result.ok && result.type == methods::Type::Int && result.value.i == 5;
    }
    case 8: {
        using Restore = void(__fastcall*)(std::uintptr_t, std::uintptr_t, void*, void*);
        const auto before = Read<std::uintptr_t>(session.object + c.Offset("Klass.java_mirror"));
        if (!before) return false;
        {
            VmScope vm(c);
            Api<Restore>(c, "Klass.restore_mirror")(session.object, session.cld, nullptr, reinterpret_cast<void*>(c.thread));
        }
        const auto after = Read<std::uintptr_t>(session.object + c.Offset("Klass.java_mirror"));
        AOKI_LOG("[JarVmApi] F9 existing-mirror branch before=%p after=%p (creation branch NOT tested)",
            reinterpret_cast<void*>(before), reinterpret_cast<void*>(after));
        return before == after && Read<std::uintptr_t>(session.object + c.Offset("Klass.class_loader_data")) == session.cld;
    }
    case 9: {
        using Find = std::uintptr_t(__fastcall*)(std::uintptr_t, int, unsigned, std::uintptr_t, std::uintptr_t);
        using Update = void(__fastcall*)(int, unsigned, std::uintptr_t, std::uintptr_t, std::uintptr_t, void*, void*);
        // Object is bootstrap-loaded. Supply its REAL bucket/hash, not the
        // reference's zero placeholders, which could insert a duplicate entry.
        const auto dictionary = Read<std::uintptr_t>(c.Fn("SystemDictionary.dictionary"));
        if (!dictionary || Read<std::uintptr_t>(session.cld) != 0) return false;
        const auto tableSize = Read<unsigned>(dictionary + 32);
        if (!tableSize || tableSize > 1000000) return false;
        const auto hash = Read<unsigned>(session.symbols[0] + 4);
        const auto index = static_cast<int>(hash % tableSize);
        bool ok = false;
        {
            VmScope vm(c);
            const auto find = Api<Find>(c, "Dictionary.find_class");
            const auto before = find(dictionary, index, hash, session.symbols[0], session.cld);
            const auto entriesBefore = Read<unsigned>(dictionary + 36);
            if (before != session.object) return false; // Never permit insertion in this probe.
            Api<Update>(c, "SystemDictionary.update_dictionary")(index, hash, 0, 0, session.object, nullptr, reinterpret_cast<void*>(c.thread));
            const auto after = find(dictionary, index, hash, session.symbols[0], session.cld);
            const auto entriesAfter = Read<unsigned>(dictionary + 36);
            ok = after == before && entriesBefore == entriesAfter;
            AOKI_LOG("[JarVmApi] F10 existing-entry branch bucket=%d hash=0x%X entries=%u/%u klass=%p (insertion branch NOT tested)",
                index, hash, entriesBefore, entriesAfter, reinterpret_cast<void*>(after));
        }
        return ok;
    }
    default: return false;
    }
}
}

void PrintTestHelp() {
    AOKI_LOG("[JarVmApi] automatic calls OFF; F1-F10 run sequential tests once; F11/F12 remain gameplay keys");
    for (unsigned i = 0; i < stepCount; ++i)
        AOKI_LOG("[JarVmApi] F%u = %s", i + 1, names[i]);
}
void RunTestStep(JNIEnv* env, unsigned step) {
    if (!session.sequence.CanRun(step)) {
        AOKI_LOG("[JarVmApi] BLOCKED F%u: next=F%u failed=%d enabled=%d; no repeat/skip/reset",
            step + 1, session.sequence.Next() < stepCount ? session.sequence.Next() + 1 : 0,
            static_cast<int>(session.sequence.Failed()), static_cast<int>(session.sequence.Enabled()));
        return;
    }
    const auto p = offsets::Get(); const auto data = classes::GetSnapshot();
    const auto base = reinterpret_cast<std::uintptr_t>(GetModuleHandleW(L"jvm.dll"));
    if (!env || !p || !data || !base) { AOKI_LOG("[JarVmApi] not ready"); return; }
    const auto thread = reinterpret_cast<std::uintptr_t>(env) - p->members.at("JavaThread.jni_environment");
    if (session.ownerThread && (session.ownerThread != GetCurrentThreadId() || session.javaThread != thread)) {
        AOKI_LOG("[JarVmApi] BLOCKED: test must stay on the same Java/render thread"); return;
    }
    if (!session.ownerThread) {
        const auto found = data->byName.find("java/lang/Object");
        if (found == data->byName.end() || found->second.empty()) return;
        const auto& object = data->classes[found->second.front()];
        session.object = object.klass; session.cld = object.loaderData;
        if (!session.object || !session.cld) return;
        session.ownerThread = GetCurrentThreadId(); session.javaThread = thread;
    }
    Context c{p, base, thread, reinterpret_cast<volatile int*>(thread + p->members.at("JavaThread.state")),
        reinterpret_cast<std::uintptr_t*>(thread + p->members.at("JavaThread.pending_exception"))};
    if (*c.state != 4 || *c.pending) {
        AOKI_LOG("[JarVmApi] BLOCKED: state=%d pending=%p", *c.state, reinterpret_cast<void*>(*c.pending)); return;
    }
    session.lastAttempt = step + 1;
    const auto started = GetTickCount64();
    AOKI_LOG("[JarVmApi] F%u BEFORE: %s thread=%p state=%d", step + 1, names[step], reinterpret_cast<void*>(thread), *c.state);
    const bool returned = Run(step, env, c);
    const bool ok = returned && *c.state == 4 && !*c.pending;
    const auto elapsed = GetTickCount64() - started;
    AOKI_LOG("[JarVmApi] F%u AFTER: %s result=%s state=%d pending=%p elapsed=%llums (network health NOT checked)",
        step + 1, names[step], ok ? "PASS" : "FAIL", *c.state, reinterpret_cast<void*>(*c.pending),
        static_cast<unsigned long long>(elapsed));
    session.sequence.Complete(ok);
    session.completedAt = GetTickCount64(); session.heartbeat = false;
    if (!ok) AOKI_LOG("[JarVmApi] STOPPED at F%u; no further test calls", step + 1);
}
void PollTests(JNIEnv* env) {
    DWORD process = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &process);
    const bool focused = process == GetCurrentProcessId();
    std::array<bool, ApiTestSequence::Count> down{};
    for (unsigned i = 0; i < down.size(); ++i)
        down[i] = focused && (GetAsyncKeyState(VK_F1 + i) & 0x8000);
    const int pressed = session.sequence.Pressed(down);
    if (pressed >= 0) {
        RunTestStep(env, static_cast<unsigned>(pressed));
    }
    if (session.completedAt && !session.heartbeat && GetTickCount64() - session.completedAt >= 5000) {
        session.heartbeat = true;
        AOKI_LOG("[JarVmApi] CHECKPOINT: render thread alive 5s after F%u; server connection not verified", session.lastAttempt);
    }
}
}
