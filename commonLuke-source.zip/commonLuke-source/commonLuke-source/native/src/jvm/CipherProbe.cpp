#include "client/CipherProbe.hpp"

#include "client/ClassRepository.hpp"
#include "client/Logger.hpp"
#include "client/NativePacketEngine.hpp"
#include "client/SocketTap.hpp"
#include "game/MappingRepository.hpp"

#include <Windows.h>

#include <array>
#include <cstdint>
#include <string>

namespace {

volatile LONG g_captureAttempted = 0;
ULONGLONG g_nextAttempt = 0;
ULONGLONG g_nextMappingRefresh = 0;
ULONGLONG g_nextDiagnostic = 0;
ULONGLONG g_nextHealthCheck = 0;
ULONGLONG g_nextHealthDiagnostic = 0;
client::native_packets::StreamHealth g_previousInboundHealth{};
std::array<std::array<std::uint8_t, 16>, 2> g_loggedKeys{};
bool g_logged[2]{};
std::uintptr_t g_lastMappedSocket = static_cast<std::uintptr_t>(-1);

constexpr const char* kRequiredClasses[] = {
    "Minecraft", "EntityPlayerSP", "NetHandlerPlayClient", "NetworkManager",
    "AbstractChannel", "AbstractNioChannel", "NioSocketChannel",
    "SocketChannelImpl", "DefaultChannelPipeline",
    "AbstractChannelHandlerContext", "DefaultChannelHandlerContext",
    "DecryptHandler", "EncryptHandler", "DecompressHandler", "CompressHandler",
    "CipherWrapper", "JavaCipher", "AESCipher", "AESCrypt", "CipherCore",
    "FeedbackCipher", "CipherFeedback",
};

constexpr const char* kRequiredFields[] = {
    "Minecraft.theMinecraft", "Minecraft.thePlayer", "Minecraft.connection",
    "EntityPlayerSP.sendQueue", "NetHandlerPlayClient.networkManager",
    "NetworkManager.channel", "AbstractNioChannel.javaChannel",
    "SocketChannelImpl.fdVal", "AbstractChannel.pipeline",
    "DefaultChannelPipeline.head", "AbstractChannelHandlerContext.next",
    "DefaultChannelHandlerContext.handler", "DecryptHandler.wrapper",
    "EncryptHandler.wrapper", "CipherWrapper.cipher", "JavaCipher.opmode",
    "JavaCipher.spi", "AESCipher.core", "CipherCore.cipher",
    "FeedbackCipher.embeddedCipher", "FeedbackCipher.iv",
    "CipherFeedback.register", "DecompressHandler.threshold",
    "CompressHandler.threshold",
};

bool MappingsReady()
{
    for (const auto* alias : kRequiredClasses)
        if (!client::mapping::Class(alias)) return false;
    for (const auto* key : kRequiredFields)
        if (!client::mapping::ResolveField(key)) return false;
    return true;
}

void ClearException(JNIEnv* environment)
{
    if (environment && environment->ExceptionCheck())
        environment->ExceptionClear();
}

std::string Hex(const std::uint8_t* bytes, std::size_t size)
{
    static constexpr char digits[] = "0123456789ABCDEF";
    std::string result(size * 2, '0');
    for (std::size_t index = 0; index < size; ++index) {
        result[index * 2] = digits[bytes[index] >> 4];
        result[index * 2 + 1] = digits[bytes[index] & 0x0F];
    }
    return result;
}

bool ByteArray(JNIEnv* environment, jobject object, std::uint8_t* output,
    std::size_t expected)
{
    if (!environment || !object || !output || !expected) return false;
    const auto array = reinterpret_cast<jbyteArray>(object);
    if (environment->GetArrayLength(array) != static_cast<jsize>(expected))
        return false;
    environment->GetByteArrayRegion(array, 0, static_cast<jsize>(expected),
        reinterpret_cast<jbyte*>(output));
    if (environment->ExceptionCheck()) {
        environment->ExceptionClear();
        return false;
    }
    return true;
}

bool WordsToKey(JNIEnv* environment, jobject object, std::uint8_t* output)
{
    if (!environment || !object || !output) return false;
    const auto words = reinterpret_cast<jintArray>(object);
    const auto length = environment->GetArrayLength(words);
    if (length != 44 && length != 52 && length != 60) return false;
    std::array<jint, 4> first{};
    environment->GetIntArrayRegion(words, 0, static_cast<jsize>(first.size()),
        first.data());
    if (environment->ExceptionCheck()) {
        environment->ExceptionClear();
        return false;
    }
    for (std::size_t index = 0; index < first.size(); ++index) {
        const auto word = static_cast<std::uint32_t>(first[index]);
        output[index * 4] = static_cast<std::uint8_t>(word >> 24);
        output[index * 4 + 1] = static_cast<std::uint8_t>(word >> 16);
        output[index * 4 + 2] = static_cast<std::uint8_t>(word >> 8);
        output[index * 4 + 3] = static_cast<std::uint8_t>(word);
    }
    return true;
}

bool ExpandedEncryptionKey(JNIEnv* environment, jobject aes,
    std::uint8_t* output, const char*& source)
{
    if (auto words = client::mapping::Object(environment, aes,
        "AESCrypt.sessionKe")) {
        if (WordsToKey(environment, words, output)) {
            source = "sessionKe";
            return true;
        }
    }

    const auto schedules = client::mapping::Object(environment, aes,
        "AESCrypt.sessionK");
    if (!schedules) return false;
    const auto array = reinterpret_cast<jobjectArray>(schedules);
    const auto count = environment->GetArrayLength(array);
    if (count <= 0 || count >= 16) return false;
    const auto words = environment->GetObjectArrayElement(array, 0);
    if (environment->ExceptionCheck()) {
        environment->ExceptionClear();
        return false;
    }
    if (!WordsToKey(environment, words, output)) return false;
    source = "sessionK[0]";
    return true;
}

void PublishCipher(unsigned direction, int opmode,
    const std::array<std::uint8_t, 16>& key, const char* keySource,
    const std::array<std::uint8_t, 16>& iv, bool haveIv,
    const std::array<std::uint8_t, 16>& reg, bool haveReg)
{
    const bool inbound = direction == 0;
    const auto packetDirection = inbound
        ? client::native_packets::Direction::Inbound
        : client::native_packets::Direction::Outbound;
    const bool resync = client::native_packets::NeedsCipherResync(packetDirection);
    const bool inactive = !client::native_packets::IsStreamActive(packetDirection);
    const bool keyChanged = g_logged[direction] && g_loggedKeys[direction] != key;
    if (keyChanged) {
        AOKI_LOG("[CIPHER-PROBE] %s connection key changed; rebinding transport",
            inbound ? "IN" : "OUT");
        client::socket_tap::ResetTransport();
        g_logged[0] = false;
        g_logged[1] = false;
    }
    if (!g_logged[direction] || g_loggedKeys[direction] != key || resync || inactive) {
        g_loggedKeys[direction] = key;
        g_logged[direction] = true;
        const auto& initialRegister = haveReg ? reg : iv;
        if (haveReg || haveIv) {
            client::native_packets::PublishCipher(packetDirection, key,
                initialRegister);
            if (resync)
                AOKI_LOG("[CIPHER-PROBE] %s stream resynchronized",
                    inbound ? "IN" : "OUT");
        }
        AOKI_LOG("[CIPHER-PROBE] %s opmode=%d key=%s source=%s iv=%s register=%s",
            inbound ? "IN" : "OUT", opmode, Hex(key.data(), key.size()).c_str(),
            keySource, haveIv ? Hex(iv.data(), iv.size()).c_str() : "unavailable",
            haveReg ? Hex(reg.data(), reg.size()).c_str() : "unavailable");
    }
}

void CheckInboundHealth(ULONGLONG now)
{
    if (now < g_nextHealthCheck) return;
    g_nextHealthCheck = now + 2000;

    constexpr auto direction = client::native_packets::Direction::Inbound;
    const auto health = client::native_packets::GetStreamHealth(direction);
    if (now >= g_nextHealthDiagnostic && health.active) {
        AOKI_LOG("[CIPHER-PROBE] IN health validated=%d calls=%llu bytes=%llu packets=%llu losses=%llu recoveries=%llu",
            static_cast<int>(health.validated),
            static_cast<unsigned long long>(health.inputCalls),
            static_cast<unsigned long long>(health.inputBytes),
            static_cast<unsigned long long>(health.packets),
            static_cast<unsigned long long>(health.boundaryLosses),
            static_cast<unsigned long long>(health.recoveries));
        g_nextHealthDiagnostic = now + 5000;
    }

    const bool countersAdvanced =
        health.inputCalls >= g_previousInboundHealth.inputCalls &&
        health.inputBytes >= g_previousInboundHealth.inputBytes;
    const auto callDelta = countersAdvanced
        ? health.inputCalls - g_previousInboundHealth.inputCalls : 0;
    const auto byteDelta = countersAdvanced
        ? health.inputBytes - g_previousInboundHealth.inputBytes : 0;
    const bool inputIsRecent = health.lastInputTick != 0 &&
        now >= health.lastInputTick && now - health.lastInputTick <= 2500;
    const bool packetIsStale = health.lastPacketTick == 0 ||
        (now >= health.lastPacketTick && now - health.lastPacketTick >= 2000);
    const bool stalled = health.active && !health.failed && countersAdvanced &&
        callDelta >= 4 && byteDelta >= 512 &&
        health.packets == g_previousInboundHealth.packets &&
        inputIsRecent && packetIsStale;

    g_previousInboundHealth = health;
    if (stalled) {
        client::native_packets::RequestCipherResync(direction,
            "inbound traffic without packet dispatch");
        g_previousInboundHealth = {};
    }
}

bool InspectCipher(JNIEnv* environment, jobject handler, unsigned direction,
    const char*& stage)
{
    const bool inbound = direction == 0;
    stage = inbound ? "decrypt handler wrapper" : "encrypt handler wrapper";
    const auto wrapper = client::mapping::Object(environment, handler,
        inbound ? "DecryptHandler.wrapper" : "EncryptHandler.wrapper");
    if (!wrapper) return false;
    stage = "CipherWrapper.cipher";
    const auto cipher = client::mapping::Object(environment, wrapper,
        "CipherWrapper.cipher");
    if (!cipher) return false;
    const auto opmode = client::mapping::Read<std::int32_t>(environment, cipher,
        "JavaCipher.opmode").value_or(0);
    stage = "JavaCipher.spi";
    const auto spi = client::mapping::Object(environment, cipher, "JavaCipher.spi");
    if (!spi) return false;
    stage = "AESCipher.core";
    const auto core = client::mapping::Object(environment, spi, "AESCipher.core");
    if (!core) return false;
    stage = "CipherCore.cipher";
    const auto feedback = client::mapping::Object(environment, core,
        "CipherCore.cipher");
    if (!feedback) return false;
    stage = "FeedbackCipher.embeddedCipher";
    const auto aes = client::mapping::Object(environment, feedback,
        "FeedbackCipher.embeddedCipher");
    if (!aes) return false;

    std::array<std::uint8_t, 16> key{};
    const char* keySource = "lastKey";
    stage = "AES original key";
    const auto keyArray = client::mapping::Object(environment, aes,
        "AESCrypt.lastKey");
    if (!ByteArray(environment, keyArray, key.data(), key.size()) &&
        !ExpandedEncryptionKey(environment, aes, key.data(), keySource))
        return false;

    std::array<std::uint8_t, 16> iv{};
    std::array<std::uint8_t, 16> reg{};
    const auto ivArray = client::mapping::Object(environment, feedback,
        "FeedbackCipher.iv");
    const auto regArray = client::mapping::Object(environment, feedback,
        "CipherFeedback.register");
    const bool haveIv = ByteArray(environment, ivArray, iv.data(), iv.size());
    const bool haveReg = ByteArray(environment, regArray, reg.data(), reg.size());
    PublishCipher(direction, opmode, key, keySource, iv, haveIv, reg, haveReg);
    return true;
}

bool ProbeManager(JNIEnv* environment, jobject manager, const char*& stage)
{
    if (!manager || !client::mapping::Instance(environment, manager, "NetworkManager"))
        return false;
    stage = "NetworkManager.channel";
    const auto channel = client::mapping::Object(environment, manager,
        "NetworkManager.channel");
    if (!channel || !client::mapping::Instance(environment, channel, "AbstractChannel"))
        return false;
    stage = "AbstractNioChannel.javaChannel";
    if (!client::mapping::Instance(environment, channel, "NioSocketChannel"))
        return false;
    const auto javaChannel = client::mapping::Object(environment, channel,
        "AbstractNioChannel.javaChannel");
    if (!javaChannel || !client::mapping::Instance(environment, javaChannel,
        "SocketChannelImpl"))
        return false;
    stage = "SocketChannelImpl.fdVal";
    const auto fdValue = client::mapping::Read<std::int32_t>(environment,
        javaChannel, "SocketChannelImpl.fdVal");
    if (!fdValue || *fdValue < 0) return false;
    const auto mappedSocket = static_cast<std::uintptr_t>(
        static_cast<std::uint32_t>(*fdValue));
    if (mappedSocket != g_lastMappedSocket) {
        g_lastMappedSocket = mappedSocket;
        g_logged[0] = false;
        g_logged[1] = false;
    }
    if (!client::socket_tap::BindTransport(mappedSocket)) return false;
    stage = "AbstractChannel.pipeline";
    const auto pipeline = client::mapping::Object(environment, channel,
        "AbstractChannel.pipeline");
    if (!pipeline || !client::mapping::Instance(environment, pipeline,
        "DefaultChannelPipeline"))
        return false;
    stage = "DefaultChannelPipeline.head";
    auto context = client::mapping::Object(environment, pipeline,
        "DefaultChannelPipeline.head");
    if (!context) return false;

    bool found[2]{};
    bool matched[2]{};
    for (unsigned depth = 0; depth < 128 && context; ++depth) {
        jobject handler = nullptr;
        if (client::mapping::Instance(environment, context, "DefaultChannelHandlerContext"))
            handler = client::mapping::Object(environment, context,
                "DefaultChannelHandlerContext.handler");
        if (handler) {
            if (client::mapping::Instance(environment, handler, "DecompressHandler")) {
                const auto threshold = client::mapping::Read<std::int32_t>(
                    environment, handler, "DecompressHandler.threshold");
                if (threshold)
                    client::native_packets::SetCompressionThreshold(*threshold);
            }
            else if (client::mapping::Instance(environment, handler, "CompressHandler")) {
                const auto threshold = client::mapping::Read<std::int32_t>(
                    environment, handler, "CompressHandler.threshold");
                if (threshold)
                    client::native_packets::SetCompressionThreshold(*threshold);
            }

            if (client::mapping::Instance(environment, handler, "DecryptHandler")) {
                matched[0] = true;
                found[0] = InspectCipher(environment, handler, 0, stage);
            }
            else if (client::mapping::Instance(environment, handler, "EncryptHandler")) {
                matched[1] = true;
                found[1] = InspectCipher(environment, handler, 1, stage);
            }
        }
        context = client::mapping::Object(environment, context,
            "AbstractChannelHandlerContext.next");
    }
    if (!matched[0] && !matched[1]) stage = "pipeline cipher handlers";
    else if (!matched[0]) stage = "inbound pipeline cipher handler";
    else if (!matched[1]) stage = "outbound pipeline cipher handler";
    const bool complete = found[0] && found[1];
    if (complete) client::socket_tap::BindTransport(mappedSocket);
    return complete;
}

bool Probe(JNIEnv* environment, const char*& stage)
{
    if (!environment || environment->PushLocalFrame(512) < 0) {
        ClearException(environment);
        stage = "local handle frame";
        return false;
    }

    bool result = false;
    stage = "Minecraft.theMinecraft";
    const auto minecraft = client::mapping::StaticObject(environment,
        "Minecraft.theMinecraft");
    if (minecraft) {
        stage = "Minecraft.thePlayer";
        const auto player = client::mapping::Object(environment, minecraft,
            "Minecraft.thePlayer");
        jobject playerManager = nullptr;
        if (player && client::mapping::Instance(environment, player, "EntityPlayerSP")) {
            const auto handler = client::mapping::Object(environment, player,
                "EntityPlayerSP.sendQueue");
            if (handler && client::mapping::Instance(environment, handler,
                "NetHandlerPlayClient"))
                playerManager = client::mapping::Object(environment, handler,
                    "NetHandlerPlayClient.networkManager");
        }
        if (playerManager)
            result = ProbeManager(environment, playerManager, stage);
        if (!result) {
            const auto directManager = client::mapping::Object(environment,
                minecraft, "Minecraft.connection");
            if (directManager)
                result = ProbeManager(environment, directManager, stage);
        }
    }
    environment->PopLocalFrame(nullptr);
    ClearException(environment);
    return result;
}

bool GuardedProbe(JNIEnv* environment, const char** stage) noexcept
{
    __try {
        return environment && stage && Probe(environment, *stage);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        if (stage) *stage = "guarded mapped Netty walk";
        return false;
    }
}

} // namespace

namespace client::cipher_probe {

void Poll(JNIEnv* environment) noexcept
{
    const ULONGLONG now = GetTickCount64();
    CheckInboundHealth(now);
    const bool needsResync =
        native_packets::NeedsCipherResync(native_packets::Direction::Inbound) ||
        native_packets::NeedsCipherResync(native_packets::Direction::Outbound);
    if (now < g_nextAttempt) return;
    g_nextAttempt = now + (needsResync ? 100 : 500);

    if (!classes::GetSnapshot() &&
        InterlockedCompareExchange(&g_captureAttempted, 1, 0) == 0)
        classes::Capture(environment);
    if (!MappingsReady() && now >= g_nextMappingRefresh) {
        g_nextMappingRefresh = now + 2000;
        classes::Capture(environment);
    }

    const char* stage = "mapped class snapshot";
    const bool ok = MappingsReady() && GuardedProbe(environment, &stage);
    if (!ok && now >= g_nextDiagnostic) {
        AOKI_LOG("[CIPHER-PROBE] waiting at %s", stage);
        g_nextDiagnostic = now + 5000;
    }
}

} // namespace client::cipher_probe
