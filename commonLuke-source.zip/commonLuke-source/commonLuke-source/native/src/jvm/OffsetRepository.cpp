#include "client/OffsetRepository.hpp"
#include "client/Logger.hpp"
#include <atomic>
#include "ClientMappings.hpp"

namespace client::offsets {
namespace { std::atomic<std::shared_ptr<const Profile>> active; }
std::shared_ptr<const Profile> Get() { return active.load(); }
bool LoadBuiltin()
{
    Profile p;
    p.id = mapping::generated::profileId;
    for (const auto& value : mapping::generated::rvas) p.rvas.emplace(value.key, value.value);
    for (const auto& value : mapping::generated::members) p.members.emplace(value.key, static_cast<std::uint32_t>(value.value));
    return Publish(std::move(p));
}
bool Publish(Profile profile)
{
    if (profile.id.empty() || profile.rvas.empty() || profile.members.empty()) return false;
    for (const auto& [name, value] : profile.members)
        if (name.empty() || value >= 0x1000) return false;
    for (const auto& [name, value] : profile.rvas)
        if (name.empty() || !value) return false;
    AOKI_LOG("[Profile] accepted id=%s RVAs=%zu members=%zu",profile.id.c_str(),profile.rvas.size(),profile.members.size());
    active.store(std::make_shared<const Profile>(std::move(profile)));
    return true;
}
}
