#include "client/ClassRepository.hpp"
#include "client/Logger.hpp"
#include "client/OffsetRepository.hpp"
#include <atomic>
#include <cstring>
#include <unordered_set>

namespace {
std::atomic<std::shared_ptr<const client::classes::Snapshot>> snapshot;
bool Copy(std::uintptr_t address, void* target, std::size_t size)
{
    __try { std::memcpy(target, reinterpret_cast<const void*>(address), size); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}
template<class T> T Read(std::uintptr_t address)
{
    T value{};
    Copy(address, &value, sizeof(value));
    return value;
}
}
namespace client::classes {
std::shared_ptr<const Snapshot> GetSnapshot() { return snapshot.load(); }
void Capture(JNIEnv* environment)
{
    const auto module = GetModuleHandleW(L"jvm.dll");
    if (!module) return;
    if (!offsets::Get() && !offsets::LoadBuiltin()) {
        AOKI_LOG("error: offsets unavailable"); return;
    }
    const auto profile = offsets::Get();
    JvmMapper::ClassLoaderData::klasses = profile->members.at("ClassLoaderData.klasses");
    JvmMapper::ClassLoaderData::next = profile->members.at("ClassLoaderData.next");
    JvmMapper::Klass::name = profile->members.at("Klass.name");
    JvmMapper::Klass::next_link = profile->members.at("Klass.next_link");
    JvmMapper::Klass::layout_helper = profile->members.at("Klass.layout_helper");
    JvmMapper::Symbol::length = profile->members.at("Symbol.length");
    JvmMapper::Symbol::body = profile->members.at("Symbol.body");
    JvmMapper::InstanceKlass::methods = profile->members.at("InstanceKlass.methods");
    JvmMapper::InstanceKlass::fields = profile->members.at("InstanceKlass.fields");
    JvmMapper::InstanceKlass::constants = profile->members.at("InstanceKlass.constants");
    JvmMapper::InstanceKlass::java_fields_count = profile->members.at("InstanceKlass.java_fields_count");
    JvmMapper::Method::const_method = profile->members.at("Method.const_method");
    JvmMapper::Method::access_flags = profile->members.at("Method.access_flags");
    JvmMapper::ConstMethod::code_size = profile->members.at("ConstMethod.code_size");
    JvmMapper::ConstMethod::bytecode = profile->members.at("ConstMethod.bytecode");
    JvmMapper::ConstMethod::constants = profile->members.at("ConstMethod.constants");
    JvmMapper::ConstMethod::name_index = profile->members.at("ConstMethod.name_index");
    JvmMapper::ConstMethod::signature_index = profile->members.at("ConstMethod.signature_index");
    JvmMapper::ConstantPool::base = profile->members.at("ConstantPool.base");
    JvmMapper::Array::length = profile->members.at("Array.length");
    JvmMapper::Array::data = profile->members.at("Array.data");
    JvmMapper::CompactU2Array::data = profile->members.at("CompactU2Array.data");
    const auto base = reinterpret_cast<std::uintptr_t>(module);
    const auto headAddress = base + profile->rvas.at("ClassLoaderDataGraph.head");
    if (!Read<std::uintptr_t>(headAddress)) {
        AOKI_LOG("error: class graph empty"); return;
    }
    auto next = std::make_shared<Snapshot>();
    std::unordered_set<std::uintptr_t> loaders, klasses;
    auto cld = Read<std::uintptr_t>(headAddress);
    std::size_t methodCount = 0, byteCount = 0;
    while (cld && loaders.size() < 32768 && loaders.insert(cld).second) {
        auto klass = Read<std::uintptr_t>(cld + JvmMapper::ClassLoaderData::klasses);
        while (klass && klasses.size() < 262144 && klasses.insert(klass).second) {
            ClassRecord record;
            record.name = ReadSymbol(Read<std::uintptr_t>(klass + JvmMapper::Klass::name));
            record.klass = klass;
            record.loaderData = cld;
            if (!record.name.empty()) {
                if (Read<int>(klass + JvmMapper::Klass::layout_helper) > 0) {
                    record.fields = ReadFields(klass);
                    for (auto& method : ReadMethods(klass)) {
                        MethodRecord entry;
                        entry.metadata = std::move(method);
                        const auto cm = Read<std::uintptr_t>(entry.metadata.method_ptr + JvmMapper::Method::const_method);
                        if (!(entry.metadata.access_flags & (0x100 | 0x400)) && cm) {
                            const auto size = Read<std::uint16_t>(cm + JvmMapper::ConstMethod::code_size);
                            entry.bytecode.resize(size);
                            entry.bytecodeReadable = Copy(cm + JvmMapper::ConstMethod::bytecode, entry.bytecode.data(), size);
                            if (!entry.bytecodeReadable) entry.bytecode.clear();
                        }
                        byteCount += entry.bytecode.size();
                        ++methodCount;
                        record.methods.push_back(std::move(entry));
                    }
                }
                next->byName[record.name].push_back(next->classes.size());
                next->byKlass.emplace(record.klass,next->classes.size());
                next->classes.push_back(std::move(record));
            }
            klass = Read<std::uintptr_t>(klass + JvmMapper::Klass::next_link);
        }
        cld = Read<std::uintptr_t>(cld + JvmMapper::ClassLoaderData::next);
    }
    AOKI_LOG("classes: %zu", next->classes.size());
    AOKI_LOG("methods: %zu", methodCount);
    AOKI_LOG("bytecode: %zu bytes", byteCount);
    snapshot.store(next);
}
}
