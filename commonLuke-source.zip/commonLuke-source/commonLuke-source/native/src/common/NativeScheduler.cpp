#include "client/NativeScheduler.hpp"
#include "client/Logger.hpp"

#include <Windows.h>

#include <algorithm>
#include <limits>

namespace client::scheduler {
namespace {

constexpr std::uint64_t EnabledBit = std::uint64_t{1} << 31;
constexpr std::uint64_t IntervalMask = EnabledBit - 1;
constexpr std::uint64_t PayloadMask = (std::uint64_t{1} << 32) - 1;

std::size_t Index(Task task) noexcept
{
    return static_cast<std::size_t>(task);
}

detail::DeadlineBank bank;
std::atomic<std::uint64_t> publishedNow{0};

std::uint64_t MonotonicMilliseconds() noexcept
{
    LARGE_INTEGER counter{}, frequency{};
    if (!QueryPerformanceCounter(&counter) ||
        !QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0)
        return GetTickCount64();
    const auto whole = counter.QuadPart / frequency.QuadPart;
    const auto remainder = counter.QuadPart % frequency.QuadPart;
    return static_cast<std::uint64_t>(whole) * 1000u +
        static_cast<std::uint64_t>(remainder * 1000 / frequency.QuadPart);
}

}

void detail::DeadlineBank::Configure(Task task, bool enabled,
    std::uint32_t intervalMilliseconds) noexcept
{
    const auto index = Index(task);
    if (index >= slots_.size()) return;
    const auto interval = (std::min)(intervalMilliseconds,
        static_cast<std::uint32_t>(IntervalMask));
    const auto payload = (enabled && interval ? EnabledBit : 0) | interval;
    auto current = slots_[index].configuration.load(std::memory_order_relaxed);
    for (;;) {
        if ((current & PayloadMask) == payload) return;
        const auto revision = static_cast<std::uint32_t>(current >> 32) + 1u;
        const auto desired = (static_cast<std::uint64_t>(revision) << 32) | payload;
        if (slots_[index].configuration.compare_exchange_weak(current, desired,
                std::memory_order_release, std::memory_order_relaxed)) return;
    }
}

void detail::DeadlineBank::Advance(std::uint64_t nowMilliseconds) noexcept
{
    for (auto& slot : slots_) {
        const auto configuration = slot.configuration.load(std::memory_order_acquire);
        const auto interval = configuration & IntervalMask;
        const bool enabled = (configuration & EnabledBit) != 0 && interval != 0;
        if (configuration != slot.observedConfiguration) {
            slot.observedConfiguration = configuration;
            slot.nextDeadline = enabled ? nowMilliseconds + interval : 0;
            continue;
        }
        if (!enabled || !slot.nextDeadline || nowMilliseconds < slot.nextDeadline) continue;
        slot.generation.fetch_add(1, std::memory_order_release);
        const auto elapsed = nowMilliseconds - slot.nextDeadline;
        const auto periods = elapsed / interval + 1;
        if (periods > ((std::numeric_limits<std::uint64_t>::max)() - slot.nextDeadline) / interval)
            slot.nextDeadline = nowMilliseconds + interval;
        else
            slot.nextDeadline += periods * interval;
    }
}

bool detail::DeadlineBank::Consume(Task task, Cursor& cursor) const noexcept
{
    const auto index = Index(task);
    if (index >= slots_.size()) return false;
    const auto published = slots_[index].generation.load(std::memory_order_acquire);
    if (published == cursor.generation) return false;
    cursor.generation = published;
    return true;
}

void detail::Advance(std::uint64_t nowMilliseconds) noexcept
{
    PublishNow(nowMilliseconds);
    bank.Advance(nowMilliseconds);
}

void detail::PublishNow(std::uint64_t nowMilliseconds) noexcept
{
    publishedNow.store(nowMilliseconds, std::memory_order_release);
}

void Configure(Task task, bool enabled, std::uint32_t intervalMilliseconds) noexcept
{
    bank.Configure(task, enabled, intervalMilliseconds);
}

bool Consume(Task task, Cursor& cursor) noexcept
{
    return bank.Consume(task, cursor);
}

std::uint64_t Now() noexcept
{
    return publishedNow.load(std::memory_order_acquire);
}

void Run(void* shutdownEvent) noexcept
{
    const auto stop = static_cast<HANDLE>(shutdownEvent);
    if (!stop) return;
    HANDLE timer = nullptr;
    bool highResolution = false;
    for (unsigned attempt = 0; attempt < 2 && !timer; ++attempt) {
        const auto flags = detail::TimerFlagsForAttempt(attempt);
        timer = CreateWaitableTimerExW(nullptr, nullptr, flags, TIMER_ALL_ACCESS);
        highResolution = timer && flags == detail::HighResolutionTimerFlag;
    }
    if (!timer) {
        AOKI_LOG("[Scheduler] timer creation failed error=%lu; scheduler disabled",
            GetLastError());
        WaitForSingleObject(stop, INFINITE);
        return;
    }

    LARGE_INTEGER first{};
    first.QuadPart = -10000; // Relative 1 ms, expressed in 100 ns units.
    if (!SetWaitableTimer(timer, &first, 1, nullptr, nullptr, FALSE)) {
        AOKI_LOG("[Scheduler] timer arm failed error=%lu; scheduler disabled",
            GetLastError());
        CloseHandle(timer);
        WaitForSingleObject(stop, INFINITE);
        return;
    }

    AOKI_LOG("[Scheduler] native timer started resolution=%s period=1ms",
        highResolution ? "HIGH" : "COMPAT");
    const HANDLE handles[]{stop, timer};
    for (;;) {
        const DWORD wait = WaitForMultipleObjects(2, handles, FALSE, INFINITE);
        const auto wake = detail::SelectWake(wait == WAIT_OBJECT_0,
            wait == WAIT_OBJECT_0 + 1);
        if (wake == detail::Wake::Stop) break;
        if (wake == detail::Wake::Tick) detail::Advance(MonotonicMilliseconds());
        else {
            AOKI_LOG("[Scheduler] wait failed result=%lu error=%lu", wait, GetLastError());
            break;
        }
    }
    CancelWaitableTimer(timer);
    CloseHandle(timer);
    AOKI_LOG("[Scheduler] native timer stopped");
}

}
