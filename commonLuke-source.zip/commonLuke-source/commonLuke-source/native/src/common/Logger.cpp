#include "client/Logger.hpp"

#include <Windows.h>

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <iterator>
#include <share.h>

namespace {

SRWLOCK g_logLock = SRWLOCK_INIT;
FILE* g_logFile = nullptr;

} // namespace

namespace client::log {

void Initialize(const wchar_t* path)
{
#ifdef AOKI_LOG_PATH
    if (!path || !*path) {
        wchar_t fallback[32768]{};
        if (MultiByteToWideChar(CP_UTF8, 0, AOKI_LOG_PATH, -1, fallback, static_cast<int>(std::size(fallback))))
            Initialize(fallback);
        return;
    }
#else
    if (!path || !*path) return;
#endif
    AcquireSRWLockExclusive(&g_logLock);
    if (g_logFile) {
        ReleaseSRWLockExclusive(&g_logLock);
        return;
    }
    FILE* file = _wfsopen(path, L"a", _SH_DENYNO);
    if (file == nullptr) {
        ReleaseSRWLockExclusive(&g_logLock);
        OutputDebugStringA("error: log file open failed\n");
        return;
    }

    g_logFile = file;
    ReleaseSRWLockExclusive(&g_logLock);
    Write("[Session] native logging enabled; build=%s %s path=%ls", __DATE__, __TIME__, path);
}

void Write(const char* format, ...)
{
    char message[1024]{};

    va_list arguments;
    va_start(arguments, format);
    vsnprintf_s(message, sizeof(message), _TRUNCATE, format, arguments);
    va_end(arguments);

    // Reference mapper diagnostics remain available in source; keep the
    // client log focused on the final capture result.
#if !defined(AOKI_ENABLE_LOGGING)
    if (std::strncmp(message, "[JvmMapper]", 11) == 0 ||
        std::strncmp(message, "JVMTI", 5) == 0) return;
#endif

    SYSTEMTIME now{};
    GetLocalTime(&now);
    char line[1200]{};
    sprintf_s(line, "[%04u-%02u-%02u %02u:%02u:%02u.%03u pid=%lu tid=%lu tick=%llu] %s\n",
        now.wYear, now.wMonth, now.wDay, now.wHour, now.wMinute, now.wSecond,
        now.wMilliseconds, GetCurrentProcessId(), GetCurrentThreadId(),
        static_cast<unsigned long long>(GetTickCount64()), message);
    OutputDebugStringA(line);

    AcquireSRWLockExclusive(&g_logLock);
    if (g_logFile != nullptr) {
        fputs(line, g_logFile);
        fflush(g_logFile);
    }
    ReleaseSRWLockExclusive(&g_logLock);
}

} // namespace client::log
