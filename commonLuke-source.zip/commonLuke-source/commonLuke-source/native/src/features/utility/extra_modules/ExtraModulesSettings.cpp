#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <mutex>
#include <algorithm>
#include <cmath>
namespace client::features::extras {
Settings Defaults(Kind kind){Settings s;if(kind==Kind::FastUse)s.speed=1;if(kind==Kind::Eagle)s.speed=40;if(kind==Kind::FastPlace)s.delay=0;if(kind==Kind::NoFall)s.mode=0;if(kind==Kind::FakeLag){s.delay=100;s.mode=0;s.history=5;}if(kind==Kind::AimBacktrack){s.delay=50;s.history=100;s.bedBox=true;s.outlineColor=0x64698605u;}if(kind==Kind::AimAssist){s.range=4;s.requireSwing=false;}return s;}
namespace {std::mutex mutex;std::array<Settings,static_cast<int>(Kind::Count)> values=[](){std::array<Settings,static_cast<int>(Kind::Count)> result;for(int i=0;i<static_cast<int>(Kind::Count);++i)result[i]=Defaults(static_cast<Kind>(i));return result;}();BacktrackVisual backtrackVisual;}
Settings Options(Kind kind){std::lock_guard lock(mutex);return values[static_cast<int>(kind)];}
void PublishBacktrackVisual(BacktrackVisual visual){std::lock_guard lock(mutex);backtrackVisual=visual;}
BacktrackVisual BacktrackVisualSnapshot(){std::lock_guard lock(mutex);return backtrackVisual;}
int ModuleIndex(Kind kind){const int index=static_cast<int>(kind);if(index<=static_cast<int>(Kind::InventoryMove))return modules::NoWeb+index;if(kind==Kind::NoFall)return modules::NoFall;if(kind==Kind::FastPlace)return modules::FastPlace;if(kind==Kind::FakeLag)return modules::FakeLag;return -1;}
std::optional<Kind> FromModuleIndex(int module){if(module>=modules::NoWeb&&module<=modules::InventoryMove)return static_cast<Kind>(module-modules::NoWeb);if(module==modules::NoFall)return Kind::NoFall;if(module==modules::FastPlace)return Kind::FastPlace;if(module==modules::FakeLag)return Kind::FakeLag;return std::nullopt;}
void SetOptions(Kind kind,Settings s){
 if(kind==Kind::Breaker)return;
 auto clamp=[](float v,float lo,float hi,float fallback){return std::isfinite(v)?std::clamp(v,lo,hi):fallback;};
 s.range=clamp(s.range,.2f,6,1);s.speed=kind==Kind::Eagle?(std::isfinite(s.speed)&&s.speed>10?std::clamp(s.speed,20.f,100.f):40.f):clamp(s.speed,1,kind==Kind::FastUse?24.f:10.f,kind==Kind::FastUse?1.f:2.f);s.delay=kind==Kind::FastPlace?0.f:kind==Kind::FakeLag?clamp(s.delay,1,1000,100):kind==Kind::AimBacktrack?clamp(s.delay,0,500,50):clamp(s.delay,0,20000.f,3000.f);s.fov=clamp(s.fov,0,180,90);s.history=kind==Kind::FakeLag?clamp(s.history,0,50,5):kind==Kind::AimBacktrack?clamp(s.history,0,500,100):clamp(s.history,1,20,1);
 s.cps=clamp(s.cps,1,20,12);s.mode=std::clamp(s.mode,0,kind==Kind::FakeLag?2:1);if(s.message.size()>400)s.message.resize(400);
 s.boxAlpha=clamp(s.boxAlpha,.05f,.5f,.18f);s.layerCount=clamp(s.layerCount,1,5,4);s.scanRange=clamp(s.scanRange,8,256,64);s.outlineWidth=clamp(s.outlineWidth,1,5,2);
 bool previous;{std::lock_guard lock(mutex);auto& value=values[static_cast<int>(kind)];previous=value.enabled;value=std::move(s);}
 const int module=ModuleIndex(kind);if(module>=0)modules::StateChanged(static_cast<modules::Id>(module),previous,Options(kind).enabled);
}
bool AnyEnabled(){std::lock_guard lock(mutex);for(const auto& s:values)if(s.enabled)return true;return false;}
bool NeedsInput(){std::lock_guard lock(mutex);for(int i=0;i<=static_cast<int>(Kind::InventoryMove);++i)if(i!=static_cast<int>(Kind::AimBacktrack)&&values[i].enabled)return true;const auto& noFall=values[static_cast<int>(Kind::NoFall)];return noFall.enabled&&noFall.mode==0;}
void DisableInputFeatures(){for(int i=0;i<=static_cast<int>(Kind::InventoryMove);++i){const auto kind=static_cast<Kind>(i);if(kind==Kind::AimBacktrack)continue;auto s=Options(kind);if(s.enabled){s.enabled=false;SetOptions(kind,s);}}}
}
