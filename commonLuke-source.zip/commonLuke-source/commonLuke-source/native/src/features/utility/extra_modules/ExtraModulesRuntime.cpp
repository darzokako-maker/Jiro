#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/utility/extra_modules/ExtraModuleRules.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "features/combat/common/AttackTargetManager.hpp"
#include "features/player/scaffold/ScaffoldPlacement.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/PacketBridge.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include <Windows.h>
#include <array>
#include <atomic>
#include <deque>
#include <mutex>
#include <random>
#include <stdexcept>
#include <type_traits>
#include <optional>
#include <unordered_map>
#include <vector>
#include <cctype>
#include "features/core/ModuleRegistry.hpp"
#include "client/NativeScheduler.hpp"
namespace client::features::extras {
namespace {
using rules::Vec;using rules::Pos;using methods::Argument;using methods::Type;
std::recursive_mutex mutex;
jobject mcRoot=nullptr,playerRoot=nullptr,worldRoot=nullptr;
int tick=-1,toolTicks=0,oldSlot=-1,toolSlot=-1;
bool inventoryMoveOwned=false;
bool eagleOwned=false,eagleKeyOwned=false;std::uint64_t eagleDelayMs=150,eagleReleaseAt=0;
bool fastPlaceCpsOwned=false,fastPlaceOriginalBypass=false;int fastPlaceOriginalLimit=15;
std::atomic<unsigned> pendingDisabled{0};
std::string warnedMessage;
std::optional<Pos> toolBlock;
std::uint64_t lastSpam=0;
client::scheduler::Cursor autoClickCursor;
client::scheduler::Cursor fastUseCursor,eagleCursor,fakeLagCursor,backtrackCursor;
struct DelayedPacket {jobject packet=nullptr;std::uint64_t releaseAt=0;bool position=false;};
std::mutex fakeLagMutex;std::deque<DelayedPacket> fakeLagPackets;
int fakeLagRuntimeMode=-1,dynamicTargetId=-1,repelTargetId=-1;
std::uint64_t dynamicLastPositionRelease=0,dynamicBlockCooldown=0,dynamicLastBlockPlace=0,repelDeadline=0,lastDynamicAttack=0;
struct BacktrackDelayedPacket {jobject packet=nullptr;std::uint64_t releaseAt=0;};
struct BacktrackPacketState {int x=0,y=0,z=0;};
std::deque<BacktrackDelayedPacket> backtrackPackets;
std::unordered_map<int,BacktrackPacketState> backtrackEntityStates;
int backtrackActiveTarget=-1,backtrackPendingTarget=-1;
bool backtrackDelaying=false,backtrackForceFlush=false,backtrackRuntimeEnabled=false;
std::optional<Vec> backtrackLastSnapshot;
Vec backtrackRenderCurrent,backtrackRenderTarget;int backtrackRenderSteps=0;bool backtrackRenderValid=false;
int mlgCooldownUntil=-1;
int mlgDiagGate=-1,mlgDiagTick=-1000,mlgDiagMode=-2;
std::uint64_t mlgDiagStatusAt=0;
std::optional<double> mlgLastY;
float mlgTrackedFall=0;
std::mt19937 random{static_cast<unsigned>(GetTickCount64())};
struct Frame {JNIEnv* env;bool ok;explicit Frame(JNIEnv* e,int capacity=4096):env(e),ok(e&&e->PushLocalFrame(capacity)==JNI_OK){}~Frame(){if(ok)env->PopLocalFrame(nullptr);}};
double R(){return std::generate_canonical<double,53>(random);}int Bound(float low,float high){return static_cast<int>(low+(high-low)*R()*R());}
void Check(JNIEnv* env){if(env->ExceptionCheck())throw std::runtime_error("game JNI exception");}
template<class T>T Read(JNIEnv*,jobject object,const char* key){const auto value=mapping::Read<T>(object,key);if(!value)throw std::runtime_error(std::string("missing field ")+key);return *value;}
template<class T>void Write(JNIEnv*,jobject object,const char* key,T value){if(!mapping::Write(object,key,value))throw std::runtime_error(std::string("field write failed ")+key);}
jobject Object(JNIEnv* env,jobject object,const char* key){const auto result=mapping::Object(env,object,key);Check(env);return result;}
Argument Obj(jobject v){Argument a{Type::Object};a.value.l=v;return a;}Argument Int(int v){Argument a{Type::Int};a.value.i=v;return a;}Argument Float(float v){Argument a{Type::Float};a.value.f=v;return a;}Argument Double(double v){Argument a{Type::Double};a.value.d=v;return a;}Argument Bool(bool v){Argument a{Type::Boolean};a.value.z=v;return a;}
jvalue Call(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={},bool isStatic=false){
 if(!isStatic&&!receiver)throw std::runtime_error(std::string("missing receiver ")+key);
 auto result=mapping::Invoke(env,isStatic?nullptr:receiver,key,args);if(!result.ok)throw std::runtime_error(std::string(key)+": "+result.error);
 jvalue out=result.value;if(result.type==Type::Object&&out.l)out.l=mapping::Root(env,mapping::Oop(out.l));result.Release(env);Check(env);return out;
}
bool StaticBool(JNIEnv*,const char* key){const auto value=mapping::ReadStatic<bool>(key);if(!value)throw std::runtime_error(std::string("missing static field ")+key);return *value;}
void StaticBool(JNIEnv*,const char* key,bool value){if(!mapping::WriteStatic(key,value))throw std::runtime_error(std::string("static field write failed ")+key);}
jobject New(JNIEnv* env,const char* key,const std::vector<Argument>& args){const auto object=mapping::New(env,key,args);Check(env);if(!object)throw std::runtime_error(std::string("construction failed ")+key);return object;}
// A packet filter can execute outside the render thread, where Java method
// dispatch is intentionally rejected. These packet constructors only assign
// the fields below (Recaf: A_ (FFZ), AF (DDDFFZF)), so reproduce that state
// without invoking Java from the callback thread.
jobject MovementPacket(JNIEnv* env,bool moving,double x,double y,double z,float yaw,float pitch,bool grounded,float extra){
 const auto packet=mapping::Allocate(env,moving?"AuraPositionLookPacket":"AuraLookPacket");Check(env);if(!packet)throw std::runtime_error("movement packet allocation failed");
 if(moving){Write(env,packet,"AuraMovementPacket.x",x);Write(env,packet,"AuraMovementPacket.y",y);Write(env,packet,"AuraMovementPacket.z",z);Write(env,packet,"AuraMovementPacket.extra",extra);Write(env,packet,"AuraMovementPacket.moving",true);}
 Write(env,packet,"AuraMovementPacket.yaw",yaw);Write(env,packet,"AuraMovementPacket.pitch",pitch);Write(env,packet,"AuraMovementPacket.onGround",grounded);Write(env,packet,"AuraMovementPacket.rotating",true);return packet;
}
Vec Position(JNIEnv* env,jobject entity){return {Read<double>(env,entity,"Entity.posX"),Read<double>(env,entity,"Entity.posY"),Read<double>(env,entity,"Entity.posZ")};}
Vec Eye(JNIEnv* env){auto p=Position(env,playerRoot);p.y+=Call(env,playerRoot,"Entity.eyeHeight").f;return p;}
jobject JavaPos(JNIEnv* env,Pos p){return New(env,"BlockPos.constructor",{Int(p.x),Int(p.y),Int(p.z)});}
Pos Coordinates(JNIEnv* env,jobject p){return {Call(env,p,"BlockPos.getX").i,Call(env,p,"BlockPos.getY").i,Call(env,p,"BlockPos.getZ").i};}
struct Block {jobject object;int id;};
Block GetBlock(JNIEnv* env,Pos p){const auto position=JavaPos(env,p),state=Call(env,worldRoot,"World.getBlockState",{Obj(position)}).l;const auto block=Call(env,state,"BlockState.getBlock").l;return {block,Call(env,block,"Block.id",{Obj(block)},true).i};}
bool Air(JNIEnv* env,Vec p){Frame frame(env,32);if(!frame.ok)return false;return GetBlock(env,rules::Block(p)).id==0;}
jobject SettingsObject(JNIEnv* env){return Object(env,mcRoot,"Minecraft.gameSettings");}
jobject Binding(JNIEnv* env,const char* key){return Object(env,SettingsObject(env),key);}
bool Down(JNIEnv* env,const char* key){return Read<bool>(env,Binding(env,key),"KeyBinding.pressed");}
int VirtualKey(int lwjgl){switch(lwjgl){case 157:return VK_RCONTROL;case 184:return VK_RMENU;case 199:return VK_HOME;case 200:return VK_UP;case 201:return VK_PRIOR;case 203:return VK_LEFT;case 205:return VK_RIGHT;case 207:return VK_END;case 208:return VK_DOWN;case 209:return VK_NEXT;case 210:return VK_INSERT;case 211:return VK_DELETE;default:return lwjgl>0&&lwjgl<128?static_cast<int>(MapVirtualKeyW(lwjgl,MAPVK_VSC_TO_VK_EX)):0;}}
bool PhysicalBinding(JNIEnv* env,const char* key){const int code=Read<int>(env,Binding(env,key),"KeyBinding.keyCode"),vk=VirtualKey(code);return vk&&(GetAsyncKeyState(vk)&0x8000)!=0;}
void RestoreEagleKey(JNIEnv* env){if(!eagleKeyOwned)return;Write(env,Binding(env,"GameSettings.keyBindSneak"),"KeyBinding.pressed",PhysicalBinding(env,"GameSettings.keyBindSneak"));eagleKeyOwned=false;}
void RestoreInventoryMove(JNIEnv* env,bool physical){for(const auto key:{"GameSettings.keyBindForward","GameSettings.keyBindBack","GameSettings.keyBindLeft","GameSettings.keyBindRight","GameSettings.keyBindJump","GameSettings.keyBindSprint","GameSettings.keyBindSneak"})Write(env,Binding(env,key),"KeyBinding.pressed",physical&&PhysicalBinding(env,key));inventoryMoveOwned=false;}
void InventoryMove(JNIEnv* env,jobject input){const bool forward=PhysicalBinding(env,"GameSettings.keyBindForward"),back=PhysicalBinding(env,"GameSettings.keyBindBack"),left=PhysicalBinding(env,"GameSettings.keyBindLeft"),right=PhysicalBinding(env,"GameSettings.keyBindRight"),jump=PhysicalBinding(env,"GameSettings.keyBindJump"),sprint=PhysicalBinding(env,"GameSettings.keyBindSprint"),sneak=PhysicalBinding(env,"GameSettings.keyBindSneak");const struct {const char* key;bool down;} keys[]={{"GameSettings.keyBindForward",forward},{"GameSettings.keyBindBack",back},{"GameSettings.keyBindLeft",left},{"GameSettings.keyBindRight",right},{"GameSettings.keyBindJump",jump},{"GameSettings.keyBindSprint",sprint},{"GameSettings.keyBindSneak",sneak}};for(const auto& key:keys)Write(env,Binding(env,key.key),"KeyBinding.pressed",key.down);const auto axes=rules::InventoryAxes(forward,back,left,right);Write(env,input,"AuraMovementInput.forward",axes[0]);Write(env,input,"AuraMovementInput.strafe",axes[1]);Write(env,input,"AuraMovementInput.jump",jump);Write(env,input,"AuraMovementInput.sneak",sneak);inventoryMoveOwned=true;}
void Click(JNIEnv* env,bool right){const auto binding=Binding(env,right?"GameSettings.keyBindUseItem":"GameSettings.keyBindAttack");Call(env,binding,"ExtraKeyBinding.tick",{Int(Read<int>(env,binding,"KeyBinding.keyCode"))},true);}
void Send(JNIEnv* env,jobject packet){const auto queue=Object(env,playerRoot,"DisconnectPlayer.sendQueue");Call(env,queue,"DisconnectNet.send",{Obj(packet)});}
jobject Stack(JNIEnv* env,jobject inventory,int slot){const auto array=static_cast<jobjectArray>(Object(env,inventory,"InventoryPlayer.mainInventory"));return slot>=0&&slot<9&&slot<env->GetArrayLength(array)?env->GetObjectArrayElement(array,slot):nullptr;}
void DispatchFakeLag(JNIEnv* env,std::vector<jobject>& packetsToSend){
 for(auto packet:packetsToSend){
  const auto future=packets::Send(env,packet);if(future)env->DeleteLocalRef(future);
  if(env->ExceptionCheck())env->ExceptionClear();mapping::ReleaseGlobal(env,packet);
 }
}
void FlushFakeLag(JNIEnv* env,bool force=false,bool one=false){
 std::vector<jobject> packetsToSend;const auto now=client::scheduler::Now();
 {std::lock_guard lock(fakeLagMutex);while(!fakeLagPackets.empty()&&(force||fakeLagPackets.front().releaseAt<=now||one)){packetsToSend.push_back(fakeLagPackets.front().packet);fakeLagPackets.pop_front();if(one)break;}}
 DispatchFakeLag(env,packetsToSend);
}
bool QueueFakeLag(JNIEnv* env,jobject packet,std::uint64_t releaseAt,bool position=false){
 const auto copy=mapping::Global(env,packet);Check(env);if(!copy)return false;
 std::lock_guard lock(fakeLagMutex);fakeLagPackets.push_back({copy,releaseAt,position});return true;
}
bool FakeLagQueued(){std::lock_guard lock(fakeLagMutex);return !fakeLagPackets.empty();}
jobject FindEntity(JNIEnv* env,int id){
 if(!worldRoot||id<0)return nullptr;const auto list=Object(env,worldRoot,"World.loadedEntityList");if(!list)return nullptr;
 const auto array=static_cast<jobjectArray>(Object(env,list,"ArrayList.elements"));if(!array)return nullptr;
 const int count=std::min(Read<int>(env,list,"ArrayList.size"),env->GetArrayLength(array));
 for(int i=0;i<count;++i){const auto entity=env->GetObjectArrayElement(array,i);if(entity&&Read<int>(env,entity,"Entity.entityId")==id)return entity;}
 return nullptr;
}
bool AttackPacket(JNIEnv* env,jobject packet,int* entityId=nullptr){
 if(!mapping::Instance(packet,"AuraAttackPacket"))return false;
 const auto action=Object(env,packet,"AuraAttackPacket.action");if(!action)return false;
 // Packet filters run on Netty's JavaThread, not the render JavaThread used by
 // MethodDispatch. java.lang.Enum.ordinal is a final VM-owned field, so read
 // the mapped field directly instead of issuing a Java call from this thread.
 const int value=Read<int>(env,action,"JavaEnum.ordinalValue");
 if(value!=1)return false;if(entityId)*entityId=Read<int>(env,packet,"AuraAttackPacket.entityId");return true;
}
void DispatchBacktrack(JNIEnv* env,bool force=false,bool discard=false){
 const auto now=client::scheduler::Now();std::vector<jobject> ready;
 while(!backtrackPackets.empty()&&(discard||force||backtrackForceFlush||backtrackPackets.front().releaseAt<=now)){
  ready.push_back(backtrackPackets.front().packet);backtrackPackets.pop_front();
 }
 if(backtrackPackets.empty())backtrackForceFlush=false;
 for(auto packet:ready){
  if(!discard&&!packets::Receive(env,packet))AOKI_LOG("[Backtrack] packet replay failed");
  if(env->ExceptionCheck())env->ExceptionClear();mapping::ReleaseGlobal(env,packet);
 }
}
void ResetBacktrack(JNIEnv* env,bool discard=false){
 DispatchBacktrack(env,true,discard);backtrackEntityStates.clear();backtrackActiveTarget=backtrackPendingTarget=-1;
 backtrackDelaying=backtrackForceFlush=backtrackRuntimeEnabled=backtrackRenderValid=false;backtrackRenderSteps=0;backtrackLastSnapshot.reset();PublishBacktrackVisual({});
}
bool QueueBacktrack(JNIEnv* env,jobject packet,const Settings& settings,bool immediate=false){
 if(backtrackPackets.size()>=512){backtrackForceFlush=true;return false;}
 const auto copy=mapping::Global(env,packet);Check(env);if(!copy)return false;
 const auto low=std::min(settings.delay,settings.history),high=std::max(settings.delay,settings.history);
 const auto latency=immediate?0ull:static_cast<std::uint64_t>(low+(high-low)*R());
 auto release=client::scheduler::Now()+latency;if(!backtrackPackets.empty())release=std::max(release,backtrackPackets.back().releaseAt);
 backtrackPackets.push_back({copy,release});if(backtrackPackets.size()>=512)backtrackForceFlush=true;return true;
}
BacktrackPacketState StateFromEntity(JNIEnv* env,int id){
 const auto entity=FindEntity(env,id);if(!entity)return {};
 const auto p=Position(env,entity);return {static_cast<int>(std::floor(p.x*32.)),static_cast<int>(std::floor(p.y*32.)),static_cast<int>(std::floor(p.z*32.))};
}
Vec Snapshot(const BacktrackPacketState& state){return {state.x/32.,state.y/32.,state.z/32.};}
void ResetBacktrackRender(Vec position){backtrackRenderCurrent=backtrackRenderTarget=position;backtrackRenderSteps=0;backtrackRenderValid=true;}
void TargetBacktrackRender(Vec position){backtrackRenderTarget=position;backtrackRenderSteps=3;if(!backtrackRenderValid)ResetBacktrackRender(position);}
void PromoteBacktrackTarget(JNIEnv* env){
 if(backtrackPendingTarget<0)return;const int next=backtrackPendingTarget;backtrackPendingTarget=-1;
 if(next==backtrackActiveTarget)return;DispatchBacktrack(env,true);backtrackActiveTarget=next;backtrackLastSnapshot.reset();backtrackDelaying=false;
 AOKI_LOG("[Backtrack] target=%d promoted",next);
 if(!backtrackEntityStates.contains(next))backtrackEntityStates.emplace(next,StateFromEntity(env,next));ResetBacktrackRender(Snapshot(backtrackEntityStates.at(next)));
}
void UpdateBacktrack(JNIEnv* env){
 backtrackRuntimeEnabled=true;DispatchBacktrack(env);PromoteBacktrackTarget(env);
 if(backtrackActiveTarget<0&&!backtrackPackets.empty())DispatchBacktrack(env,true);
 if(backtrackActiveTarget<0||!backtrackRenderValid){PublishBacktrackVisual({});return;}
 if(backtrackRenderSteps>0){backtrackRenderCurrent.x+=(backtrackRenderTarget.x-backtrackRenderCurrent.x)/backtrackRenderSteps;backtrackRenderCurrent.y+=(backtrackRenderTarget.y-backtrackRenderCurrent.y)/backtrackRenderSteps;backtrackRenderCurrent.z+=(backtrackRenderTarget.z-backtrackRenderCurrent.z)/backtrackRenderSteps;--backtrackRenderSteps;}
 double width=.6,height=1.8;const auto entity=FindEntity(env,backtrackActiveTarget);
 if(entity){const auto box=Object(env,entity,"Entity.boundingBox");if(box){width=std::max(.1,Read<double>(env,box,"AxisAlignedBB.maxX")-Read<double>(env,box,"AxisAlignedBB.minX"));height=std::max(.1,Read<double>(env,box,"AxisAlignedBB.maxY")-Read<double>(env,box,"AxisAlignedBB.minY"));}}
 PublishBacktrackVisual({backtrackRenderCurrent.x,backtrackRenderCurrent.y,backtrackRenderCurrent.z,width,height,true});
}
bool BacktrackCritical(JNIEnv* env,jobject packet){
 if(mapping::Instance(packet,"NoRotateTeleportPacket"))return true;
 if(!mapping::Instance(packet,"VelocityPacket"))return false;
 return playerRoot&&Read<int>(env,packet,"VelocityPacket.entityId")==Read<int>(env,playerRoot,"Entity.entityId");
}
std::optional<Vec> ProcessBacktrackPacket(JNIEnv* env,jobject packet){
 if(mapping::Instance(packet,"BacktrackEntityPacket")){
  const int id=Read<int>(env,packet,"BacktrackEntityPacket.entityId");auto [it,inserted]=backtrackEntityStates.try_emplace(id);
  if(inserted)it->second=StateFromEntity(env,id);
  it->second.x+=Read<signed char>(env,packet,"BacktrackEntityPacket.deltaX");
  it->second.y+=Read<signed char>(env,packet,"BacktrackEntityPacket.deltaY");
  it->second.z+=Read<signed char>(env,packet,"BacktrackEntityPacket.deltaZ");
  if(id==backtrackActiveTarget){const auto snapshot=Snapshot(it->second);TargetBacktrackRender(snapshot);return snapshot;}return {};
 }
 if(mapping::Instance(packet,"BacktrackTeleportPacket")){
  const int id=Read<int>(env,packet,"BacktrackTeleportPacket.entityId");backtrackEntityStates[id]={Read<int>(env,packet,"BacktrackTeleportPacket.x"),Read<int>(env,packet,"BacktrackTeleportPacket.y"),Read<int>(env,packet,"BacktrackTeleportPacket.z")};if(id==backtrackActiveTarget)TargetBacktrackRender(Snapshot(backtrackEntityStates[id]));return {};
 }
 if(mapping::Instance(packet,"BacktrackDestroyPacket")){
  const auto ids=static_cast<jintArray>(Object(env,packet,"BacktrackDestroyPacket.entityIds"));if(!ids)return {};
  const auto length=env->GetArrayLength(ids);std::vector<jint> values(static_cast<std::size_t>(length));env->GetIntArrayRegion(ids,0,length,values.data());Check(env);
  for(const auto id:values){backtrackEntityStates.erase(id);if(id==backtrackActiveTarget){backtrackActiveTarget=-1;backtrackLastSnapshot.reset();backtrackDelaying=backtrackRenderValid=false;backtrackForceFlush=true;PublishBacktrackVisual({});}}
 }
 return {};
}
int HurtTime(JNIEnv* env,int entityId){const auto entity=FindEntity(env,entityId);return entity&&mapping::Instance(entity,"EntityLivingBase")?Read<int>(env,entity,"EntityLivingBase.hurtTime"):-1;}
int DynamicCrosshairTarget(JNIEnv* env);
void ResetFakeLagState(){dynamicTargetId=repelTargetId=-1;dynamicLastPositionRelease=dynamicBlockCooldown=dynamicLastBlockPlace=repelDeadline=lastDynamicAttack=0;}
void UpdateFakeLag(JNIEnv* env,const Settings& settings){
 if(fakeLagRuntimeMode!=settings.mode){FlushFakeLag(env,true);ResetFakeLagState();fakeLagRuntimeMode=settings.mode;}
 if(settings.mode==0||settings.mode==1)FlushFakeLag(env);
 if(settings.mode==1)dynamicTargetId=DynamicCrosshairTarget(env);
 if(settings.mode==2&&FakeLagQueued()){
  const int hurt=HurtTime(env,repelTargetId),window=static_cast<int>(std::ceil(settings.delay/50.f));
  if(client::scheduler::Now()>=repelDeadline||(hurt>0&&hurt<=window)){FlushFakeLag(env,true);repelTargetId=-1;repelDeadline=0;}
 }
}
jobject FakeLagSend(JNIEnv* env,jobject packet,const Settings& settings){
 if(!playerRoot||!worldRoot)return packet;const auto now=client::scheduler::Now();const auto delay=static_cast<std::uint64_t>(settings.delay);
 if(fakeLagRuntimeMode!=settings.mode){FlushFakeLag(env,true);ResetFakeLagState();fakeLagRuntimeMode=settings.mode;}
 if(settings.mode==0){FlushFakeLag(env);return QueueFakeLag(env,packet,now+delay)?nullptr:packet;}
 int attacked=-1;const bool attack=AttackPacket(env,packet,&attacked);
 if(settings.mode==2){
  if(FakeLagQueued()){
   const bool release=now>=repelDeadline||attack||mapping::Instance(packet,"AuraTransactionPacket");
   if(!QueueFakeLag(env,packet,repelDeadline))return packet;if(release){FlushFakeLag(env,true);repelTargetId=-1;repelDeadline=0;}return nullptr;
  }
  if(attack){const auto jitter=static_cast<std::uint64_t>(R()*100),total=delay+jitter;const int hurt=HurtTime(env,attacked),window=static_cast<int>(std::ceil(total/50.));if(hurt>0&&hurt<=window){repelTargetId=attacked;repelDeadline=now+total;return QueueFakeLag(env,packet,repelDeadline)?nullptr:packet;}}
  return packet;
 }
 FlushFakeLag(env);
 auto delayWithOffset=[&]()->jobject{const auto offset=static_cast<std::uint64_t>(settings.history);if(!offset){FlushFakeLag(env,true);return packet;}return QueueFakeLag(env,packet,now+offset)?nullptr:packet;};
 if(attack){const int hurt=HurtTime(env,attacked),window=static_cast<int>(std::ceil(settings.delay/50.f));if(hurt>=0&&hurt<=window&&now-lastDynamicAttack>250&&FakeLagQueued()){FlushFakeLag(env,false,true);lastDynamicAttack=now;return packet;}lastDynamicAttack=now;}
 else {
  const bool control=mapping::Instance(packet,"AuraKeepAlivePacket")||mapping::Instance(packet,"AuraTransactionPacket")||mapping::Instance(packet,"AuraPayloadPacket")||mapping::Instance(packet,"AuraAbilitiesPacket");
  if(control)return delayWithOffset();
  if(mapping::Instance(packet,"AuraPlacePacket")){
   const auto stack=Object(env,packet,"AuraPlacePacket.stack"),item=stack?Object(env,stack,"ItemStack.item"):nullptr;
   if(stack&&item&&!mapping::Instance(item,"ItemSword")){dynamicBlockCooldown=now+500;return delayWithOffset();}
   if(stack&&now-dynamicLastBlockPlace>=500){dynamicLastBlockPlace=now;return delayWithOffset();}
  }
  if(now<dynamicBlockCooldown||(!Read<bool>(env,playerRoot,"ExtraEntity.onGround")&&Read<float>(env,playerRoot,"Entity.fallDistance")>3))return delayWithOffset();
 }
 if(dynamicTargetId<0)return delayWithOffset();
 const bool movement=mapping::Instance(packet,"AuraMovementPacket"),position=movement&&Read<bool>(env,packet,"AuraMovementPacket.moving");
 std::uint64_t release=now+delay;if(dynamicLastPositionRelease)release=std::min(release,dynamicLastPositionRelease+90);else release=std::min(release,now+90);
 if(position)dynamicLastPositionRelease=release;
 return QueueFakeLag(env,packet,release,position)?nullptr:packet;
}
void MlgDiagnostic(int gate,const char* reason,float fallDistance,double motionY,bool grounded,bool inWater,bool onLadder,double reach=-1.){
 if(gate==mlgDiagGate&&tick-mlgDiagTick<20)return;mlgDiagGate=gate;mlgDiagTick=tick;
 AOKI_LOG("[DEBUG-mlg12] gate=%s fall=%.2f motionY=%.3f grounded=%d water=%d ladder=%d reach=%.2f cooldown=%d gameTick=%d",reason,static_cast<double>(fallDistance),motionY,grounded?1:0,inWater?1:0,onLadder?1:0,reach,mlgCooldownUntil,tick);
}
struct MlgItem {jobject stack=nullptr;int slot=-1;bool water=false;};
int ItemId(JNIEnv* env,jobject stack){const auto item=stack?Object(env,stack,"ItemStack.item"):nullptr;return item?Call(env,nullptr,"Item.id",{Obj(item)},true).i:0;}
MlgItem FindMlgItem(JNIEnv* env){
 const auto inventory=Object(env,playerRoot,"EntityPlayer.inventory");const auto stacks=inventory?static_cast<jobjectArray>(Object(env,inventory,"InventoryPlayer.mainInventory")):nullptr;
 if(!stacks)return {};const int length=env->GetArrayLength(stacks),hotbarCount=std::min(9,length);MlgItem cobweb;
 for(int slot=0;slot<hotbarCount;++slot){const auto stack=env->GetObjectArrayElement(stacks,slot);if(!stack)continue;const int id=ItemId(env,stack);if(id==326)return {stack,slot,true};if(id==30&&!cobweb.stack)cobweb={stack,slot,false};}
 if(cobweb.stack)return cobweb;
 int source=-1;bool water=false;int webSource=-1;
 for(int slot=9;slot<length;++slot){const auto stack=env->GetObjectArrayElement(stacks,slot);if(!stack)continue;const int id=ItemId(env,stack);if(id==326){source=slot;water=true;break;}if(id==30&&webSource<0)webSource=slot;}
 if(source<0)source=webSource;if(source<0)return {};
 int destination=-1;
 for(int slot=0;slot<hotbarCount;++slot)if(!env->GetObjectArrayElement(stacks,slot)){destination=slot;break;}
 if(destination<0)for(int slot=0;slot<hotbarCount;++slot){const auto stack=env->GetObjectArrayElement(stacks,slot);const auto item=stack?Object(env,stack,"ItemStack.item"):nullptr;if(item&&mapping::Instance(item,"ItemBlock")&&ItemId(env,stack)!=30){destination=slot;break;}}
 if(destination<0)return {};
 const auto controller=Object(env,mcRoot,"Minecraft.playerController");Call(env,controller,"PlayerControllerMP.windowClick",{Int(0),Int(source),Int(destination),Int(2),Obj(playerRoot)});
 const auto equipped=env->GetObjectArrayElement(stacks,destination);if(equipped)AOKI_LOG("[NoFall/MLG] moved %s inventorySlot=%d hotbarSlot=%d",water?"water":"cobweb",source,destination);
 return {equipped,destination,water};
}
std::optional<Pos> PredictMlgSupport(JNIEnv* env,double motionY){
 const auto position=Position(env,playerRoot);
 auto trace=[&](double x,double z)->std::optional<Pos>{
  const auto from=New(env,"Vec3.constructor",{Double(x),Double(position.y+.25),Double(z)}),to=New(env,"Vec3.constructor",{Double(x),Double(position.y-50.),Double(z)});
  const auto hit=Call(env,worldRoot,"World.rayTraceBlocks",{Obj(from),Obj(to)}).l;if(!hit)return {};
  const auto block=Object(env,hit,"MovingObjectPosition.blockPos");return block?std::optional<Pos>{Coordinates(env,block)}:std::nullopt;
 };
 const auto below=trace(position.x,position.z);int predictionTicks=12;
 if(below){double y=position.y,vy=motionY;for(int i=1;i<=50;++i){y+=vy;vy=(vy-.08)*.98;if(y<=below->y+1.){predictionTicks=i;break;}}}
 double x=position.x,z=position.z,vx=Read<double>(env,playerRoot,"Entity.motionX"),vz=Read<double>(env,playerRoot,"Entity.motionZ");
 // Vanilla horizontal drag makes the early ticks dominate the landing point.
 // Two vertical traces are still cheaper than a 50-block per-block scan.
 for(int i=0;i<predictionTicks;++i){x+=vx;z+=vz;vx*=.91;vz*=.91;}
 const auto predicted=trace(x,z);return predicted?predicted:below;
}
void Mlg(JNIEnv* env,const Settings&){
 const bool grounded=Call(env,playerRoot,"Entity.onGround").z!=0;
 const auto position=Position(env,playerRoot);const double deltaY=mlgLastY?position.y-*mlgLastY:0.;mlgLastY=position.y;
 mlgTrackedFall=rules::MlgTrackedFall(mlgTrackedFall,deltaY,grounded);
 const float mappedFall=Read<float>(env,playerRoot,"Entity.fallDistance");
 // The local player overrides the getter and stores vertical motion in a wrapper.
 const double mappedMotionY=Call(env,playerRoot,"ClientPlayer.getMotionY").d;
 if(!grounded&&deltaY<-.08&&mlgTrackedFall>=3.f&&mlgTrackedFall+deltaY<3.f){
  AOKI_LOG("[DEBUG-mlg12] rawFall=%.6f rawMotionY=%.6f deltaY=%.6f trackedFall=%.3f gameTick=%d",
   static_cast<double>(mappedFall),mappedMotionY,deltaY,static_cast<double>(mlgTrackedFall),tick);
 }
 const float fallDistance=std::max(mappedFall,mlgTrackedFall);const double motionY=std::abs(mappedMotionY)>.0001?mappedMotionY:deltaY;
 const bool inWater=Call(env,playerRoot,"Entity.isInWater").z!=0,onLadder=Call(env,playerRoot,"EntityLivingBase.isOnLadder").z!=0;
 if(grounded){mlgCooldownUntil=-1;MlgDiagnostic(0,"grounded",fallDistance,motionY,grounded,inWater,onLadder);return;}
 if(!rules::MlgReady(fallDistance,motionY,grounded,inWater,onLadder,false)){MlgDiagnostic(1,"activation",fallDistance,motionY,grounded,inWater,onLadder);return;}
 if(tick<=mlgCooldownUntil){MlgDiagnostic(2,"cooldown",fallDistance,motionY,grounded,inWater,onLadder);return;}
 const auto item=FindMlgItem(env);if(!item.stack){MlgDiagnostic(3,"item",fallDistance,motionY,grounded,inWater,onLadder);return;}
 const auto support=PredictMlgSupport(env,motionY);if(!support){MlgDiagnostic(4,"support",fallDistance,motionY,grounded,inWater,onLadder);return;}
 const auto eye=Eye(env);
 const auto aim=rules::Aim(eye,{support->x+.5,support->y+1.,support->z+.5});
 const float yaw=Read<float>(env,playerRoot,"Entity.rotationYaw"),pitch=Read<float>(env,playerRoot,"Entity.rotationPitch");constexpr float step=35.f;
 Write(env,playerRoot,"Entity.rotationYaw",yaw+std::clamp(rules::Wrap(aim[0]-yaw),-step,step));
 Write(env,playerRoot,"Entity.rotationPitch",std::clamp(pitch+std::clamp(aim[1]-pitch,-step,step),-90.f,90.f));
 const double reach=rules::Distance(eye,{support->x+.5,support->y+1.,support->z+.5});
 if(!rules::MlgWithinReach(eye,*support)){MlgDiagnostic(5,"reach",fallDistance,motionY,grounded,inWater,onLadder,reach);return;}
 const auto inventory=Object(env,playerRoot,"EntityPlayer.inventory");const int original=Read<int>(env,inventory,"InventoryPlayer.currentItem");
 const auto controller=Object(env,mcRoot,"Minecraft.playerController");
 const scaffold::Placement placement{{support->x+.5,support->y+1.,support->z+.5},{support->x,support->y,support->z},scaffold::Face::Up};
 bool placed=false;
 Write(env,inventory,"InventoryPlayer.currentItem",item.slot);
 try {
  Call(env,controller,"PlayerControllerMP.syncCurrentItem");
  if(item.water){
   Write(env,playerRoot,"Entity.rotationYaw",yaw+rules::Wrap(aim[0]-yaw));
   Write(env,playerRoot,"Entity.rotationPitch",aim[1]);
   const auto renderer=Object(env,mcRoot,"Minecraft.entityRenderer");
   Call(env,renderer,"EntityRenderer.getMouseOver",{Float(1.f)});
   Call(env,mcRoot,"Minecraft.rightClickMouse");
   placed=ItemId(env,Stack(env,inventory,item.slot))==325;
  }else{
   placed=scaffold::Place(env,mcRoot,playerRoot,item.stack,placement,scaffold::RayCast::Off,std::nullopt,{.5,.5,.5});
  }
 }catch(...){
  if(env->ExceptionCheck())env->ExceptionClear();
  Write(env,inventory,"InventoryPlayer.currentItem",original);
  Call(env,controller,"PlayerControllerMP.syncCurrentItem");
  throw;
 }
 Write(env,inventory,"InventoryPlayer.currentItem",original);Call(env,controller,"PlayerControllerMP.syncCurrentItem");
 MlgDiagnostic(placed?7:6,placed?"placed":"place-call",fallDistance,motionY,grounded,inWater,onLadder,reach);
 if(placed){mlgCooldownUntil=tick+20;AOKI_LOG("[NoFall/MLG] placed %s slot=%d support=(%d,%d,%d)",item.water?"water":"cobweb",item.slot,support->x,support->y,support->z);}
}
void Select(JNIEnv* env,int slot){if(slot<0||slot>8)return;const auto inv=Object(env,playerRoot,"EntityPlayer.inventory");if(oldSlot<0)oldSlot=Read<int>(env,inv,"InventoryPlayer.currentItem");Write(env,inv,"InventoryPlayer.currentItem",slot);toolSlot=slot;Call(env,Object(env,mcRoot,"Minecraft.playerController"),"PlayerControllerMP.syncCurrentItem");}
void RestoreTool(JNIEnv* env){if(oldSlot>=0&&playerRoot){const auto inv=Object(env,playerRoot,"EntityPlayer.inventory");if(Read<int>(env,inv,"InventoryPlayer.currentItem")==toolSlot){Write(env,inv,"InventoryPlayer.currentItem",oldSlot);Call(env,Object(env,mcRoot,"Minecraft.playerController"),"PlayerControllerMP.syncCurrentItem");}}oldSlot=toolSlot=-1;}
struct Entity {jobject object;int id;Vec position,lo,hi;};
bool Named(const std::string& names,const std::string& name){std::size_t start=0;while(start<names.size()){const auto end=names.find(',',start);auto token=names.substr(start,end==std::string::npos?end:end-start);const auto first=token.find_first_not_of(" \r\n\t"),last=token.find_last_not_of(" \r\n\t");if(first!=std::string::npos&&_stricmp(token.substr(first,last-first+1).c_str(),name.c_str())==0)return true;if(end==std::string::npos)break;start=end+1;}return false;}
std::string Text(JNIEnv* env,jobject entity,const char* method){const auto text=static_cast<jstring>(Call(env,entity,method).l);if(!text)return {};const auto chars=env->GetStringUTFChars(text,nullptr);Check(env);std::string value=chars?chars:"";if(chars)env->ReleaseStringUTFChars(text,chars);return value;}
std::vector<Entity> Entities(JNIEnv* env,const Settings& s,double range){
 std::vector<Entity> result;const auto list=Object(env,worldRoot,"World.loadedEntityList");if(!list)return result;const auto array=static_cast<jobjectArray>(Object(env,list,"ArrayList.elements"));const int count=std::min(Read<int>(env,list,"ArrayList.size"),env->GetArrayLength(array));const auto player=Position(env,playerRoot);
 for(int i=0;i<count&&i<4096;++i){const auto entity=env->GetObjectArrayElement(array,i);if(!entity||env->IsSameObject(entity,playerRoot)||!mapping::Instance(entity,"EntityLivingBase")||mapping::Instance(entity,"AuraArmorStand"))continue;
  if(Read<bool>(env,entity,"Entity.isDead")||Call(env,entity,"EntityLivingBase.getHealth").f<=0)continue;
  const bool isPlayer=mapping::Instance(entity,"EntityPlayer");
  if((isPlayer&&!s.players)||((mapping::Instance(entity,"AuraHostile")||mapping::Instance(entity,"AuraNpc"))&&!s.mobs)||((mapping::Instance(entity,"EntityAnimal")||mapping::Instance(entity,"AuraAmbient")||mapping::Instance(entity,"AuraWaterMob"))&&!s.animals)||(!s.invisibles&&Call(env,entity,"Entity.isInvisible").z))continue;
  if(isPlayer&&combat::targets::IsNpcPlayer(env,entity))continue;
  const auto position=Position(env,entity);if(rules::Distance(position,player)>range)continue;
  const auto name=Text(env,entity,"Entity.getName");if(Named(aura::Options().friends,name)||Named(aura::Options().bots,name))continue;
  if(!s.teammates&&mapping::Instance(entity,"EntityPlayer")){const auto one=Call(env,entity,"EntityLivingBase.getTeam").l,two=Call(env,playerRoot,"EntityLivingBase.getTeam").l;if(one&&two&&env->IsSameObject(one,two))continue;}
  const auto box=Object(env,entity,"Entity.boundingBox");result.push_back({entity,Read<int>(env,entity,"Entity.entityId"),position,{Read<double>(env,box,"AxisAlignedBB.minX"),Read<double>(env,box,"AxisAlignedBB.minY"),Read<double>(env,box,"AxisAlignedBB.minZ")},{Read<double>(env,box,"AxisAlignedBB.maxX"),Read<double>(env,box,"AxisAlignedBB.maxY"),Read<double>(env,box,"AxisAlignedBB.maxZ")}});
 }
 return result;
}
std::optional<Entity> Ray(JNIEnv* env,const std::vector<Entity>& entities,std::array<float,2> angles,double range,double expand=0){
 const auto eye=Eye(env),direction=rules::Direction(angles);double nearest=range;
 const auto from=New(env,"Vec3.constructor",{Double(eye.x),Double(eye.y),Double(eye.z)}),to=New(env,"Vec3.constructor",{Double(eye.x+direction.x*range),Double(eye.y+direction.y*range),Double(eye.z+direction.z*range)});
 const auto block=Call(env,worldRoot,"World.rayTraceBlocks",{Obj(from),Obj(to)}).l;
 if(block){const auto hit=Object(env,block,"MovingObjectPosition.hitVec");if(hit)nearest=rules::Distance(eye,{Read<double>(env,hit,"Vec3.x"),Read<double>(env,hit,"Vec3.y"),Read<double>(env,hit,"Vec3.z")});}
 std::optional<Entity> selected;for(const auto& entity:entities){const auto hit=rules::RayBox(eye,direction,entity.lo,entity.hi,range,.1+expand);if(hit&&*hit<=nearest){selected=entity;nearest=*hit;}}return selected;
}
int DynamicCrosshairTarget(JNIEnv* env){
 Settings targets;targets.players=targets.invisibles=targets.animals=targets.mobs=targets.teammates=true;
 const auto entities=Entities(env,targets,10.);if(entities.empty())return -1;
 const std::array<float,2> angles{Read<float>(env,playerRoot,"Entity.rotationYaw"),Read<float>(env,playerRoot,"Entity.rotationPitch")};
 const auto target=Ray(env,entities,angles,10.);return target?target->id:-1;
}
bool MouseEntity(JNIEnv* env){const auto hit=Object(env,mcRoot,"Minecraft.objectMouseOver");return hit&&Object(env,hit,"MovingObjectPosition.entityHit");}
std::optional<Pos> MouseBlock(JNIEnv* env){const auto hit=Object(env,mcRoot,"Minecraft.objectMouseOver");if(!hit||Object(env,hit,"MovingObjectPosition.entityHit"))return {};const auto pos=Object(env,hit,"MovingObjectPosition.blockPos");if(!pos)return {};const auto p=Coordinates(env,pos);return GetBlock(env,p).id==0?std::nullopt:std::optional<Pos>(p);}
void Failure(JNIEnv* env,Kind kind,const std::exception& error){if(env->ExceptionCheck())env->ExceptionClear();const int module=ModuleIndex(kind);AOKI_LOG("[ExtraModules] %s disabled: %s",module>=0?modules::Catalog[module].name:"Unknown",error.what());auto s=Options(kind);s.enabled=false;SetOptions(kind,s);}
template<class F>void Run(JNIEnv* env,Kind kind,F action){const auto s=Options(kind);if(!s.enabled)return;try{action(s);}catch(const std::exception& error){Failure(env,kind,error);}}
void AutoTool(JNIEnv* env,const Settings&){
 const auto mouse=MouseBlock(env);if(mouse&&Down(env,"GameSettings.keyBindAttack")){toolBlock=mouse;toolTicks=15;}
 if(toolTicks--<=0||!toolBlock){RestoreTool(env);return;}
 const auto block=GetBlock(env,*toolBlock);const auto inventory=Object(env,playerRoot,"EntityPlayer.inventory");float best=1;int slot=-1;
 for(int i=0;i<9;++i){const auto stack=Stack(env,inventory,i);if(stack){const float strength=Call(env,stack,"ExtraStack.strength",{Obj(block.object)}).f;if(strength>best){best=strength;slot=i;}}}
 if(slot>=0)Select(env,slot);
}
void FastUse(JNIEnv* env,const Settings& s){if(Call(env,playerRoot,"EntityPlayer.isUsingItem").z&&Read<int>(env,playerRoot,"EntityPlayer.itemInUseCount")==31){const auto p=Position(env,playerRoot);for(int i=0;i<=static_cast<int>(s.speed);++i)Send(env,MovementPacket(env,true,p.x,p.y,p.z,Read<float>(env,playerRoot,"Entity.rotationYaw"),Read<float>(env,playerRoot,"Entity.rotationPitch"),Call(env,playerRoot,"Entity.onGround").z!=0,0));}}
int BoxedInt(JNIEnv* env,jobject boxed){if(!boxed)throw std::runtime_error("missing boxed CPS value");return Call(env,boxed,"JavaInteger.intValue").i;}
jobject CpsLimit(JNIEnv* env){const auto core=Call(env,mcRoot,"ExtraMinecraft.clientCore").l;const auto manager=Call(env,core,"ExtraClientCore.clickManager").l;const auto tracker=Call(env,manager,"ExtraClickManager.cpsTracker").l;const auto limit=Call(env,tracker,"ExtraCpsTracker.limit").l;if(!limit)throw std::runtime_error("CPS limit unavailable");return limit;}
int CpsLimit(JNIEnv* env,jobject limit){return BoxedInt(env,Call(env,limit,"ExtraIntValue.get").l);}
void CpsLimit(JNIEnv* env,jobject limit,int value){const auto boxed=Call(env,nullptr,"JavaInteger.valueOf",{Int(value)},true).l;Call(env,limit,"ExtraIntValue.set",{Obj(boxed)});}
void EnableFastPlaceCps(JNIEnv* env){
 if(fastPlaceCpsOwned)return;const auto limit=CpsLimit(env);const bool originalBypass=StaticBool(env,"ExtraClientCore.cpsBypass");const int originalLimit=CpsLimit(env,limit);
 StaticBool(env,"ExtraClientCore.cpsBypass",true);
 try{CpsLimit(env,limit,rules::FastPlaceLimiterValue());}catch(...){if(env->ExceptionCheck())env->ExceptionClear();StaticBool(env,"ExtraClientCore.cpsBypass",originalBypass);throw;}
 fastPlaceOriginalBypass=originalBypass;fastPlaceOriginalLimit=originalLimit;fastPlaceCpsOwned=true;
}
void RestoreFastPlaceCps(JNIEnv* env){
 if(!fastPlaceCpsOwned)return;fastPlaceCpsOwned=false;if(!env||!mcRoot)return;
 try{const auto limit=CpsLimit(env);if(CpsLimit(env,limit)==rules::FastPlaceLimiterValue())CpsLimit(env,limit,fastPlaceOriginalLimit);}catch(...){if(env->ExceptionCheck())env->ExceptionClear();}
 try{if(StaticBool(env,"ExtraClientCore.cpsBypass"))StaticBool(env,"ExtraClientCore.cpsBypass",fastPlaceOriginalBypass);}catch(...){if(env->ExceptionCheck())env->ExceptionClear();}
}
void FastPlace(JNIEnv* env,const Settings&){
 EnableFastPlaceCps(env);
 const auto held=Call(env,playerRoot,"EntityLivingBase.getHeldItem").l;
 const auto item=held?Object(env,held,"ItemStack.item"):nullptr;
 const bool block=item&&mapping::Instance(item,"ItemBlock");
 const int current=Read<int>(env,mcRoot,"ExtraMinecraft.rightClickDelay");
 const int next=rules::FastPlaceDelay(current,block);
 if(next!=current)Write(env,mcRoot,"ExtraMinecraft.rightClickDelay",next);
}
void Spammer(JNIEnv* env,const Settings& s){if(s.message.empty())return;const auto now=client::scheduler::Now();if(lastSpam&&now-lastSpam<static_cast<std::uint64_t>(s.delay))return;if(s.message.starts_with('#')){if(warnedMessage!=s.message){warnedMessage=s.message;AOKI_LOG("[Spammer] # messages are reserved for IRC; nothing sent");}return;}
 const auto server=Object(env,mcRoot,"ExtraMinecraft.serverData");if(server&&s.message.starts_with('/')){const auto value=static_cast<jstring>(Object(env,server,"ExtraServerData.address"));if(value){const auto chars=env->GetStringUTFChars(value,nullptr);Check(env);std::string address=chars?chars:"";if(chars)env->ReleaseStringUTFChars(value,chars);std::transform(address.begin(),address.end(),address.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});if(address.find("loyisa.cn")!=std::string::npos)throw std::runtime_error("reference Loyisa command blacklist");}}
const auto text=env->NewStringUTF(s.message.c_str());Check(env);Send(env,New(env,"DisconnectChatPacket.constructor",{Obj(text)}));lastSpam=now;}
void AutoClicker(JNIEnv* env,const Settings& s){
 const bool attack=Down(env,"GameSettings.keyBindAttack"),use=Down(env,"GameSettings.keyBindUseItem");
 if((!s.left||!attack)&&(!s.right||!use))return;
 if(s.right&&use&&!attack)Click(env,true);
 if(s.left&&attack&&!use){const bool block=MouseBlock(env).has_value();if(!s.breakBlocks&&block)Write(env,Object(env,mcRoot,"Minecraft.playerController"),"PlayerControllerMP.curBlockDamageMP",0.f);if(!block||!s.breakBlocks)Click(env,false);}
}
void Aimbot(JNIEnv* env,const Settings& s){
 if(s.limitItems){const auto held=Call(env,playerRoot,"EntityLivingBase.getHeldItem").l;if(!held||!mapping::Instance(Object(env,held,"ItemStack.item"),"ItemSword"))return;}
 const auto entities=Entities(env,s,s.range);if(entities.empty())return;const auto eye=Eye(env);const auto camera=std::array<float,2>{Read<float>(env,playerRoot,"Entity.rotationYaw"),Read<float>(env,playerRoot,"Entity.rotationPitch")};const Entity* selected=nullptr;std::array<float,2> selectedAngle{};double best=1e9;
 for(const auto& target:entities){const auto angle=rules::Aim(eye,{target.position.x,target.position.y+(target.hi.y-target.lo.y)*.85,target.position.z});const float yaw=rules::Wrap(angle[0]-camera[0]),pitch=angle[1]-camera[1];const double angular=std::hypot(yaw,pitch);if(!rules::AimbotCandidate(yaw,pitch,s.fov))continue;if(s.visibleOnly){const auto hit=Ray(env,entities,angle,s.range,.05);if(!hit||hit->id!=target.id)continue;}const double score=angular+rules::Distance(eye,target.position)*.01;if(score<best){best=score;selected=&target;selectedAngle=angle;}}
 if(!selected)return;Write(env,playerRoot,"Entity.rotationYaw",selectedAngle[0]);Write(env,playerRoot,"Entity.rotationPitch",std::clamp(selectedAngle[1],-90.f,90.f));
}
void Eagle(JNIEnv* env,jobject input,const Settings& s){
 const auto held=Call(env,playerRoot,"EntityLivingBase.getHeldItem").l;const bool block=held&&mapping::Instance(Object(env,held,"ItemStack.item"),"ItemBlock"),allowed=rules::EagleAllowed(s.blocksOnly,block);
 const bool grounded=Call(env,playerRoot,"Entity.onGround").z!=0,inputSneak=Read<bool>(env,input,"AuraMovementInput.sneak"),physicalSneak=PhysicalBinding(env,"GameSettings.keyBindSneak"),manual=eagleKeyOwned?physicalSneak:inputSneak;
 const float forward=Read<float>(env,input,"AuraMovementInput.forward"),strafe=Read<float>(env,input,"AuraMovementInput.strafe");bool edge=false;
 if(allowed&&rules::EagleMaySneak(forward,grounded)){
  const auto box=Object(env,playerRoot,"Entity.boundingBox");
  const rules::Vec low{Read<double>(env,box,"AxisAlignedBB.minX"),Read<double>(env,box,"AxisAlignedBB.minY"),Read<double>(env,box,"AxisAlignedBB.minZ")};
  const rules::Vec high{Read<double>(env,box,"AxisAlignedBB.maxX"),Read<double>(env,box,"AxisAlignedBB.maxY"),Read<double>(env,box,"AxisAlignedBB.maxZ")};
  const Vec motion{Read<double>(env,playerRoot,"Entity.motionX"),0,Read<double>(env,playerRoot,"Entity.motionZ")};
  const auto bounds=rules::EagleCollisionBox(low,high,motion);
  const auto checkBox=New(env,"AxisAlignedBB.constructor",{Double(bounds[0]),Double(bounds[1]),Double(bounds[2]),Double(bounds[3]),Double(bounds[4]),Double(bounds[5])});
  const auto collisions=Call(env,worldRoot,"World.collisions",{Obj(checkBox)}).l;if(!collisions)throw std::runtime_error("World.collisions returned null");
  const auto size=mapping::Read<int>(collisions,"ArrayList.size");
  if(!size)throw std::runtime_error("collision list size unavailable");
  edge=*size==0;
 }
 const auto now=client::scheduler::Now();
 if(edge){if(!eagleOwned)eagleDelayMs=100+static_cast<std::uint64_t>(R()*100);eagleReleaseAt=now+eagleDelayMs;eagleOwned=true;}
 else if(!grounded||!allowed||now>=eagleReleaseAt)eagleOwned=false;
 if(eagleOwned&&!manual){const float slowdown=std::clamp(s.speed/100.f,.2f,1.f);Write(env,input,"AuraMovementInput.forward",forward*slowdown);Write(env,input,"AuraMovementInput.strafe",strafe*slowdown);}
 Write(env,input,"AuraMovementInput.sneak",manual||eagleOwned);
 if(eagleOwned){Write(env,Binding(env,"GameSettings.keyBindSneak"),"KeyBinding.pressed",true);eagleKeyOwned=true;}
 else RestoreEagleKey(env);
}
void Restore(JNIEnv* env,bool discardBacktrack=false){
 auto safe=[&](const auto& action){try{action();}catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[ExtraModules] restoration: %s",e.what());}};
 safe([&]{FlushFakeLag(env,true);});fakeLagRuntimeMode=-1;ResetFakeLagState();
 safe([&]{ResetBacktrack(env,discardBacktrack);});
 RestoreFastPlaceCps(env);
 if(eagleKeyOwned)safe([&]{RestoreEagleKey(env);});
 if(inventoryMoveOwned)safe([&]{RestoreInventoryMove(env,false);});
 safe([&]{RestoreTool(env);});
 for(auto* root:{&mcRoot,&playerRoot,&worldRoot})mapping::ReleaseGlobal(env,*root);
 tick=-1;toolTicks=0;toolBlock.reset();inventoryMoveOwned=false;eagleOwned=false;eagleKeyOwned=false;eagleReleaseAt=0;mlgCooldownUntil=-1;mlgDiagGate=-1;mlgDiagTick=-1000;mlgLastY.reset();mlgTrackedFall=0;
}
}
void Stop(JNIEnv* env){std::lock_guard lock(mutex);if(env)Restore(env);}
void Poll(JNIEnv* env){
 if(!env||env->ExceptionCheck())return;std::lock_guard lock(mutex);Frame frame(env,128);if(!frame.ok)return;
 const auto clicker=Options(Kind::AutoClicker);
 client::scheduler::Configure(client::scheduler::Task::AutoClicker,clicker.enabled,
  rules::AutoClickInterval(clicker.cps));
 const auto spammer=Options(Kind::Spammer);
 client::scheduler::Configure(client::scheduler::Task::Spammer,spammer.enabled,
  static_cast<std::uint32_t>((std::max)(1.f,spammer.delay)));
 const auto fastUse=Options(Kind::FastUse),eagle=Options(Kind::Eagle);
 const auto fakeLagSchedule=Options(Kind::FakeLag),backtrackSchedule=Options(Kind::AimBacktrack);
 client::scheduler::Configure(client::scheduler::Task::FastUse,fastUse.enabled,1);
 client::scheduler::Configure(client::scheduler::Task::EagleRelease,eagle.enabled,1);
 client::scheduler::Configure(client::scheduler::Task::FakeLagRelease,fakeLagSchedule.enabled,1);
 client::scheduler::Configure(client::scheduler::Task::BacktrackRelease,backtrackSchedule.enabled,1);
 const auto disabled=pendingDisabled.exchange(0);for(int i=0;i<static_cast<int>(Kind::Count);++i)if(disabled&(1u<<i)){const auto kind=static_cast<Kind>(i);auto s=Options(kind);s.enabled=false;SetOptions(kind,s);}
 if(!AnyEnabled()){if(mcRoot)Stop(env);return;}
 if(!packets::IsInstalled(env))return;
 try{const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft");if(!mc)return;const auto player=Object(env,mc,"Minecraft.thePlayer"),world=Object(env,mc,"Minecraft.theWorld");if(!player||!world){if(playerRoot)Restore(env,true);return;}
  if(!playerRoot||!env->IsSameObject(playerRoot,player)||!env->IsSameObject(worldRoot,world)){if(playerRoot)Restore(env,true);mcRoot=mapping::Global(env,mc);playerRoot=mapping::Global(env,player);worldRoot=mapping::Global(env,world);}
  if(!Options(Kind::AutoTool).enabled)RestoreTool(env);
   {const auto noFall=Options(Kind::NoFall);const auto now=client::scheduler::Now();if(noFall.enabled&&(noFall.mode!=mlgDiagMode||now-mlgDiagStatusAt>=5000)){mlgDiagMode=noFall.mode;mlgDiagStatusAt=now;AOKI_LOG("[DEBUG-mlg12] status enabled=1 mode=%d needsInput=%d roots=%d/%d/%d",noFall.mode,NeedsInput()?1:0,mcRoot?1:0,playerRoot?1:0,worldRoot?1:0);}}
   if(!Options(Kind::Eagle).enabled){eagleOwned=false;eagleReleaseAt=0;if(eagleKeyOwned)RestoreEagleKey(env);}
   if(Options(Kind::FastPlace).enabled)Run(env,Kind::FastPlace,[&](const Settings& s){FastPlace(env,s);});else RestoreFastPlaceCps(env);
   if(backtrackSchedule.enabled){if(client::scheduler::Consume(client::scheduler::Task::BacktrackRelease,backtrackCursor))UpdateBacktrack(env);}else if(backtrackRuntimeEnabled||backtrackActiveTarget>=0||!backtrackPackets.empty())ResetBacktrack(env);
   {const auto fakeLag=fakeLagSchedule;if(fakeLag.enabled){if(client::scheduler::Consume(client::scheduler::Task::FakeLagRelease,fakeLagCursor))UpdateFakeLag(env,fakeLag);}else if(fakeLagRuntimeMode>=0){FlushFakeLag(env,true);fakeLagRuntimeMode=-1;ResetFakeLagState();}}
   if(clicker.enabled&&client::scheduler::Consume(client::scheduler::Task::AutoClicker,autoClickCursor)){
    const auto screen=Object(env,mcRoot,"Minecraft.currentScreen");
    const bool blockedUi=screen||ui::input::IsOpen();
    const bool dead=Read<bool>(env,playerRoot,"Entity.isDead");
    if(!dead&&(!blockedUi||!clicker.disableOnUi))Run(env,Kind::AutoClicker,[&](const Settings& s){AutoClicker(env,s);});
   }
   static client::scheduler::Cursor spammerCursor;
   if(spammer.enabled&&client::scheduler::Consume(client::scheduler::Task::Spammer,spammerCursor))
    Run(env,Kind::Spammer,[&](const Settings& s){Spammer(env,s);});
 }catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[ExtraModules] setup disabled: %s",e.what());DisableInputFeatures();Stop(env);}
}
void AfterInput(JNIEnv* env,jobject input){
 if(!env||env->ExceptionCheck()||!NeedsInput())return;std::lock_guard lock(mutex);if(!playerRoot)return;Frame frame(env);if(!frame.ok)return;
 try{const auto current=Read<int>(env,playerRoot,"Entity.ticksExisted");if(current==tick)return;tick=current;
  const auto screen=Object(env,mcRoot,"Minecraft.currentScreen");const bool chat=screen&&mapping::Instance(screen,"GuiChat"),moveScreen=rules::InventoryMoveAllowed(Options(Kind::InventoryMove).enabled,screen!=nullptr,chat,ui::input::IsOpen()),blockedUi=screen||ui::input::IsOpen(),dead=Read<bool>(env,playerRoot,"Entity.isDead");
  if(moveScreen)Run(env,Kind::InventoryMove,[&](const Settings&){InventoryMove(env,input);});else if(inventoryMoveOwned)RestoreInventoryMove(env,!screen&&!ui::input::IsOpen());
   if(blockedUi||dead){eagleOwned=false;eagleReleaseAt=0;if(eagleKeyOwned)RestoreEagleKey(env);return;}
  Run(env,Kind::NoWeb,[&](const Settings&){const auto web=Object(env,playerRoot,"ExtraEntity.web");const auto value=mapping::StaticObject(env,"JavaBoolean.FALSE");if(!value)throw std::runtime_error("Boolean.FALSE unavailable");Call(env,web,"ExtraWeb.set",{Obj(value)});});
  Run(env,Kind::AutoTool,[&](const Settings& s){AutoTool(env,s);});
  if(client::scheduler::Consume(client::scheduler::Task::FastUse,fastUseCursor))Run(env,Kind::FastUse,[&](const Settings& s){FastUse(env,s);});
  Run(env,Kind::AimAssist,[&](const Settings& s){Aimbot(env,s);});
  if(client::scheduler::Consume(client::scheduler::Task::EagleRelease,eagleCursor))Run(env,Kind::Eagle,[&](const Settings& s){Eagle(env,input,s);});
  Run(env,Kind::NoFall,[&](const Settings& s){if(s.mode==0)Mlg(env,s);});
 }catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[ExtraModules] tick disabled: %s",e.what());DisableInputFeatures();}
}
jobject BeforeSend(JNIEnv* env,jobject packet){
 if(!env||!packet||env->ExceptionCheck())return packet;const auto noFall=Options(Kind::NoFall),fakeLag=Options(Kind::FakeLag),backtrack=Options(Kind::AimBacktrack);if(!noFall.enabled&&!fakeLag.enabled&&!backtrack.enabled)return packet;
 std::lock_guard lock(mutex);Frame frame(env,64);if(!frame.ok)return packet;
 if(backtrack.enabled)try{int attacked=-1;if(AttackPacket(env,packet,&attacked)&&attacked!=backtrackActiveTarget&&attacked!=backtrackPendingTarget)backtrackPendingTarget=attacked;}
 catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();pendingDisabled.fetch_or(1u<<static_cast<int>(Kind::AimBacktrack));AOKI_LOG("[ExtraModules] Backtrack attack failure: %s",e.what());}
 if(noFall.enabled)try{if(noFall.mode==1&&mapping::Instance(packet,"AuraMovementPacket")){const bool current=Read<bool>(env,packet,"AuraMovementPacket.onGround");Write(env,packet,"AuraMovementPacket.onGround",rules::SpoofGround(true,true,current));}}
 catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();pendingDisabled.fetch_or(1u<<static_cast<int>(Kind::NoFall));AOKI_LOG("[ExtraModules] NoFall packet failure: %s",e.what());}
 if(fakeLag.enabled)try{return FakeLagSend(env,packet,fakeLag);}
 catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();pendingDisabled.fetch_or(1u<<static_cast<int>(Kind::FakeLag));AOKI_LOG("[ExtraModules] FakeLag packet failure: %s",e.what());}
 return packet;
}
bool BeforeReceive(JNIEnv* env,jobject packet){
 if(!env||!packet||env->ExceptionCheck())return true;const auto settings=Options(Kind::AimBacktrack);if(!settings.enabled)return true;
 std::lock_guard lock(mutex);Frame frame(env,128);if(!frame.ok||!playerRoot||!worldRoot)return true;
 try{
  if(BacktrackCritical(env,packet)){if(!backtrackPackets.empty())backtrackForceFlush=true;return true;}
  const auto snapshot=ProcessBacktrackPacket(env,packet);
  if(snapshot&&backtrackActiveTarget>=0){const auto player=Position(env,playerRoot);backtrackDelaying=backtrackLastSnapshot&&rules::BacktrackShouldDelay(player,*backtrackLastSnapshot,*snapshot);backtrackLastSnapshot=*snapshot;}
  if(backtrackActiveTarget<0){if(!backtrackPackets.empty()){if(QueueBacktrack(env,packet,settings,true)){backtrackForceFlush=true;return false;}backtrackForceFlush=true;}return true;}
  if(backtrackDelaying)return QueueBacktrack(env,packet,settings)?false:true;
  if(!backtrackPackets.empty()){if(QueueBacktrack(env,packet,settings,true)){backtrackForceFlush=true;return false;}backtrackForceFlush=true;}
 }catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();backtrackForceFlush=true;pendingDisabled.fetch_or(1u<<static_cast<int>(Kind::AimBacktrack));AOKI_LOG("[ExtraModules] Backtrack receive failure: %s",e.what());}
 return true;
}
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet){
 using native_packets::Action;std::lock_guard lock(mutex);
 auto varInt=[&](std::size_t& offset,int& value){std::uint32_t result=0;for(unsigned i=0;i<5;++i){if(offset>=packet.payload.size())return false;const auto byte=packet.payload[offset++];result|=static_cast<std::uint32_t>(byte&0x7f)<<(i*7);if(!(byte&0x80)){value=static_cast<int>(result);return true;}}return false;};
 if(packet.direction==native_packets::Direction::Outbound){
  const auto backtrack=Options(Kind::AimBacktrack);if(backtrack.enabled&&packet.mappingKey=="Play.Serverbound.UseEntity"){std::size_t offset=0;int entity=-1,action=-1;if(varInt(offset,entity)&&varInt(offset,action)&&action==1&&entity!=backtrackActiveTarget&&entity!=backtrackPendingTarget)backtrackPendingTarget=entity;}
  const auto noFall=Options(Kind::NoFall);if(noFall.enabled&&noFall.mode==1&&packet.packetId>=3&&packet.packetId<=6){const std::size_t groundOffset=packet.packetId==3?0:packet.packetId==4?24:packet.packetId==5?8:32;if(packet.payload.size()>groundOffset){packet.payload[groundOffset]=1;return Action::Modify;}}
  const auto fakeLag=Options(Kind::FakeLag);if(fakeLag.enabled){packet.delayMilliseconds=static_cast<std::uint32_t>((std::max)(1.f,fakeLag.mode==1&&fakeLag.history>0?fakeLag.history:fakeLag.delay));return Action::Delay;}
  return Action::Pass;
 }
 const auto backtrack=Options(Kind::AimBacktrack);if(!backtrack.enabled||backtrackPendingTarget<0)return Action::Pass;
 if(packet.packetId==8||packet.packetId==18)return Action::Pass;
 if((packet.packetId>=20&&packet.packetId<=24)||packet.packetId==28){std::size_t offset=0;int entity=-1;if(varInt(offset,entity)&&entity==backtrackPendingTarget){const auto low=(std::min)(backtrack.delay,backtrack.history),high=(std::max)(backtrack.delay,backtrack.history);packet.delayMilliseconds=static_cast<std::uint32_t>((std::max)(1.f,low+static_cast<float>((high-low)*R())));return Action::Delay;}}
 return Action::Pass;
}
}
