#include "features/utility/auto_miner/AutoMiner.hpp"

#include "features/utility/ore/OreScan.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "ui/clickgui/InputBridge.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <numbers>
#include <string>
#include <string_view>

namespace client::features::autominer {
namespace {
using namespace mapping;

// The module poll fires far more often than the game tick, so dig calls are
// gated to the vanilla 50 ms tick.
constexpr std::uint64_t kTickMs = 50;
// Number of consecutive ticks a damage call may fail before the fallback
// destroyBlock path is tried once.
constexpr int kDigFallbackTicks = 10;

struct State {
    std::uint64_t lastTick = 0;
    std::uint64_t lastScan = 0;
    bool hasTarget = false;
    int x = 0, y = 0, z = 0;
    ore::Kind kind = ore::Kind::Diamond;
    int failedDigs = 0;
    int loggedX = 0, loggedY = 0, loggedZ = 0;
    bool hasLogged = false;
};

State state;

struct LocalFrame {
    JNIEnv* env;
    bool valid;
    explicit LocalFrame(JNIEnv* value) : env(value), valid(value->PushLocalFrame(32) == JNI_OK) {}
    ~LocalFrame() { if (valid) env->PopLocalFrame(nullptr); }
};

methods::Argument Int(int value) {
    methods::Argument argument{methods::Type::Int};
    argument.value.i = value;
    return argument;
}

methods::Argument Obj(jobject value) {
    methods::Argument argument{methods::Type::Object};
    argument.value.l = value;
    return argument;
}

void Diagnostic(std::string_view message) {
    static std::string previous;
    static std::uint64_t last = 0;
    const auto now = client::scheduler::Now();
    if (previous == message && now - last < 5000) return;
    previous.assign(message);
    last = now;
    AOKI_LOG("[AutoMiner] %.*s", static_cast<int>(message.size()), message.data());
}

void Reset() {
    state.hasTarget = false;
    state.failedDigs = 0;
    state.hasLogged = false;
}

bool ScreenOpen(JNIEnv* env, jobject minecraft) {
    if (client::ui::input::IsOpen()) return true;
    const auto screen = Object(env, minecraft, "Minecraft.currentScreen");
    if (!screen) return false;
    env->DeleteLocalRef(screen);
    return true;
}

float EyeHeight(JNIEnv* env, jobject player) {
    auto result = Invoke(env, player, "Entity.eyeHeight");
    float height = 1.62f;
    if (result.ok && result.type == methods::Type::Float && std::isfinite(result.value.f))
        height = result.value.f;
    result.Release(env);
    return height;
}

void Look(JNIEnv* env, jobject player, double x, double y, double z) {
    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) return;
    const double eyeX = *px, eyeY = *py + EyeHeight(env, player), eyeZ = *pz;
    const double dx = x - eyeX, dy = y - eyeY, dz = z - eyeZ;
    const double horizontal = std::sqrt(dx * dx + dz * dz);
    if (horizontal < 1e-4) return;
    constexpr double degrees = 180.0 / std::numbers::pi;
    const float yaw = static_cast<float>(std::remainder(std::atan2(dz, dx) * degrees - 90.0, 360.0));
    const float pitch = static_cast<float>(
        std::clamp(-std::atan2(dy, horizontal) * degrees, -90.0, 90.0));
    if (!Write<float>(player, "Entity.rotationYaw", yaw) ||
        !Write<float>(player, "Entity.rotationPitch", pitch)) {
        Diagnostic("cannot write player rotation");
    }
}

bool CallDig(JNIEnv* env, jobject controller, std::string_view key,
             jobject position, jobject face) {
    auto result = Invoke(env, controller, key, {Obj(position), Obj(face)});
    const bool damaged = result.ok && result.type == methods::Type::Boolean && result.value.z;
    if (!result.ok && !result.error.empty())
        Diagnostic(result.error);
    result.Release(env);
    return damaged;
}

bool Dig(JNIEnv* env, jobject controller, int x, int y, int z) {
    const auto position = New(env, "BlockPos.constructor", {Int(x), Int(y), Int(z)});
    const auto face = StaticObject(env, "ExtraFace.up");
    bool damaged = false;
    if (position && face) {
        // damageBlock is PlayerControllerMP.onPlayerDamageBlock: it initiates the
        // dig itself through the vanilla clickBlock path and then accumulates
        // progress. destroyBlock is only a recovery path for a client build where
        // the first method does not advance the damage counter.
        damaged = CallDig(env, controller, "ExtraController.damageBlock", position, face);
        if (!damaged && state.failedDigs >= kDigFallbackTicks) {
            state.failedDigs = 0;
            damaged = CallDig(env, controller, "ExtraController.destroyBlock", position, face);
        }
    } else {
        Diagnostic("BlockPos or ExtraFace.up unresolved");
    }
    if (position) env->DeleteLocalRef(position);
    if (face) env->DeleteLocalRef(face);
    return damaged;
}

void Swing(JNIEnv* env, jobject player) {
    auto result = Invoke(env, player, "EntityLivingBase.swingItem");
    result.Release(env);
}

} // namespace

void Poll(JNIEnv* env) {
    const auto& settings = Options();
    if (!settings.enabled) { Reset(); return; }
    if (!env || env->ExceptionCheck()) return;

    const auto now = client::scheduler::Now();
    if (state.lastTick && now - state.lastTick < kTickMs) return;
    state.lastTick = now;

    LocalFrame frame(env);
    if (!frame.valid) return;

    const auto minecraft = StaticObject(env, "Minecraft.theMinecraft");
    if (!minecraft || ScreenOpen(env, minecraft)) { Reset(); return; }
    const auto world = Object(env, minecraft, "Minecraft.theWorld");
    const auto player = Object(env, minecraft, "Minecraft.thePlayer");
    const auto controller = Object(env, minecraft, "Minecraft.playerController");
    if (!world || !player || !controller) { Reset(); return; }
    if (Read<bool>(player, "Entity.isDead").value_or(false)) { Reset(); return; }

    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) { Reset(); return; }

    const auto interval = static_cast<std::uint64_t>(
        std::clamp(settings.scanIntervalMs, 50.f, 2000.f));
    if (!state.hasTarget || now - state.lastScan >= interval) {
        // Reach is measured from the eye, which is what the server checks. The
        // scanner is sphere based, so the returned list is already ordered by
        // distance from that point and the first entry is the closest ore.
        const double eyeY = *py + EyeHeight(env, player);
        const auto result = ore::Scan(env, world, *px, eyeY, *pz, settings.range,
                                      settings.ores, 64);
        state.lastScan = now;
        state.hasTarget = !result.blocks.empty();
        if (state.hasTarget) {
            const auto& best = result.blocks.front();
            state.x = best.x;
            state.y = best.y;
            state.z = best.z;
            state.kind = best.kind;
        } else if (result.status == ore::ScanStatus::UnsupportedProvider) {
            Diagnostic("ore scan unavailable for this chunk provider");
        }
    }
    if (!state.hasTarget) return;

    if (settings.rotate)
        Look(env, player, state.x + 0.5, state.y + 0.5, state.z + 0.5);

    const bool damaged = Dig(env, controller, state.x, state.y, state.z);
    if (damaged) {
        state.failedDigs = 0;
        if (settings.swing) Swing(env, player);
    } else {
        ++state.failedDigs;
    }
    if (damaged && (!state.hasLogged || state.loggedX != state.x ||
                    state.loggedY != state.y || state.loggedZ != state.z)) {
        state.hasLogged = true;
        state.loggedX = state.x;
        state.loggedY = state.y;
        state.loggedZ = state.z;
        AOKI_LOG("[AutoMiner] target=%s pos=%d %d %d", ore::Name(state.kind), state.x, state.y, state.z);
    }
}

} // namespace client::features::autominer
