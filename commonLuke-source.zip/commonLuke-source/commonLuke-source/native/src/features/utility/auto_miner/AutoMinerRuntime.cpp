#include "features/utility/auto_miner/AutoMiner.hpp"

#include "features/utility/nav/PathFinder.hpp"
#include "features/utility/ore/OreScan.hpp"
#include "features/utility/world/BlockGrid.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "ui/clickgui/InputBridge.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <numbers>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace client::features::autominer {
namespace {
using namespace mapping;

// The module poll fires far more often than the game tick, so all work is
// gated to the vanilla 50 ms tick.
constexpr std::uint64_t kTickMs = 50;
// Number of consecutive ticks a damage call may fail before the fallback
// destroyBlock path is tried once.
constexpr int kDigFallbackTicks = 10;
// A vein that keeps refusing damage for this many ticks is abandoned.
constexpr int kDigGiveUpTicks = 40;
// Re-plan interval. Moving the player changes the world, so the plan is only
// trusted for a short window.
constexpr std::uint64_t kPlanIntervalMs = 2000;
// How long an unreachable vein is ignored.
constexpr std::uint64_t kSkipMs = 6000;
// Walking to a target may take a while in a maze of tunnels.
constexpr std::uint64_t kWalkTimeoutMs = 45000;
// A vein that accepts damage but never breaks is abandoned after this.
constexpr std::uint64_t kDigTimeoutMs = 20000;

struct SkipEntry {
    int x = 0, y = 0, z = 0;
    std::uint64_t until = 0;
};

struct State {
    std::uint64_t lastTick = 0;
    std::uint64_t lastScan = 0;
    jobject world = nullptr;
    std::vector<ore::Block> targets;
    std::size_t targetIndex = 0;
    bool hasTarget = false;
    int x = 0, y = 0, z = 0;
    int oreId = 0;
    ore::Kind kind = ore::Kind::Diamond;
    bool toolChosen = false;
    std::vector<nav::Node> path;
    std::size_t pathIndex = 0;
    std::uint64_t planned = 0;
    int failedDigs = 0;
    int misses = 0;
    std::uint64_t targetSince = 0;
    std::vector<SkipEntry> skipped;
    bool hasLogged = false;
    int loggedX = 0, loggedY = 0, loggedZ = 0;
};

State state;

struct LocalFrame {
    JNIEnv* env;
    bool valid;
    explicit LocalFrame(JNIEnv* value) : env(value), valid(value->PushLocalFrame(32) == JNI_OK) {}
    ~LocalFrame() { if (valid) env->PopLocalFrame(nullptr); }
};

methods::Argument Double(double value) {
    methods::Argument argument{methods::Type::Double};
    argument.value.d = value;
    return argument;
}

methods::Argument Int(int value) {
    methods::Argument argument{methods::Type::Int};
    argument.value.i = value;
    return argument;
}

methods::Argument Obj(jobject value) {
    methods::Argument argument{methods::Type::Object};
    argument.value.l = value;
    return argument;
}

methods::Argument Bool(bool value) {
    methods::Argument argument{methods::Type::Boolean};
    argument.value.z = value;
    return argument;
}

void Diagnostic(std::string_view message) {
    static std::string previous;
    static std::uint64_t last = 0;
    const auto now = client::scheduler::Now();
    if (previous == message && now - last < 5000) return;
    previous.assign(message);
    last = now;
    AOKI_LOG("[AutoMiner] %.*s", static_cast<int>(message.size()), message.data());
}

void ClearTarget() {
    state.hasTarget = false;
    state.oreId = 0;
    state.toolChosen = false;
    state.path.clear();
    state.pathIndex = 0;
    state.planned = 0;
    state.failedDigs = 0;
    state.misses = 0;
    state.targetSince = 0;
    state.hasLogged = false;
}

void Reset(JNIEnv* env) {
    if (state.world) {
        // Releasing a global reference needs a JNIEnv. Without one, keep the
        // reference for the next call instead of leaking it.
        if (!env) return;
        ReleaseGlobal(env, state.world);
    }
    state.world = nullptr;
    state.targets.clear();
    state.targetIndex = 0;
    state.skipped.clear();
    ClearTarget();
}

bool IsSkipped(const ore::Block& block) {
    const auto now = client::scheduler::Now();
    for (const auto& entry : state.skipped) {
        if (entry.x == block.x && entry.y == block.y && entry.z == block.z)
            return entry.until > now;
    }
    return false;
}

void SkipTarget() {
    const auto now = client::scheduler::Now();
    for (auto& entry : state.skipped) {
        if (entry.x == state.x && entry.y == state.y && entry.z == state.z) {
            entry.until = now + kSkipMs;
            ClearTarget();
            return;
        }
    }
    state.skipped.push_back({state.x, state.y, state.z, now + kSkipMs});
    if (state.skipped.size() > 32) state.skipped.erase(state.skipped.begin());
    ClearTarget();
}

bool ScreenOpen(JNIEnv* env, jobject minecraft) {
    if (client::ui::input::IsOpen()) return true;
    const auto screen = Object(env, minecraft, "Minecraft.currentScreen");
    if (!screen) return false;
    env->DeleteLocalRef(screen);
    return true;
}

float EyeHeight(JNIEnv* env, jobject player) {
    auto result = Invoke(env, player, "Entity.eyeHeight");
    float height = 1.62f;
    if (result.ok && result.type == methods::Type::Float && std::isfinite(result.value.f))
        height = result.value.f;
    result.Release(env);
    return height;
}

void Look(JNIEnv* env, jobject player, double x, double y, double z) {
    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) return;
    const double eyeX = *px, eyeY = *py + EyeHeight(env, player), eyeZ = *pz;
    const double dx = x - eyeX, dy = y - eyeY, dz = z - eyeZ;
    const double horizontal = std::sqrt(dx * dx + dz * dz);
    if (horizontal < 1e-4) return;
    constexpr double degrees = 180.0 / std::numbers::pi;
    const float yaw = static_cast<float>(std::remainder(std::atan2(dz, dx) * degrees - 90.0, 360.0));
    const float pitch = static_cast<float>(
        std::clamp(-std::atan2(dy, horizontal) * degrees, -90.0, 90.0));
    if (!Write<float>(player, "Entity.rotationYaw", yaw) ||
        !Write<float>(player, "Entity.rotationPitch", pitch)) {
        Diagnostic("cannot write player rotation");
    }
}

// Same teleport-style step the Clips feature proved out: move the authoritative
// position, zero the velocity so gravity does not fight the next step, and mark
// the entity as grounded so no fall state builds up.
bool Move(JNIEnv* env, jobject player, double dx, double dy, double dz) {
    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) return false;

    auto position = Invoke(env, player, "Entity.setPosition", {
        Double(*px + dx), Double(*py + dy), Double(*pz + dz)});
    const bool positioned = position.ok;
    position.Release(env);
    if (!positioned || env->ExceptionCheck()) return false;

    auto velocity = Invoke(env, player, "Entity.setVelocity", {
        Double(0), Double(0), Double(0)});
    const bool stopped = velocity.ok;
    velocity.Release(env);
    if (!stopped || env->ExceptionCheck()) return false;

    // onGround is a setter on this client (setOnGround(Z)V), not a field.
    auto grounded = Invoke(env, player, "Entity.setOnGround", {Bool(true)});
    grounded.Release(env);
    // Clear the fall counter so the jump does not trigger fall damage later.
    Write<float>(player, "Entity.fallDistance", 0.f);
    return true;
}

bool CallDig(JNIEnv* env, jobject controller, std::string_view key,
             jobject position, jobject face) {
    auto result = Invoke(env, controller, key, {Obj(position), Obj(face)});
    const bool damaged = result.ok && result.type == methods::Type::Boolean && result.value.z;
    if (!result.ok && !result.error.empty())
        Diagnostic(result.error);
    result.Release(env);
    return damaged;
}

// Puts the strongest hotbar item for the ore block into the hand. Vanilla
// strength returns 1 for "no tool helps", so anything above that wins. Failure
// is silent: the miner still digs by hand, only slower.
bool EquipBestTool(JNIEnv* env, jobject player, jobject controller, int oreId) {
    if (!env || !player || !controller || oreId <= 0) return false;

    auto block = Invoke(env, nullptr, "ExtraBlock.byId", {Int(oreId)});
    const jobject blockObject = block.ok && block.type == methods::Type::Object ? block.value.l : nullptr;
    if (!blockObject) {
        block.Release(env);
        return false;
    }

    const auto inventory = Object(env, player, "EntityPlayer.inventory");
    const auto stacks = inventory
        ? static_cast<jobjectArray>(Object(env, inventory, "InventoryPlayer.mainInventory"))
        : nullptr;
    if (!inventory || !stacks) {
        if (stacks) env->DeleteLocalRef(stacks);
        if (inventory) env->DeleteLocalRef(inventory);
        block.Release(env);
        return false;
    }

    // Only the hotbar can be held. The current slot is part of mainInventory.
    const int hotbar = std::min<int>(9, env->GetArrayLength(stacks));
    float best = 1.f;
    int bestSlot = -1;
    for (int slot = 0; slot < hotbar; ++slot) {
        const auto stack = env->GetObjectArrayElement(stacks, slot);
        if (!stack) continue;
        auto strength = Invoke(env, stack, "ExtraStack.strength", {Obj(blockObject)});
        const bool measured = strength.ok && strength.type == methods::Type::Float;
        const float value = measured ? strength.value.f : 0.f;
        strength.Release(env);
        env->DeleteLocalRef(stack);
        if (measured && value > best) {
            best = value;
            bestSlot = slot;
        }
    }

    const auto current = Read<int>(env, inventory, "InventoryPlayer.currentItem");
    if (bestSlot >= 0 && current.value_or(-1) != bestSlot) {
        Write(env, inventory, "InventoryPlayer.currentItem", bestSlot);
        auto synced = Invoke(env, controller, "PlayerControllerMP.syncCurrentItem");
        synced.Release(env);
        AOKI_LOG("[AutoMiner] tool slot=%d strength=%.2f ore=%d", bestSlot, best, oreId);
    }

    env->DeleteLocalRef(stacks);
    env->DeleteLocalRef(inventory);
    block.Release(env);
    return bestSlot >= 0;
}

bool Dig(JNIEnv* env, jobject controller, int x, int y, int z) {
    const auto position = New(env, "BlockPos.constructor", {Int(x), Int(y), Int(z)});
    // ScaffoldFace.up is the mapped UP constant of the same EnumFacing class
    // (net/minecraft/ZE) that ExtraController.damageBlock expects.
    const auto face = StaticObject(env, "ScaffoldFace.up");
    bool damaged = false;
    if (position && face) {
        // damageBlock is PlayerControllerMP.onPlayerDamageBlock: it initiates the
        // dig itself through the vanilla clickBlock path and then accumulates
        // progress. destroyBlock is only a recovery path for a client build where
        // the first method does not advance the damage counter.
        damaged = CallDig(env, controller, "ExtraController.damageBlock", position, face);
        if (!damaged && state.failedDigs >= kDigFallbackTicks) {
            state.failedDigs = 0;
            damaged = CallDig(env, controller, "ExtraController.destroyBlock", position, face);
        }
    } else {
        Diagnostic("BlockPos or ScaffoldFace.up unresolved");
    }
    if (position) env->DeleteLocalRef(position);
    if (face) env->DeleteLocalRef(face);
    return damaged;
}

void Swing(JNIEnv* env, jobject player) {
    auto result = Invoke(env, player, "EntityLivingBase.swingItem");
    result.Release(env);
}

// Builds the voxel snapshot around the player and plans a path to a standable
// cell touching the current vein. Returns true once the path is ready.
bool Plan(JNIEnv* env, jobject world, double px, double py, double pz,
          const Settings& settings) {
    const int horizontal = static_cast<int>(std::ceil(
        std::clamp(settings.searchRadius, std::max(settings.range, 4.f), 24.f)));
    const int playerY = static_cast<int>(std::floor(py));
    int verticalDelta = state.y - playerY;
    if (verticalDelta < 0) verticalDelta = -verticalDelta;
    const int vertical = std::clamp(verticalDelta + 4, 4, 24);

    blocks::Grid grid;
    const auto status = blocks::Build(env, world,
        static_cast<int>(std::floor(px)), static_cast<int>(std::floor(py)),
        static_cast<int>(std::floor(pz)), horizontal, vertical, grid);
    if (status == blocks::BuildStatus::UnsupportedProvider) {
        Diagnostic("navigation needs the SeedChunkProvider chunk source");
        return false;
    }
    if (status != blocks::BuildStatus::Ok) {
        Diagnostic("cannot read the loaded chunks for navigation");
        return false;
    }

    const auto start = nav::Snap(grid, static_cast<int>(std::floor(px)),
        static_cast<int>(std::floor(py)), static_cast<int>(std::floor(pz)));
    auto path = nav::Find(grid, start, {state.x, state.y, state.z}, nav::Goal::Adjacent);
    if (!path.found && path.steps.empty()) {
        Diagnostic("no walkable route to the selected vein");
        state.planned = client::scheduler::Now();
        return false;
    }
    if (!path.found) {
        // Partial route: keep walking toward the closest reachable cell.
        Diagnostic("vein not fully reachable; following the closest approach");
    }
    state.path = std::move(path.steps);
    state.pathIndex = 0;
    return true;
}

// One movement step toward the next path node. Returns true when the player was
// moved this tick.
bool Step(JNIEnv* env, jobject player, const Settings& settings,
          double px, double py, double pz) {
    const double speed = std::clamp(settings.moveSpeed, 0.04f, 0.5f);
    for (int guard = 0; guard < 4 && state.pathIndex < state.path.size(); ++guard) {
        const auto& node = state.path[state.pathIndex];
        const double tx = node.x + 0.5, ty = static_cast<double>(node.y), tz = node.z + 0.5;
        const double dx = tx - px, dy = ty - py, dz = tz - pz;
        const double horizontal = std::sqrt(dx * dx + dz * dz);
        if (horizontal < 0.35 && std::abs(dy) < 0.25) {
            ++state.pathIndex;
            continue;
        }
        double stepX = 0.0, stepZ = 0.0;
        // Vertical correction is finished before horizontal movement. Walking
        // and rising in the same tick makes the player slide through the side of
        // a step-up block, and dropping sideways makes the server rubber-band.
        const double stepY = std::clamp(dy, -0.3, 0.3);
        if (std::abs(dy) < 0.26 && horizontal > 1e-4) {
            const double factor = std::min(speed, horizontal) / horizontal;
            stepX = dx * factor;
            stepZ = dz * factor;
        }
        if (!Move(env, player, stepX, stepY, stepZ)) {
            Diagnostic("move rejected by the client");
            return false;
        }
        if (settings.rotate) Look(env, player, tx, ty + 1.0, tz);
        return true;
    }
    return false;
}

} // namespace

void Poll(JNIEnv* env) {
    const auto& settings = Options();
    if (!settings.enabled) { Reset(env); return; }
    if (!env || env->ExceptionCheck()) return;

    const auto now = client::scheduler::Now();
    if (state.lastTick && now - state.lastTick < kTickMs) return;
    state.lastTick = now;

    LocalFrame frame(env);
    if (!frame.valid) return;

    const auto minecraft = StaticObject(env, "Minecraft.theMinecraft");
    if (!minecraft || ScreenOpen(env, minecraft)) { ClearTarget(); return; }
    const auto world = Object(env, minecraft, "Minecraft.theWorld");
    const auto player = Object(env, minecraft, "Minecraft.thePlayer");
    const auto controller = Object(env, minecraft, "Minecraft.playerController");
    if (!world || !player || !controller) { ClearTarget(); return; }
    if (Read<bool>(player, "Entity.isDead").value_or(false)) { ClearTarget(); return; }

    if (!state.world || !env->IsSameObject(state.world, world)) {
        if (state.world) ReleaseGlobal(env, state.world);
        state.world = Global(env, world);
        if (!state.world) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            return;
        }
        state.targets.clear();
        state.targetIndex = 0;
        state.skipped.clear();
        ClearTarget();
    }

    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) { ClearTarget(); return; }
    const double eyeY = *py + EyeHeight(env, player);

    // Discovery. With navigation on the search sphere is wider than reach, so a
    // vein a few blocks away is enough to start walking. Refreshing is slower
    // while a target is held to keep the chunk walk off the hot path, and an
    // empty result waits at least 300 ms instead of rebuilding the chunk grid
    // on every tick.
    const auto interval = static_cast<std::uint64_t>(
        std::clamp(settings.scanIntervalMs, 50.f, 2000.f));
    const std::uint64_t refresh = state.hasTarget ? 500 : std::max<std::uint64_t>(interval, 300);
    if (now - state.lastScan >= refresh) {
        const double radius = settings.nav
            ? std::clamp<double>(settings.searchRadius, settings.range, 24.0)
            : settings.range;
        const auto result = ore::Scan(env, world, *px, eyeY, *pz, radius,
                                      settings.ores, settings.filter, 64);
        state.lastScan = now;
        state.targets = result.blocks;
        state.targetIndex = 0;
        if (result.status == ore::ScanStatus::UnsupportedProvider)
            Diagnostic("ore scan unavailable for this chunk provider");
        // A mined vein disappears from the fresh scan; drop it so the miner
        // moves on to the next one instead of wasting a give-up window.
        if (state.hasTarget &&
            std::none_of(state.targets.begin(), state.targets.end(),
                [&](const ore::Block& block) {
                    return block.x == state.x && block.y == state.y && block.z == state.z;
                })) {
            ClearTarget();
        }
    }

    if (!state.hasTarget) {
        while (state.targetIndex < state.targets.size()) {
            const auto& candidate = state.targets[state.targetIndex];
            if (IsSkipped(candidate)) { ++state.targetIndex; continue; }
            state.hasTarget = true;
            state.x = candidate.x;
            state.y = candidate.y;
            state.z = candidate.z;
            state.kind = candidate.kind;
            state.oreId = candidate.id;
            state.toolChosen = false;
            state.path.clear();
            state.pathIndex = 0;
            state.planned = 0;
            state.failedDigs = 0;
            state.misses = 0;
            state.targetSince = now;
            break;
        }
    }
    if (!state.hasTarget) return;

    const double targetX = state.x + 0.5, targetY = state.y + 0.5, targetZ = state.z + 0.5;
    const double dx = targetX - *px, dy = targetY - eyeY, dz = targetZ - *pz;
    const double distanceSquared = dx * dx + dy * dy + dz * dz;
    const double reach = settings.range;
    const bool inReach = distanceSquared <= reach * reach;

    if (!inReach && settings.nav) {
        if (state.targetSince && now - state.targetSince > kWalkTimeoutMs) {
            Diagnostic("walk to the vein timed out; skipping it");
            state.targets.clear();
            SkipTarget();
            return;
        }
        if (state.pathIndex >= state.path.size()) {
            state.path.clear();
            state.pathIndex = 0;
        }
        if (state.path.empty()) {
            if (state.planned && now - state.planned < kPlanIntervalMs) return;
            state.planned = now;
            if (!Plan(env, world, *px, *py, *pz, settings) || state.path.empty()) {
                SkipTarget();
                return;
            }
        }
        Step(env, player, settings, *px, *py, *pz);
        return;
    }
    if (!inReach) return;
    if (state.targetSince && now - state.targetSince > kDigTimeoutMs) {
        Diagnostic("vein did not break; skipping it");
        state.targets.clear();
        SkipTarget();
        return;
    }

    if (settings.rotate) Look(env, player, targetX, targetY, targetZ);

    // One attempt per vein: a failed mapping lookup must not turn into a
    // strength call storm on every tick.
    if (!state.toolChosen) {
        state.toolChosen = true;
        if (!EquipBestTool(env, player, controller, state.oreId))
            Diagnostic("no usable tool; digging by hand");
    }

    const bool damaged = Dig(env, controller, state.x, state.y, state.z);
    if (damaged) {
        state.failedDigs = 0;
        state.misses = 0;
        if (settings.swing) Swing(env, player);
    } else {
        ++state.failedDigs;
        if (++state.misses >= kDigGiveUpTicks) {
            Diagnostic("nearest vein is not responding; skipping it");
            state.targets.clear();
            SkipTarget();
            return;
        }
    }
    if (damaged && (!state.hasLogged || state.loggedX != state.x ||
                    state.loggedY != state.y || state.loggedZ != state.z)) {
        state.hasLogged = true;
        state.loggedX = state.x;
        state.loggedY = state.y;
        state.loggedZ = state.z;
        AOKI_LOG("[AutoMiner] target=%s pos=%d %d %d", ore::Name(state.kind), state.x, state.y, state.z);
    }
}

} // namespace client::features::autominer
