#include "features/utility/auto_miner/AutoMiner.hpp"

namespace client::features::autominer {
namespace {
Settings options;
std::uint64_t optionsRevision = 1;
}

const Settings& Options() { return options; }

void SetOptions(const Settings& settings) {
    options = settings;
    ++optionsRevision;
}

std::uint64_t OptionsRevision() { return optionsRevision; }

} // namespace client::features::autominer
