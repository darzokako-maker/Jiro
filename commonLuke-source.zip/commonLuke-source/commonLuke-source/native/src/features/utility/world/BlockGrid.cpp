#include "features/utility/world/BlockGrid.hpp"

#include "game/MappingRepository.hpp"

#include <algorithm>
#include <cmath>
#include <optional>
#include <utility>
#include <vector>

namespace client::features::blocks {
namespace {

struct LocalFrame {
    JNIEnv* env;
    bool ok;
    explicit LocalFrame(JNIEnv* value) : env(value), ok(value->PushLocalFrame(96) == JNI_OK) {}
    ~LocalFrame() { if (ok) env->PopLocalFrame(nullptr); }
};

// Floor division that is correct for negative world coordinates.
int FloorDiv(int value, int divisor) noexcept {
    int quotient = value / divisor;
    if (value % divisor != 0 && ((value < 0) != (divisor < 0))) --quotient;
    return quotient;
}

} // namespace

BuildStatus Build(JNIEnv* env, jobject world, int centerX, int centerY, int centerZ,
                  int horizontalRadius, int verticalRadius, Grid& out) {
    out = Grid{};
    if (!env || !world) return BuildStatus::NoWorld;
    if (horizontalRadius <= 0 || verticalRadius <= 0) return BuildStatus::Failed;

    const auto provider = mapping::Object(env, world, "World.chunkProvider");
    if (!provider) return BuildStatus::Failed;
    if (!mapping::Instance(provider, "SeedChunkProvider")) return BuildStatus::UnsupportedProvider;
    const auto list = mapping::Object(env, provider, "SeedChunkProvider.chunks");
    if (!list || !mapping::Instance(list, "ArrayList")) return BuildStatus::Failed;
    const auto size = mapping::Read<int>(list, "ArrayList.size");
    const auto elements = static_cast<jobjectArray>(mapping::Object(env, list, "ArrayList.elements"));
    if (!size || !elements || *size <= 0) return BuildStatus::NoChunks;
    const int count = std::min(*size, env->GetArrayLength(elements));
    if (count <= 0) return BuildStatus::NoChunks;

    Grid grid;
    const int rx = std::clamp(horizontalRadius, 2, 40);
    const int ry = std::clamp(verticalRadius, 2, 24);
    grid.ox = centerX - rx;
    grid.oz = centerZ - rx;
    grid.oy = std::max(0, centerY - ry);
    const int top = std::min(255, centerY + ry);
    grid.sx = rx * 2 + 1;
    grid.sz = rx * 2 + 1;
    grid.sy = top - grid.oy + 1;
    if (grid.sy <= 0) return BuildStatus::Failed;

    const std::size_t cells =
        static_cast<std::size_t>(grid.sx) * static_cast<std::size_t>(grid.sy) * static_cast<std::size_t>(grid.sz);
    grid.ids.assign(cells, 0);
    grid.known.assign(cells, 0);

    LocalFrame frame(env);
    if (!frame.ok) return BuildStatus::Failed;

    const int minChunkX = FloorDiv(grid.ox, 16);
    const int maxChunkX = FloorDiv(grid.ox + grid.sx - 1, 16);
    const int minChunkZ = FloorDiv(grid.oz, 16);
    const int maxChunkZ = FloorDiv(grid.oz + grid.sz - 1, 16);

    std::vector<jchar> states(4096);

    for (int index = 0; index < count; ++index) {
        const auto chunk = env->GetObjectArrayElement(elements, static_cast<jsize>(index));
        if (!chunk) continue;
        const bool isChunk = mapping::Instance(chunk, "Chunk");
        const auto chunkX = isChunk ? mapping::Read<int>(chunk, "Chunk.xPosition") : std::nullopt;
        const auto chunkZ = isChunk ? mapping::Read<int>(chunk, "Chunk.zPosition") : std::nullopt;
        if (!chunkX || !chunkZ ||
            *chunkX < minChunkX || *chunkX > maxChunkX ||
            *chunkZ < minChunkZ || *chunkZ > maxChunkZ) {
            env->DeleteLocalRef(chunk);
            continue;
        }

        const int worldX0 = *chunkX * 16;
        const int worldZ0 = *chunkZ * 16;
        const int x0 = std::max(0, grid.ox - worldX0);
        const int x1 = std::min(15, grid.ox + grid.sx - 1 - worldX0);
        const int z0 = std::max(0, grid.oz - worldZ0);
        const int z1 = std::min(15, grid.oz + grid.sz - 1 - worldZ0);

        if (x1 >= x0 && z1 >= z0) {
            const auto sections = static_cast<jobjectArray>(mapping::Object(env, chunk, "Chunk.storageArrays"));
            if (sections) {
                const int sectionCount = std::min(16, env->GetArrayLength(sections));
                for (int sectionIndex = 0; sectionIndex < sectionCount; ++sectionIndex) {
                    const auto section =
                        env->GetObjectArrayElement(sections, static_cast<jsize>(sectionIndex));
                    if (!section) continue;
                    const auto base = mapping::Read<int>(section, "ExtendedBlockStorage.yBase");
                    const auto data = static_cast<jcharArray>(
                        mapping::Object(env, section, "ExtendedBlockStorage.data"));
                    const bool usable = base && data && env->GetArrayLength(data) == 4096;
                    if (usable) {
                        const int y0 = std::max(0, grid.oy - *base);
                        const int y1 = std::min(15, grid.oy + grid.sy - 1 - *base);
                        if (y1 >= y0) {
                            env->GetCharArrayRegion(data, 0, 4096, states.data());
                            if (env->ExceptionCheck()) {
                                env->ExceptionClear();
                            } else {
                                for (int ly = y0; ly <= y1; ++ly) {
                                    const int worldY = *base + ly;
                                    for (int lz = z0; lz <= z1; ++lz) {
                                        const int worldZ = worldZ0 + lz;
                                        const int row = ly * 256 + lz * 16;
                                        for (int lx = x0; lx <= x1; ++lx) {
                                            // Index() expects world coordinates and
                                            // subtracts the grid origin itself.
                                            const auto cell = grid.Index(worldX0 + lx, worldY, worldZ);
                                            grid.ids[cell] = static_cast<std::uint16_t>(
                                                static_cast<unsigned short>(states[static_cast<std::size_t>(row + lx)]) >> 4);
                                            grid.known[cell] = 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (data) env->DeleteLocalRef(data);
                    env->DeleteLocalRef(section);
                }
                env->DeleteLocalRef(sections);
            }
        }
        env->DeleteLocalRef(chunk);
    }

    out = std::move(grid);
    return BuildStatus::Ok;
}

} // namespace client::features::blocks
