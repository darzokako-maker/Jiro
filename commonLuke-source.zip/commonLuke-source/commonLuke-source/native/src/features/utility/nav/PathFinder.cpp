#include "features/utility/nav/PathFinder.hpp"

#include "features/utility/world/Blocks.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <limits>
#include <queue>
#include <utility>

namespace client::features::nav {
namespace {

bool Passable(const blocks::Grid& grid, int x, int y, int z) {
    return blocks::Passable(grid.Id(x, y, z));
}

struct Entry {
    float f = 0.f;
    std::size_t index = 0;
};

struct Worse {
    bool operator()(const Entry& left, const Entry& right) const {
        return left.f > right.f;
    }
};

} // namespace

bool Standable(const blocks::Grid& grid, int x, int y, int z) {
    if (!grid.Contains(x, y, z)) return false;
    if (!grid.Contains(x, y + 1, z)) return false;
    if (!Passable(grid, x, y, z) || !Passable(grid, x, y + 1, z)) return false;
    const auto ground = grid.Id(x, y - 1, z);
    if (blocks::Passable(ground) || blocks::Hazard(ground) || blocks::Liquid(ground)) return false;
    return true;
}

Node Snap(const blocks::Grid& grid, int x, int y, int z) {
    if (Standable(grid, x, y, z)) return {x, y, z};
    Node best{x, y, z};
    int bestScore = std::numeric_limits<int>::max();
    for (int dy = 2; dy >= -2; --dy) {
        for (int dx = -2; dx <= 2; ++dx) {
            for (int dz = -2; dz <= 2; ++dz) {
                if (!Standable(grid, x + dx, y + dy, z + dz)) continue;
                const int score = std::abs(dx) + std::abs(dz) + std::abs(dy) * 3;
                if (score < bestScore) {
                    bestScore = score;
                    best = {x + dx, y + dy, z + dz};
                }
            }
        }
    }
    return best;
}

Path Find(const blocks::Grid& grid, Node start, Node target, Goal goal,
          const Options& options) {
    Path path;
    if (grid.Empty()) return path;
    if (!grid.Contains(start.x, start.y, start.z) ||
        !grid.Contains(target.x, target.y, target.z)) {
        return path;
    }

    const int maxNodes = std::clamp(options.maxNodes, 128, 200000);
    const int maxFall = std::clamp(options.maxFall, 0, 6);
    const int maxJump = std::clamp(options.maxJump, 0, 2);
    const bool adjacent = goal == Goal::Adjacent;
    const int slack = adjacent ? 1 : 0;

    const auto heuristic = [&](int x, int y, int z) {
        const int dx = std::max(0, std::abs(x - target.x) - slack);
        const int dz = std::max(0, std::abs(z - target.z) - slack);
        const int dy = std::max(0, std::abs(y - target.y) - slack);
        return static_cast<float>(dx + dz) + 1.6f * static_cast<float>(dy);
    };
    const auto isGoal = [&](int x, int y, int z) {
        if (!adjacent) return x == target.x && y == target.y && z == target.z;
        if (std::abs(x - target.x) > 1 || std::abs(z - target.z) > 1) return false;
        if (std::abs(y - target.y) > 1) return false;
        return std::abs(x - target.x) + std::abs(y - target.y) + std::abs(z - target.z) > 0;
    };

    const std::size_t cells = grid.ids.size();
    const std::size_t startIndex = grid.Index(start.x, start.y, start.z);
    if (startIndex >= cells) return path;

    std::vector<float> scores(cells, std::numeric_limits<float>::infinity());
    std::vector<int> cameFrom(cells, -1);
    std::vector<std::uint8_t> closed(cells, 0);

    std::priority_queue<Entry, std::vector<Entry>, Worse> open;
    scores[startIndex] = 0.f;
    open.push({heuristic(start.x, start.y, start.z), startIndex});

    static constexpr int kDirections[4][2] = {
        {1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    int expanded = 0;
    int bestIndex = static_cast<int>(startIndex);
    float bestHeuristic = heuristic(start.x, start.y, start.z);
    bool reached = false;

    while (!open.empty() && expanded < maxNodes) {
        const Entry current = open.top();
        open.pop();
        const std::size_t index = current.index;
        if (index >= cells || closed[index]) continue;
        closed[index] = 1;
        ++expanded;

        const int gx = static_cast<int>(index % static_cast<std::size_t>(grid.sx));
        const std::size_t row = index / static_cast<std::size_t>(grid.sx);
        const int gz = static_cast<int>(row % static_cast<std::size_t>(grid.sz));
        const int gy = static_cast<int>(row / static_cast<std::size_t>(grid.sz));
        const int x = grid.ox + gx, y = grid.oy + gy, z = grid.oz + gz;

        if (isGoal(x, y, z)) {
            reached = true;
            bestIndex = static_cast<int>(index);
            break;
        }
        const float h = heuristic(x, y, z);
        if (h < bestHeuristic) {
            bestHeuristic = h;
            bestIndex = static_cast<int>(index);
        }

        const float base = scores[index];
        const auto relax = [&](int nx, int ny, int nz, float cost) {
            if (!grid.Contains(nx, ny, nz)) return;
            const std::size_t next = grid.Index(nx, ny, nz);
            if (next >= cells || closed[next]) return;
            const float tentative = base + cost;
            if (tentative >= scores[next] - 1e-4f) return;
            scores[next] = tentative;
            cameFrom[next] = static_cast<int>(index);
            open.push({tentative + heuristic(nx, ny, nz), next});
        };

        for (const auto& direction : kDirections) {
            const int nx = x + direction[0];
            const int nz = z + direction[1];
            if (!grid.Contains(nx, y, nz)) continue;

            // The feet cell is blocked: try to step on top of it.
            if (!Passable(grid, nx, y, nz)) {
                if (maxJump >= 1 && Standable(grid, nx, y + 1, nz))
                    relax(nx, y + 1, nz, 1.8f);
                continue;
            }
            // Same level walk.
            if (Standable(grid, nx, y, nz)) {
                relax(nx, y, nz, 1.0f);
                continue;
            }
            // Walk off a ledge and drop onto the first solid floor below.
            for (int fall = 1; fall <= maxFall; ++fall) {
                if (!Passable(grid, nx, y - fall, nz)) break;
                if (Standable(grid, nx, y - fall, nz)) {
                    relax(nx, y - fall, nz, 1.0f + 0.4f * static_cast<float>(fall));
                    break;
                }
            }
        }
    }

    path.expanded = expanded;
    if (bestIndex < 0) return path;

    std::vector<Node> reverse;
    int cursor = bestIndex;
    constexpr std::size_t kPathCap = 4096;
    while (cursor >= 0 && static_cast<std::size_t>(cursor) != startIndex &&
           reverse.size() < kPathCap) {
        const std::size_t index = static_cast<std::size_t>(cursor);
        const int gx = static_cast<int>(index % static_cast<std::size_t>(grid.sx));
        const std::size_t row = index / static_cast<std::size_t>(grid.sx);
        const int gz = static_cast<int>(row % static_cast<std::size_t>(grid.sz));
        const int gy = static_cast<int>(row / static_cast<std::size_t>(grid.sz));
        reverse.push_back({grid.ox + gx, grid.oy + gy, grid.oz + gz});
        cursor = cameFrom[index];
    }
    path.found = reached;
    path.steps.assign(reverse.rbegin(), reverse.rend());
    return path;
}

} // namespace client::features::nav
