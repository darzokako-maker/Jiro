#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "features/utility/seed_dumper/SeedDump.hpp"
#include "game/MappingRepository.hpp"
#include "ui/hud/Notifications.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include <Windows.h>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <future>
#include <map>
#include <memory>

namespace client::features::seeddumper {
namespace {
struct Result {std::uint64_t session=0,hash=0;std::pair<int,int> chunk;std::string error;};
struct Runtime {
 jobject world=nullptr;bool active=false,failed=false;
 std::uint64_t session=0;std::size_t cursor=0;unsigned revision=0;
 std::filesystem::path directory;
 std::map<std::pair<int,int>,std::uint64_t> hashes;
 std::future<Result> pending;
 Status status;
} runtime;
client::scheduler::Cursor captureCursor;
struct Frame {JNIEnv* env;bool ok;explicit Frame(JNIEnv* e):env(e),ok(e->PushLocalFrame(96)==JNI_OK){}~Frame(){if(ok)env->PopLocalFrame(nullptr);}};
void Notice(const std::string& message){ui::notifications::State().Push(ui::notifications::Type::Info,"SeedDumper",message);AOKI_LOG("[SeedDumper] %s",message.c_str());}
void Reset(JNIEnv* env){mapping::ReleaseGlobal(env,runtime.world);runtime.hashes.clear();runtime.cursor=0;runtime.revision=0;runtime.directory.clear();runtime.failed=false;++runtime.session;runtime.status={};}
std::filesystem::path Root(){
 const auto length=GetEnvironmentVariableW(L"APPDATA",nullptr,0);if(!length)return {};
 std::wstring value(length,L'\0');const auto count=GetEnvironmentVariableW(L"APPDATA",value.data(),length);if(!count||count>=length)return {};value.resize(count);
 return std::filesystem::path(value)/L".sonoyuncu"/L"commonLuke"/L"seed-dumps";
}
std::uint64_t NowMs(){return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count());}
bool Ready(){
 for(const char* key:{"SeedChunkProvider.chunks","Chunk.biomes","Chunk.storageArrays","Chunk.worldObj","Chunk.xPosition","Chunk.zPosition","ExtendedBlockStorage.data","ExtendedBlockStorage.yBase","ArrayList.elements","ArrayList.size"})if(!mapping::ResolveField(key))return false;
 return true;
}
bool ReadChunk(JNIEnv* env,jobject chunk,jobject world,Snapshot& s){
 const auto owner=mapping::Object(env,chunk,"Chunk.worldObj");if(!owner||!env->IsSameObject(owner,world))return false;
 const auto x=mapping::Read<int>(chunk,"Chunk.xPosition"),z=mapping::Read<int>(chunk,"Chunk.zPosition");if(!x||!z||*x<-1875000||*x>1875000||*z<-1875000||*z>1875000)return false;
 s.x=*x;s.z=*z;s.capturedMs=NowMs();
 const auto provider=mapping::Object(env,world,"World.provider");if(provider)s.dimension=mapping::Read<int>(provider,"SeedWorldProvider.dimension").value_or(UnknownDimension);
 const auto biomes=static_cast<jbyteArray>(mapping::Object(env,chunk,"Chunk.biomes"));
 if(!biomes||env->GetArrayLength(biomes)!=256)return false;
 env->GetByteArrayRegion(biomes,0,256,reinterpret_cast<jbyte*>(s.biomes.data()));if(env->ExceptionCheck())return false;
 // A newly allocated placeholder has no biome packet yet. Do not persist it as air.
 if(std::all_of(s.biomes.begin(),s.biomes.end(),[](auto b){return b==255;}))return false;
 const auto sections=static_cast<jobjectArray>(mapping::Object(env,chunk,"Chunk.storageArrays"));
 if(!sections||env->GetArrayLength(sections)!=16)return false;
 for(int y=0;y<16;++y){
  const auto section=env->GetObjectArrayElement(sections,y);if(env->ExceptionCheck())return false;if(!section)continue;
  const auto base=mapping::Read<int>(section,"ExtendedBlockStorage.yBase");
  const auto data=static_cast<jcharArray>(mapping::Object(env,section,"ExtendedBlockStorage.data"));
  if(!base||*base!=y*16||!data||env->GetArrayLength(data)!=4096)return false;
  env->GetCharArrayRegion(data,0,4096,reinterpret_cast<jchar*>(s.states.data()+y*4096));
  env->DeleteLocalRef(data);env->DeleteLocalRef(section);if(env->ExceptionCheck())return false;
  s.sections|=static_cast<std::uint16_t>(1u<<y);
 }
 return true;
}
Result Save(std::filesystem::path directory,std::filesystem::path filename,std::shared_ptr<Snapshot> snapshot,std::uint64_t session,std::uint64_t hash){
 Result result{session,hash,{snapshot->x,snapshot->z},{}};
 try{
  std::error_code ec;std::filesystem::create_directories(directory,ec);if(ec){result.error="Cannot create dump directory: "+ec.message();return result;}
  const auto manifest=directory/L"session.json";
  if(!std::filesystem::exists(manifest)){
   std::ofstream file(manifest,std::ios::binary);
   file<<R"({"format":"AOKISD01","game_family":"Java 1.8.x","generator_version":"unknown","server_implementation":"unknown","source":"client loaded chunk arrays","ore_obfuscation":"suspected","states":"block_id << 4 | metadata","index":"y*256+z*16+x","ore_evidence":"observations only; exposure is a heuristic; never infer absence","dungeon_evidence":"spawner/floor samples need natural-generation and orientation verification","dimension_unknown":-2147483648,"capture_time":"UTC unix milliseconds","snapshot_limit":4096})";
   file.flush();if(!file){result.error="Cannot write session manifest";return result;}file.close();if(file.fail()){result.error="Cannot close session manifest";return result;}
  }
  WriteSnapshot(directory/filename,*snapshot,result.error);
 }catch(const std::exception& e){result.error=e.what();}catch(...){result.error="Unexpected dump writer error";}
 return result;
}
void Fail(std::string error){runtime.failed=true;runtime.status.message=std::move(error);Notice(runtime.status.message);Publish(runtime.status);}
}
void Capture(JNIEnv* env){
 if(!env||env->ExceptionCheck())return;
 Frame refs(env);if(!refs.ok)return;
 const bool enabled=Options().enabled;
 client::scheduler::Configure(client::scheduler::Task::SeedDumperCapture,
  enabled,100);
 const auto mc=enabled?mapping::StaticObject(env,"Minecraft.theMinecraft"):nullptr;
 const auto world=mc?mapping::Object(env,mc,"Minecraft.theWorld"):nullptr;
 if(!enabled){if(runtime.active){Reset(env);runtime.active=false;runtime.status.message="Disabled; pending write finishes";Publish(runtime.status);}}
 else {
  if(!runtime.active){Reset(env);runtime.active=true;runtime.status.message="Waiting for world";}
  if(!world){if(runtime.world)Reset(env);runtime.status.message="Waiting for world";}
  else if(!runtime.world||!env->IsSameObject(runtime.world,world)){
   Reset(env);runtime.world=mapping::Global(env,world);runtime.status.message="Mapping loaded chunks";
   if(!runtime.world){if(env->ExceptionCheck())env->ExceptionClear();Fail("Cannot retain world reference");return;}
  }
 }
 if(runtime.pending.valid()){
  if(runtime.pending.wait_for(std::chrono::seconds(0))!=std::future_status::ready){Publish(runtime.status);return;}
  const auto result=runtime.pending.get();
  if(result.session==runtime.session){if(!result.error.empty()){Fail(result.error);return;}runtime.hashes[result.chunk]=result.hash;++runtime.status.saved;runtime.status.message="Recording client observations";}
 }
 if(!enabled||!world||runtime.failed){Publish(runtime.status);return;}
 if(!client::scheduler::Consume(client::scheduler::Task::SeedDumperCapture,
     captureCursor)){Publish(runtime.status);return;}
 if(!Ready()){runtime.status.message="Waiting for chunk mappings";Publish(runtime.status);return;}
 if(runtime.revision>=4096){runtime.status.message="Session limit reached; toggle for a new session";Publish(runtime.status);return;}
 const auto provider=mapping::Object(env,world,"World.chunkProvider");
 if(!provider||!mapping::Instance(provider,"SeedChunkProvider")){Fail("Unsupported client chunk provider");return;}
 const auto list=mapping::Object(env,provider,"SeedChunkProvider.chunks");
 if(!list||!mapping::Instance(list,"ArrayList")){Fail("Unsupported loaded chunk list");return;}
 const auto size=mapping::Read<int>(list,"ArrayList.size");const auto elements=static_cast<jobjectArray>(mapping::Object(env,list,"ArrayList.elements"));
 if(!size||*size<0||*size>16384||!elements){runtime.status.message="Waiting for loaded chunks";Publish(runtime.status);return;}
 const int count=std::min(*size,env->GetArrayLength(elements));if(count<=0){runtime.status.message="Waiting for loaded chunks";Publish(runtime.status);return;}
 runtime.cursor%=static_cast<std::size_t>(count);
 const auto chunk=env->GetObjectArrayElement(elements,static_cast<jsize>(runtime.cursor++));
 if(!chunk||!mapping::Instance(chunk,"Chunk"))return;
 auto snapshot=std::make_shared<Snapshot>();
 if(!ReadChunk(env,chunk,world,*snapshot)){if(env->ExceptionCheck())env->ExceptionClear();runtime.status.message="Waiting for complete chunk data";Publish(runtime.status);return;}
 const auto key=std::make_pair(snapshot->x,snapshot->z);const auto hash=Fingerprint(*snapshot);
 if(const auto found=runtime.hashes.find(key);found!=runtime.hashes.end()&&found->second==hash){Publish(runtime.status);return;}
 if(runtime.directory.empty()){
  const auto root=Root();if(root.empty()){Fail("APPDATA unavailable; cannot save dumps");return;}
  runtime.directory=root/(std::to_wstring(NowMs())+L"-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(runtime.session));
  runtime.status.directory=runtime.directory.string();Notice("Recording to "+runtime.status.directory);
 }
 const auto filename=std::to_wstring(++runtime.revision)+L"_"+std::to_wstring(snapshot->x)+L"_"+std::to_wstring(snapshot->z)+L".aokisd";
 try{runtime.pending=std::async(std::launch::async,Save,runtime.directory,std::filesystem::path(filename),std::move(snapshot),runtime.session,hash);}
 catch(const std::exception& e){Fail(std::string("Cannot start dump writer: ")+e.what());return;}
 Publish(runtime.status);
}
}
