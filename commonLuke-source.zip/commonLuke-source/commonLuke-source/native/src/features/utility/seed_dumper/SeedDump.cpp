#include "features/utility/seed_dumper/SeedDump.hpp"
#include <algorithm>
#include <bit>
#include <fstream>

namespace client::features::seeddumper {
namespace {
constexpr std::array<std::uint8_t,8> Magic{'A','O','K','I','S','D','0','1'};
void Put(std::vector<std::uint8_t>& out,std::uint64_t value,int size){for(int i=0;i<size;++i)out.push_back(static_cast<std::uint8_t>(value>>(8*i)));}
struct Reader {
 std::span<const std::uint8_t> bytes;std::size_t at=0;bool ok=true;
 std::uint64_t Get(int count){if(at+count>bytes.size()){ok=false;return 0;}std::uint64_t value=0;for(int i=0;i<count;++i)value|=std::uint64_t(bytes[at++])<<(8*i);return value;}
};
}
std::vector<std::uint8_t> Encode(const Snapshot& s){
 std::vector<std::uint8_t> out(Magic.begin(),Magic.end());
 Put(out,static_cast<std::uint32_t>(s.x),4);Put(out,static_cast<std::uint32_t>(s.z),4);Put(out,static_cast<std::uint32_t>(s.dimension),4);
 Put(out,s.capturedMs,8);Put(out,s.sections,2);Put(out,1,2); // raw client observations, possibly obfuscated
 out.insert(out.end(),s.biomes.begin(),s.biomes.end());
 const auto runOffset=out.size();Put(out,0,4);std::uint32_t runs=0;
 for(std::size_t at=0;at<s.states.size();){auto end=at+1;while(end<s.states.size()&&s.states[end]==s.states[at])++end;Put(out,s.states[at],2);Put(out,end-at,4);++runs;at=end;}
 for(int i=0;i<4;++i)out[runOffset+i]=static_cast<std::uint8_t>(runs>>(8*i));
 return out;
}
bool Decode(std::span<const std::uint8_t> bytes,Snapshot& output,std::string& error){
 error.clear();auto fail=[&]{error="Invalid or truncated SeedDumper snapshot";return false;};
 if(bytes.size()<292||!std::equal(Magic.begin(),Magic.end(),bytes.begin()))return fail();
 Reader r{bytes,8};Snapshot s;
 s.x=std::bit_cast<std::int32_t>(static_cast<std::uint32_t>(r.Get(4)));s.z=std::bit_cast<std::int32_t>(static_cast<std::uint32_t>(r.Get(4)));s.dimension=std::bit_cast<std::int32_t>(static_cast<std::uint32_t>(r.Get(4)));
 s.capturedMs=r.Get(8);s.sections=static_cast<std::uint16_t>(r.Get(2));if(r.Get(2)!=1)return fail();
 for(auto& biome:s.biomes)biome=static_cast<std::uint8_t>(r.Get(1));
 const auto runs=r.Get(4);if(!runs||runs>65536)return fail();std::size_t at=0;
 for(std::uint64_t i=0;i<runs;++i){const auto value=static_cast<std::uint16_t>(r.Get(2));const auto length=r.Get(4);if(!r.ok||!length||length>65536-at)return fail();std::fill_n(s.states.begin()+at,static_cast<std::size_t>(length),value);at+=length;}
 if(!r.ok||at!=65536||r.at!=bytes.size())return fail();output=std::move(s);return true;
}
std::uint64_t Fingerprint(const Snapshot& s){
 std::uint64_t hash=14695981039346656037ULL;
 auto byte=[&](std::uint8_t b){hash^=b;hash*=1099511628211ULL;};
 for(auto b:s.biomes)byte(b);for(auto state:s.states){byte(static_cast<std::uint8_t>(state));byte(static_cast<std::uint8_t>(state>>8));}
 byte(static_cast<std::uint8_t>(s.sections));byte(static_cast<std::uint8_t>(s.sections>>8));return hash;
}
bool WriteSnapshot(const std::filesystem::path& path,const Snapshot& s,std::string& error){
 error.clear();std::error_code ec;
 std::filesystem::create_directories(path.parent_path(),ec);if(ec){error="Cannot create dump directory: "+ec.message();return false;}
 if(std::filesystem::exists(path,ec)||ec){error="Snapshot already exists or cannot be accessed";return false;}
 const auto temporary=std::filesystem::path(path.wstring()+L".tmp");
 const auto bytes=Encode(s);
 {std::ofstream file(temporary,std::ios::binary|std::ios::trunc);file.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));file.flush();if(!file){error="Cannot write dump (disk full or access denied)";file.close();std::filesystem::remove(temporary,ec);return false;}file.close();if(file.fail()){error="Cannot close dump file";std::filesystem::remove(temporary,ec);return false;}}
 std::filesystem::rename(temporary,path,ec);if(ec){error="Cannot finalize dump: "+ec.message();std::filesystem::remove(temporary,ec);return false;}return true;
}
}
