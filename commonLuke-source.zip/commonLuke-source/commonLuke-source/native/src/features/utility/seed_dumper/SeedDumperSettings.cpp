#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <mutex>
namespace client::features::seeddumper {
namespace {std::mutex mutex;Settings settings;Status status;}
Settings Options(){std::lock_guard lock(mutex);return settings;}
void SetOptions(Settings value){bool previous;{std::lock_guard lock(mutex);previous=settings.enabled;settings=value;}modules::StateChanged(modules::SeedDumper,previous,value.enabled);}
Status CurrentStatus(){std::lock_guard lock(mutex);return status;}
void Publish(Status value){std::lock_guard lock(mutex);status=std::move(value);}
}
