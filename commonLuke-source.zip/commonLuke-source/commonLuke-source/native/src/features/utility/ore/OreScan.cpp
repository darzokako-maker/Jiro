#include "features/utility/ore/OreScan.hpp"

#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "features/utility/world/Blocks.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>

namespace client::features::ore {
namespace {

ScanStatus Convert(blocks::BuildStatus status) {
    switch (status) {
        case blocks::BuildStatus::Ok:                  return ScanStatus::Ok;
        case blocks::BuildStatus::NoWorld:             return ScanStatus::NoWorld;
        case blocks::BuildStatus::UnsupportedProvider: return ScanStatus::UnsupportedProvider;
        case blocks::BuildStatus::NoChunks:            return ScanStatus::NoChunks;
        case blocks::BuildStatus::Failed:              return ScanStatus::Failed;
    }
    return ScanStatus::Failed;
}

void WarnProvider() {
    static bool warned = false;
    if (warned) return;
    warned = true;
    AOKI_LOG("[OreScan] World.chunkProvider is not SeedChunkProvider; ore scanning unavailable");
}

// A face counts as exposed when it touches air or a liquid. Out-of-grid faces
// do not count, so a vein at the border of the loaded snapshot is judged only
// from data we actually read.
bool Open(const blocks::Grid& grid, int x, int y, int z) {
    if (!grid.Contains(x, y, z)) return false;
    const auto id = grid.Id(x, y, z);
    return id == 0 || blocks::Liquid(id);
}

bool Exposed(const blocks::Grid& grid, int x, int y, int z) {
    return Open(grid, x + 1, y, z) || Open(grid, x - 1, y, z) ||
           Open(grid, x, y + 1, z) || Open(grid, x, y - 1, z) ||
           Open(grid, x, y, z + 1) || Open(grid, x, y, z - 1);
}

// Bounded flood fill over same-kind cells. Stops as soon as `requirement`
// blocks were found, so large custom veins cost at most a handful of reads and
// no heap allocation (the max cluster size the filter can ask for is 6).
bool ClusterAtLeast(const blocks::Grid& grid, int x, int y, int z, Kind kind,
                    int requirement) {
    if (requirement <= 1) return true;
    struct Cell { int x, y, z; };
    static constexpr int kCapacity = 8;
    static constexpr int kOffsets[6][3] = {
        {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    Cell stack[kCapacity]{{x, y, z}};
    Cell seen[kCapacity]{{x, y, z}};
    int stackCount = 1, seenCount = 1, count = 0;
    while (stackCount > 0 && count < requirement) {
        const Cell cell = stack[--stackCount];
        ++count;
        for (const auto& offset : kOffsets) {
            const int nx = cell.x + offset[0];
            const int ny = cell.y + offset[1];
            const int nz = cell.z + offset[2];
            if (!grid.Contains(nx, ny, nz)) continue;
            const auto other = FromBlockId(grid.Id(nx, ny, nz));
            if (!other || *other != kind) continue;
            bool duplicate = false;
            for (int i = 0; i < seenCount; ++i) {
                if (seen[i].x == nx && seen[i].y == ny && seen[i].z == nz) {
                    duplicate = true;
                    break;
                }
            }
            if (duplicate || seenCount >= kCapacity) continue;
            seen[seenCount++] = {nx, ny, nz};
            stack[stackCount++] = {nx, ny, nz};
        }
    }
    return count >= requirement;
}

void Diagnose(std::size_t raw, std::size_t kept, const blocks::Grid& grid,
              const Filter& filter) {
    static std::uint64_t last = 0;
    const auto now = client::scheduler::Now();
    if (last && now - last < 10000) return;
    last = now;
    AOKI_LOG("[OreScan] raw=%d kept=%d grid=%dx%dx%d exposed=%d cluster=%d yRange=%d",
        static_cast<int>(raw), static_cast<int>(kept), grid.sx, grid.sy, grid.sz,
        filter.exposedOnly ? 1 : 0, ClusterRequirement(filter),
        filter.yRange ? 1 : 0);
}

} // namespace

Result Scan(JNIEnv* env, jobject world, double x, double y, double z,
            double radius, const Toggles& toggles, const Filter& filter,
            std::size_t limit) {
    Result result;
    if (!env || !world || radius <= 0.0) return result;

    // One extra block of margin keeps the exposed/cluster checks fed at the
    // edge of the requested sphere instead of reading unwritten cells.
    const int horizontal = static_cast<int>(std::ceil(radius)) + 2;
    const int vertical = static_cast<int>(std::ceil(radius)) + 2;

    blocks::Grid grid;
    result.status = Convert(blocks::Build(env, world,
        static_cast<int>(std::floor(x)), static_cast<int>(std::floor(y)),
        static_cast<int>(std::floor(z)), horizontal, vertical, grid));
    if (result.status == ScanStatus::UnsupportedProvider) {
        WarnProvider();
        return result;
    }
    if (result.status != ScanStatus::Ok) return result;

    const double radiusSquared = radius * radius;
    const int requirement = ClusterRequirement(filter);
    const std::size_t hardLimit = std::max<std::size_t>(limit, 1) * 8;
    std::vector<Block> kept;
    kept.reserve(std::min<std::size_t>(hardLimit, 512));

    for (int gy = grid.oy; gy < grid.oy + grid.sy; ++gy) {
        for (int gz = grid.oz; gz < grid.oz + grid.sz; ++gz) {
            for (int gx = grid.ox; gx < grid.ox + grid.sx; ++gx) {
                if (!grid.Seen(gx, gy, gz)) continue;
                const int id = grid.Id(gx, gy, gz);
                if (!id) continue;
                const auto kind = FromBlockId(id);
                if (!kind || !Enabled(toggles, *kind)) continue;
                ++result.raw;

                const double dx = gx + 0.5 - x;
                const double dy = gy + 0.5 - y;
                const double dz = gz + 0.5 - z;
                const double distanceSquared = dx * dx + dy * dy + dz * dz;
                if (distanceSquared > radiusSquared) continue;

                if (filter.yRange && !InVanillaRange(*kind, gy)) continue;
                if (filter.exposedOnly && !Exposed(grid, gx, gy, gz)) continue;
                if (requirement > 1 &&
                    !ClusterAtLeast(grid, gx, gy, gz, *kind, requirement)) continue;

                kept.push_back({gx, gy, gz, id, *kind,
                    static_cast<float>(std::sqrt(distanceSquared))});
                if (kept.size() >= hardLimit) break;
            }
            if (kept.size() >= hardLimit) break;
        }
        if (kept.size() >= hardLimit) break;
    }

    Diagnose(result.raw, kept.size(), grid, filter);

    if (kept.size() > 1) {
        std::sort(kept.begin(), kept.end(),
            [](const Block& left, const Block& right) {
                return left.distance < right.distance;
            });
    }
    if (kept.size() > limit) kept.resize(limit);
    result.blocks = std::move(kept);
    return result;
}

} // namespace client::features::ore
