#include "features/utility/ore/OreScan.hpp"

#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"

#include <algorithm>
#include <cmath>

namespace client::features::ore {
namespace {

struct LocalFrame {
    JNIEnv* env;
    bool ok;
    explicit LocalFrame(JNIEnv* value) : env(value), ok(value->PushLocalFrame(32) == JNI_OK) {}
    ~LocalFrame() { if (ok) env->PopLocalFrame(nullptr); }
};

void WarnProvider() {
    static bool warned = false;
    if (warned) return;
    warned = true;
    AOKI_LOG("[OreScan] World.chunkProvider is not SeedChunkProvider; ore scanning unavailable");
}

bool InChunkRange(int chunk, int low, int high) noexcept {
    return chunk >= low && chunk <= high;
}

} // namespace

Result Scan(JNIEnv* env, jobject world, double x, double y, double z,
            double radius, const Toggles& toggles, std::size_t limit) {
    Result result;
    if (!env || !world || radius <= 0.0) return result;
    LocalFrame frame(env);
    if (!frame.ok) return result;
    result.status = ScanStatus::Failed;

    const auto provider = mapping::Object(env, world, "World.chunkProvider");
    if (!provider) return result;
    if (!mapping::Instance(provider, "SeedChunkProvider")) {
        WarnProvider();
        result.status = ScanStatus::UnsupportedProvider;
        return result;
    }
    const auto list = mapping::Object(env, provider, "SeedChunkProvider.chunks");
    if (!list || !mapping::Instance(list, "ArrayList")) return result;
    const auto size = mapping::Read<int>(list, "ArrayList.size");
    const auto elements = static_cast<jobjectArray>(mapping::Object(env, list, "ArrayList.elements"));
    if (!size || !elements || *size < 0) return result;
    const int count = std::min(*size, env->GetArrayLength(elements));
    result.status = ScanStatus::Ok;
    if (count <= 0) {
        result.status = ScanStatus::NoChunks;
        return result;
    }

    const double radiusSquared = radius * radius;
    const int minChunkX = static_cast<int>(std::floor((x - radius) / 16.0));
    const int maxChunkX = static_cast<int>(std::floor((x + radius) / 16.0));
    const int minChunkZ = static_cast<int>(std::floor((z - radius) / 16.0));
    const int maxChunkZ = static_cast<int>(std::floor((z + radius) / 16.0));
    const std::size_t hardLimit = std::max<std::size_t>(limit, 1) * 8;
    std::vector<jchar> states(4096);

    for (int index = 0; index < count && result.blocks.size() < hardLimit; ++index) {
        const auto chunk = env->GetObjectArrayElement(elements, static_cast<jsize>(index));
        if (!chunk) continue;
        if (!mapping::Instance(chunk, "Chunk")) {
            env->DeleteLocalRef(chunk);
            continue;
        }
        const auto chunkX = mapping::Read<int>(chunk, "Chunk.xPosition");
        const auto chunkZ = mapping::Read<int>(chunk, "Chunk.zPosition");
        if (!chunkX || !chunkZ ||
            !InChunkRange(*chunkX, minChunkX, maxChunkX) ||
            !InChunkRange(*chunkZ, minChunkZ, maxChunkZ)) {
            env->DeleteLocalRef(chunk);
            continue;
        }

        const auto sections = static_cast<jobjectArray>(mapping::Object(env, chunk, "Chunk.storageArrays"));
        if (sections) {
            const int sectionCount = std::min(16, env->GetArrayLength(sections));
            for (int sectionIndex = 0;
                 sectionIndex < sectionCount && result.blocks.size() < hardLimit;
                 ++sectionIndex) {
                const auto section = env->GetObjectArrayElement(sections, static_cast<jsize>(sectionIndex));
                if (!section) continue;
                const auto base = mapping::Read<int>(section, "ExtendedBlockStorage.yBase");
                const auto references = mapping::Read<int>(section, "ExtendedBlockStorage.blockRefCount");
                const auto data = static_cast<jcharArray>(mapping::Object(env, section, "ExtendedBlockStorage.data"));
                const bool populated = base && data && env->GetArrayLength(data) == 4096 &&
                    (!references || *references > 0);
                const bool vertical = populated &&
                    static_cast<double>(*base + 15) >= y - radius &&
                    static_cast<double>(*base) <= y + radius;
                if (vertical) {
                    env->GetCharArrayRegion(data, 0, 4096, states.data());
                    if (env->ExceptionCheck()) {
                        env->ExceptionClear();
                    } else {
                        for (int state = 0; state < 4096; ++state) {
                            const int id = static_cast<int>(
                                static_cast<unsigned short>(states[static_cast<std::size_t>(state)]) >> 4);
                            if (!id) continue;
                            const auto kind = FromBlockId(id);
                            if (!kind || !Enabled(toggles, *kind)) continue;
                            const int blockX = *chunkX * 16 + (state & 15);
                            const int blockY = *base + (state >> 8);
                            const int blockZ = *chunkZ * 16 + ((state >> 4) & 15);
                            const double dx = blockX + 0.5 - x;
                            const double dy = blockY + 0.5 - y;
                            const double dz = blockZ + 0.5 - z;
                            const double distanceSquared = dx * dx + dy * dy + dz * dz;
                            if (distanceSquared > radiusSquared) continue;
                            result.blocks.push_back({blockX, blockY, blockZ, id, *kind,
                                static_cast<float>(std::sqrt(distanceSquared))});
                            if (result.blocks.size() >= hardLimit) break;
                        }
                    }
                }
                if (data) env->DeleteLocalRef(data);
                env->DeleteLocalRef(section);
            }
            env->DeleteLocalRef(sections);
        }
        env->DeleteLocalRef(chunk);
    }

    if (result.blocks.size() > 1) {
        std::sort(result.blocks.begin(), result.blocks.end(),
            [](const Block& left, const Block& right) { return left.distance < right.distance; });
    }
    if (result.blocks.size() > limit) result.blocks.resize(limit);
    return result;
}

} // namespace client::features::ore
