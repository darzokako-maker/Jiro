#include "features/core/ModuleRegistry.hpp"
#include "features/visual/esp/Esp.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/visual/freecam/FreeCam.hpp"
#include "features/visual/dragon_wings/DragonWings.hpp"
#include "features/combat/velocity/Velocity.hpp"
#include "features/combat/aim_assist/AimAssist.hpp"
#include "features/movement/clips/Clips.hpp"
#include "features/exploit/no_rotate/NoRotate.hpp"
#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/target_hud/TargetHud.hpp"
#include "features/visual/cosmetics/Cosmetics.hpp"
#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/utility/seed_dumper/SeedDumper.hpp"
#include "features/utility/auto_miner/AutoMiner.hpp"
#include "features/visual/xray/Xray.hpp"
#include "features/visual/ambiance/Ambiance.hpp"
#include "ui/hud/Notifications.hpp"
#include "client/PacketChatLogger.hpp"

namespace client::features::modules {

namespace {
bool hud=true;
bool mcf=true;
}

bool Enabled(Id id){
 if(!Available(id))return false;
 if(const auto kind=extras::FromModuleIndex(static_cast<int>(id)))return extras::Options(*kind).enabled;
 switch(id){
  case Hud:return hud;
  case Esp:return esp::Options().enabled;
  case DragonWings:return wings::Options().enabled;
   case UpClip:return clips::Options(clips::Kind::Up).enabled;
   case DownClip:return clips::Options(clips::Kind::Down).enabled;
   case LookClip:return clips::Options(clips::Kind::Look).enabled;
  case Velocity:return velocity::Options().enabled;
  case NoRotate:return norotate::Options().enabled;
  case AutoDisconnect:return disconnect::Options().enabled;
  case NoJumpCooldown:return nojump::Options().enabled;
  case SpotifyWidget:return spotify::Options().enabled;
  case TargetHud:return targethud::Options().enabled;
  case Cosmetics:return cosmetics::Options().enabled;
  case SeedDumper:return seeddumper::Options().enabled;
  case ItemEsp:return item_esp::Options().enabled;
  case FreeCam:return freecam::Options().enabled;
  case Ambiance:return ambiance::Options().enabled;
  case Mcf:return mcf;
  case Scaffold:return scaffold::Options().enabled;
  case InventoryHud:return inventory_hud::Options().enabled;
  case AimAssist:return aimassist::Options().enabled;
  case PacketLogger:return packet_chat::Enabled();
   case Xray:return xray::Options().enabled;
   case AutoMiner:return autominer::Options().enabled;
  default:return false;
 }
}

void StateChanged(Id id,bool previous,bool enabled){
 if(previous!=enabled&&id>=0&&id<Count)ui::notifications::ModuleChanged(Catalog[id].name,enabled);
}

void SetEnabled(Id id,bool enabled){
 if(!Available(id))return;
 if(const auto kind=extras::FromModuleIndex(static_cast<int>(id))){
  auto settings=extras::Options(*kind);settings.enabled=enabled;extras::SetOptions(*kind,settings);
  return;
 }
 switch(id){
  case Hud:{const bool previous=hud;hud=enabled;StateChanged(id,previous,enabled);break;}
  case Esp:{auto settings=esp::Options();settings.enabled=enabled;esp::SetOptions(settings);break;}
  case DragonWings:{auto settings=wings::Options();settings.enabled=enabled;wings::SetOptions(settings);break;}
   case UpClip:{auto settings=clips::Options(clips::Kind::Up);settings.enabled=enabled;clips::SetOptions(clips::Kind::Up,settings);break;}
   case DownClip:{auto settings=clips::Options(clips::Kind::Down);settings.enabled=enabled;clips::SetOptions(clips::Kind::Down,settings);break;}
   case LookClip:{auto settings=clips::Options(clips::Kind::Look);settings.enabled=enabled;clips::SetOptions(clips::Kind::Look,settings);break;}
  case Velocity:{auto settings=velocity::Options();settings.enabled=enabled;velocity::SetOptions(settings);break;}
  case NoRotate:{auto settings=norotate::Options();settings.enabled=enabled;norotate::SetOptions(settings);break;}
  case AutoDisconnect:{auto settings=disconnect::Options();settings.enabled=enabled;disconnect::SetOptions(settings);break;}
  case NoJumpCooldown:{auto settings=nojump::Options();settings.enabled=enabled;nojump::SetOptions(settings);break;}
  case SpotifyWidget:{auto settings=spotify::Options();settings.enabled=enabled;spotify::SetOptions(settings);break;}
  case TargetHud:{auto settings=targethud::Options();settings.enabled=enabled;targethud::SetOptions(settings);break;}
  case Cosmetics:{auto settings=cosmetics::Options();settings.enabled=enabled;cosmetics::SetOptions(settings);break;}
  case SeedDumper:{auto settings=seeddumper::Options();settings.enabled=enabled;seeddumper::SetOptions(settings);break;}
  case ItemEsp:{auto settings=item_esp::Options();settings.enabled=enabled;item_esp::SetOptions(settings);break;}
  case FreeCam:{auto settings=freecam::Options();settings.enabled=enabled;freecam::SetOptions(settings);break;}
  case Ambiance:{auto settings=ambiance::Options();settings.enabled=enabled;ambiance::SetOptions(settings);break;}
  case Mcf:{const bool previous=mcf;mcf=enabled;StateChanged(id,previous,enabled);break;}
  case Scaffold:{auto settings=scaffold::Options();settings.enabled=enabled;scaffold::SetOptions(settings);break;}
  case InventoryHud:{auto settings=inventory_hud::Options();settings.enabled=enabled;inventory_hud::SetOptions(settings);break;}
  case AimAssist:{auto settings=aimassist::Options();settings.enabled=enabled;aimassist::SetOptions(settings);break;}
  case PacketLogger:{const bool previous=packet_chat::Enabled();packet_chat::SetEnabled(enabled);StateChanged(id,previous,enabled);break;}
   case Xray:{auto settings=xray::Options();settings.enabled=enabled;xray::SetOptions(settings);break;}
   case AutoMiner:{auto settings=autominer::Options();settings.enabled=enabled;autominer::SetOptions(settings);break;}
  default:break;
 }
}

void Toggle(Id id){SetEnabled(id,!Enabled(id));}
}
