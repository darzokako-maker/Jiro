#include "features/visual/esp/EspGlowRenderer.hpp"
#include "client/OffsetRepository.hpp"
#include "game/MappingRepository.hpp"
#include "render/GlDiagnostics.hpp"
#include "render/LegacyGuiState.hpp"
#include "client/Logger.hpp"
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

namespace client::features::esp {
namespace {
using namespace render;

void (APIENTRY* GenRenderbuffers)(GLsizei,GLuint*)=nullptr;
void (APIENTRY* DeleteRenderbuffers)(GLsizei,const GLuint*)=nullptr;
void (APIENTRY* BindRenderbuffer)(GLenum,GLuint)=nullptr;
void (APIENTRY* RenderbufferStorage)(GLenum,GLenum,GLsizei,GLsizei)=nullptr;
void (APIENTRY* FramebufferRenderbuffer)(GLenum,GLenum,GLenum,GLuint)=nullptr;

template<class T> T Resolve(const char* name) {
 const auto proc=wglGetProcAddress(name);
 const auto value=reinterpret_cast<ULONG_PTR>(proc);
 return value>3 && value!=static_cast<ULONG_PTR>(-1)?reinterpret_cast<T>(proc):nullptr;
}
bool LoadRenderbuffers() {
 if(GenRenderbuffers)return true;
 GenRenderbuffers=Resolve<decltype(GenRenderbuffers)>("glGenRenderbuffers");
 DeleteRenderbuffers=Resolve<decltype(DeleteRenderbuffers)>("glDeleteRenderbuffers");
 BindRenderbuffer=Resolve<decltype(BindRenderbuffer)>("glBindRenderbuffer");
 RenderbufferStorage=Resolve<decltype(RenderbufferStorage)>("glRenderbufferStorage");
 FramebufferRenderbuffer=Resolve<decltype(FramebufferRenderbuffer)>("glFramebufferRenderbuffer");
 return GenRenderbuffers&&DeleteRenderbuffers&&BindRenderbuffer&&RenderbufferStorage&&FramebufferRenderbuffer;
}
methods::Argument ObjectArg(jobject value){methods::Argument a{methods::Type::Object};a.value.l=value;return a;}
methods::Argument IntArg(int value){methods::Argument a{methods::Type::Int};a.value.i=value;return a;}
methods::Argument FloatArg(float value){methods::Argument a{methods::Type::Float};a.value.f=value;return a;}
methods::Argument DoubleArg(double value){methods::Argument a{methods::Type::Double};a.value.d=value;return a;}
methods::Argument BoolArg(bool value){methods::Argument a{methods::Type::Boolean};a.value.z=value?JNI_TRUE:JNI_FALSE;return a;}
}

struct EspGlowRenderer::ScopedState {
 struct CacheSnapshot {
  struct Value { jobject owner=nullptr; unsigned offset=0; std::vector<unsigned char> bytes; };
  std::vector<Value> values;
  std::vector<jobject> seen;
  std::string allowedPrefix;
  JNIEnv* env=nullptr;

  explicit CacheSnapshot(JNIEnv* environment):env(environment) {
   const auto klass=mapping::Class("GlStateManager");
   const auto profile=offsets::Get();
   if(!klass||!profile)return;
   allowedPrefix=klass->name.substr(0,klass->name.find_last_of('/')+1);
   const auto found=profile->members.find("Klass.java_mirror");
   if(found==profile->members.end())return;
   const auto mirror=hotspot::Read<std::uintptr_t>(klass->klass+found->second).value_or(0);
   if(const auto root=mapping::Root(env,mirror))Save(root,*klass,true,0);
  }
  void Save(jobject root,const classes::ClassRecord& klass,bool statics,int depth) {
   if(depth>5||seen.size()>256||(depth&&klass.name.rfind(allowedPrefix,0)!=0))return;
   for(const auto previous:seen)if(env->IsSameObject(root,previous))return;
   seen.push_back(root);
   for(const auto& field:klass.fields) {
    if(((field.access_flags&8)!=0)!=statics||field.signature.empty())continue;
    const char type=field.signature[0];
    const auto oop=mapping::Oop(root);if(!oop)continue;
    const unsigned size=type=='Z'||type=='B'?1:type=='S'||type=='C'?2:type=='I'||type=='F'?4:type=='J'||type=='D'?8:0;
    if(size) {
     Value value{root,field.offset,std::vector<unsigned char>(size)};
     if(hotspot::ReadMemory(oop+field.offset,value.bytes.data(),size))values.push_back(std::move(value));
    } else if(type=='L'||(field.signature.size()>1&&field.signature[0]=='['&&field.signature[1]=='L')) {
     const auto object=mapping::Root(env,hotspot::ReadObjectReference(oop+field.offset).value_or(0));
     if(!object)continue;
     if(type=='[') {
      const auto array=static_cast<jobjectArray>(object);const int length=env->GetArrayLength(array);
      if(length>64)continue;
      for(int i=0;i<length;++i)if(const auto child=env->GetObjectArrayElement(array,i))
       if(const auto childClass=mapping::RuntimeClass(child))Save(child,*childClass,false,depth+1);
     } else if(const auto childClass=mapping::RuntimeClass(object))Save(object,*childClass,false,depth+1);
    }
   }
  }
  void Restore() {
   for(const auto& value:values)if(const auto oop=mapping::Oop(value.owner))
    hotspot::WriteMemory(oop+value.offset,value.bytes.data(),value.bytes.size());
  }
 };

 CacheSnapshot cache;
 std::unique_ptr<render::LegacyGuiState> glState;
 explicit ScopedState(JNIEnv* env):cache(env),glState(std::make_unique<render::LegacyGuiState>()){}
 ~ScopedState(){cache.Restore();glState.reset();}
};

EspGlowRenderer::EspGlowRenderer()=default;
EspGlowRenderer::~EspGlowRenderer(){End();}

bool EspGlowRenderer::Call(const char* key,const std::vector<methods::Argument>& args) {
 auto result=mapping::Invoke(env_,nullptr,key,args);
 const bool ok=result.ok;result.Release(env_);return ok;
}

bool EspGlowRenderer::Resize(Target& target,int width,int height) {
 if(target.fbo&&target.width==width&&target.height==height)return true;
 if(!LoadRenderbuffers())return false;
 if(target.fbo)gl.DeleteFramebuffers(1,&target.fbo);
 if(target.texture)glDeleteTextures(1,&target.texture);
 if(target.depth)DeleteRenderbuffers(1,&target.depth);
 target={};
 target.width=width;target.height=height;
 glGenTextures(1,&target.texture);glBindTexture(GL_TEXTURE_2D,target.texture);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,0x812F);
 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,0x812F);
 gl.BindBuffer(0x88EC,0);
 glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
 gl.GenFramebuffers(1,&target.fbo);gl.BindFramebuffer(0x8D40,target.fbo);
 gl.FramebufferTexture2D(0x8D40,0x8CE0,GL_TEXTURE_2D,target.texture,0);
 GLint previousRenderbuffer=0;glGetIntegerv(0x8CA7,&previousRenderbuffer);
 GenRenderbuffers(1,&target.depth);BindRenderbuffer(0x8D41,target.depth);
 RenderbufferStorage(0x8D41,0x88F0,width,height);
 FramebufferRenderbuffer(0x8D40,0x821A,0x8D41,target.depth);
 BindRenderbuffer(0x8D41,previousRenderbuffer);
 glDrawBuffer(0x8CE0);glReadBuffer(0x8CE0);
 if(gl.CheckFramebufferStatus(0x8D40)==0x8CD5)return true;
 AOKI_LOG("ESP glow: incomplete mask framebuffer %dx%d",width,height);
 gl.DeleteFramebuffers(1,&target.fbo);glDeleteTextures(1,&target.texture);DeleteRenderbuffers(1,&target.depth);target={};
 return false;
}

bool EspGlowRenderer::Bind(Target& target) {
 if(bound_==&target)return true;
 diagnostics::Scope trace("ESP glow / bind mask");
 gl.BindFramebuffer(0x8D40,target.fbo);glDrawBuffer(0x8CE0);glReadBuffer(0x8CE0);
 glViewport(0,0,target.width,target.height);
 gl.UseProgram(0);render::LegacyGuiState::BindClientArrays();
 glMatrixMode(GL_PROJECTION);glLoadMatrixf(camera_.projection.data());
 glMatrixMode(GL_MODELVIEW);glLoadMatrixf(camera_.model.data());
 glDisable(GL_SCISSOR_TEST);glEnable(GL_STENCIL_TEST);glStencilMask(0xFF);
 glStencilFunc(GL_ALWAYS,1,0xFF);glStencilOp(GL_KEEP,GL_KEEP,GL_REPLACE);glDisable(0x8DB9);
 glDisable(0x8C89);glDisable(0x8F9D);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 glDepthFunc(GL_LEQUAL);glEnable(GL_ALPHA_TEST);glAlphaFunc(GL_GREATER,.01f);
 if(gl.BindSampler){gl.BindSampler(0,0);gl.BindSampler(1,0);}
 gl.BlendEquationSeparate(0x8006,0x8006);
 const bool ok=
  Call("GlStateManager.activeTexture",{IntArg(render::Texture0)})&&
  Call("GlStateManager.enableTexture2D")&&Call("GlStateManager.enableBlend")&&
  Call("GlStateManager.disableCull")&&Call("GlStateManager.enableDepth")&&
  Call("GlStateManager.depthMask",{BoolArg(true)})&&
  Call("GlStateManager.blendFuncSeparate",{IntArg(GL_SRC_ALPHA),IntArg(GL_ONE_MINUS_SRC_ALPHA),IntArg(GL_ONE),IntArg(GL_ONE_MINUS_SRC_ALPHA)})&&
  Call("GlStateManager.color",{FloatArg(1),FloatArg(1),FloatArg(1),FloatArg(1)})&&
  Call("GlStateManager.colorMask",{BoolArg(false),BoolArg(false),BoolArg(false),BoolArg(true)});
 bound_=&target;return ok;
}

bool EspGlowRenderer::Begin(JNIEnv* env,jobject minecraft,const Camera& camera,bool living,bool items,bool shareMasks) {
 End();
 if(!env||!minecraft||(!living&&!items)||camera.framebufferHeight<=0||camera.viewport[2]<=0)return false;
 diagnostics::Scope trace("ESP glow / begin");
 env_=env;manager_=mapping::Object(env,minecraft,"Minecraft.renderManager");
 if(!manager_){env_=nullptr;return false;}
 camera_=camera;livingActive_=living;itemsActive_=items;sharedMask_=shareMasks&&living&&items;
 state_=std::make_unique<ScopedState>(env);
 const int width=std::max(1,(camera.viewport[2]+1)/2);
 const int height=std::max(1,(camera.framebufferHeight+1)/2);
 if((living&&!Resize(living_,width,height))||(items&&!sharedMask_&&!Resize(items_,width,height))){End();return false;}
 state_->glState->RestoreTextures();
 renderShadow_=mapping::Read<bool>(manager_,"RenderManager.renderShadow");
 if(renderShadow_)mapping::Write(manager_,"RenderManager.renderShadow",false);
 const char* ranges[]={"LivingRenderer.nameRange","LivingRenderer.sneakNameRange"};
 for(int i=0;i<2;++i)if(const auto address=mapping::StaticAddress(ranges[i]))
  if(const auto value=hotspot::Read<float>(address)){nameRanges_[i]={address,*value};hotspot::WritePrimitive(address,0.f);}
 ready_=true;
 auto clear=[&](Target& target) {
  bound_=nullptr;if(!Bind(target))return false;
  Call("GlStateManager.colorMask",{BoolArg(true),BoolArg(true),BoolArg(true),BoolArg(true)});
  glClearColor(1,1,1,0);glClearDepth(1);glClearStencil(0);
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
  return Call("GlStateManager.colorMask",{BoolArg(false),BoolArg(false),BoolArg(false),BoolArg(true)});
 };
 if((living&&!clear(living_))||(items&&!sharedMask_&&!clear(items_))){End();return false;}
 bound_=nullptr;
 return true;
}

bool EspGlowRenderer::Draw(jobject entity,bool item,const Vec3& position,const Vec3& last) {
 if(!ready_||!entity||(item?!itemsActive_:!livingActive_))return false;
 Target& target=item&&!sharedMask_?items_:living_;
 bound_=nullptr;
 if(!Bind(target))return false;
 // RenderManager is expected to balance its own matrices. Reassert the mask's
 // alpha-only write before every entity in case a specialized renderer changed it.
 glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_TRUE);
 const double partial=camera_.partial;
 const double x=last.x+(position.x-last.x)*partial-camera_.origin.x;
 const double y=last.y+(position.y-last.y)*partial-camera_.origin.y;
 const double z=last.z+(position.z-last.z)*partial-camera_.origin.z;
 if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z))return false;
 const float yaw=mapping::Read<float>(entity,"Entity.rotationYaw").value_or(0.f);
 auto result=mapping::Invoke(env_,manager_,"RenderManager.renderEntity",{
  ObjectArg(entity),DoubleArg(x),DoubleArg(y),DoubleArg(z),FloatArg(yaw),FloatArg(camera_.partial),BoolArg(true)});
 const bool ok=result.ok&&result.value.z==JNI_TRUE;
 if(!ok){static bool logged=false;if(!logged){logged=true;AOKI_LOG("ESP glow: RenderManager.renderEntity failed: %s",result.error.c_str());}}
 result.Release(env_);return ok;
}

void EspGlowRenderer::RestoreJavaState() {
 if(manager_&&renderShadow_)mapping::Write(manager_,"RenderManager.renderShadow",*renderShadow_);
 for(auto& range:nameRanges_)if(range.address)hotspot::WritePrimitive(range.address,range.value);
 renderShadow_.reset();nameRanges_={};
}

void EspGlowRenderer::End() {
 if(!env_&&!state_)return;
 diagnostics::Scope trace("ESP glow / end");
 // Some specialized entity renderers change the color mask internally. Make
 // the finished masks deterministically white without touching their alpha.
 // This also guarantees that custom module tinting is the only glow color.
 if(ready_) {
  Target* targets[]{livingActive_?&living_:nullptr,itemsActive_&&!sharedMask_?&items_:nullptr};
  for(Target* target:targets)if(target) {
   gl.BindFramebuffer(0x8D40,target->fbo);glDrawBuffer(0x8CE0);
   glViewport(0,0,target->width,target->height);glDisable(GL_SCISSOR_TEST);
   glDisable(GL_DEPTH_TEST);glDisable(GL_ALPHA_TEST);glDisable(GL_BLEND);glDisable(GL_CULL_FACE);
   glEnable(GL_STENCIL_TEST);glStencilMask(0);glStencilFunc(GL_EQUAL,1,0xFF);glStencilOp(GL_KEEP,GL_KEEP,GL_KEEP);
   glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_TRUE);glClearColor(0,0,0,0);glClear(GL_COLOR_BUFFER_BIT);
   glDisable(GL_TEXTURE_2D);glMatrixMode(GL_PROJECTION);glLoadIdentity();glMatrixMode(GL_MODELVIEW);glLoadIdentity();
   glColor4f(1,1,1,1);glBegin(GL_QUADS);glVertex2f(-1,-1);glVertex2f(1,-1);glVertex2f(1,1);glVertex2f(-1,1);glEnd();
   glDisable(GL_STENCIL_TEST);glStencilMask(0xFF);glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_FALSE);
   glClearColor(1,1,1,0);glClear(GL_COLOR_BUFFER_BIT);
  }
 }
 RestoreJavaState();
 state_.reset();
 env_=nullptr;manager_=nullptr;bound_=nullptr;ready_=false;
 livingActive_=itemsActive_=sharedMask_=false;
}

}
