#include "features/visual/esp/Esp.hpp"
#include "features/visual/esp/EspDebug.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "client/NativeScheduler.hpp"
#include "ui/font/FontManager.hpp"
#include "asm/AsmProjection.hpp"
#include <Windows.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <mutex>
#include <memory>
#include <string_view>

namespace client::features::esp {
namespace {
Settings options;
std::mutex frameMutex;
std::shared_ptr<const Frame> latest;
std::uint64_t optionsRevision=0;
std::uint64_t updated=0;
struct V4 { double x,y,z,w; };
V4 Multiply(const std::array<float,16>& matrix,V4 p) {
 return {matrix[0]*p.x+matrix[4]*p.y+matrix[8]*p.z+matrix[12]*p.w,
         matrix[1]*p.x+matrix[5]*p.y+matrix[9]*p.z+matrix[13]*p.w,
         matrix[2]*p.x+matrix[6]*p.y+matrix[10]*p.z+matrix[14]*p.w,
         matrix[3]*p.x+matrix[7]*p.y+matrix[11]*p.z+matrix[15]*p.w};
}
std::optional<ImVec2> ProjectPoint(const Vec3& point,const Camera& camera) {
 const auto eye=Multiply(camera.model,{point.x-camera.origin.x,point.y-camera.origin.y,point.z-camera.origin.z,1});
 const auto clip=Multiply(camera.projection,eye);if(clip.w<=.000001||clip.z< -clip.w||clip.z>clip.w)return {};
 return ImVec2(static_cast<float>(camera.viewport[0]+(clip.x/clip.w+1)*camera.viewport[2]/2),static_cast<float>(camera.framebufferHeight-camera.viewport[1]-(clip.y/clip.w+1)*camera.viewport[3]/2));
}
void DrawBacktrack(const Camera& camera,ImDrawList& draw) {
 const auto settings=extras::Options(extras::Kind::AimBacktrack);if(!settings.enabled||!settings.bedBox)return;
 const auto visual=extras::BacktrackVisualSnapshot();if(!visual.valid)return;
 const double half=visual.width*.5;const Vec3 low{visual.x-half,visual.y+.01,visual.z-half},high{visual.x+half,visual.y+visual.height,visual.z+half};
 std::array<std::optional<ImVec2>,8> points;for(int i=0;i<8;++i)points[i]=ProjectPoint({i&1?high.x:low.x,i&2?high.y:low.y,i&4?high.z:low.z},camera);
 const auto line=static_cast<ImU32>(settings.outlineColor);const int alpha=(line>>24)&255;const auto fill=(line&0x00ffffffu)|(static_cast<ImU32>(std::max(10,alpha/4))<<24);
 constexpr std::array<std::array<int,4>,6> faces{{{{0,1,3,2}},{{4,6,7,5}},{{0,4,5,1}},{{2,3,7,6}},{{0,2,6,4}},{{1,5,7,3}}}};
 for(const auto& face:faces){ImVec2 polygon[4];bool valid=true;for(int i=0;i<4;++i){if(!points[face[i]]){valid=false;break;}polygon[i]=*points[face[i]];}if(valid)draw.AddConvexPolyFilled(polygon,4,fill);}
 constexpr std::array<std::array<int,2>,12> edges{{{{0,1}},{{1,3}},{{3,2}},{{2,0}},{{4,5}},{{5,7}},{{7,6}},{{6,4}},{{0,4}},{{1,5}},{{2,6}},{{3,7}}}};
 for(const auto& edge:edges)if(points[edge[0]]&&points[edge[1]])draw.AddLine(*points[edge[0]],*points[edge[1]],line,1.5f);
}
ImU32 HealthColor(float fraction) {
 return fraction>.75f?IM_COL32(66,246,123,255):fraction>.5f?IM_COL32(228,255,105,255):fraction>.35f?IM_COL32(236,100,64,255):IM_COL32(255,65,68,255);
}
ImU32 Alpha(ImU32 color,int alpha) { return (color&0xffffff)|(static_cast<ImU32>(alpha)<<24); }
ImU32 Mix(ImU32 a,ImU32 b,float t) {
 ImU32 out=0;
 for(int shift=0;shift<32;shift+=8) out|=static_cast<ImU32>(((a>>shift)&255)*(1-t)+((b>>shift)&255)*t)<<shift;
 return out;
}
struct FormatToken { size_t length=0;bool color=false,reset=false;ImU32 value=0; };
size_t SectionMarker(std::string_view text,size_t at) {
 if(at>=text.size())return 0;
 const auto first=static_cast<unsigned char>(text[at]);
 if(first==0xa7)return 1; // Defensive support for legacy single-byte strings.
 return first==0xc2&&at+1<text.size()&&static_cast<unsigned char>(text[at+1])==0xa7?2:0;
}
int HexDigit(char value) {
 if(value>='0'&&value<='9')return value-'0';
 value=static_cast<char>(value>='A'&&value<='Z'?value+('a'-'A'):value);
 return value>='a'&&value<='f'?value-'a'+10:-1;
}
std::optional<FormatToken> MinecraftFormat(std::string_view text,size_t at,ImU32 base) {
 const size_t marker=SectionMarker(text,at);if(!marker||at+marker>=text.size())return {};
 char code=text[at+marker];if(code>='A'&&code<='Z')code=static_cast<char>(code+('a'-'A'));
 constexpr char colors[]="0123456789abcdef";
 if(const char* found=std::strchr(colors,code)) {
  const int n=static_cast<int>(found-colors),bright=(n&8)?85:0;
  const int r=((n>>2)&1)*170+bright+(n==6?85:0),g=((n>>1)&1)*170+bright,b=(n&1)*170+bright;
  return FormatToken{marker+1,true,false,IM_COL32(r,g,b,(base>>24)&255)};
 }
 if(code=='r')return FormatToken{marker+1,false,true,base};
 // Modern servers can emit §x§R§R§G§G§B§B even when the client protocol is old.
 if(code=='x') {
  size_t cursor=at+marker+1;unsigned rgb=0;
  for(int digit=0;digit<6;++digit) {
   const size_t nextMarker=SectionMarker(text,cursor);
   if(!nextMarker||cursor+nextMarker>=text.size())return {};
   const int value=HexDigit(text[cursor+nextMarker]);if(value<0)return {};
   rgb=(rgb<<4)|static_cast<unsigned>(value);cursor+=nextMarker+1;
  }
  return FormatToken{cursor-at,true,false,IM_COL32((rgb>>16)&255,(rgb>>8)&255,rgb&255,(base>>24)&255)};
 }
 // Formatting flags are consumed so they never leak into the visible label.
 if(code=='k'||code=='l'||code=='m'||code=='n'||code=='o')return FormatToken{marker+1,false,false,0};
 return {};
}
void Text(const ui::FontManager& fonts,ImDrawList& draw,const std::string& text,ImVec2 pos,float size,ImU32 color) {
 auto pass=[&](ImVec2 at,bool shadow) {
  std::string segment;float x=at.x;ImU32 active=color;
  auto flush=[&] {
   if(segment.empty())return;
   fonts.Draw(draw,segment,{x,at.y},size,shadow?IM_COL32(0,0,0,180):active);
   x+=fonts.Measure(segment,size).x;segment.clear();
  };
  for(size_t i=0;i<text.size();) {
   if(const auto token=MinecraftFormat(text,i,color)) {
    flush();if(token->color)active=token->value;else if(token->reset)active=color;i+=token->length;continue;
   }
   segment+=text[i++];
  }
  flush();
 };
 pass({pos.x+1,pos.y+1},true);pass(pos,false);
}
std::string Plain(std::string_view text) {
 std::string plain;plain.reserve(text.size());
 for(size_t i=0;i<text.size();) {
  if(const auto token=MinecraftFormat(text,i,IM_COL32_WHITE)){i+=token->length;continue;}
  plain+=text[i++];
 }
 return plain;
}
void ImageDraw(ImDrawList& draw,const Image& image,ImVec2 a,ImVec2 b,ImU32 tint=IM_COL32_WHITE) {
 draw.AddImage(static_cast<ImTextureID>(image.texture),a,b,{image.u0,image.v0},{image.u1,image.v1},tint);
}
template<class T> ImU32 GlowColor(const T& settings,float time) {
 if(settings.rainbow) {
  float r,g,b;ImGui::ColorConvertHSVtoRGB(std::fmod(time*.12f,1.f),.75f,1.f,r,g,b);
  return ImGui::ColorConvertFloat4ToU32({r,g,b,1});
 }
 if(settings.customColor)return Mix(settings.color,settings.alternate,.5f+.5f*std::sin(time*2.f));
 return IM_COL32_WHITE;
}
void GlowSlice(ImDrawList& bloom,std::uint32_t texture,const ScreenBox& box,const Camera& camera,ImU32 tint) {
 if(!texture||camera.viewport[2]<=0||camera.framebufferHeight<=0)return;
 constexpr float padding=20.f;
 const float width=static_cast<float>(camera.viewport[2]);
 const float height=static_cast<float>(camera.framebufferHeight);
 const ImVec2 a{std::clamp(box.x-padding,0.f,width),std::clamp(box.y-padding,0.f,height)};
 const ImVec2 b{std::clamp(box.right+padding,0.f,width),std::clamp(box.bottom+padding,0.f,height)};
 if(b.x<=a.x||b.y<=a.y)return;
 bloom.AddImage(static_cast<ImTextureID>(texture),a,b,
  {a.x/width,1.f-a.y/height},{b.x/width,1.f-b.y/height},tint);
}
ScreenBox UiBox(const Entity& entity) {
 auto box=entity.box;
 const double worldWidth=std::max(entity.bounds.max.x-entity.bounds.min.x,entity.bounds.max.z-entity.bounds.min.z);
 const double projectedHalf=worldWidth/1.5+.15;
 if(worldWidth>0&&projectedHalf>0) {
  const float ratio=std::clamp(static_cast<float>((worldWidth*.5)/projectedHalf),.45f,1.f);
  const float center=(box.x+box.right)*.5f,half=(box.right-box.x)*.5f*ratio;
  box.x=center-half;box.right=center+half;
 }
 const double worldHeight=entity.bounds.max.y-entity.bounds.min.y;
 if(!entity.sneaking&&worldHeight>0) {
  const float screenHeight=box.bottom-box.y;
  const double expandedHeight=worldHeight+.48;
  box.y+=screenHeight*static_cast<float>(.33/expandedHeight);
  box.bottom-=screenHeight*static_cast<float>(.15/expandedHeight);
 }
 return box;
}
}
const Settings& Options() { return options; }
void SetOptions(const Settings& settings) { const bool previous=options.enabled;options=settings;options.minecraftFont=false;++optionsRevision;modules::StateChanged(modules::Esp,previous,options.enabled); }
std::uint64_t OptionsRevision(){return optionsRevision;}
void Publish(Frame frame) { auto next=std::make_shared<const Frame>(std::move(frame));std::lock_guard lock(frameMutex); latest=std::move(next); updated=client::scheduler::Now(); }
std::optional<Frame> Snapshot() {
 std::lock_guard lock(frameMutex);
 const auto now=client::scheduler::Now();
 if(now>=updated&&now-updated>250) return {};
 return latest?std::optional<Frame>(*latest):std::nullopt;
}
namespace {
void FillAsmParams(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera,AsmProjectParams& out) {
 out.minX=bounds.min.x; out.minY=bounds.min.y; out.minZ=bounds.min.z;
 out.maxX=bounds.max.x; out.maxY=bounds.max.y; out.maxZ=bounds.max.z;
 out.posX=position.x;   out.posY=position.y;   out.posZ=position.z;
 out.lastX=last.x;     out.lastY=last.y;     out.lastZ=last.z;
 out.camX=camera.origin.x; out.camY=camera.origin.y; out.camZ=camera.origin.z;
 out.partial=camera.partial;
 out.sneaking=sneaking?1:0;
 std::memcpy(out.model,camera.model.data(),sizeof(out.model));
 std::memcpy(out.projection,camera.projection.data(),sizeof(out.projection));
 std::memcpy(out.viewport,camera.viewport.data(),sizeof(out.viewport));
 out.framebufferHeight=camera.framebufferHeight;
 out.pad=0;
}
}

std::optional<ScreenBox> Project(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera) {
 AsmProjectParams params;
 FillAsmParams(bounds,position,last,sneaking,camera,params);
 AsmScreenBox box;
 if(client::asm_math::ProjectDispatch(&params,&box)) {
  return ScreenBox{box.x,box.y,box.right,box.bottom};
 }
 return std::nullopt;
}

std::optional<ScreenBox> ProjectCppReference(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera) {
 AsmProjectParams params;
 FillAsmParams(bounds,position,last,sneaking,camera,params);
 AsmScreenBox box;
 if(client::asm_math::ProjectReferenceCpp(&params,&box)) {
  return ScreenBox{box.x,box.y,box.right,box.bottom};
 }
 return std::nullopt;
}

std::optional<ScreenBox> ProjectOptimizedCpp(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera) {
 AsmProjectParams params;
 FillAsmParams(bounds,position,last,sneaking,camera,params);
 AsmScreenBox box;
 if(client::asm_math::ProjectOptimizedCpp(&params,&box)) {
  return ScreenBox{box.x,box.y,box.right,box.bottom};
 }
 return std::nullopt;
}

std::optional<ScreenBox> ProjectAsmScalar(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera) {
 AsmProjectParams params;
 FillAsmParams(bounds,position,last,sneaking,camera,params);
 AsmScreenBox box;
 if(asm_ProjectScalar(&params,&box)) {
  return ScreenBox{box.x,box.y,box.right,box.bottom};
 }
 return std::nullopt;
}

std::optional<ScreenBox> ProjectAsmAVX2(const Bounds& bounds,const Vec3& position,const Vec3& last,bool sneaking,const Camera& camera) {
 AsmProjectParams params;
 FillAsmParams(bounds,position,last,sneaking,camera,params);
 AsmScreenBox box;
 if(asm_ProjectAVX2(&params,&box)) {
  return ScreenBox{box.x,box.y,box.right,box.bottom};
 }
 return std::nullopt;
}
void DrawFrame(const Frame& frame,const Settings& s,const ui::FontManager& fonts,ImDrawList& front,ImDrawList& bloom) {
 debug::FrameStats stats;
 ++stats.drawFrames;
 stats.drawReceived=frame.entities.size();
 const bool espOn=s.enabled;
 const bool itemEspOn=item_esp::Options().enabled;
 if(!espOn && !itemEspOn) { stats.Merge();return; }
 const float time=static_cast<float>(client::scheduler::Now()%100000)/1000.f;
 const ImU32 espGlow=GlowColor(s,time);
 const ImU32 itemGlow=GlowColor(item_esp::Options(),time);
 for(const auto& e:frame.entities) {
  if(e.isItem) {
   if(!itemEspOn) continue;
   if(!e.onScreen) continue;
   ++stats.drawOnScreen;
   const auto& opt=item_esp::Options();
   const auto b=e.box;
   if(opt.box&&frame.glow.items){GlowSlice(bloom,frame.glow.items,b,frame.camera,itemGlow);++stats.drawBoxes;}
   if(opt.nametags && !e.name.empty()) {
    std::string name=opt.formattedTags && !e.formattedName.empty()?e.formattedName:e.name;
    const float size=20.f*opt.tagScale;
    const ImVec2 extent=fonts.Measure(Plain(name),size);
    const ImVec2 a((b.x+b.right-extent.x)*.5f,b.y-extent.y-7.f);
    if(opt.tagBackground) {
     const ImU32 color=opt.redBackground?IM_COL32(255,0,0,165):IM_COL32(10,10,10,130);
     front.AddRectFilled({a.x-4,a.y-3},{a.x+extent.x+4,a.y+extent.y+3},color,opt.roundedTags?4.f:0.f);
    }
    if(opt.tagPostprocess) bloom.AddRectFilled({a.x-4,a.y-3},{a.x+extent.x+4,a.y+extent.y+3},opt.redBackground?IM_COL32(255,0,0,255):IM_COL32_BLACK,opt.roundedTags?4.f:0.f);
    Text(fonts,front,name,a,size,itemGlow);
   }
   continue;
  }
  if(!espOn) continue;
  if(e.invisible&&!s.invisibles)continue;
  if(!(e.player?s.players:e.animal?s.animals:e.mob?s.mobs:false)) continue;
  if(!e.onScreen) continue;
  ++stats.drawOnScreen;
  const auto glowBox=e.box;
  const auto b=UiBox(e);
  const float fraction=e.health && e.maxHealth && *e.maxHealth>0?std::clamp(*e.health / *e.maxHealth,0.f,1.f):1.f;
  const ImU32 healthColor=HealthColor(fraction);
  if(s.box&&frame.glow.living){GlowSlice(bloom,frame.glow.living,glowBox,frame.camera,espGlow);++stats.drawBoxes;}
  if(s.healthBar && e.health && e.maxHealth) {
   const float height=b.bottom-b.y+1, fillY=b.bottom+1-height*fraction;
   front.AddRectFilled({b.x-7,b.y-1},{b.x-3,b.bottom+2},IM_COL32(0,0,0,180));
   const ImU32 friendColor=IM_COL32(255,85,255,255);
   const ImU32 top=e.friendEntity?friendColor:s.healthByValue?healthColor:espGlow;
   const ImU32 bottom=e.friendEntity?friendColor:s.healthByValue?healthColor:espGlow;
   front.AddRectFilledMultiColor({b.x-6,b.y},{b.x-4,b.bottom+1},Alpha(top,76),Alpha(top,76),Alpha(bottom,76),Alpha(bottom,76));
   front.AddRectFilledMultiColor({b.x-6,fillY},{b.x-4,b.bottom+1},top,top,bottom,bottom);
   if(s.healthText) {
    char text[32]; std::snprintf(text,sizeof(text),"%.0f%%",fraction*100.f);
    const auto extent=fonts.Measure(text,12.f); Text(fonts,front,text,{b.x-10-extent.x,fillY-6},12.f,IM_COL32_WHITE);
   }
  }
  if(s.nametags && !e.name.empty()) {
   std::string name=s.formattedTags && !e.formattedName.empty()?e.formattedName:e.name;
   if(s.tagHealth && e.health) { char hp[48]; std::snprintf(hp,sizeof(hp)," [%.1f HP]",*e.health); name+=hp; }
   const float size=20.f*s.tagScale;
   const ImVec2 extent=fonts.Measure(Plain(name),size);
   const ImVec2 a((b.x+b.right-extent.x)*.5f,b.y-extent.y-7.f);
   if(s.tagBackground) {
    const ImU32 color=s.redBackground?IM_COL32(255,0,0,165):IM_COL32(10,10,10,130);
    front.AddRectFilled({a.x-4,a.y-3},{a.x+extent.x+4,a.y+extent.y+3},color,s.roundedTags?4.f:0.f);
   }
   if(s.tagPostprocess) bloom.AddRectFilled({a.x-4,a.y-3},{a.x+extent.x+4,a.y+extent.y+3},s.redBackground?IM_COL32(255,0,0,255):IM_COL32_BLACK,s.roundedTags?4.f:0.f);
   const ImU32 color=e.friendEntity?IM_COL32(255,85,255,255):s.redTags?IM_COL32(255,85,85,255):healthColor;
   Text(fonts,front,e.friendEntity?Plain(name):name,a,size,color);
  }
  if(s.heldItem && !e.heldItem.empty()) {
   const auto extent=fonts.Measure(Plain(e.heldItem),13.f);
   const ImVec2 a((b.x+b.right-extent.x)*.5f,b.bottom+7);
   front.AddRectFilled({a.x-3,a.y-2},{a.x+extent.x+3,a.y+extent.y+3},IM_COL32(10,10,10,130));
   Text(fonts,front,e.heldItem,a,13.f,IM_COL32_WHITE);
  }
  if(s.equipment) for(int i=0;i<4;++i) if(e.equipment[i].texture||e.equipmentDurability[i].total>0) {
   const float boxHeight=b.bottom-b.y;
   const float icon=std::clamp((boxHeight-9.f)/4.f,12.f,22.f);
   const float pitch=icon+3.f,totalHeight=icon+pitch*3.f;
   const float y=(b.y+b.bottom-totalHeight)*.5f+i*pitch;
   const float x=b.right+7;
   if(e.equipment[i].texture)ImageDraw(front,e.equipment[i],{x,y},{x+icon,y+icon});
   const auto durability=e.equipmentDurability[i];
   if(durability.total>0) {
    const float durabilityFraction=std::clamp(static_cast<float>(durability.remaining)/durability.total,0.f,1.f);
    front.AddRectFilled({x,y+icon-3},{x+icon,y+icon},IM_COL32(0,0,0,210),1.f);
    front.AddRectFilled({x+1,y+icon-2},{x+1+(icon-2)*durabilityFraction,y+icon-1},HealthColor(durabilityFraction),1.f);
    char percentage[16];std::snprintf(percentage,sizeof(percentage),"%.0f%%",durabilityFraction*100.f);
    const float fontSize=std::clamp(icon*.5f,8.f,11.f);
    Text(fonts,front,percentage,{x+icon+4,y+(icon-fontSize)*.5f},fontSize,HealthColor(durabilityFraction));
   }
  }
 }
 stats.Merge();
}
void Draw(const ui::FontManager& fonts,ImDrawList& front,ImDrawList& bloom) {
 std::shared_ptr<const Frame> frame;
 {std::lock_guard lock(frameMutex);const auto now=client::scheduler::Now();if(now>=updated&&now-updated<=250)frame=latest;}
 if(frame){DrawBacktrack(frame->camera,front);DrawFrame(*frame,Options(),fonts,front,bloom);}
}
}
