#include "features/visual/esp/EspCapture.hpp"
#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "render/GlDiagnostics.hpp"
#include "features/visual/esp/Esp.hpp"
#include "features/visual/esp/EspDetailsCache.hpp"
#include "features/visual/esp/EspDebug.hpp"
#include "features/visual/esp/EspGlowRenderer.hpp"
#include "game/MappingRepository.hpp"
#include "game/GuiAtlas.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "asm/AsmJvm.hpp"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <limits>

namespace client::features::esp {
namespace {
using namespace mapping;
DetailsCache details;
jobject cachedWorld=nullptr;
struct Selected { jobject object=nullptr;std::uint32_t bits=0; };
std::vector<Selected> selectedCache;
int selectedTick=std::numeric_limits<int>::min(),selectedPerspective=-1;
std::uint64_t selectedRevision=0;
void ResetSelection(JNIEnv* env) {
 for(auto& selected:selectedCache)if(selected.object&&env)ReleaseGlobal(env,selected.object);
 selectedCache.clear();selectedTick=std::numeric_limits<int>::min();selectedPerspective=-1;selectedRevision=0;
}
void ResetDetails(JNIEnv* env) {
 details.Clear();
 ResetSelection(env);
 if(cachedWorld&&env)ReleaseGlobal(env,cachedWorld);
}
struct LocalFrame {
 JNIEnv* env; bool valid;
 explicit LocalFrame(JNIEnv* e):env(e),valid(e->PushLocalFrame(4096)==JNI_OK) {}
 ~LocalFrame() { if(valid) env->PopLocalFrame(nullptr); }
};
std::optional<float> Float(JNIEnv* env,jobject object,std::string_view method) {
 auto r=Invoke(env,object,method);std::optional<float> value;
 if(r.ok && r.type==methods::Type::Float && std::isfinite(r.value.f)) value=r.value.f;
 r.Release(env);return value;
}
bool Boolean(JNIEnv* env,jobject object,std::string_view method) {
 auto r=Invoke(env,object,method);const bool value=r.ok && r.type==methods::Type::Boolean && r.value.z;r.Release(env);return value;
}
methods::Argument Int(int value) { methods::Argument a{methods::Type::Int};a.value.i=value;return a; }
bool Matrix(JNIEnv* env,std::string_view field,void* output,std::size_t size) {
 jobject buffer=StaticObject(env,field);if(!buffer) return false;
 if(env->GetDirectBufferCapacity(buffer)<16) return false;
 const void* address=env->GetDirectBufferAddress(buffer);
 return address && hotspot::ReadMemory(reinterpret_cast<std::uintptr_t>(address),output,size);
}
// Field offsets resolved once per capture against a single snapshot; entity
// loops then read oop+offset directly instead of resolving metadata per read.
struct EspLayout {
 std::optional<std::uint32_t> entityId,isDead;
 std::optional<std::uint32_t> posX,posY,posZ,lastX,lastY,lastZ;
 std::optional<std::uint32_t> boundingBox;
 std::optional<std::uint32_t> boxMinX,boxMinY,boxMinZ,boxMaxX,boxMaxY,boxMaxZ;
 std::optional<std::uint32_t> viewerX,viewerY,viewerZ,partialTicks,thirdPersonView;
 std::optional<std::uint32_t> listSize,listElements,itemStackSize,itemStackItem,itemStackDamage,itemMaxDamage;
};
EspLayout ResolveLayout(const classes::Snapshot& snapshot) {
 EspLayout l;
 auto f=[&](std::string_view key)->std::optional<std::uint32_t>{
  const auto info=mapping::ResolveField(key,snapshot);
  return info?std::optional<std::uint32_t>(info->offset):std::optional<std::uint32_t>{};
 };
 l.entityId=f("Entity.entityId");l.isDead=f("Entity.isDead");
 l.posX=f("Entity.posX");l.posY=f("Entity.posY");l.posZ=f("Entity.posZ");
 l.lastX=f("Entity.lastTickPosX");l.lastY=f("Entity.lastTickPosY");l.lastZ=f("Entity.lastTickPosZ");
 l.boundingBox=f("Entity.boundingBox");
 l.boxMinX=f("AxisAlignedBB.minX");l.boxMinY=f("AxisAlignedBB.minY");l.boxMinZ=f("AxisAlignedBB.minZ");
 l.boxMaxX=f("AxisAlignedBB.maxX");l.boxMaxY=f("AxisAlignedBB.maxY");l.boxMaxZ=f("AxisAlignedBB.maxZ");
 l.viewerX=f("RenderManager.viewerPosX");l.viewerY=f("RenderManager.viewerPosY");l.viewerZ=f("RenderManager.viewerPosZ");
 l.partialTicks=f("Timer.partialTicks");l.thirdPersonView=f("GameSettings.thirdPersonView");
 l.listSize=f("ArrayList.size");l.listElements=f("ArrayList.elements");
 l.itemStackSize=f("ItemStack.stackSize");l.itemStackItem=f("ItemStack.item");l.itemStackDamage=f("ItemStack.itemDamage");l.itemMaxDamage=f("Item.maxDamage");
 return l;
}
// Bit indices into InstanceMask targets; order must match InstanceTargets().
constexpr std::uint32_t kItem=1u<<0,kLiving=1u<<1,kPlayer=1u<<2,kAnimal=1u<<3,kMob=1u<<4;
std::vector<std::uintptr_t> InstanceTargets(const classes::Snapshot& snapshot) {
 static const char* aliases[]={"EntityItem","EntityLivingBase","EntityPlayer","EntityAnimal","EntityMob"};
 std::vector<std::uintptr_t> targets;targets.reserve(5);
 for(const auto* alias:aliases){const auto owner=mapping::Class(alias,snapshot);targets.push_back(owner?owner->klass:0);}
 return targets;
}
template<class T> std::optional<T> Rd(std::uintptr_t oop,std::optional<std::uint32_t> offset) {
 if(!offset) return {};
 return hotspot::Read<T>(oop+*offset);
}
std::optional<Vec3> Position(std::uintptr_t oop,std::optional<std::uint32_t> x,std::optional<std::uint32_t> y,std::optional<std::uint32_t> z) {
 const auto a=Rd<double>(oop,x),b=Rd<double>(oop,y),c=Rd<double>(oop,z);
 if(!a||!b||!c||!std::isfinite(*a)||!std::isfinite(*b)||!std::isfinite(*c)) return {};
 return Vec3{*a,*b,*c};
}
jobject FieldObject(JNIEnv* env,std::uintptr_t oop,std::optional<std::uint32_t> offset) {
 if(!offset) return nullptr;
 const auto ref=hotspot::ReadObjectReference(oop+*offset);
 return ref?mapping::Root(env,*ref):nullptr;
}
bool Finite3(double x,double y,double z) { return std::isfinite(x)&&std::isfinite(y)&&std::isfinite(z); }
// Outputs of the ASM gather kernels; zero-initialized before each call.
struct GatheredEntity {
 std::int32_t entityId=0;
 double posX=0,posY=0,posZ=0,lastX=0,lastY=0,lastZ=0;
 std::uintptr_t boundingBox=0;
};
struct GatheredBox { double minX=0,minY=0,minZ=0,maxX=0,maxY=0,maxZ=0; };
struct EspPlan {
 EspLayout layout;
 std::vector<asm_jvm::FieldOp> entityOps,boxOps;
 std::uint32_t refCompressed=0,refShift=0,refNullIsZero=1;
 std::uintptr_t refBase=0;
 bool entityReady=false,boxReady=false;
};
EspPlan ResolvePlan(const classes::Snapshot& snapshot) {
 EspPlan plan;plan.layout=ResolveLayout(snapshot);
 const auto& l=plan.layout;
 const auto constants=hotspot::GetConstants();
 const bool compressed=constants&&constants->compressedOops.value_or(false);
 const bool refOk=constants&&constants->compressedOops.has_value()&&
  (!compressed||(constants->narrowOopBase&&constants->narrowOopShift&&*constants->narrowOopShift<=16));
 if(constants){plan.refCompressed=compressed?1u:0u;plan.refBase=constants->narrowOopBase.value_or(0);plan.refShift=constants->narrowOopShift.value_or(0);}
 auto entityOp=[&](std::optional<std::uint32_t> off,std::size_t dest,std::uint32_t size,std::uint32_t kind){
  if(off)plan.entityOps.push_back({*off,static_cast<std::uint32_t>(dest),size,kind});
 };
 entityOp(l.entityId,offsetof(GatheredEntity,entityId),4,asm_jvm::OpCopy);
 entityOp(l.posX,offsetof(GatheredEntity,posX),8,asm_jvm::OpCopy);
 entityOp(l.posY,offsetof(GatheredEntity,posY),8,asm_jvm::OpCopy);
 entityOp(l.posZ,offsetof(GatheredEntity,posZ),8,asm_jvm::OpCopy);
 entityOp(l.lastX,offsetof(GatheredEntity,lastX),8,asm_jvm::OpCopy);
 entityOp(l.lastY,offsetof(GatheredEntity,lastY),8,asm_jvm::OpCopy);
 entityOp(l.lastZ,offsetof(GatheredEntity,lastZ),8,asm_jvm::OpCopy);
 // The ref op is only emitted when the oop decode parameters are usable;
 // otherwise boundingBox stays 0 and every entity is skipped exactly like
 // the C++ path does when ReadObjectReference fails.
 if(l.boundingBox&&refOk)entityOp(l.boundingBox,offsetof(GatheredEntity,boundingBox),8,asm_jvm::OpRef);
 auto boxOp=[&](std::optional<std::uint32_t> off,std::size_t dest){
  if(off)plan.boxOps.push_back({*off,static_cast<std::uint32_t>(dest),8,asm_jvm::OpCopy});
 };
 boxOp(l.boxMinX,offsetof(GatheredBox,minX));boxOp(l.boxMinY,offsetof(GatheredBox,minY));boxOp(l.boxMinZ,offsetof(GatheredBox,minZ));
 boxOp(l.boxMaxX,offsetof(GatheredBox,maxX));boxOp(l.boxMaxY,offsetof(GatheredBox,maxY));boxOp(l.boxMaxZ,offsetof(GatheredBox,maxZ));
 // Gather path is only taken when every skip-critical offset resolved;
 // otherwise the per-field C++ path below preserves the original behavior.
 plan.entityReady=l.posX&&l.posY&&l.posZ&&l.lastX&&l.lastY&&l.lastZ;
 plan.boxReady=l.boxMinX&&l.boxMinY&&l.boxMinZ&&l.boxMaxX&&l.boxMaxY&&l.boxMaxZ;
 return plan;
}
}
void UpdateNameTags() {
 struct Range { std::string_view key; std::optional<float> original; };
 static Range ranges[]={{"LivingRenderer.nameRange",{}},{"LivingRenderer.sneakNameRange",{}}};
 const bool hide=Options().enabled && Options().nametags;
 for(auto& range:ranges) {
  const auto address=StaticAddress(range.key);if(!address) continue;
  if(hide) {
   if(!range.original) range.original=hotspot::Read<float>(address);
   if(range.original) hotspot::WritePrimitive(address,0.f);
  } else if(range.original) {
   hotspot::WritePrimitive(address,*range.original);range.original.reset();
  }
 }
}
void Capture(JNIEnv* env,int width,int height) {
 render::diagnostics::Scope trace("ESP.capture");
 debug::Tick();
 const bool espOn=Options().enabled, itemEspOn=item_esp::Options().enabled;
 const auto backtrack=extras::Options(extras::Kind::AimBacktrack);const bool backtrackOn=backtrack.enabled&&backtrack.bedBox;
 if(!espOn && !itemEspOn && !backtrackOn) { debug::NoteExit(debug::kExitDisabled);ResetDetails(env);Publish({});return; }
 if(!env || env->ExceptionCheck()) {
  debug::NoteExit(!env?debug::kExitNoEnv:debug::kExitPendingException);
  if(env&&!env->ExceptionCheck())ResetDetails(env);Publish({});return;
 }
 LocalFrame refs(env);if(!refs.valid){debug::NoteExit(debug::kExitRefsFailed);return;}
 if(!mapping::Class("ActiveRenderInfo") || !mapping::Class("RenderHelper")) {
  static ULONGLONG lastScan=0;
  const auto now=client::scheduler::Now();
  if(!lastScan || now-lastScan>=5000) { lastScan=now; classes::Capture(env); }
 }
 const auto snapshot=classes::GetSnapshot();
 const auto plan=snapshot?ResolvePlan(*snapshot):EspPlan{};
 const auto& layout=plan.layout;
 const auto targets=snapshot?InstanceTargets(*snapshot):std::vector<std::uintptr_t>{};
 const bool gatherOk=plan.entityReady&&plan.boxReady;
 Frame frame;
 auto empty=[&] { ResetDetails(env);Publish({}); };
 const auto mc=StaticObject(env,"Minecraft.theMinecraft"); if(!mc) { debug::NoteExit(debug::kExitNoMinecraft);empty();return; }
 const auto world=Object(env,mc,"Minecraft.theWorld"), player=Object(env,mc,"Minecraft.thePlayer");
 if(!world) { debug::NoteExit(debug::kExitNoWorld);empty();return; }
 if(!player) { debug::NoteExit(debug::kExitNoPlayer);empty();return; }
 if(!cachedWorld || !env->IsSameObject(cachedWorld,world)) {
  ResetDetails(env);cachedWorld=Global(env,world);
  if(!cachedWorld){if(env->ExceptionCheck())env->ExceptionClear();debug::NoteExit(debug::kExitCachedWorldFail);empty();return;}
 }
 const auto manager=Object(env,mc,"Minecraft.renderManager"), timer=Object(env,mc,"Minecraft.timer");
 if(!manager) { debug::NoteExit(debug::kExitNoManager);empty();return; }
 if(!timer) { debug::NoteExit(debug::kExitNoTimer);empty();return; }
 auto& camera=frame.camera;
 if(!Matrix(env,"ActiveRenderInfo.MODELVIEW",camera.model.data(),sizeof(camera.model)) ||
    !Matrix(env,"ActiveRenderInfo.PROJECTION",camera.projection.data(),sizeof(camera.projection)) ||
    !Matrix(env,"ActiveRenderInfo.VIEWPORT",camera.viewport.data(),sizeof(camera.viewport))) {
  static bool warned=false;if(!warned) { warned=true;AOKI_LOG("ESP: ActiveRenderInfo direct buffers unavailable"); }
  debug::NoteExit(debug::kExitMatrixFetch);empty();return;
 }
 for(float v:camera.model) if(!std::isfinite(v)) { debug::NoteExit(debug::kExitMatrixNonFinite);empty();return; }
 for(float v:camera.projection) if(!std::isfinite(v)) { debug::NoteExit(debug::kExitMatrixNonFinite);empty();return; }
 const auto managerOop=mapping::Oop(manager);
 const auto origin=Position(managerOop,layout.viewerX,layout.viewerY,layout.viewerZ);
 if(!origin) { debug::NoteExit(debug::kExitNoOrigin);empty();return; }camera.origin=*origin;
 camera.partial=std::clamp(Rd<float>(mapping::Oop(timer),layout.partialTicks).value_or(1.f),0.f,1.f);camera.framebufferHeight=height;
 if(camera.viewport[2]<=0||camera.viewport[3]<=0||camera.viewport[2]>width*2||camera.viewport[3]>height*2) { debug::NoteExit(debug::kExitBadViewport);empty();return; }
 if(!espOn&&!itemEspOn){details.Clear();Publish(std::move(frame));return;}
 const auto list=Object(env,world,"World.loadedEntityList");if(!list||!Instance(list,"ArrayList")) { debug::NoteExit(debug::kExitNoEntityList);empty();return; }
 const auto listOop=mapping::Oop(list);
 const auto elements=static_cast<jobjectArray>(FieldObject(env,listOop,layout.listElements));
 const auto count=Rd<int>(listOop,layout.listSize);if(!elements||!count||*count<0||*count>100000) { debug::NoteExit(debug::kExitBadEntityArray);empty();return; }
 const int length=std::min(*count,env->GetArrayLength(elements));
 const auto settings=Object(env,mc,"Minecraft.gameSettings");
 const int perspective=Rd<int>(mapping::Oop(settings),layout.thirdPersonView).value_or(0);
 debug::FrameStats stats;
 const auto selectionRevision=OptionsRevision()^(item_esp::OptionsRevision()<<16);
 const auto playerTick=mapping::Read<int>(player,"Entity.ticksExisted");
 const bool rebuildSelection=!playerTick||*playerTick!=selectedTick||perspective!=selectedPerspective||selectionRevision!=selectedRevision;
 bool unknownClass=false;
 if(rebuildSelection) {
  ++stats.scanFrames;
  ResetSelection(env);selectedCache.reserve(std::min(length,1024));
  for(int i=0;i<length;++i) {
   ++stats.total;
   const auto object=env->GetObjectArrayElement(elements,i);if(!object) continue;
   const auto info=InstanceMask(object,targets);
   if(!info.resolved) { ++stats.classFail;unknownClass=true;env->DeleteLocalRef(object);continue; }
   if(!info.bits) ++stats.maskZero;
   if(info.bits&kLiving)++stats.living;
   if(info.bits&kItem)++stats.item;
   if(info.bits&kPlayer)++stats.player;
   if(info.bits&kAnimal)++stats.animal;
   if(info.bits&kMob)++stats.mob;
   const bool isItem=itemEspOn && (info.bits&kItem);
   const bool isLiving=espOn && (info.bits&kLiving);
   const auto oop=mapping::Oop(object);
   if(!isLiving && !isItem) { ++stats.notTarget;env->DeleteLocalRef(object);continue; }
   if(Rd<bool>(oop,layout.isDead).value_or(true)) { ++stats.dead;env->DeleteLocalRef(object);continue; }
   if(perspective==0 && env->IsSameObject(object,player)) { ++stats.self;env->DeleteLocalRef(object);continue; }
   const bool valid=isItem || (Options().players && (info.bits&kPlayer)) ||
       (Options().animals && (info.bits&kAnimal)) || (Options().mobs && (info.bits&kMob));
   if(valid) {
    if(const auto global=Global(env,object)){++stats.valid;selectedCache.push_back({global,info.bits});}
   }
   env->DeleteLocalRef(object);
  }
  selectedTick=playerTick.value_or(std::numeric_limits<int>::min());selectedPerspective=perspective;selectedRevision=selectionRevision;
 }
 stats.selected=selectedCache.size();
 const auto& entities=selectedCache;
 if(unknownClass) {
  static ULONGLONG previousRefresh=0;
  const auto now=client::scheduler::Now();
  if(!previousRefresh || now-previousRefresh>=5000) { previousRefresh=now;classes::Capture(env); }
 }
 static game::GuiAtlas atlas;
 if(!render::gl.BindFramebuffer && !render::gl.Load()) { debug::NoteExit(debug::kExitGlUnavailable);stats.Merge();empty();return; }
 const auto captureTime=client::scheduler::Now(),revision=selectionRevision;
 const bool refresh=details.Due(captureTime,revision);
 std::unordered_map<int,Details> nextDetails;
 bool atlasAttempted=false,atlasReady=false;
 auto ensureAtlas=[&] {
  if(!atlasAttempted){
   atlasAttempted=true;
   atlasReady=Options().equipment&&atlas.Begin(env,mc);
  }
  return atlasReady;
 };
 struct EndAtlas { game::GuiAtlas& atlas; ~EndAtlas() { atlas.End(); } } end{atlas};
 struct GlowEntry { jobject object=nullptr;bool item=false;Vec3 position,last; };
 std::vector<GlowEntry> glowEntries;glowEntries.reserve(std::min<std::size_t>(entities.size(),96));
 auto accept=[&](jobject object,Entity&& entity) {
  const float boxWidth=entity.box.right-entity.box.x,boxHeight=entity.box.bottom-entity.box.y;
  const bool glowEnabled=entity.isItem?item_esp::Options().box:Options().box;
  if(glowEnabled&&boxWidth>0.f&&boxHeight>0.f)
   glowEntries.push_back({object,entity.isItem,entity.position,entity.last});
  frame.entities.push_back(std::move(entity));
 };
 for(const auto& entry:entities) {
  const auto object=entry.object;const auto bits=entry.bits;
  Entity e;
  e.isItem=(bits&kItem)!=0;
  e.player=(bits&kPlayer)!=0; e.animal=(bits&kAnimal)!=0;e.mob=(bits&kMob)!=0;
  const auto oop=mapping::Oop(object);
  std::optional<Vec3> position,last,minv,maxv;
  if(gatherOk) {
   GatheredEntity ge{};GatheredBox gb{};
   asm_jvm::GatherJob job{};
   job.oop=oop;job.ops=plan.entityOps.data();job.count=static_cast<std::uint32_t>(plan.entityOps.size());
   job.out=&ge;job.outSize=static_cast<std::uint32_t>(sizeof(ge));
   job.refCompressed=plan.refCompressed;job.refBase=plan.refBase;job.refShift=plan.refShift;job.refNullIsZero=plan.refNullIsZero;
   const bool gathered=asm_jvm::GatherFields(&job,1);
   bool ok=gathered&&ge.boundingBox!=0;
   if(gathered&&!ge.boundingBox)++stats.gatherRefNull;
   if(ok){
    job.oop=ge.boundingBox;job.ops=plan.boxOps.data();job.count=static_cast<std::uint32_t>(plan.boxOps.size());
    job.out=&gb;job.outSize=static_cast<std::uint32_t>(sizeof(gb));
    ok=asm_jvm::GatherFields(&job,2);
   }
   if(ok){
    e.id=ge.entityId;
    if(Finite3(ge.posX,ge.posY,ge.posZ))position=Vec3{ge.posX,ge.posY,ge.posZ};
    if(Finite3(ge.lastX,ge.lastY,ge.lastZ))last=Vec3{ge.lastX,ge.lastY,ge.lastZ};
    if(Finite3(gb.minX,gb.minY,gb.minZ))minv=Vec3{gb.minX,gb.minY,gb.minZ};
    if(Finite3(gb.maxX,gb.maxY,gb.maxZ))maxv=Vec3{gb.maxX,gb.maxY,gb.maxZ};
   }
  } else {
   ++stats.gatherFallback;
   e.id=Rd<int>(oop,layout.entityId).value_or(0);
   position=Position(oop,layout.posX,layout.posY,layout.posZ);
   last=Position(oop,layout.lastX,layout.lastY,layout.lastZ);
   const auto box=FieldObject(env,oop,layout.boundingBox);
   if(box){const auto boxOop=mapping::Oop(box);minv=Position(boxOop,layout.boxMinX,layout.boxMinY,layout.boxMinZ);maxv=Position(boxOop,layout.boxMaxX,layout.boxMaxY,layout.boxMaxZ);}
  }
  if(!position||!last||!minv||!maxv) { ++stats.detailSkipped;continue; }
  if(maxv->x<=minv->x||maxv->y<=minv->y||maxv->z<=minv->z) { ++stats.detailSkipped;continue; }
  e.position=*position;e.last=*last;e.bounds={*minv,*maxv};
  // All later Java calls use rooted handles; raw heap addresses are not retained.
  const auto previous=details.Find(e.id);
  e.sneaking=!e.isItem && (refresh?Boolean(env,object,"Entity.isSneaking"):previous?previous->entity.sneaking:false);
  const auto projected=Project(e.bounds,e.position,e.last,e.sneaking,camera);
  ++stats.projCalls;
  if(!projected) { ++stats.projRejected;continue; }
  ++stats.projAccepted;
  e.box=*projected;
  e.onScreen=true;
  ++stats.onScreen;
  if(!refresh) {
   if(!previous||previous->hidden)continue;
   Entity reused=previous->entity;
   reused.bounds=e.bounds;reused.position=e.position;reused.last=e.last;
   reused.player=e.player;reused.animal=e.animal;reused.mob=e.mob;reused.isItem=e.isItem;
   reused.sneaking=e.sneaking;
   reused.box=e.box;
   reused.onScreen=true;
   accept(object,std::move(reused));continue;
  }
  if(e.isItem) {
   std::string itemName;
   auto stack=Invoke(env,object,"EntityItem.getEntityItem");
   if(stack.ok && stack.value.l) {
    auto name=String(env,stack.value.l,"ItemStack.displayName");
    if(name && !name->empty()) {
     itemName=*name;
     if(item_esp::Options().formattedTags) e.formattedName=*name;
    }
    const auto stackSize=Rd<int>(mapping::Oop(stack.value.l),layout.itemStackSize).value_or(1);
    if(stackSize>1) {
     itemName+=" x"+std::to_string(stackSize);
     if(!e.formattedName.empty()) e.formattedName+=" §7x"+std::to_string(stackSize);
    }
   }
   stack.Release(env);
   if(itemName.empty()) {
    auto display=Invoke(env,object,"Entity.getDisplayName");
    if(display.ok && display.value.l) {
     itemName=String(env,display.value.l,"ChatComponentBase.unformatted").value_or("");
     if(item_esp::Options().formattedTags) e.formattedName=String(env,display.value.l,"ChatComponentBase.formatted").value_or("");
    }
    display.Release(env);
   }
   if(itemName.empty()) itemName=String(env,object,"Entity.getName").value_or("Item");
   e.name=std::move(itemName);
   nextDetails[e.id]={e,false};accept(object,std::move(e));
   continue;
  }
  e.invisible=Boolean(env,object,"Entity.isInvisible");
  if(e.invisible&&!Options().invisibles){nextDetails[e.id]={e,true};continue;}
  const auto identifier=String(env,object,"Entity.getName").value_or("");
  e.name=identifier;
  auto display=Invoke(env,object,"Entity.getDisplayName");
  if(display.ok && display.value.l) {
   e.name=String(env,display.value.l,"ChatComponentBase.unformatted").value_or(identifier);
   if(Options().formattedTags) e.formattedName=String(env,display.value.l,"ChatComponentBase.formatted").value_or("");
  }
  display.Release(env);
  if(e.player && e.name.find("[NPC")!=std::string::npos){nextDetails[e.id]={e,true};continue;}
  e.friendEntity=!identifier.empty() && (","+Options().friends+",").find(","+identifier+",")!=std::string::npos;
  e.health=Float(env,object,"EntityLivingBase.getHealth"); e.maxHealth=Float(env,object,"EntityLivingBase.getMaxHealth");
  if(Options().heldItem) {
   auto held=Invoke(env,object,"EntityLivingBase.getHeldItem");
   if(held.ok && held.value.l) {
    e.heldItem=String(env,held.value.l,"ItemStack.displayName").value_or("");
    const int itemCount=std::max(0,Rd<int>(mapping::Oop(held.value.l),layout.itemStackSize).value_or(1));
    if(!e.heldItem.empty()) {
     e.heldItem+=" §7x";
     e.heldItem+=std::to_string(itemCount);
    }
   }
   held.Release(env);
  }
  if(Options().equipment) {
   const bool renderIcons=ensureAtlas();
   for(int i=0;i<4;++i) {
    auto stack=Invoke(env,object,"EntityLivingBase.getArmor",{Int(3-i)});
    if(stack.ok && stack.value.l) {
     if(renderIcons)e.equipment[i]=atlas.Item(stack.value.l);
     const auto stackOop=mapping::Oop(stack.value.l);
     const int damage=std::max(0,Rd<int>(stackOop,layout.itemStackDamage).value_or(0));
     const auto item=FieldObject(env,stackOop,layout.itemStackItem);
     const int maximum=item?std::max(0,Rd<int>(mapping::Oop(item),layout.itemMaxDamage).value_or(0)):0;
     if(maximum>0)e.equipmentDurability[i]={std::clamp(maximum-damage,0,maximum),maximum};
    }
    stack.Release(env);
   }
  }
  nextDetails[e.id]={e,false};accept(object,std::move(e));
 }
 // Finish the occasional item-atlas work before the per-frame world mask takes
 // ownership of legacy matrices/client arrays and the GlStateManager cache.
 atlas.End();
 if(!glowEntries.empty()) {
  static std::size_t glowBudget=48;
  if(glowEntries.size()>glowBudget) {
   std::vector<GlowEntry> living,items;living.reserve(glowEntries.size());items.reserve(glowEntries.size());
   for(auto& entry:glowEntries)(entry.item?items:living).push_back(entry);
   const std::size_t total=living.size()+items.size();
   std::size_t livingBudget=items.empty()?glowBudget:living.empty()?0:std::clamp<std::size_t>((glowBudget*living.size()+total/2)/total,1,glowBudget-1);
   const std::size_t itemBudget=glowBudget-livingBudget;
   std::vector<GlowEntry> selected;selected.reserve(glowBudget);
   auto append=[&](const std::vector<GlowEntry>& source,std::size_t take){
    take=std::min(take,source.size());
    selected.insert(selected.end(),source.begin(),source.begin()+take);
   };
   append(living,livingBudget);append(items,itemBudget);glowEntries=std::move(selected);
  }
  const bool livingMask=std::any_of(glowEntries.begin(),glowEntries.end(),[](const GlowEntry& e){return !e.item;});
  const bool itemMask=std::any_of(glowEntries.begin(),glowEntries.end(),[](const GlowEntry& e){return e.item;});
  static EspGlowRenderer glowRenderer;
  const auto glowStart=std::chrono::steady_clock::now();
  std::size_t rendered=0;
  const auto& itemOptions=item_esp::Options();
  const bool shareMasks=livingMask&&itemMask&&!Options().customColor&&!Options().rainbow&&
   !itemOptions.customColor&&!itemOptions.rainbow;
  if(glowRenderer.Begin(env,mc,camera,livingMask,itemMask,shareMasks)) {
   for(const bool itemsPass:{false,true})for(const auto& entry:glowEntries)if(entry.item==itemsPass)
    rendered+=glowRenderer.Draw(entry.object,entry.item,entry.position,entry.last)?1u:0u;
   frame.glow.living=glowRenderer.LivingTexture();
   frame.glow.items=glowRenderer.ItemTexture();
   glowRenderer.End();
  }
  const float glowMs=std::chrono::duration<float,std::milli>(std::chrono::steady_clock::now()-glowStart).count();
  // Keep the duplicate model pass inside a small CPU budget. The capped set
  // stays stable so entities do not blink as a round-robin cursor advances.
  if(glowMs>2.5f&&glowBudget>16)glowBudget=std::max<std::size_t>(16,glowBudget-8);
  else if(glowMs<1.25f&&rendered==glowEntries.size()&&glowEntries.size()>=glowBudget&&glowBudget<96)glowBudget+=4;
 }
 if(refresh)details.Commit(captureTime,revision,std::move(nextDetails));
 static bool logged=false;
 if(!logged && !frame.entities.empty()) { logged=true;AOKI_LOG("ESP: matrices + %zu projected entities captured; atlas=%s",frame.entities.size(),atlasReady?"ready":"unavailable"); }
 stats.Merge();
 debug::AddPublished(frame.entities.size());
 Publish(std::move(frame));
}
}
