#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/visual/spotify_widget/SpotifySession.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include <Windows.h>
#include <roapi.h>
#include <process.h>
#include <atomic>

namespace client::features::spotify {
namespace {
std::atomic<bool> started{false};

unsigned __stdcall Worker(void*) {
 const HRESULT apartment=RoInitialize(RO_INIT_MULTITHREADED);
 AOKI_LOG("[SpotifyWidget] media worker started apartment=0x%08X",static_cast<unsigned>(apartment));
 client::scheduler::Cursor refreshCursor;
 bool firstRefresh=true;
 while(true) {
  if(Options().enabled) {
   const unsigned actions=TakeRequests();
   if(actions&static_cast<unsigned>(Action::Previous))session::Execute(Action::Previous);
   if(actions&static_cast<unsigned>(Action::Toggle))session::Execute(Action::Toggle);
   if(actions&static_cast<unsigned>(Action::Next))session::Execute(Action::Next);
   if(firstRefresh||client::scheduler::Consume(client::scheduler::Task::SpotifyRefresh,refreshCursor)){firstRefresh=false;if(const auto state=session::Query())Publish(*state);}
  } else {TakeRequests();firstRefresh=true;}
  Sleep(50);
 }
}
}

void PollRuntime() {
 const bool enabled=Options().enabled;
 client::scheduler::Configure(client::scheduler::Task::SpotifyRefresh,enabled,600);
 if(!enabled||started.exchange(true))return;
 const auto thread=reinterpret_cast<HANDLE>(_beginthreadex(nullptr,0,&Worker,nullptr,0,nullptr));
 if(thread)CloseHandle(thread);else {started=false;auto value=Options();value.enabled=false;SetOptions(value);AOKI_LOG("[SpotifyWidget] media worker creation failed");}
}
}
