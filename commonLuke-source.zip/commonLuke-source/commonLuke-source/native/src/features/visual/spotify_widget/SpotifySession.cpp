#include "features/visual/spotify_widget/SpotifySession.hpp"
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Storage.Streams.h>
#include <algorithm>
#include <limits>

namespace client::features::spotify::session {
namespace {
using namespace winrt;
using namespace Windows::Media::Control;
using namespace Windows::Storage::Streams;

std::vector<std::uint8_t> Artwork(const IRandomAccessStreamReference& reference) {
 if(!reference)return {};
 const auto stream=reference.OpenReadAsync().get();if(!stream)return {};
 const auto size=stream.Size();if(!size||size>16*1024*1024||size>std::numeric_limits<std::uint32_t>::max())return {};
 DataReader reader(stream.GetInputStreamAt(0));
 const auto loaded=reader.LoadAsync(static_cast<std::uint32_t>(size)).get();
 std::vector<std::uint8_t> bytes(loaded);if(loaded)reader.ReadBytes(bytes);return bytes;
}

std::uint64_t Hash(const std::vector<std::uint8_t>& bytes) {
 std::uint64_t value=1469598103934665603ull;
 for(const auto byte:bytes){value^=byte;value*=1099511628211ull;}return value;
}
}

std::optional<MediaState> QueryImpl(bool artwork) {
 try {
  MediaState state;
  const auto manager=GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();if(!manager)return state;
  const auto current=manager.GetCurrentSession();if(!current)return state;
  state.available=true;state.source=winrt::to_string(current.SourceAppUserModelId());
  if(const auto properties=current.TryGetMediaPropertiesAsync().get()) {
   state.title=winrt::to_string(properties.Title());state.artist=winrt::to_string(properties.Artist());
   if(artwork){state.artwork=Artwork(properties.Thumbnail());state.artworkHash=Hash(state.artwork);}
  }
  if(state.title.empty())state.title="Unknown track";if(state.artist.empty())state.artist="Unknown artist";
  if(const auto playback=current.GetPlaybackInfo())
   state.playing=playback.PlaybackStatus()==GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing;
  if(const auto timeline=current.GetTimelineProperties()) {
   const auto start=timeline.StartTime().count(),end=timeline.EndTime().count(),position=timeline.Position().count();
   state.durationMs=std::max<std::int64_t>(0,(end-start)/10000);
   state.positionMs=std::clamp<std::int64_t>((position-start)/10000,0,state.durationMs);
  }
  return state;
 } catch(...) {return std::nullopt;}
}

std::optional<MediaState> Query() { return QueryImpl(true); }
std::optional<MediaState> QueryPlayback() { return QueryImpl(false); }

bool Execute(Action action) {
 try {
  const auto manager=GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();if(!manager)return false;
  const auto current=manager.GetCurrentSession();if(!current)return false;
  switch(action) {
   case Action::Previous:return current.TrySkipPreviousAsync().get();
   case Action::Toggle:return current.TryTogglePlayPauseAsync().get();
   case Action::Next:return current.TrySkipNextAsync().get();
  }
 } catch(...) {}
 return false;
}
}
