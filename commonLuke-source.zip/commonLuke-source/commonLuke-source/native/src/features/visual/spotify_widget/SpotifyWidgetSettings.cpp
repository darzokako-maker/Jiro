#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <atomic>
#include <mutex>

namespace client::features::spotify {
namespace {
std::mutex settingsMutex;
Settings settings;
std::atomic<std::shared_ptr<const MediaState>> media{std::make_shared<const MediaState>()};
std::atomic<unsigned> requests{0};
}

Settings Options(){std::lock_guard lock(settingsMutex);return settings;}
void SetOptions(Settings value){
 bool previous;{std::lock_guard lock(settingsMutex);previous=settings.enabled;settings=value;}
 if(!value.enabled)media.store(std::make_shared<const MediaState>());
 modules::StateChanged(modules::SpotifyWidget,previous,value.enabled);
}
std::shared_ptr<const MediaState> Snapshot(){return media.load();}
void Publish(MediaState state){media.store(std::make_shared<const MediaState>(std::move(state)));}
void Request(Action action){requests.fetch_or(static_cast<unsigned>(action));}
unsigned TakeRequests(){return requests.exchange(0);}
}
