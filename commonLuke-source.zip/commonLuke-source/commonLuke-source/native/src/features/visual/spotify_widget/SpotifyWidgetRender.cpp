#include "features/visual/spotify_widget/SpotifyWidget.hpp"
#include "render/Texture.hpp"
#include "render/RoundedPanel.hpp"
#include "ui/font/FontManager.hpp"
#include "ui/animation/AnimatedNumber.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "ui/clickgui/ReferencePrimitives.hpp"
#include "ui/hud/HudLayout.hpp"
#include "ui/hud/HudState.hpp"
#include <Windows.h>
#include <imgui.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <vector>

namespace client::features::spotify {
namespace {
GLuint texture=0;std::uint64_t textureHash=0;HGLRC textureContext=nullptr;ImU32 accent=IM_COL32(255,190,197,255);ImVec2 artUv0{0,0},artUv1{1,1};

bool Inside(ImVec2 point,ImVec2 a,ImVec2 b){return point.x>=a.x&&point.y>=a.y&&point.x<=b.x&&point.y<=b.y;}
ImU32 Alpha(ImU32 color,float alpha){return (color&0x00ffffff)|(static_cast<ImU32>(std::clamp(alpha,0.f,1.f)*((color>>24)&255))<<24);}
ImU32 Lighten(ImU32 color,float amount){const auto channel=[&](int shift){const float value=static_cast<float>((color>>shift)&255);return static_cast<ImU32>(std::clamp(value+(255-value)*amount,0.f,255.f));};return channel(0)|(channel(8)<<8)|(channel(16)<<16)|(color&0xff000000);}

void SmoothRect(ImDrawList& list,ImVec2 a,ImVec2 b,float radius,ImU32 color) {
 radius=std::min(radius,std::min((b.x-a.x)*.5f,(b.y-a.y)*.5f));constexpr int segments=24;
 list.PathArcTo({b.x-radius,a.y+radius},radius,-1.57079633f,0,segments);
 list.PathArcTo({b.x-radius,b.y-radius},radius,0,1.57079633f,segments);
 list.PathArcTo({a.x+radius,b.y-radius},radius,1.57079633f,3.14159265f,segments);
 list.PathArcTo({a.x+radius,a.y+radius},radius,3.14159265f,4.71238898f,segments);
 list.PathFillConvex(color);
}
std::string Shorten(const ui::FontManager& fonts,std::string text,float width,float size,ui::FontWeight weight) {
 if(fonts.Measure(text,size,weight).x<=width)return text;
 while(!text.empty()&&fonts.Measure(text+"...",size,weight).x>width){auto at=text.size()-1;while(at>0&&(static_cast<unsigned char>(text[at])&0xc0)==0x80)--at;text.erase(at);}return text+"...";
}
ImU32 Accent(const render::DecodedImage& image) {
 double r=0,g=0,b=0,weight=0;
 for(std::size_t i=0;i+3<image.pixels.size();i+=16) {
  const double pr=image.pixels[i],pg=image.pixels[i+1],pb=image.pixels[i+2],alpha=image.pixels[i+3]/255.;
  const double high=std::max({pr,pg,pb}),low=std::min({pr,pg,pb}),saturation=(high-low)/std::max(1.,high);
  const double sample=alpha*(.25+saturation);if(high<24||high>248||sample<=0)continue;r+=pr*sample;g+=pg*sample;b+=pb*sample;weight+=sample;
 }
 if(weight<=0)return IM_COL32(255,190,197,255);
 auto pastel=[&](double value){return static_cast<int>(std::clamp(value/weight*.48+255*.52,92.,244.));};
 return IM_COL32(pastel(r),pastel(g),pastel(b),255);
}
void RefreshTexture(const MediaState& state) {
 const auto context=wglGetCurrentContext();
 if(context!=textureContext){texture=0;textureHash=0;textureContext=context;}
 if(state.artworkHash==textureHash)return;
 if(texture){glDeleteTextures(1,&texture);texture=0;}textureHash=state.artworkHash;
 const auto image=render::DecodeImageRgba(state.artwork);if(image.pixels.empty())return;
 artUv0={0,0};artUv1={1,1};constexpr float targetRatio=314.f/151.f;const float sourceRatio=static_cast<float>(image.width)/image.height;
 if(sourceRatio>targetRatio){const float visible=targetRatio/sourceRatio;artUv0.x=(1-visible)*.5f;artUv1.x=1-artUv0.x;}
 else {const float visible=sourceRatio/targetRatio;artUv0.y=(1-visible)*.5f;artUv1.y=1-artUv0.y;}
 accent=Accent(image);texture=render::UploadRgba(image.pixels,image.width,image.height);
}
void SpotifyMark(ImDrawList& list,ImVec2 center,float scale) {
 const float radius=8*scale;const ImVec2 topLeft{center.x-radius,center.y-radius};
 if(!ui::clickgui::ReferenceRectangle(list,topLeft,radius*2,radius*2,radius,1.f,IM_COL32_WHITE))list.AddCircleFilled(center,radius,IM_COL32_WHITE,64);
 for(int i=0;i<3;++i){const float arcRadius=(5.2f-i*1.55f)*scale;list.PathArcTo({center.x-.7f*scale,center.y+(2.f-i*1.1f)*scale},arcRadius,3.85f,5.75f,28);list.PathStroke(IM_COL32(23,23,23,255),0,std::max(1.f,1.2f*scale));}
}
void Previous(ImDrawList& list,ImVec2 center,ImU32 color,float scale) {
 list.AddRectFilled({center.x-7*scale,center.y-6*scale},{center.x-5*scale,center.y+6*scale},color,scale);ImVec2 points[3]{{center.x-4*scale,center.y},{center.x+6*scale,center.y-6*scale},{center.x+6*scale,center.y+6*scale}};list.AddConvexPolyFilled(points,3,color);
}
void Next(ImDrawList& list,ImVec2 center,ImU32 color,float scale) {
 ImVec2 points[3]{{center.x+4*scale,center.y},{center.x-6*scale,center.y-6*scale},{center.x-6*scale,center.y+6*scale}};list.AddConvexPolyFilled(points,3,color);list.AddRectFilled({center.x+5*scale,center.y-6*scale},{center.x+7*scale,center.y+6*scale},color,scale);
}
void FilledWave(ImDrawList& list,float left,float right,float y,float scale,float phase,ImU32 color) {
 if(right<=left+.5f)return;
 const int segments=std::max(3,static_cast<int>((right-left)/(1.8f*scale)));std::vector<ImVec2> points;points.reserve(segments+1);
 for(int i=0;i<=segments;++i){const float t=static_cast<float>(i)/segments,x=left+(right-left)*t,envelope=.35f+.65f*std::sin(3.14159265f*t);points.push_back({x,y+std::sin((x-left)/(16.f*scale)*6.2831853f+phase)*3.8f*scale*envelope});}
 const float half=1.35f*scale;
 for(int i=0;i<segments;++i){const auto p=points[i],q=points[i+1];const float dx=q.x-p.x,dy=q.y-p.y,length=std::max(.001f,std::sqrt(dx*dx+dy*dy)),nx=-dy/length*half,ny=dx/length*half;ImVec2 quad[4]{{p.x+nx,p.y+ny},{q.x+nx,q.y+ny},{q.x-nx,q.y-ny},{p.x-nx,p.y-ny}};list.AddConvexPolyFilled(quad,4,color);}
 for(const auto p:points)list.AddCircleFilled(p,half,color,8);
}
}

void Draw(const ui::FontManager& fonts,ImDrawList& foreground,float width,float height,std::vector<render::RoundedPanel>& panels) {
 const auto enabled=Options().enabled;const auto state=Snapshot();
 static ui::Spring revealMotion,trackMotion,progressMotion,playMotion,playHoverMotion,playPressMotion,progressHoverMotion,previousHoverMotion,nextHoverMotion;
 static bool wasVisible=false;static std::uint64_t trackKey=0;static std::shared_ptr<const MediaState> observed;static std::int64_t observedPosition=0;static std::chrono::steady_clock::time_point observedAt;static float wavePhase=0;
 if(!enabled||!state||!state->available){wasVisible=false;observed.reset();return;}
 constexpr float scale=.936f,cardWidth=314*scale,cardHeight=151*scale;
 if(width<cardWidth+16||height<cardHeight+16)return;
 const auto now=std::chrono::steady_clock::now();const float dt=std::clamp(ImGui::GetIO().DeltaTime,0.f,.05f);
 const std::uint64_t nextTrackKey=state->artworkHash^(static_cast<std::uint64_t>(std::hash<std::string>{}(state->title+'\n'+state->artist))<<1);
 if(!wasVisible){revealMotion.Reset(0);trackMotion.Reset(0);progressMotion.Reset(0);playMotion.Reset(state->playing?1.f:0.f);playHoverMotion.Reset(0);playPressMotion.Reset(0);progressHoverMotion.Reset(0);previousHoverMotion.Reset(0);nextHoverMotion.Reset(0);trackKey=nextTrackKey;wavePhase=0;wasVisible=true;}
 if(nextTrackKey!=trackKey){trackKey=nextTrackKey;trackMotion.Reset(0);progressMotion.Reset(0);}
 if(observed.get()!=state.get()){observed=state;observedPosition=state->positionMs;observedAt=now;}
 double predicted=static_cast<double>(observedPosition);if(state->playing)predicted+=std::chrono::duration<double,std::milli>(now-observedAt).count();predicted=std::clamp(predicted,0.,static_cast<double>(std::max<std::int64_t>(0,state->durationMs)));
 const float actualProgress=state->durationMs>0?static_cast<float>(predicted/state->durationMs):0.f;
 const float reveal=std::clamp(revealMotion.Update(1,dt,190,24),0.f,1.f),content=std::clamp(trackMotion.Update(1,dt,155,22),0.f,1.f),progress=std::clamp(progressMotion.Update(actualProgress,dt,115,21),0.f,1.f),playing=std::clamp(playMotion.Update(state->playing?1.f:0.f,dt,260,29),0.f,1.f);
 wavePhase=std::fmod(wavePhase+dt*(state->playing?4.4f:1.05f),6.2831853f);
 ui::hud_layout::Report(ui::hud_layout::Element::Spotify,cardWidth,cardHeight);
 const auto position=ui::hud_layout::Position(ui::hud_layout::Element::Spotify,width,height);
 RefreshTexture(*state);const ImVec2 baseA{position.x,position.y},baseB{baseA.x+cardWidth,baseA.y+cardHeight},center{(baseA.x+baseB.x)*.5f,(baseA.y+baseB.y)*.5f};
 const float entrance=1-std::pow(1-reveal,3.f),visualScale=.94f+.06f*entrance,yShift=(1-entrance)*7.f,drawScale=scale*visualScale;
 const ImVec2 a{center.x+(baseA.x-center.x)*visualScale,center.y+(baseA.y-center.y)*visualScale+yShift},b{center.x+(baseB.x-center.x)*visualScale,center.y+(baseB.y-center.y)*visualScale+yShift};
 const float drawWidth=b.x-a.x,drawHeight=b.y-a.y,drawRadius=25*drawScale;
 // Use the exact same neutral panel shadow/blur path as the watermark.
 render::RoundedPanel panel{a.x,a.y,drawWidth,drawHeight,drawRadius};panel.opacity=entrance;panels.push_back(panel);
 const float imageOpacity=entrance*(.58f+.42f*content);const ImU32 imageTint=IM_COL32(255,255,255,static_cast<int>(255*imageOpacity));
 if(texture){if(!ui::clickgui::ReferenceImageRounded(foreground,texture,a,drawWidth,drawHeight,drawRadius,artUv0,artUv1,imageTint))foreground.AddImageRounded(static_cast<ImTextureID>(texture),a,b,artUv0,artUv1,imageTint,drawRadius);}
 else if(!ui::clickgui::ReferenceRectangle(foreground,a,drawWidth,drawHeight,drawRadius,1.f,Alpha(IM_COL32(39,31,47,255),entrance)))SmoothRect(foreground,a,b,drawRadius,Alpha(IM_COL32(39,31,47,255),entrance));
 if(!ui::clickgui::ReferenceRectangle(foreground,a,drawWidth,drawHeight,drawRadius,1.f,IM_COL32(0,0,0,static_cast<int>(92*entrance))))SmoothRect(foreground,a,b,drawRadius,IM_COL32(0,0,0,static_cast<int>(92*entrance)));
 SpotifyMark(foreground,{a.x+24*drawScale,a.y+29*drawScale},drawScale);
 const auto title=Shorten(fonts,state->title,190*drawScale,15.5f*drawScale,ui::FontWeight::SemiBold),artist=Shorten(fonts,state->artist,190*drawScale,13.5f*drawScale,ui::FontWeight::Medium);const float textAlpha=entrance*content,textOffset=(1-content)*5*drawScale;
 fonts.Draw(foreground,title,{a.x+15*drawScale,a.y+65*drawScale+textOffset},15.5f*drawScale,Alpha(IM_COL32_WHITE,textAlpha),ui::FontWeight::SemiBold);
 fonts.Draw(foreground,artist,{a.x+15*drawScale,a.y+84*drawScale+textOffset},13.5f*drawScale,Alpha(IM_COL32(245,245,245,240),textAlpha),ui::FontWeight::Medium);
 const bool interactive=ui::input::IsOpen()||ui::IsScreenOpen();const auto mouse=ImGui::GetIO().MousePos;
 const ImVec2 playBaseA{a.x+232*drawScale,a.y+59*drawScale},playBaseB{a.x+299*drawScale,a.y+101*drawScale},playCenter{(playBaseA.x+playBaseB.x)*.5f,(playBaseA.y+playBaseB.y)*.5f};
 const bool playHovered=interactive&&Inside(mouse,playBaseA,playBaseB),playPressed=playHovered&&ImGui::IsMouseDown(ImGuiMouseButton_Left);const float playHover=std::clamp(playHoverMotion.Update(playHovered?1.f:0.f,dt,300,30),0.f,1.f),playPress=std::clamp(playPressMotion.Update(playPressed?1.f:0.f,dt,390,34),0.f,1.f),buttonScale=1+.035f*playHover-.05f*playPress;
 const float playWidth=67*drawScale*buttonScale,playHeight=42*drawScale*buttonScale;const ImVec2 playA{playCenter.x-playWidth*.5f,playCenter.y-playHeight*.5f},playB{playCenter.x+playWidth*.5f,playCenter.y+playHeight*.5f};const auto animatedAccent=Alpha(Lighten(accent,.14f*playHover),entrance);
 if(!ui::clickgui::ReferenceRectangle(foreground,playA,playWidth,playHeight,14*drawScale*buttonScale,1.f,animatedAccent))SmoothRect(foreground,playA,playB,14*drawScale*buttonScale,animatedAccent);
 const ImU32 symbol=IM_COL32(54,42,45,255);const float symbolScale=drawScale*(1-.08f*playPress);ImVec2 playPoints[3]{{playCenter.x-5*symbolScale,playCenter.y-8*symbolScale},{playCenter.x-5*symbolScale,playCenter.y+8*symbolScale},{playCenter.x+8*symbolScale,playCenter.y}};foreground.AddConvexPolyFilled(playPoints,3,Alpha(symbol,entrance*(1-playing)));
 const float barWidth=4*symbolScale,barHeight=14*symbolScale;for(const float offset:{-3.f,4.f}){const ImVec2 barA{playCenter.x+offset*symbolScale-barWidth*.5f,playCenter.y-barHeight*.5f};const auto pauseColor=Alpha(symbol,entrance*playing);if(!ui::clickgui::ReferenceRectangle(foreground,barA,barWidth,barHeight,1.3f*symbolScale,1.f,pauseColor))foreground.AddRectFilled(barA,{barA.x+barWidth,barA.y+barHeight},pauseColor,1.3f*symbolScale);}
 const float lineLeft=a.x+83*drawScale,lineRight=a.x+231*drawScale,lineY=a.y+122*drawScale,current=lineLeft+(lineRight-lineLeft)*progress;const ImVec2 progressA{lineLeft,lineY-9*drawScale},progressB{lineRight,lineY+9*drawScale};const bool progressHovered=interactive&&Inside(mouse,progressA,progressB);const float progressHover=std::clamp(progressHoverMotion.Update(progressHovered?1.f:0.f,dt,260,28),0.f,1.f),waveHeight=17*drawScale,waveAmplitude=(3.8f+1.25f*progressHover)*drawScale,waveThickness=(1.3f+.2f*progressHover)*drawScale;
 if(lineRight>current+.1f){const ImVec2 remainingA{current,lineY-1.2f*drawScale};if(!ui::clickgui::ReferenceRectangle(foreground,remainingA,lineRight-current,2.4f*drawScale,1.2f*drawScale,1.f,Alpha(IM_COL32(255,255,255,245),entrance)))foreground.AddRectFilled(remainingA,{lineRight,lineY+1.2f*drawScale},Alpha(IM_COL32(255,255,255,245),entrance),1.2f*drawScale);}
 if(current>lineLeft+.5f&&!ui::clickgui::ReferenceWave(foreground,{lineLeft,lineY-waveHeight*.5f},current-lineLeft,waveHeight,waveAmplitude,16*drawScale,waveThickness,wavePhase,Alpha(IM_COL32(255,250,252,255),entrance)))FilledWave(foreground,lineLeft,current,lineY,drawScale,wavePhase,Alpha(IM_COL32(255,250,252,255),entrance));
 const float pulse=state->playing?.5f+.5f*std::sin(wavePhase*1.45f):0.f,knobWidth=(3.5f+.65f*pulse)*drawScale,knobHeight=(15.f+1.5f*pulse)*drawScale;const ImVec2 knobA{current-knobWidth*.5f,lineY-knobHeight*.5f};if(!ui::clickgui::ReferenceRectangle(foreground,knobA,knobWidth,knobHeight,knobWidth*.5f,1.f,Alpha(IM_COL32_WHITE,entrance)))foreground.AddRectFilled(knobA,{knobA.x+knobWidth,knobA.y+knobHeight},Alpha(IM_COL32_WHITE,entrance),knobWidth*.5f);
 const ImVec2 previousCenter{a.x+64*drawScale,lineY},nextCenter{a.x+252*drawScale,lineY};const bool previousHovered=interactive&&Inside(mouse,{a.x+47*drawScale,a.y+106*drawScale},{a.x+78*drawScale,a.y+139*drawScale}),nextHovered=interactive&&Inside(mouse,{a.x+238*drawScale,a.y+106*drawScale},{a.x+270*drawScale,a.y+139*drawScale});const float previousScale=drawScale*(1+.12f*std::clamp(previousHoverMotion.Update(previousHovered?1.f:0.f,dt,280,30),0.f,1.f)),nextScale=drawScale*(1+.12f*std::clamp(nextHoverMotion.Update(nextHovered?1.f:0.f,dt,280,30),0.f,1.f));Previous(foreground,previousCenter,Alpha(IM_COL32_WHITE,entrance),previousScale);Next(foreground,nextCenter,Alpha(IM_COL32_WHITE,entrance),nextScale);
 if(interactive) {
  ImGui::SetNextWindowPos(a,ImGuiCond_Always);ImGui::SetNextWindowSize({drawWidth,drawHeight},ImGuiCond_Always);
  ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});
  constexpr auto flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoNav|ImGuiWindowFlags_NoBringToFrontOnFocus;
  ImGui::Begin("##SpotifyWidgetControls",nullptr,flags);
  const auto control=[&](const char* id,float x,float y,float w,float h,Action action){ImGui::SetCursorPos({x*drawScale,y*drawScale});ImGui::InvisibleButton(id,{w*drawScale,h*drawScale});if(ImGui::IsItemClicked(ImGuiMouseButton_Left))Request(action);};
  control("##SpotifyPrevious",47,106,31,33,Action::Previous);
  control("##SpotifyToggle",232,59,67,42,Action::Toggle);
  control("##SpotifyNext",238,106,32,33,Action::Next);
  ImGui::End();ImGui::PopStyleVar();
 }
}
}
