#include "features/visual/ambiance/LyricsJson.hpp"
#include <charconv>
#include <cmath>

namespace client::features::ambiance::lyricsjson {
namespace {

constexpr int kMaxDepth=32;

struct Parser {
 std::string_view text;
 std::size_t at=0;
 int depth=0;

 bool Eof()const{return at>=text.size();}
 char Peek()const{return Eof()?'\0':text[at];}
 void Space(){while(!Eof()&&(Peek()==' '||Peek()=='\t'||Peek()=='\n'||Peek()=='\r'))++at;}
 bool Eat(char c){Space();if(Peek()==c){++at;return true;}return false;}
 bool Literal(std::string_view word){if(text.substr(at,word.size())!=word)return false;at+=word.size();return true;}

 void Utf8(std::string& out,unsigned cp){
  if(cp<0x80)out+=static_cast<char>(cp);
  else if(cp<0x800){out+=static_cast<char>(0xc0|(cp>>6));out+=static_cast<char>(0x80|(cp&0x3f));}
  else if(cp<0x10000){out+=static_cast<char>(0xe0|(cp>>12));out+=static_cast<char>(0x80|((cp>>6)&0x3f));out+=static_cast<char>(0x80|(cp&0x3f));}
  else{out+=static_cast<char>(0xf0|(cp>>18));out+=static_cast<char>(0x80|((cp>>12)&0x3f));out+=static_cast<char>(0x80|((cp>>6)&0x3f));out+=static_cast<char>(0x80|(cp&0x3f));}
 }

 bool Hex4(unsigned& cp){
  if(at+4>text.size())return false;cp=0;
  for(int i=0;i<4;++i){const char c=text[at++];cp<<=4;
   if(c>='0'&&c<='9')cp|=static_cast<unsigned>(c-'0');
   else if(c>='a'&&c<='f')cp|=static_cast<unsigned>(c-'a'+10);
   else if(c>='A'&&c<='F')cp|=static_cast<unsigned>(c-'A'+10);
   else return false;}
  return true;
 }

 bool String(std::string& out){
  if(Peek()!='"')return false;++at;out.clear();
  while(!Eof()){
   const char c=text[at++];
   if(c=='"')return true;
   if(static_cast<unsigned char>(c)<0x20)return false;
   if(c!='\\'){out+=c;continue;}
   if(Eof())return false;
   const char esc=text[at++];
   switch(esc){
    case '"':out+='"';break;case '\\':out+='\\';break;case '/':out+='/';break;
    case 'b':out+='\b';break;case 'f':out+='\f';break;case 'n':out+='\n';break;
    case 'r':out+='\r';break;case 't':out+='\t';break;
    case 'u':{
     unsigned cp=0;if(!Hex4(cp))return false;
     if(cp>=0xd800&&cp<=0xdbff){ // high surrogate: expect \uDC00-DFFF
      if(at+6>text.size()||text[at]!='\\'||text[at+1]!='u')return false;
      at+=2;unsigned lo=0;if(!Hex4(lo)||lo<0xdc00||lo>0xdfff)return false;
      cp=0x10000+((cp-0xd800)<<10)+(lo-0xdc00);
     }else if(cp>=0xdc00&&cp<=0xdfff)return false;
     Utf8(out,cp);break;
    }
    default:return false;
   }
  }
  return false;
 }

 bool Number(double& value){
  Space();const auto begin=at;
  if(Peek()=='-')++at;
  if(Eof())return false;
  if(Peek()=='0')++at;
  else if(Peek()>='1'&&Peek()<='9'){while(!Eof()&&Peek()>='0'&&Peek()<='9')++at;}
  else return false;
  if(Peek()=='.'){++at;if(Eof()||Peek()<'0'||Peek()>'9')return false;while(!Eof()&&Peek()>='0'&&Peek()<='9')++at;}
  if(Peek()=='e'||Peek()=='E'){++at;if(Peek()=='+'||Peek()=='-')++at;if(Eof()||Peek()<'0'||Peek()>'9')return false;while(!Eof()&&Peek()>='0'&&Peek()<='9')++at;}
  const auto len=at-begin;std::string token(text.substr(begin,len));
  try{value=std::stod(token);}catch(...){return false;}
  return std::isfinite(value);
 }

 bool Value(JsonValue& out){
  Space();
  if(++depth>kMaxDepth){--depth;return false;}
  const char c=Peek();bool ok=false;
  if(c=='"'){out.type=JsonValue::Type::String;ok=String(out.text);}
  else if(c=='{'){out.type=JsonValue::Type::Object;ok=Object(out);}
  else if(c=='['){out.type=JsonValue::Type::Array;ok=Array(out);}
  else if(c=='t'){ok=Literal("true")&&(out.type=JsonValue::Type::Bool,out.boolean=true,true);}
  else if(c=='f'){ok=Literal("false")&&(out.type=JsonValue::Type::Bool,out.boolean=false,true);}
  else if(c=='n'){ok=Literal("null")&&(out.type=JsonValue::Type::Null,true);}
  else if(c=='-'||(c>='0'&&c<='9')){out.type=JsonValue::Type::Number;ok=Number(out.number);}
  --depth;
  return ok;
 }

 bool Array(JsonValue& out){
  ++at;Space();out.items.clear();
  if(Eat(']'))return true;
  for(;;){JsonValue item;if(!Value(item))return false;out.items.push_back(std::move(item));
   if(Eat(']'))return true;if(!Eat(','))return false;}
 }

 bool Object(JsonValue& out){
  ++at;Space();out.members.clear();
  if(Eat('}'))return true;
  for(;;){
   Space();std::string key;if(Peek()!='"'||!String(key))return false;
   if(!Eat(':'))return false;JsonValue item;if(!Value(item))return false;
   out.members.emplace_back(std::move(key),std::move(item));
   if(Eat('}'))return true;if(!Eat(','))return false;
  }
 }
};

}

const JsonValue* JsonValue::Find(std::string_view key)const{
 if(type!=Type::Object)return nullptr;
 for(const auto& member:members)if(member.first==key)return &member.second;
 return nullptr;
}

bool Parse(std::string_view text,JsonValue& out){
 Parser parser{text};
 if(!parser.Value(out))return false;
 parser.Space();
 return parser.Eof();
}

}
