#include "features/visual/ambiance/ParticleLyrics.hpp"
#include "features/visual/ambiance/Ambiance.hpp"
#include "features/visual/ambiance/ParticleLyricsLogic.hpp"
#include "features/visual/ambiance/ParticleRaster.hpp"
#include "game/MappingRepository.hpp"
#include "client/HotSpotAccess.hpp"
#include "client/Logger.hpp"
#include "render/GlApi.hpp"
#include "render/GlDiagnostics.hpp"
#include "render/LegacyGuiState.hpp"
#include "render/Texture.hpp"
#include <Windows.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace client::features::ambiance {
namespace {
using namespace client::features::ambiance::lyrics3d;

// ---- tunables (world space) ----
constexpr float kTextWorldHeight=2.2f;  // blocks tall on screen (chunk budget)
constexpr float kParticleSizePx=2.2f;  // reference particleSize
constexpr std::size_t kGlQuadChunk=2048;// quads per glBegin/glEnd batch

// ---- soft round particle sprite (generated once, uploaded on first use) ----
GLuint CircleTexture(){
 static GLuint texture=0;
 if(texture)return texture;
 constexpr int kSize=64;
 std::vector<unsigned char> rgba(kSize*kSize*4);
 for(int y=0;y<kSize;++y)for(int x=0;x<kSize;++x){
  const float dx=(x+0.5f)/kSize*2.f-1.f,dy=(y+0.5f)/kSize*2.f-1.f;
  const float d=std::sqrt(dx*dx+dy*dy);
  const float a=std::clamp(1.f-d,0.f,1.f);
  const auto falloff=std::pow(a,1.35f);
  auto* px=rgba.data()+(static_cast<std::size_t>(y)*kSize+x)*4;
  px[0]=px[1]=px[2]=255;px[3]=static_cast<unsigned char>(falloff*255.f);
 }
 texture=render::UploadRgba(rgba,kSize,kSize);
 return texture;
}

// ---- runtime state ----
struct RState {
 Field field;
 LineLayout fullLayout;          // rasterized once per lyric line
 std::string rasterKey;          // track|line identity for fullLayout
 std::string chunkKey;           // rasterKey|c0-c1 word chunk on screen
 std::string trackKey;
 std::int64_t lastPosMs=-1;
 LyricsClock clock;              // jitter-separated lyrics clock
 std::chrono::steady_clock::time_point clockAt{};
 bool anchored=false;
 double anchorX=0,anchorY=0,anchorZ=0;
 // Manual world-space placement: fixed horizontal basis captured at first
 // activation + user sliders; anchor never depends on camera pitch/yaw.
 double placeFx=0,placeFz=1;    // horizontal forward (XZ unit vector)
 double placeRx=1,placeRz=0;    // horizontal right
 double placeYaw=0;             // damped tracking yaw (degrees)
 bool basisValid=false;
 int prevFollow=-1;             // mode-switch jump guard
 double fixedX=0,fixedY=0,fixedZ=0;      // follow=OFF world anchor
 bool fixedValid=false;
 std::uintptr_t worldOop=0;     // world-change detection for fixed anchor
 std::chrono::steady_clock::time_point lastFrameAt{};
 float accent[3]={1.f,0.78f,0.42f};   // readable warm-gold fallback
 float target[3]={1.f,0.78f,0.42f};
 bool snapNext=false;
 bool logged=false;
 bool wasPlaying=false;
 int rebuilds=0;
 std::chrono::steady_clock::time_point summaryAt{};
 std::chrono::steady_clock::time_point rasterRetryAt{};
 int rasterFails=0;
};
RState rt;

// Tracks the world depth-clear pass, same contract as the other world renderers.
class WorldPass {
 bool armed_=false,drawn_=false;
public:
 bool Clear(unsigned mask){if((mask&0x4100)==0x4100)armed_=true;return armed_&&!drawn_&&mask==0x100;}
 void Drawn(){drawn_=true;}
 void Present(){armed_=drawn_=false;}
};
WorldPass pass;

bool Matrix(JNIEnv* env,const char* key,float* output){
 const auto buffer=mapping::StaticObject(env,key);if(!buffer)return false;
 const auto data=env->GetDirectBufferAddress(buffer);
 return env->GetDirectBufferCapacity(buffer)>=16&&data&&hotspot::ReadMemory(reinterpret_cast<std::uintptr_t>(data),output,sizeof(float)*16);
}

std::string LineKey(const LyricsState& state,const ActiveLyrics& active){
 char buf[64];std::snprintf(buf,sizeof(buf),"%s|%zu",state.trackKey.c_str(),active.lineIndex);
 return std::string(buf);
}

// Column-major 4x4 * vec4 helper for the billboard clipping diagnostic.
void MulMatVec(const float* m,const float* v,float* out){
 out[0]=m[0]*v[0]+m[4]*v[1]+m[8]*v[2]+m[12]*v[3];
 out[1]=m[1]*v[0]+m[5]*v[1]+m[9]*v[2]+m[13]*v[3];
 out[2]=m[2]*v[0]+m[6]*v[1]+m[10]*v[2]+m[14]*v[3];
 out[3]=m[3]*v[0]+m[7]*v[1]+m[11]*v[2]+m[15]*v[3];
}

void Reset(bool keepPlacement){
 rt.field.Clear();rt.fullLayout=LineLayout{};rt.rasterKey.clear();rt.chunkKey.clear();rt.trackKey.clear();
 rt.anchored=false;rt.lastPosMs=-1;rt.snapNext=false;rt.clock=LyricsClock{};rt.clockAt={};
 rt.rasterRetryAt={};rt.rasterFails=0;
 // keepPlacement preserves the follow=OFF world anchor across lyric gaps;
 // the disabled path (every frame while off) and world changes recreate it.
 if(!keepPlacement){rt.fixedValid=false;rt.basisValid=false;rt.prevFollow=-1;}
}

}

void ResetLyrics3D(){Reset(false);}

void RenderLyricsWorld(JNIEnv* env,unsigned mask){
 const auto options=Options();
 if(!options.enabled||!options.lyrics||!options.lyrics3d){Reset(false);return;}
 if(!pass.Clear(mask)||!env||env->ExceptionCheck())return;
 // Same perspective/main-FBO gates as the other world renderers: orthographic
 // menus, hand pass and auxiliary framebuffers must never see particles.
 GLfloat projection[16]{};glGetFloatv(GL_PROJECTION_MATRIX,projection);
 if(std::abs(projection[15])>.0001f||std::abs(projection[11])<.0001f)return;
 if(env->PushLocalFrame(96)!=JNI_OK)return;
 struct Refs{JNIEnv* env;~Refs(){env->PopLocalFrame(nullptr);}}refs{env};
 const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft");if(!mc)return;
 const auto world=mapping::Object(env,mc,"Minecraft.theWorld"),player=mapping::Object(env,mc,"Minecraft.thePlayer");
 if(!world||!player||mapping::Read<bool>(player,"Entity.isDead").value_or(true))return;
 // A fixed (follow=OFF) anchor belongs to its world: dimension change or a
 // new world object recreates it on the next placement.
 if(const auto worldOop=mapping::Oop(world);worldOop){
  if(rt.worldOop&&worldOop!=rt.worldOop){rt.fixedValid=false;rt.basisValid=false;rt.prevFollow=-1;rt.anchored=false;rt.field.Clear();}
  rt.worldOop=worldOop;
 }
 const auto framebuffer=mapping::Object(env,mc,"Minecraft.framebuffer");if(!framebuffer)return;
 const auto expected=mapping::Read<int>(framebuffer,"Framebuffer.object");if(!expected)return;
 GLint drawFbo=0;glGetIntegerv(0x8CA6,&drawFbo);if(drawFbo!=std::max(0,*expected))return;
 const auto manager=mapping::Object(env,mc,"Minecraft.renderManager");if(!manager)return;

 // Camera state: MODELVIEW is viewer-relative (same convention as wings/aura).
 float model[16]{},proj[16]{};
 if(!Matrix(env,"ActiveRenderInfo.MODELVIEW",model)||!Matrix(env,"ActiveRenderInfo.PROJECTION",proj))return;
 GLint viewport[4]{};glGetIntegerv(GL_VIEWPORT,viewport);
 if(viewport[2]<=0||viewport[3]<=0)return;
 const auto viewerX=mapping::Read<double>(manager,"RenderManager.viewerPosX").value_or(0);
 const auto viewerY=mapping::Read<double>(manager,"RenderManager.viewerPosY").value_or(0);
 const auto viewerZ=mapping::Read<double>(manager,"RenderManager.viewerPosZ").value_or(0);
 const auto px=mapping::Read<double>(player,"Entity.posX"),py=mapping::Read<double>(player,"Entity.posY"),pz=mapping::Read<double>(player,"Entity.posZ");

 if(!px||!py||!pz)return;
 const float playerYaw=mapping::Read<float>(player,"Entity.rotationYaw").value_or(0.f);

 // Lyrics clock: predicted position freezes while paused, jumps on seek.
 const auto lyrics=LyricsSnapshot();
 if(!lyrics.available||lyrics.status!=LyricsStatus::Synced||!lyrics.content||lyrics.content->lines.empty()){
  if(!rt.field.Empty()){Reset(true);AOKI_LOG("[Ambiance:lyrics3d] no active synced line; particles cleared");}
  pass.Drawn();return;
 }
 // Lyrics clock: SyncLyricsClock holds a monotonic position that only
 // resyncs on real seeks, absorbing GSMTC republish jitter (a few hundred ms
 // backward steps that used to teleport every particle via delta<0).
 const auto now=std::chrono::steady_clock::now();
 const auto rawMs=PredictPositionMs(lyrics,now);
 const auto elapsedMs=rt.clockAt.time_since_epoch().count()==0?0:
  std::chrono::duration_cast<std::chrono::milliseconds>(now-rt.clockAt).count();
 rt.clockAt=now;
 bool clockSeek=false;
 const auto positionMs=SyncLyricsClock(rt.clock,rawMs,elapsedMs,lyrics.playing,lyrics.durationMs,clockSeek);
 if(clockSeek||lyrics.playing!=rt.wasPlaying){
  AOKI_LOG("[lyrics3d:clock] raw=%lld smooth=%lld err=%lld playing=%d->%d seek=%d",
   static_cast<long long>(rawMs),static_cast<long long>(positionMs),
   static_cast<long long>(rawMs-positionMs),rt.wasPlaying?1:0,lyrics.playing?1:0,clockSeek?1:0);
 }
 rt.wasPlaying=lyrics.playing;
 const auto active=GetActiveLyrics(lyrics,positionMs);
 if(active.lineIndex==ActiveLyrics::npos||!active.line||active.line->text.empty()){
  if(!rt.field.Empty()){Reset(true);}
  pass.Drawn();return;
 }

 // Track change: drop all particle state so the next line gathers fresh
 // instead of morphing across songs. Same track keeps morph continuity.
 if(lyrics.trackKey!=rt.trackKey){
  rt.trackKey=lyrics.trackKey;
  rt.field.Clear();
  rt.fullLayout=LineLayout{};
  rt.rasterKey.clear();rt.chunkKey.clear();
  rt.lastPosMs=-1;rt.snapNext=false;rt.clock=LyricsClock{};
  AOKI_LOG("[Ambiance:lyrics3d] track change -> field cleared");
 }

 // Layout (re)build only when the line identity changes. A line without word
 // tokens still renders: synthesize a single word spanning the whole line.
 LyricLine lineStorage;
 const LyricLine* linePtr=active.line;
 if(linePtr->words.empty()){
  lineStorage=*linePtr;
  LyricWord whole;whole.text=lineStorage.text;whole.startMs=lineStorage.startMs;whole.endMs=lineStorage.endMs;
  whole.estimated=true; // synthesized span: line timing only, no word tags
  lineStorage.words.push_back(std::move(whole));
  linePtr=&lineStorage;
 }
 // Rasterize once per line; word morphs reuse the cached layout.
 const auto rasterKey=LineKey(lyrics,active);
 if(rasterKey!=rt.rasterKey){
  // Failed rasterizations retry with a 2 s backoff instead of locking the
  // line out permanently; stale particles are dropped so wrong text never
  // lingers on screen.
  if(rt.rasterRetryAt!=std::chrono::steady_clock::time_point{}&&std::chrono::steady_clock::now()<rt.rasterRetryAt){pass.Drawn();return;}
  const auto rasterT0=std::chrono::steady_clock::now();
  LineLayout layout;
  if(!RasterizeLine(*linePtr,layout)){
   ++rt.rasterFails;
   rt.rasterRetryAt=std::chrono::steady_clock::now()+std::chrono::seconds(2);
   rt.field.Clear();rt.rasterKey.clear();rt.chunkKey.clear();++rt.rebuilds;
   if(rt.rasterFails<=3||rt.rasterFails%30==0)AOKI_LOG("[lyrics3d:layout] reason=raster-fail line=%zu attempt=%d",active.lineIndex,rt.rasterFails);
   pass.Drawn();return;
  }
  const auto rasterMs=std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-rasterT0).count()/1000.0;
  rt.rasterRetryAt={};rt.rasterFails=0;
  rt.fullLayout=std::move(layout);
  rt.rasterKey=rasterKey;
  rt.chunkKey.clear();++rt.rebuilds;
  AOKI_LOG("[lyrics3d:layout] reason=rasterize line=%zu targets=%zu words=%zu ms=%.2f",
   active.lineIndex,rt.fullLayout.targets.size(),rt.fullLayout.words.size(),rasterMs);
 }

 // Sentence rendering: the whole line is rasterized once; long lines are
 // shown as a phrase chunk around the active word so the text stays inside
 // the frustum at readable size. The chunk contains every particle target of
 // its words — karaoke fills left-to-right and unsung parts stay dim but
 // visible. The billboard anchor never moves between words.
 const auto& words=linePtr->words;
 const auto displayWord=SelectDisplayWord(words,positionMs);
 if(displayWord==ActiveLyrics::npos){
  if(!rt.field.Empty()){rt.field.Clear();++rt.rebuilds;AOKI_LOG("[lyrics3d:morph] reason=before-first-word field cleared");}
  rt.chunkKey.clear();
  pass.Drawn();return;
 }
 // Chunk pixel budget: visible world width at the ~10-block anchor distance
 // (85% frustum margin), converted to pixels via the height-driven
 // pixels-per-world-unit so the chunk always fits on screen at readable size.
 const float tanHalfFov=1.f/std::max(1e-4f,proj[5]);
 const float aspect=static_cast<float>(viewport[2])/static_cast<float>(viewport[3]);
 // Chunk budget follows the user's Distance slider so close placements get
 // narrower phrases and far placements can show more words per chunk.
 const float chunkDist=std::max(2.f,Options().lyrics3dColor.distance);
 const float fitWAtAnchor=2.f*chunkDist*tanHalfFov*aspect*0.72f;
 const float budgetPx=rt.fullLayout.height>0.f
  ?fitWAtAnchor*rt.fullLayout.height/kTextWorldHeight:fitWAtAnchor;
 std::size_t c0=0,c1=0;
 ChunkWordRange(rt.fullLayout,displayWord,budgetPx,c0,c1);
 const auto realChunkKey=rasterKey+"|"+std::to_string(c0)+"-"+std::to_string(c1);
 if(realChunkKey!=rt.chunkKey){
  const auto morphT0=std::chrono::steady_clock::now();
  auto sub=ChunkLayout(rt.fullLayout,c0,c1);
  const auto oldCount=rt.field.Particles().size();
  if(sub.targets.empty()){
   rt.field.Clear();rt.chunkKey=realChunkKey;++rt.rebuilds;
   AOKI_LOG("[lyrics3d:morph] reason=empty-chunk line=%zu word=%zu",active.lineIndex,displayWord);
   pass.Drawn();return;
  }
  const bool freshField=rt.field.Empty();
  rt.field.SetLayout(sub,static_cast<std::uint32_t>(active.lineIndex*2654435761u+c0*97u+c1*13u+7u));
  rt.chunkKey=realChunkKey;++rt.rebuilds;
  const auto morphMs=std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-morphT0).count()/1000.0;
  const bool estimated=std::any_of(words.begin(),words.end(),[](const LyricWord& w){return w.estimated;});
  AOKI_LOG("[lyrics3d:morph] line=%zu word=%zu/%zu chunk=%zu-%zu chunkTargets=%zu particles=%zu->%zu fresh=%d est=%d ms=%.2f",
   active.lineIndex,displayWord,words.size(),c0,c1,sub.targets.size(),oldCount,rt.field.Particles().size(),
   freshField?1:0,estimated?1:0,morphMs);
  // Late-arriving lyrics or a mid-word position must not replay the gather
  // intro: snap the field onto its targets instead.
  if(ShouldSnapOnLayout(positionMs,words[displayWord].startMs)){
   for(auto& p:rt.field.Particles()){p.x=p.targetX;p.y=p.targetY;p.startX=p.x;p.startY=p.y;p.fade=p.fadeGoal;}
   AOKI_LOG("[lyrics3d:morph] late-layout snap wordStart=%lld pos=%lld",
    static_cast<long long>(words[displayWord].startMs),static_cast<long long>(positionMs));
  }
 }

 // Lyrics-time delta drives the simulation so pause/seek are honored exactly.
 // positionMs is monotonic while playing, so delta<0 cannot occur; the clock
 // already snapped heldMs on real seeks.
 float dtMs=0.f;
 if(rt.lastPosMs>=0){
  const auto delta=static_cast<float>(positionMs-rt.lastPosMs);
  if(delta>0.f)dtMs=std::min(delta,100.f);
 }
 rt.lastPosMs=positionMs;
 if(clockSeek||rt.snapNext){
  AOKI_LOG("[Ambiance:lyrics3d] snap particles to targets (clockSeek=%d snapNext=%d)",clockSeek?1:0,rt.snapNext?1:0);
  for(auto& p:rt.field.Particles()){p.x=p.targetX;p.y=p.targetY;p.startX=p.x;p.startY=p.y;}
  rt.snapNext=false;
 }
 rt.field.SetKaraoke(positionMs);
 rt.field.Step(dtMs,0.8f);
 if(rt.field.Empty()){pass.Drawn();return;}

 const auto colorCfg=Options().lyrics3dColor;
 rt.target[0]=(colorCfg.color&0xFF)/255.f*colorCfg.brightness;
 rt.target[1]=((colorCfg.color>>8)&0xFF)/255.f*colorCfg.brightness;
 rt.target[2]=((colorCfg.color>>16)&0xFF)/255.f*colorCfg.brightness;
 const float lyricsGlow=colorCfg.glow;
 for(int i=0;i<3;++i)rt.accent[i]+=(rt.target[i]-rt.accent[i])*0.06f;

 // ---- manual world-space placement ----
 // anchor = playerPos + horizontalForward*distance + horizontalRight*hOffset
 //         + worldUp*vOffset. Follow ON tracks the player's yaw (damped,
 // wrap-aware) so the anchor swings back in front on camera turns; pitch
 // never affects it. OFF pins the world position. Slider changes retarget
 // the offset instantly; phrase changes never move the anchor.
 const auto placeCfg=Options().lyrics3dColor;
 const bool followPlayer=placeCfg.follow;
 const float tanHalfV=1.f/std::max(1e-4f,std::abs(proj[5]));

 // Capture the placement yaw once per enable/world.
 if(!rt.basisValid){
  rt.placeYaw=playerYaw;
  rt.basisValid=true;
  AOKI_LOG("[lyrics3d:placement] basis yaw=%.1f",static_cast<double>(playerYaw));
 }
 // Frame delta for the damped follow (~220 ms, follow=ON only).
 const auto frameNow=std::chrono::steady_clock::now();
 float frameDtMs=16.f;
 if(rt.lastFrameAt.time_since_epoch().count()!=0)
  frameDtMs=std::clamp(static_cast<float>(std::chrono::duration_cast<std::chrono::milliseconds>(frameNow-rt.lastFrameAt).count()),1.f,100.f);
 rt.lastFrameAt=frameNow;
 const float followK=1.f-std::exp(-frameDtMs*0.0045f);

 // Follow ON: the horizontal basis tracks the player's yaw (wrap-aware,
 // damped) so the anchor swings back in front when the camera turns —
 // pitch never affects it. OFF keeps the last basis frozen.
 if(followPlayer){
  double dy=static_cast<double>(playerYaw)-rt.placeYaw;
  while(dy>180.)dy-=360.;while(dy<-180.)dy+=360.;
  rt.placeYaw+=dy*followK;
  const float yawRad=static_cast<float>(rt.placeYaw)*3.14159265f/180.f;
  rt.placeFx=-std::sin(yawRad);rt.placeFz=std::cos(yawRad);
  rt.placeRx=-rt.placeFz;rt.placeRz=rt.placeFx;
 }
 const double offX=rt.placeFx*placeCfg.distance+rt.placeRx*placeCfg.hOffset;
 const double offZ=rt.placeFz*placeCfg.distance+rt.placeRz*placeCfg.hOffset;
 const double offY=placeCfg.vOffset;
 // Mode switch: adopt the current anchor as the fixed point so toggling
 // Follow never produces a jump.
 if(static_cast<int>(followPlayer)!=rt.prevFollow){
  rt.prevFollow=followPlayer;
  if(!followPlayer&&rt.anchored){rt.fixedX=rt.anchorX;rt.fixedY=rt.anchorY;rt.fixedZ=rt.anchorZ;rt.fixedValid=true;}
 }

 const double baseX=*px,baseY=*py,baseZ=*pz;
 const double desired[3]={baseX+offX,baseY+offY,baseZ+offZ};
 if(!followPlayer){
  if(!rt.fixedValid){
   rt.fixedX=desired[0];rt.fixedY=desired[1];rt.fixedZ=desired[2];rt.fixedValid=true;
   AOKI_LOG("[lyrics3d:placement] reason=fixed-init offset=%.1f,%.1f,%.1f",
    offX,offY,offZ);
  }
  rt.anchorX=rt.fixedX;rt.anchorY=rt.fixedY;rt.anchorZ=rt.fixedZ;rt.anchored=true;
 }else{
  if(!rt.anchored){rt.anchorX=desired[0];rt.anchorY=desired[1];rt.anchorZ=desired[2];rt.anchored=true;}
  rt.anchorX+=(desired[0]-rt.anchorX)*followK;
  rt.anchorY+=(desired[1]-rt.anchorY)*followK;
  rt.anchorZ+=(desired[2]-rt.anchorZ)*followK;
 }
 const double ax=rt.anchorX-viewerX,ay=rt.anchorY-viewerY,az=rt.anchorZ-viewerZ;

 // GL pass: textured camera-facing quads, one begin/end for every particle.
 const auto texture=CircleTexture();
 if(!texture){pass.Drawn();return;}
 if(!render::gl.BindFramebuffer&&!render::gl.Load()){pass.Drawn();return;}
 render::diagnostics::Scope trace("Ambiance.lyrics3d");
 const auto renderT0=std::chrono::steady_clock::now();
 render::LegacyGuiState saved;
 auto& gl=render::gl;
 gl.UseProgram(0);
 gl.ActiveTexture(render::Texture1);glDisable(GL_TEXTURE_2D);
 gl.ActiveTexture(render::Texture0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,texture);
 if(gl.BindSampler){gl.BindSampler(0,0);gl.BindSampler(1,0);}
 glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
 glDisable(GL_LIGHTING);glDisable(GL_FOG);glDisable(GL_STENCIL_TEST);glDisable(GL_SCISSOR_TEST);
 glDisable(GL_COLOR_LOGIC_OP);glDisable(0x8C89);glDisable(0x8F9D);glDisable(GL_CULL_FACE);
 glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 // Lyrics are cinematic overlays: depth test is fully OFF so walls, trees
 // and terrain never hide them; depth writes stay off so lyric quads never
 // occlude the world, the held item or later translucent passes. Both states
 // are restored after glEnd — other world renderers are unaffected.
 static bool depthLogged=false;
 if(!depthLogged){depthLogged=true;AOKI_LOG("[lyrics3d:billboard] depthTest=OFF");}
 const GLboolean depthWas=glIsEnabled(GL_DEPTH_TEST);
 glDisable(GL_DEPTH_TEST);
 GLboolean depthMask=GL_TRUE;glGetBooleanv(GL_DEPTH_WRITEMASK,&depthMask);glDepthMask(GL_FALSE);
 glEnable(GL_BLEND);
 gl.BlendEquationSeparate(0x8006,0x8006);gl.BlendFuncSeparate(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
 glViewport(viewport[0],viewport[1],viewport[2],viewport[3]);
 glMatrixMode(GL_PROJECTION);glLoadMatrixf(proj);
 glMatrixMode(GL_MODELVIEW);
 // Orientation basis (column-major). Billboard ON: camera-facing quads from
 // the view rotation's axes. Billboard OFF: fixed world orientation — text
 // stands upright facing the placement forward, so camera turns show real
 // 3D parallax instead of a screen-locked overlay.
 float right[3]={0,0,1},up[3]={0,1,0};
 float basis[16]={1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
 if(placeCfg.billboard){
  right[0]=model[0];right[1]=model[4];right[2]=model[8];
  up[0]=model[1];up[1]=model[5];up[2]=model[9];
  const float rl=std::sqrt(right[0]*right[0]+right[1]*right[1]+right[2]*right[2]);
  const float ul=std::sqrt(up[0]*up[0]+up[1]*up[1]+up[2]*up[2]);
  if(rl>1e-6f&&ul>1e-6f){
   for(float& v:right)v/=rl;for(float& v:up)v/=ul;
   const float bx=right[1]*up[2]-right[2]*up[1],by=right[2]*up[0]-right[0]*up[2],bz=right[0]*up[1]-right[1]*up[0];
   basis[0]=right[0];basis[1]=right[1];basis[2]=right[2];
   basis[4]=up[0];basis[5]=up[1];basis[6]=up[2];
   basis[8]=bx;basis[9]=by;basis[10]=bz;
  }
 }else{
  // Upright plane: local +x -> placement right, +y -> world up,
  // +z -> back toward the player (normal faces the anchor origin).
  const float rx=static_cast<float>(rt.placeRx),rz=static_cast<float>(rt.placeRz);
  const float fx=static_cast<float>(rt.placeFx),fz=static_cast<float>(rt.placeFz);
  right[0]=rx;right[1]=0;right[2]=rz;
  basis[0]=rx;basis[1]=0;basis[2]=rz;
  basis[4]=0;basis[5]=1;basis[6]=0;
  basis[8]=-fx;basis[9]=0;basis[10]=-fz;
 }
 // World-space anchor for both modes and both orientations.
 glLoadMatrixf(model);
 glTranslated(ax,ay,az);
 glMultMatrixf(basis);
 const auto* lineLayout=rt.field.Layout();
 // Manual scale: world height = ~9% of the view height at the configured
 // distance, multiplied by the user's Scale slider; width capped at ~72%
 // of the view. Pure vertex-scale change — particles/layout never rebuild.
 const float viewAspect=static_cast<float>(viewport[2])/static_cast<float>(viewport[3]);
 const float viewH=2.f*std::max(1.f,placeCfg.distance)*tanHalfV;
 const float viewW=viewH*viewAspect;
 float worldW=0,worldH=0.09f*viewH*placeCfg.scale;
 if(lineLayout&&lineLayout->height>0.f&&lineLayout->width>0.f)
  worldW=worldH*lineLayout->width/lineLayout->height;
 const float maxW=0.72f*viewW;
 if(worldW>maxW&&worldW>0.f){const float k=maxW/worldW;worldW*=k;worldH*=k;}
 float wpp=1.f;
 if(lineLayout&&lineLayout->height>0.f)
  wpp=worldH/lineLayout->height;
 glScalef(wpp,wpp,wpp);
 const float half=kParticleSizePx*0.5f;
 const float sunR=std::min(1.f,rt.accent[0]*1.15f+0.05f),sunG=std::min(1.f,rt.accent[1]*1.15f+0.05f),sunB=std::min(1.f,rt.accent[2]*1.15f+0.05f);
 const float baseR=rt.accent[0]*0.45f+0.30f,baseG=rt.accent[1]*0.45f+0.32f,baseB=rt.accent[2]*0.45f+0.36f;
 glBegin(GL_QUADS);
 // Chunked batches bound driver vertex-buffer growth on very dense lines;
 // still a single texture/state setup, never one draw call per particle.
 std::size_t quadsInBatch=0;
 for(const auto& p:rt.field.Particles()){
  const float fill=rt.field.KaraokeFill(p);
  float r=baseR+(sunR-baseR)*fill,g=baseG+(sunG-baseG)*fill,b=baseB+(sunB-baseB)*fill;
  const float boost=(0.80f+0.45f*p.heat)*lyricsGlow; // motion highlight: brightness only
  r=std::min(1.f,r*boost);g=std::min(1.f,g*boost);b=std::min(1.f,b*boost);
  const float alpha=std::clamp(0.95f*p.weight*p.fade*(0.72f+0.28f*fill)*std::clamp(lyricsGlow,0.4f,1.5f),0.f,1.f);
  glColor4f(r,g,b,alpha);
  const float x0=p.x-half,y0=p.y-half,x1=p.x+half,y1=p.y+half;
  glTexCoord2f(0,0);glVertex3f(x0,y0,0);
  glTexCoord2f(1,0);glVertex3f(x1,y0,0);
  glTexCoord2f(1,1);glVertex3f(x1,y1,0);
  glTexCoord2f(0,1);glVertex3f(x0,y1,0);
  if(++quadsInBatch>=kGlQuadChunk){glEnd();glBegin(GL_QUADS);quadsInBatch=0;}
 }
 glEnd();
 glDepthMask(depthMask);
 if(depthWas)glEnable(GL_DEPTH_TEST);else glDisable(GL_DEPTH_TEST);
 // Restore the world modelview — follow mode left an identity+translate
 // camera-space matrix on the stack.
 glMatrixMode(GL_MODELVIEW);glLoadMatrixf(model);
 // 1 Hz diagnostic summary: draw counts, rebuild rate, billboard metrics and
 // an approximate count of particles projected outside the viewport.
 {
  const auto done=std::chrono::steady_clock::now();
  if(rt.summaryAt.time_since_epoch().count()==0||done-rt.summaryAt>=std::chrono::seconds(1)){
   rt.summaryAt=done;
   const double cpuMs=std::chrono::duration_cast<std::chrono::microseconds>(done-renderT0).count()/1000.0;
   int drawn=0,clipped=0;
   for(const auto& p:rt.field.Particles()){
    if(p.fade<0.02f)continue;
    ++drawn;
    // Particle -> viewer-relative world -> view -> clip, mirroring the GL
    // transform chain (translate anchor, billboard basis, uniform scale).
    const float wx=static_cast<float>(ax)+wpp*(right[0]*p.x+up[0]*p.y);
    const float wy=static_cast<float>(ay)+wpp*(right[1]*p.x+up[1]*p.y);
    const float wz=static_cast<float>(az)+wpp*(right[2]*p.x+up[2]*p.y);
    const float view[4]={wx,wy,wz,1.f};
    float mv[4],clip[4];MulMatVec(model,view,mv);MulMatVec(proj,mv,clip);
    if(std::abs(clip[0])>std::abs(clip[3])||std::abs(clip[1])>std::abs(clip[3]))++clipped;
   }
   const double dist=std::sqrt(ax*ax+ay*ay+az*az);
   AOKI_LOG("[lyrics3d:render] particles=%zu drawn=%d cpuMs=%.2f rebuilds=%d worldW=%.2f worldH=%.2f dist=%.1f clipped=%d depthTest=OFF pos=%lld playing=%d",
    rt.field.Particles().size(),drawn,cpuMs,rt.rebuilds,worldW,worldH,dist,clipped,
    static_cast<long long>(positionMs),lyrics.playing?1:0);
   rt.rebuilds=0;
  }
 }
 pass.Drawn();
}

void Lyrics3DPresent(){pass.Present();}

}
