#include "features/visual/ambiance/LyricsService.hpp"
#include "features/visual/ambiance/LyricsJson.hpp"
#include "features/visual/ambiance/LyricsLogic.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cctype>
#include <thread>

namespace client::features::ambiance::lyrics {
namespace {

std::string g_endpoint="https://lrclib.net";
Transport g_transport;
std::atomic<unsigned> g_httpRequests{0};

const Transport& ActiveTransport(){
 static const Transport fallback=[](std::string_view url){return TransportWinHttp(url);};
 if(!g_transport)return fallback;
 return g_transport;
}

std::string Encode(std::string_view value){
 static constexpr char hex[]="0123456789ABCDEF";
 std::string out;out.reserve(value.size());
 for(const unsigned char c:value){
  if((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')out+=static_cast<char>(c);
  else{out+='%';out+=hex[c>>4];out+=hex[c&15];}
 }
 return out;
}

struct Candidate {
 std::string trackName,artistName,albumName;
 double durationSec=0;
 bool instrumental=false;
 bool hasSynced=false,hasPlain=false;
 std::string syncedLyrics,plainLyrics;
};

const lyricsjson::JsonValue* Str(const lyricsjson::JsonValue& object,std::string_view key){
 const auto* value=object.Find(key);
 return value&&value->type==lyricsjson::JsonValue::Type::String?value:nullptr;
}

bool ReadCandidate(const lyricsjson::JsonValue& value,Candidate& out){
 if(value.type!=lyricsjson::JsonValue::Type::Object)return false;
 const auto* track=Str(value,"trackName");
 if(!track){track=Str(value,"name");}
 const auto* artist=Str(value,"artistName");
 if(!artist||!track)return false;
 out.trackName=track->text;out.artistName=artist->text;
 if(const auto* album=Str(value,"albumName"))out.albumName=album->text;
 if(const auto* duration=value.Find("duration");duration&&duration->type==lyricsjson::JsonValue::Type::Number)out.durationSec=duration->number;
 if(const auto* flag=value.Find("instrumental");flag&&flag->type==lyricsjson::JsonValue::Type::Bool)out.instrumental=flag->boolean;
 if(const auto* synced=Str(value,"syncedLyrics"))out.syncedLyrics=synced->text,out.hasSynced=!synced->text.empty();
 if(const auto* plain=Str(value,"plainLyrics"))out.plainLyrics=plain->text,out.hasPlain=!plain->text.empty();
 return true;
}

// Duration sanity: reject only when both sides are known and clearly off.
double DurationDiffSec(const TrackQuery& query,const Candidate& candidate){
 if(query.durationMs<=0||candidate.durationSec<=0)return 0;
 return std::abs(candidate.durationSec-static_cast<double>(query.durationMs)/1000.0);
}

struct Match {
 double name=0,artist=0,duration=0,score=0;
 bool accepted=false;
};

Match Evaluate(const TrackQuery& query,const Candidate& candidate){
 Match match;
 match.name=lyricslogic::NameSimilarity(query.title,candidate.trackName);
 match.artist=query.artist.empty()?1.0:lyricslogic::NameSimilarity(query.artist,candidate.artistName);
 const auto diff=DurationDiffSec(query,candidate);
 const bool durationKnown=query.durationMs>0&&candidate.durationSec>0;
 match.duration=durationKnown?diff:-1;
 // Hard rejects: hopeless name, weak artist, impossible duration.
 if(match.name<0.45||match.artist<0.40)return match;
 if(durationKnown&&diff>5.0)return match;
 // Soft scoring for ranking search candidates.
 match.score=match.name*0.5+match.artist*0.3+(durationKnown?std::max(0.0,1.0-diff/10.0)*0.2:0.1);
 match.accepted=match.name>=0.55&&match.artist>=0.50&&(durationKnown?diff<=4.0:true);
 return match;
}

FetchResult Build(const Candidate& candidate){
 FetchResult result;result.cacheable=true;
 auto content=std::make_shared<LyricsContent>();
 if(!candidate.syncedLyrics.empty()){
  content->lines=lyricslogic::ParseLrc(candidate.syncedLyrics,content->offsetMs);
 }
 if(content->lines.empty()&&!candidate.plainLyrics.empty()){
  content->plainLines=lyricslogic::ParsePlain(candidate.plainLyrics);
 }
 if(content->lines.empty()&&candidate.syncedLyrics.empty()&&candidate.plainLyrics.empty()&&candidate.instrumental){
  result.status=LyricsStatus::Instrumental;result.content=std::move(content);return result;
 }
 if(!content->lines.empty()){
  result.status=LyricsStatus::Synced;result.content=std::move(content);return result;
 }
 if(!content->plainLines.empty()){
  result.status=LyricsStatus::Plain;result.content=std::move(content);return result;
 }
 // Synced payload existed but had no timestamps: degrade to plain text.
 if(!candidate.syncedLyrics.empty()){
  content->plainLines=lyricslogic::ParsePlain(candidate.syncedLyrics);
  if(!content->plainLines.empty()){result.status=LyricsStatus::Plain;result.content=std::move(content);return result;}
 }
 result.status=LyricsStatus::NotFound;result.detail="No lyrics content";
 return result;
}

FetchResult NotFound(const std::string& detail){
 FetchResult result;result.status=LyricsStatus::NotFound;result.detail=detail;result.cacheable=true;return result;
}

FetchResult TransportFailure(const HttpResponse& response){
 FetchResult result;result.status=LyricsStatus::Error;
 result.detail=response.error.empty()?"Network error":response.error;
 result.retryable=true;
 return result;
}

FetchResult HttpFailure(int status,const std::string& retryAfter){
 FetchResult result;result.status=LyricsStatus::Error;
 result.detail="HTTP "+std::to_string(status);
 result.retryable=status==429||status>=500;
 if(status==429){
  try{result.retryAfterMs=std::stoll(retryAfter)*1000;}catch(...){}
 }
 return result;
}

const lyricsjson::JsonValue* Root(const HttpResponse& response,lyricsjson::JsonValue& document){
 if(response.status!=200||response.body.empty())return nullptr;
 if(!lyricsjson::Parse(response.body,document))return nullptr;
 return &document;
}

}

FetchResult FetchOnce(const TrackQuery& query,const Transport& transport){
 if(query.title.empty()&&query.artist.empty())return NotFound("No track metadata");
 const std::string get=g_endpoint+"/api/get?artist_name="+Encode(query.artist)+"&track_name="+Encode(query.title)+
  (query.durationMs>0?"&duration="+std::to_string(query.durationMs/1000):"");
 ++g_httpRequests;
 auto response=transport(get);
 if(response.TransportFailed())return TransportFailure(response);
 if(response.status==429||response.status>=500)return HttpFailure(response.status,response.retryAfter);
 if(response.status==200){
  lyricsjson::JsonValue document;
  if(const auto* root=Root(response,document)){
   Candidate candidate;
   if(ReadCandidate(*root,candidate)){
    const auto match=Evaluate(query,candidate);
    if(match.accepted)return Build(candidate);
    // Rejected exact match: still try search before giving up.
   }else{
    FetchResult result;result.status=LyricsStatus::Error;result.detail="Malformed API response";return result;
   }
  }else{
   FetchResult result;result.status=LyricsStatus::Error;result.detail="Malformed API response";return result;
  }
 }else if(response.status!=404){
  return HttpFailure(response.status,response.retryAfter);
 }
 // Controlled fallback: artist+track search, client-side validation.
 const std::string search=g_endpoint+"/api/search?artist_name="+Encode(query.artist)+"&track_name="+Encode(query.title);
 ++g_httpRequests;
 response=transport(search);
 if(response.TransportFailed())return TransportFailure(response);
 if(response.status==429||response.status>=500)return HttpFailure(response.status,response.retryAfter);
 if(response.status!=200)return HttpFailure(response.status,response.retryAfter);
 lyricsjson::JsonValue document;
 const auto* root=Root(response,document);
 if(!root||root->type!=lyricsjson::JsonValue::Type::Array){
  FetchResult result;result.status=LyricsStatus::Error;result.detail="Malformed API response";return result;
 }
 Candidate bestCandidate;Match bestMatch;double bestScore=-1;bool found=false;
 for(const auto& item:root->items){
  Candidate candidate;
  if(!ReadCandidate(item,candidate))continue;
  const auto match=Evaluate(query,candidate);
  if(!match.accepted)continue;
  if(match.score>bestScore){bestScore=match.score;bestCandidate=std::move(candidate);bestMatch=match;found=true;}
 }
 if(!found)return NotFound("No matching lyrics");
 return Build(bestCandidate);
}

FetchResult Fetch(const TrackQuery& query){
 static const int delays[]={800,2000};
 FetchResult result;
 for(int attempt=0;attempt<3;++attempt){
  result=FetchOnce(query,ActiveTransport());
  if(!result.retryable||attempt==2)break;
  auto delay=result.retryAfterMs>0?std::min<std::int64_t>(result.retryAfterMs,8000):delays[attempt];
  std::this_thread::sleep_for(std::chrono::milliseconds(delay));
 }
 return result;
}

void SetTransport(Transport transport){g_transport=std::move(transport);}
void SetEndpoint(std::string_view baseUrl){g_endpoint=std::string(baseUrl);}
unsigned HttpRequestCount(){return g_httpRequests.load();}

}
