#include "features/visual/ambiance/Ambiance.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <atomic>
#include <cmath>
#include <mutex>

namespace client::features::ambiance {
namespace {
std::mutex settingsMutex;
Settings settings;
std::atomic<std::shared_ptr<const MediaSnapshot>> media{std::make_shared<const MediaSnapshot>()};
std::atomic<std::shared_ptr<const LyricsPayload>> lyrics{std::make_shared<const LyricsPayload>()};
}

Settings Options(){std::lock_guard lock(settingsMutex);return settings;}

void SetOptions(Settings value){
 bool previous;{std::lock_guard lock(settingsMutex);previous=settings.enabled;settings=value;}
 if(!value.enabled||!value.lyrics){
  media.store(std::make_shared<const MediaSnapshot>());
  lyrics.store(std::make_shared<const LyricsPayload>());
 }
 modules::StateChanged(modules::Ambiance,previous,value.enabled);
}

void PublishMedia(MediaSnapshot snapshot){media.store(std::make_shared<const MediaSnapshot>(std::move(snapshot)));}
void PublishLyrics(LyricsPayload payload){lyrics.store(std::make_shared<const LyricsPayload>(std::move(payload)));}

LyricsState LyricsSnapshot(){
 const auto options=Options();
 LyricsState state;
 if(!options.enabled||!options.lyrics)return state;
 const auto track=media.load();
 if(!track||!track->available)return state;
 state.available=true;
 state.trackKey=track->trackKey;
 state.title=track->title;
 state.artist=track->artist;
 state.durationMs=track->durationMs;
 state.positionMs=track->positionMs;
 state.playing=track->playing;
 state.positionAt=track->positionAt;
 state.offsetMs=static_cast<std::int64_t>(std::lround(options.offsetMs));
 if(const auto payload=lyrics.load();payload&&payload->trackKey==track->trackKey){
  state.status=payload->status;
  state.content=payload->content;
  state.detail=payload->detail;
 }else state.status=LyricsStatus::Loading;
 return state;
}

}
