#include "features/visual/ambiance/LyricsLogic.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <unordered_set>

namespace client::features::ambiance::lyricslogic {
namespace {

bool Digit(char c){return c>='0'&&c<='9';}
bool Space(char c){return c==' '||c=='\t'||c=='\r'||c=='\n';}

// Parses "[mm:ss]" / "[mm:ss.xx]" style stamps at pos (pos points at the open
// bracket). On success pos advances past the closing bracket and ms is set.
bool Stamp(std::string_view text,std::size_t& pos,char open,char close,std::int64_t& ms){
 if(pos>=text.size()||text[pos]!=open)return false;
 std::size_t i=pos+1;
 if(i>=text.size()||!Digit(text[i]))return false;
 std::int64_t minutes=0;
 while(i<text.size()&&Digit(text[i]))minutes=minutes*10+(text[i++]-'0');
 if(i>=text.size()||text[i]!=':')return false;
 ++i;
 if(i>=text.size()||!Digit(text[i]))return false;
 std::int64_t seconds=0;
 while(i<text.size()&&Digit(text[i]))seconds=seconds*10+(text[i++]-'0');
 std::int64_t frac=0;int fracDigits=0;
 if(i<text.size()&&text[i]=='.'){
  ++i;
  while(i<text.size()&&Digit(text[i])&&fracDigits<3){frac=frac*10+(text[i]-'0');++fracDigits;++i;}
  while(fracDigits<3){frac*=10;++fracDigits;}
  while(i<text.size()&&Digit(text[i]))++i; // extra precision: truncate
 }
 if(i>=text.size()||text[i]!=close)return false;
 ms=((minutes*60+seconds)*1000)+frac;
 pos=i+1;
 return true;
}

bool MetadataOffset(std::string_view line,std::int64_t& offsetMs){
 // "[offset:+/-N]" (also accepts "[offset: N]").
 constexpr std::string_view tag="[offset:";
 if(line.size()<tag.size()+1)return false;
 for(std::size_t i=0;i<tag.size();++i)
  if(std::tolower(static_cast<unsigned char>(line[i]))!=tag[i])return false;
 std::size_t i=tag.size();
 bool negative=false;
 if(i<line.size()&&(line[i]=='+'||line[i]=='-')){negative=line[i]=='-';++i;}
 while(i<line.size()&&Space(line[i]))++i;
 if(i>=line.size()||!Digit(line[i]))return false;
 std::int64_t value=0;
 while(i<line.size()&&Digit(line[i]))value=value*10+(line[i++]-'0');
 offsetMs=negative?-value:value;
 return true;
}

struct RawToken { std::string text; std::int64_t tagMs=-1; };

// Splits body into whitespace tokens; <mm:ss.xx> tags assign absolute times.
// Tokens before the first tag keep tagMs=-1 (inherit the line start).
std::vector<RawToken> Tokens(std::string_view body){
 std::vector<RawToken> tokens;
 std::string current;
 std::int64_t currentMs=-1;
 const auto flush=[&]{
  while(!current.empty()&&Space(current.back()))current.pop_back();
  std::size_t first=0;while(first<current.size()&&Space(current[first]))++first;
  if(first<current.size())tokens.push_back({current.substr(first),currentMs});
  current.clear();
 };
 std::size_t i=0;
 while(i<body.size()){
  if(body[i]=='<'){
   std::size_t probe=i;std::int64_t ms=0;
   if(Stamp(body,probe,'<','>',ms)){flush();currentMs=ms;i=probe;continue;}
  }
  current+=body[i++];
  if(Space(current.back()))flush();
 }
 flush();
 return tokens;
}

// Line text with <mm:ss.xx> tags removed, whitespace preserved.
std::string CleanText(std::string_view body){
 std::string out;out.reserve(body.size());
 std::size_t i=0;
 while(i<body.size()){
  if(body[i]=='<'){
   std::size_t probe=i;std::int64_t ms=0;
   if(Stamp(body,probe,'<','>',ms)){i=probe;continue;}
  }
  out+=body[i++];
 }
 return out;
}

std::string Trim(std::string_view value){
 std::size_t first=0,last=value.size();
 while(first<last&&Space(value[first]))++first;
 while(last>first&&Space(value[last-1]))--last;
 return std::string(value.substr(first,last-first));
}

int Levenshtein(std::string_view a,std::string_view b){
 const std::size_t n=a.size(),m=b.size();
 if(!n)return static_cast<int>(m);if(!m)return static_cast<int>(n);
 std::vector<int> prev(m+1),curr(m+1);
 for(std::size_t j=0;j<=m;++j)prev[j]=static_cast<int>(j);
 for(std::size_t i=1;i<=n;++i){
  curr[0]=static_cast<int>(i);
  for(std::size_t j=1;j<=m;++j){
   const int cost=a[i-1]==b[j-1]?0:1;
   curr[j]=std::min({prev[j]+1,curr[j-1]+1,prev[j-1]+cost});
  }
  std::swap(prev,curr);
 }
 return prev[m];
}

}

std::vector<LyricLine> ParseLrc(std::string_view lrc,std::int64_t& offsetMs){
 offsetMs=0;
 struct Draft { std::int64_t startMs; std::string text; std::vector<RawToken> tokens; };
 std::vector<Draft> drafts;
 std::size_t at=0;
 while(at<=lrc.size()){
  const auto newline=lrc.find('\n',at);
  std::string_view line=lrc.substr(at,newline==std::string_view::npos?std::string_view::npos:newline-at);
  at=newline==std::string_view::npos?lrc.size()+1:newline+1;
  while(!line.empty()&&line.back()=='\r')line.remove_suffix(1);
  while(!line.empty()&&Space(line.front()))line.remove_prefix(1);
  while(!line.empty()&&Space(line.back()))line.remove_suffix(1);
  if(line.empty())continue;
  if(MetadataOffset(line,offsetMs))continue;
  if(line.front()=='['&&line.size()>1&&std::isalpha(static_cast<unsigned char>(line[1])))continue; // [ti:], [ar:], ...
  std::vector<std::int64_t> stamps;
  std::size_t pos=0;
  while(pos<line.size()&&line[pos]=='['){
   std::int64_t ms=0;
   if(!Stamp(line,pos,'[',']',ms))break;
   stamps.push_back(ms);
  }
  if(stamps.empty())continue;
  const auto body=line.substr(pos);
  Draft draft{0,CleanText(body),Tokens(body)};
  for(const auto stamp:stamps){draft.startMs=stamp;drafts.push_back(draft);}
 }
 std::vector<LyricLine> lines;
 lines.reserve(drafts.size());
 for(auto& draft:drafts){
  LyricLine line;line.startMs=draft.startMs;line.text=Trim(draft.text);
  line.words.reserve(draft.tokens.size());
  for(std::size_t i=0;i<draft.tokens.size();++i){
   const auto& token=draft.tokens[i];
   const auto next=i+1<draft.tokens.size()?draft.tokens[i+1].tagMs:-1;
   LyricWord word;word.text=token.text;
   word.startMs=token.tagMs>=0?token.tagMs:line.startMs;
   word.endMs=next>=0?next:0;
   line.words.push_back(std::move(word));
  }
  lines.push_back(std::move(line));
 }
 // Words without explicit tags get even estimates across the line span.
 for(std::size_t i=0;i<lines.size();++i){
  auto& line=lines[i];
  const auto lineEnd=i+1<lines.size()?lines[i+1].startMs:0;
  line.endMs=lineEnd;
  const auto lineStart=line.startMs;
  const bool explicitTags=std::any_of(line.words.begin(),line.words.end(),[lineStart](const LyricWord& w){return w.endMs>0||w.startMs!=lineStart;});
  if(line.words.empty())continue;
  if(!explicitTags&&lineEnd>line.startMs){
   const auto span=lineEnd-line.startMs;const auto each=span/static_cast<std::int64_t>(line.words.size());
   for(std::size_t w=0;w<line.words.size();++w){
    line.words[w].startMs=line.startMs+each*static_cast<std::int64_t>(w);
    line.words[w].endMs=w+1<line.words.size()?line.words[w].startMs+each:lineEnd;
    line.words[w].estimated=true; // even split, not real word timing
   }
  }else{
   for(std::size_t w=0;w<line.words.size();++w)
    if(line.words[w].endMs==0)line.words[w].endMs=w+1<line.words.size()?line.words[w+1].startMs:lineEnd;
  }
 }
 std::stable_sort(lines.begin(),lines.end(),[](const LyricLine& a,const LyricLine& b){return a.startMs<b.startMs;});
 return lines;
}

std::vector<std::string> ParsePlain(std::string_view plain){
 std::vector<std::string> lines;
 std::size_t at=0;
 while(at<=plain.size()){
  const auto newline=plain.find('\n',at);
  std::string_view line=plain.substr(at,newline==std::string_view::npos?std::string_view::npos:newline-at);
  at=newline==std::string_view::npos?plain.size()+1:newline+1;
  while(!line.empty()&&line.back()=='\r')line.remove_suffix(1);
  lines.push_back(Trim(line));
 }
 while(!lines.empty()&&lines.back().empty())lines.pop_back();
 return lines;
}

std::string NormalizeName(std::string_view name){
 std::string out;
 // Strip "feat. ..." / "ft. ..." / "featuring ..." tails first.
 std::string lower;
 lower.reserve(name.size());
 for(const unsigned char c:name)lower+=static_cast<char>(std::tolower(c));
 for(const char* mark:{" feat."," ft."," featuring"," feat "," ft "}){
  if(const auto at=lower.find(mark);at!=std::string::npos)lower.resize(at);
 }
 for(const unsigned char c:lower){
  if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c>=0x80)out+=static_cast<char>(c);
  else out+=' ';
 }
 // collapse spaces
 std::string collapsed;bool pending=false;
 for(const char c:out){
  if(c==' '){if(!collapsed.empty()&&!pending){collapsed+=' ';pending=true;}continue;}
  collapsed+=c;pending=false;
 }
 while(!collapsed.empty()&&collapsed.back()==' ')collapsed.pop_back();
 return collapsed;
}

double NameSimilarity(std::string_view a,std::string_view b){
 const auto na=NormalizeName(a),nb=NormalizeName(b);
 if(na.empty()||nb.empty())return 0;
 if(na==nb)return 1;
 const double lev=1.0-static_cast<double>(Levenshtein(na,nb))/static_cast<double>(std::max(na.size(),nb.size()));
 std::unordered_set<std::string> ta,tb;
 std::string token;
 const auto split=[&](const std::string& s,std::unordered_set<std::string>& into){
  for(const char c:s){if(c==' '){if(!token.empty()){into.insert(token);token.clear();}}else token+=c;}
  if(!token.empty())into.insert(token);
 };
 split(na,ta);split(nb,tb);
 std::size_t shared=0;
 for(const auto& t:ta)if(tb.count(t))++shared;
 const double dice=ta.empty()||tb.empty()?0:2.0*static_cast<double>(shared)/static_cast<double>(ta.size()+tb.size());
 return std::max(lev,dice);
}

}

namespace client::features::ambiance {

ActiveLyrics GetActiveLyrics(const LyricsState& state,std::int64_t positionMs){
 ActiveLyrics result;
 if(state.status!=LyricsStatus::Synced||!state.content)return result;
 const auto& lines=state.content->lines;
 if(lines.empty())return result;
 auto t=positionMs+state.offsetMs+(state.content?state.content->offsetMs:0);
 if(t<0)t=0;
 // last line with startMs <= t
 std::size_t lo=0,hi=lines.size();
 while(lo<hi){const auto mid=(lo+hi)/2;if(lines[mid].startMs<=t)lo=mid+1;else hi=mid;}
 if(lo==0)return result;
 const auto index=lo-1;const auto& line=lines[index];
 if(line.endMs>0&&t>=line.endMs)return result;
 result.lineIndex=index;result.line=&line;
 for(std::size_t w=0;w<line.words.size();++w){
  const auto& word=line.words[w];
  if(word.startMs>t)break;
  if(word.endMs==0||t<word.endMs){result.wordIndex=w;break;}
 }
 return result;
}

std::int64_t PredictPositionMs(const LyricsState& state,std::chrono::steady_clock::time_point now){
 if(!state.playing||state.durationMs<=0)return state.positionMs;
 const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(now-state.positionAt).count();
 return std::clamp<std::int64_t>(state.positionMs+elapsed,0,state.durationMs);
}

namespace lyricslogic {

std::int64_t AdvancePlaybackClock(PlaybackClock& clock,std::int64_t gsmPosMs,
                                  bool playing,std::int64_t durationMs,
                                  std::int64_t nowTickMs){
 if(!playing){
  // Paused: GSMTC position is authoritative and frozen.
  clock.pubPos=gsmPosMs;clock.pubAtMs=nowTickMs;
  clock.rawGsm=gsmPosMs;clock.wasPlaying=false;
  return gsmPosMs;
 }
 // Playing: keep a free-running estimate anchored at the last adopted
 // position. A GSMTC sample stays on the estimate when it is a stale repeat
 // (<=60 ms vs the previous sample) or within tolerance of the estimate
 // (normal advance, catch-up after a stall, jitter, small corrections).
 // Anything else is a real seek or large correction and re-anchors below.
 // Only adopted samples move the anchor, so multi-second GSMTC stalls never
 // freeze or jump the published clock.
 constexpr std::int64_t kGsmToleranceMs=800;
 constexpr std::int64_t kSameSampleMs=60;
 if(clock.wasPlaying&&clock.pubPos>=0&&nowTickMs>clock.pubAtMs){
  const std::int64_t est=clock.pubPos+(nowTickMs-clock.pubAtMs);
  if(durationMs>0&&est>=durationMs)return durationMs;
  const bool staleSample=std::llabs(gsmPosMs-clock.rawGsm)<=kSameSampleMs;
  const bool withinTol=std::llabs(gsmPosMs-est)<=kGsmToleranceMs;
  // Stale repeats and in-tolerance samples (normal advance, catch-up,
  // jitter, small backward corrections) stay on the smooth estimate;
  // anything else is a real seek or large correction -> adopt below.
  if(staleSample||withinTol){clock.rawGsm=gsmPosMs;return est;}
 }
 // Adopt: first sample, resume after pause, or a real seek/correction.
 clock.pubPos=gsmPosMs;clock.pubAtMs=nowTickMs;
 clock.rawGsm=gsmPosMs;clock.wasPlaying=true;
 return gsmPosMs;
}

}

}
