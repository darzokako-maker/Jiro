#include "features/visual/ambiance/LyricsService.hpp"
#include <Windows.h>
#include <winhttp.h>
#include <string>
#include <vector>

namespace client::features::ambiance::lyrics {
namespace {

constexpr DWORD kTimeoutMs=8000;
constexpr std::size_t kMaxBodyBytes=512*1024;

struct Url {
 std::wstring host;
 std::wstring path;
 INTERNET_PORT port=INTERNET_DEFAULT_HTTPS_PORT;
 bool secure=true;
};

bool ParseUrl(std::string_view url,Url& out){
 if(url.rfind("https://",0)!=0&&url.rfind("http://",0)!=0)return false;
 const bool secure=url[4]=='s';
 std::string_view rest=url.substr(secure?8:7);
 const auto slash=rest.find('/');
 const auto authority=slash==std::string_view::npos?rest:rest.substr(0,slash);
 out.path=slash==std::string_view::npos?L"/":std::wstring(rest.substr(slash).begin(),rest.substr(slash).end());
 out.secure=secure;
 out.port=secure?INTERNET_DEFAULT_HTTPS_PORT:INTERNET_DEFAULT_HTTP_PORT;
 std::string_view host=authority;
 if(const auto colon=host.rfind(':');colon!=std::string_view::npos&&host.find(':')==colon){
  const auto portText=host.substr(colon+1);host=host.substr(0,colon);
  int port=0;for(const char c:portText){if(c<'0'||c>'9')return false;port=port*10+(c-'0');}
  if(port<=0||port>65535)return false;out.port=static_cast<INTERNET_PORT>(port);
 }
 if(host.empty())return false;
 out.host.assign(host.begin(),host.end());
 return true;
}

std::wstring Wide(std::string_view value){return {value.begin(),value.end()};}

}

HttpResponse TransportWinHttp(std::string_view url){
 HttpResponse response;
 Url parsed;
 if(!ParseUrl(url,parsed)){response.error="Unsupported URL";return response;}
 HINTERNET session=WinHttpOpen(L"AokiAmbiance/1.0",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
  WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);
 if(!session){response.error="WinHttpOpen failed";return response;}
 // TLS certificate validation stays enabled (WinHTTP default for HTTPS).
 WinHttpSetTimeouts(session,kTimeoutMs,kTimeoutMs,kTimeoutMs,kTimeoutMs+4000);
 HINTERNET connection=nullptr,request=nullptr;
 const auto cleanup=[&]{if(request)WinHttpCloseHandle(request);if(connection)WinHttpCloseHandle(connection);WinHttpCloseHandle(session);};
 connection=WinHttpConnect(session,parsed.host.c_str(),parsed.port,0);
 if(!connection){response.error="WinHttpConnect failed";cleanup();return response;}
 DWORD flags=parsed.secure?WINHTTP_FLAG_SECURE:0;
 request=WinHttpOpenRequest(connection,L"GET",parsed.path.c_str(),nullptr,
  WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,flags);
 if(!request){response.error="WinHttpOpenRequest failed";cleanup();return response;}
 if(!WinHttpSendRequest(request,WINHTTP_NO_ADDITIONAL_HEADERS,0,WINHTTP_NO_REQUEST_DATA,0,0,0)||
    !WinHttpReceiveResponse(request,nullptr)){
  response.error="Request failed";cleanup();return response;
 }
 DWORD status=0,statusSize=sizeof(status);
 if(!WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,
  WINHTTP_HEADER_NAME_BY_INDEX,&status,&statusSize,WINHTTP_NO_HEADER_INDEX)){
  response.error="Status query failed";cleanup();return response;
 }
 response.status=static_cast<int>(status);
 wchar_t retry[64]{};DWORD retrySize=sizeof(retry);
 if(WinHttpQueryHeaders(request,WINHTTP_QUERY_RETRY_AFTER,WINHTTP_HEADER_NAME_BY_INDEX,
  retry,&retrySize,WINHTTP_NO_HEADER_INDEX)){
  std::string text;for(const wchar_t* p=retry;*p&&text.size()<63;++p)text+=static_cast<char>(*p<128?*p:'?');
  response.retryAfter=text;
 }
 if(status==200){
  std::vector<char> body;body.reserve(64*1024);DWORD available=0;
  for(;;){
   if(!WinHttpQueryDataAvailable(request,&available)){response.error="Read failed";cleanup();return response;}
   if(available==0)break;
   if(body.size()+available>kMaxBodyBytes){response.error="Response too large";cleanup();return response;}
   const auto offset=body.size();body.resize(offset+available);
   DWORD read=0;
   if(!WinHttpReadData(request,body.data()+offset,available,&read)){response.error="Read failed";cleanup();return response;}
   body.resize(offset+read);
   if(read==0)break;
  }
  response.body.assign(body.begin(),body.end());
 }
 cleanup();
 return response;
}

}
