#include "features/visual/ambiance/ParticleRaster.hpp"
#include "client/Logger.hpp"
#include "EmbeddedFonts.hpp"
#include <Windows.h>
#include <objidl.h>
#include <gdiplus.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

namespace client::features::ambiance::lyrics3d {
namespace {
using Gdiplus::Bitmap;
using Gdiplus::BitmapData;
using Gdiplus::CharacterRange;
using Gdiplus::Color;
using Gdiplus::Font;
using Gdiplus::FontFamily;
using Gdiplus::FontStyle;
using Gdiplus::Graphics;
using Gdiplus::PrivateFontCollection;
using Gdiplus::RectF;
using Gdiplus::Region;
using Gdiplus::SolidBrush;
using Gdiplus::StringFormat;

// ---- tunables (text-pixel space) ----
constexpr int kDensity=1;               // every pixel: dense, small-looking dots
constexpr float kFontEm=72.f;           // rasterization size; world scale is derived
constexpr float kMaxTextWidth=1500.f;   // px; longer lines shrink the font
constexpr float kMinFontEm=28.f;
constexpr int kPad=10;
// No fixed particle limit: density=1 keeps every alpha>40 sample.

// ---- GDI+ font (initialized once, process lifetime) ----
// GDI+ PrivateFontCollection only accepts file paths, so the embedded TTF is
// staged to %TEMP% once and registered from there. failStage pinpoints the
// first broken stage for diagnostics: 0 ok, 1 startup, 2 temp write,
// 3 AddFontFile, 4 GetFamilies.
struct FontKit {
 ULONG_PTR token=0;
 // Created only after GdiplusStartup succeeds: GDI+ objects constructed
 // before startup hold an invalid native handle and every call fails.
 std::unique_ptr<PrivateFontCollection> collection;
 std::unique_ptr<FontFamily[]> families;
 FontFamily* family=nullptr;
 INT style=Gdiplus::FontStyleRegular;
 int failStage=0;
 bool ready=false;
 FontKit(){
  Gdiplus::GdiplusStartupInput input{};input.GdiplusVersion=1;
  Gdiplus::GdiplusStartupOutput output{};
  const auto status=Gdiplus::GdiplusStartup(&token,&input,&output);
  if(status!=Gdiplus::Ok){failStage=1;AOKI_LOG("[lyrics3d] GdiplusStartup failed status=%d",static_cast<int>(status));return;}
  wchar_t temp[MAX_PATH]{};
  if(!GetTempPathW(MAX_PATH,temp)){failStage=2;AOKI_LOG("[lyrics3d] GetTempPathW failed %lu",GetLastError());return;}
  const std::wstring path=std::wstring(temp)+L"aoki_fredoka_semibold.ttf";
  {
   FILE* file=nullptr;
   if(_wfopen_s(&file,path.c_str(),L"wb")||!file){failStage=2;AOKI_LOG("[lyrics3d] font temp open failed %lu",GetLastError());return;}
   const bool wrote=std::fwrite(kFredokaSemiBold,1,sizeof(kFredokaSemiBold),file)==sizeof(kFredokaSemiBold);
   std::fclose(file);
   if(!wrote){failStage=2;AOKI_LOG("[lyrics3d] font temp write incomplete");return;}
  }
  collection=std::make_unique<PrivateFontCollection>();
  if(collection->AddFontFile(path.c_str())!=Gdiplus::Ok){failStage=3;AOKI_LOG("[lyrics3d] AddFontFile failed");return;}
  families=std::make_unique<FontFamily[]>(1);
  int found=0;
  if(collection->GetFamilies(1,families.get(),&found)!=Gdiplus::Ok||found<1){failStage=4;AOKI_LOG("[lyrics3d] GetFamilies failed status found=%d",found);return;}
  family=families.get();
  // Fredoka SemiBold is a single family; prefer real bold only when the face
  // actually provides it, otherwise fall back to regular.
  style=family->IsStyleAvailable(Gdiplus::FontStyleBold)?Gdiplus::FontStyleBold:Gdiplus::FontStyleRegular;
  ready=true;
 }
 ~FontKit(){family=nullptr;families.reset();collection.reset();if(token)Gdiplus::GdiplusShutdown(token);}
};
FontKit& Kit(){static FontKit kit;return kit;}

std::wstring UTF8ToWide(const std::string& utf8){
 if(utf8.empty())return {};
 const int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,utf8.data(),static_cast<int>(utf8.size()),nullptr,0);
 if(count<=0)return {};
 std::wstring out(static_cast<std::size_t>(count),L'\0');
 MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,utf8.data(),static_cast<int>(utf8.size()),out.data(),count);
 return out;
}

// The embedded Fredoka subset lacks several Turkish diacritics; they rasterize
// as .notdef boxes or vanish. Synthesize ASCII lookalikes before drawing so
// every glyph produces particles (ş->s, ğ->g, ç->c, ı->i, İ->I, ö->o, ü->u,
// â->a, î->i, û->u). Applied to BOTH the line text and word texts so the
// character-range mapping stays consistent.
wchar_t MapGlyph(wchar_t c){
 switch(c){
  case L'ş':return L's';case L'Ş':return L'S';
  case L'ğ':return L'g';case L'Ğ':return L'G';
  case L'ç':return L'c';case L'Ç':return L'C';
  case L'ı':return L'i';
  case L'İ':return L'I';
  case L'ö':return L'o';case L'Ö':return L'O';
  case L'ü':return L'u';case L'Ü':return L'U';
  case L'â':return L'a';case L'Â':return L'A';
  case L'î':return L'i';case L'Î':return L'I';
  case L'û':return L'u';case L'Û':return L'U';
 }
 return c;
}
std::wstring SanitizeForFont(std::wstring text){
 for(auto& c:text)c=MapGlyph(c);
 return text;
}

// Measures with a fresh Font at the requested em size; Font objects are cheap
// but must be recreated whenever em changes.
bool MeasureText(Graphics& g,const std::wstring& text,float em,const FontKit& kit,
                 const StringFormat* format,Gdiplus::RectF& out){
 Font font(kit.family,em,kit.style,Gdiplus::UnitPixel);
 if(font.GetLastStatus()!=Gdiplus::Ok){AOKI_LOG("[lyrics3d] Font create failed em=%.1f",em);return false;}
 const auto status=g.MeasureString(text.c_str(),-1,&font,Gdiplus::RectF(0,0,8192,1024),format,&out);
 if(status!=Gdiplus::Ok){AOKI_LOG("[lyrics3d] MeasureString failed status=%d",static_cast<int>(status));return false;}
 return true;
}

}

int RasterFontKitStatus(){auto& kit=Kit();return kit.ready?-1:kit.failStage;}

bool RasterizeLine(const LyricLine& line,LineLayout& layout){
 layout=LineLayout{};
 auto& kit=Kit();
 if(!kit.ready){
  static bool loggedKit=false;
  if(!loggedKit){loggedKit=true;AOKI_LOG("[lyrics3d] font kit not ready failStage=%d",kit.failStage);}
  return false;
 }
 const auto text=SanitizeForFont(UTF8ToWide(line.text));
 if(text.empty()){AOKI_LOG("[lyrics3d] empty text after utf8 conversion");return false;}
 auto format=std::unique_ptr<StringFormat>(StringFormat::GenericDefault()->Clone());
 format->SetAlignment(Gdiplus::StringAlignmentNear);
 format->SetLineAlignment(Gdiplus::StringAlignmentNear);
 format->SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap);

 // Measure once, shrink the em size until the line fits the width budget.
 // The Font is recreated per attempt so the new em actually applies.
 float em=kFontEm;
 RectF measured{};
 {
  Bitmap probe(4,4,PixelFormat32bppPARGB);
  Graphics g(&probe);
  g.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
  for(int attempt=0;attempt<4;++attempt){
   if(!MeasureText(g,text,em,kit,format.get(),measured))return false;
   if(measured.Width<=kMaxTextWidth||em<=kMinFontEm)break;
   em=std::max(kMinFontEm,em*kMaxTextWidth/std::max(1.f,measured.Width));
  }
 }
 const int width=static_cast<int>(std::ceil(measured.Width))+kPad*2;
 const int height=static_cast<int>(std::ceil(measured.Height))+kPad*2;
 if(width<=0||height<=0||width>8192||height>2048){
  AOKI_LOG("[lyrics3d] implausible bitmap %dx%d (measured %.0fx%.0f)",width,height,measured.Width,measured.Height);
  return false;
 }

 // Map each word to its UTF-16 range inside the full line text. Words are
 // whitespace tokens of the same cleaned body, so sequential find is exact;
 // repeated words resolve in order.
 std::vector<CharacterRange> charRanges(line.words.size());
 std::vector<std::wstring> wordWide(line.words.size());
 {
  std::size_t cursor=0;bool rangesOk=true;
  for(std::size_t w=0;w<line.words.size();++w){
   wordWide[w]=SanitizeForFont(UTF8ToWide(line.words[w].text));
   const auto pos=wordWide[w].empty()?std::wstring::npos:text.find(wordWide[w],cursor);
   if(pos==std::wstring::npos){rangesOk=false;break;}
   charRanges[w]=CharacterRange(static_cast<INT>(pos),static_cast<INT>(wordWide[w].size()));
   cursor=pos+wordWide[w].size();
  }
  if(rangesOk&&!charRanges.empty())
   format->SetMeasurableCharacterRanges(static_cast<INT>(charRanges.size()),charRanges.data());
 }

 Bitmap bitmap(width,height,PixelFormat32bppPARGB);
 {
  Graphics g(&bitmap);
  g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
  g.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
  g.Clear(Color(0,0,0,0));
  SolidBrush brush(Color(255,255,255,255));
  Font font(kit.family,em,kit.style,Gdiplus::UnitPixel);
  if(font.GetLastStatus()!=Gdiplus::Ok){AOKI_LOG("[lyrics3d] draw Font create failed");return false;}
  const auto status=g.DrawString(text.c_str(),-1,&font,Gdiplus::RectF(static_cast<Gdiplus::REAL>(kPad),static_cast<Gdiplus::REAL>(kPad),
   static_cast<Gdiplus::REAL>(width-kPad*2),static_cast<Gdiplus::REAL>(height-kPad*2)),format.get(),&brush);
  if(status!=Gdiplus::Ok){AOKI_LOG("[lyrics3d] DrawString failed status=%d",static_cast<int>(status));return false;}
 }

 // Per-word horizontal bounds from the REAL full-line layout via
 // MeasureCharacterRanges: kerning, bearings and overhang are accounted for,
 // unlike cumulative per-word MeasureString which drifted and left glyph
 // pixels unassigned (visible as missing letters like 'a').
 std::vector<float> wordLeft(line.words.size()),wordRight(line.words.size());
 bool spansAccurate=false;
 {
  Graphics g(&bitmap);
  g.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
  Font font(kit.family,em,kit.style,Gdiplus::UnitPixel);
  if(font.GetLastStatus()==Gdiplus::Ok){
   const auto layoutRect=Gdiplus::RectF(static_cast<Gdiplus::REAL>(kPad),static_cast<Gdiplus::REAL>(kPad),
    static_cast<Gdiplus::REAL>(width-kPad*2),static_cast<Gdiplus::REAL>(height-kPad*2));
   std::vector<Region> regions(charRanges.size());
   const auto status=g.MeasureCharacterRanges(text.c_str(),static_cast<INT>(text.size()),&font,layoutRect,
    format.get(),static_cast<INT>(charRanges.size()),regions.data());
   if(status==Gdiplus::Ok){
    bool ok=true;
    for(std::size_t w=0;w<charRanges.size();++w){
     Gdiplus::RectF bounds{};
     if(regions[w].GetBounds(&bounds,&g)!=Gdiplus::Ok){ok=false;break;}
     wordLeft[w]=bounds.X;wordRight[w]=bounds.X+bounds.Width;
    }
    spansAccurate=ok;
   }
  }
 }
 if(!spansAccurate){
  // Fallback: cumulative per-word measurement (approximate; chunk rescue in
  // ChunkLayout still prevents dropped pixels).
  Bitmap probe(4,4,PixelFormat32bppPARGB);
  Graphics g(&probe);
  g.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
  Gdiplus::RectF space{};
  if(!MeasureText(g,L" ",em,kit,format.get(),space))return false;
  const float spaceWidth=space.Width;
  float cursor=kPad;
  for(std::size_t w=0;w<line.words.size();++w){
   Gdiplus::RectF box{};
   if(!wordWide[w].empty()&&!MeasureText(g,wordWide[w],em,kit,format.get(),box))return false;
   wordLeft[w]=cursor;wordRight[w]=cursor+box.Width;
   cursor+=box.Width+spaceWidth;
  }
 }

 BitmapData data{};
 const auto rect=Gdiplus::Rect(0,0,width,height);
 if(bitmap.LockBits(&rect,Gdiplus::ImageLockModeRead,PixelFormat32bppPARGB,&data)!=Gdiplus::Ok){
  AOKI_LOG("[lyrics3d] LockBits failed");return false;
 }

 int unassigned=0;
 const auto* base=static_cast<const unsigned char*>(data.Scan0);
 int stride=data.Stride;
 if(stride<0){base+=static_cast<std::ptrdiff_t>(height-1)*(-stride);stride=-stride;}
 for(int y=0;y<height;y+=kDensity){
  const auto* row=base+static_cast<std::ptrdiff_t>(y)*stride;
  for(int x=0;x<width;x+=kDensity){
   const auto alpha=row[static_cast<std::ptrdiff_t>(x)*4+3];
   if(alpha<=40)continue;
   // Locate the owning word by its measured layout span.
   int word=-1;
   for(std::size_t w=0;w<line.words.size();++w)
    if(static_cast<float>(x)>=wordLeft[w]&&static_cast<float>(x)<=wordRight[w]){word=static_cast<int>(w);break;}
   if(word<0)++unassigned;
   ParticleTarget target;
   target.x=static_cast<float>(x);target.y=static_cast<float>(y);
   target.word=word;target.weight=alpha/255.f;
   if(word>=0){
    const float span=std::max(1.f,wordRight[word]-wordLeft[word]);
    target.xNorm=std::clamp((static_cast<float>(x)-wordLeft[word])/span,0.f,1.f);
   }
   layout.targets.push_back(target);
  }
 }
 bitmap.UnlockBits(&data);
 {
  int assigned=0;for(const auto&t:layout.targets)if(t.word>=0)++assigned;
  AOKI_LOG("[lyrics3d:glyph] line=%lld spans=%s alphaTargets=%zu assigned=%d unassigned=%d",
   static_cast<long long>(line.startMs),spansAccurate?"ranges":"approx",
   layout.targets.size(),assigned,unassigned);
 }
 if(layout.targets.empty()){
  AOKI_LOG("[lyrics3d] sampling produced 0 targets (%dx%d em=%.1f text=\"%s\")",width,height,em,line.text.c_str());
  return false;
 }
 // No particle cap: every alpha>40 sample is kept; real glyph density
 // decides the particle count.
 // Center the layout so the billboard anchors on the text's middle. GDI+
 // bitmap rows grow downward while the billboard's world-space Y grows up,
 // so the vertical axis must be negated or the text renders upside down.
 const float cx=width*0.5f,cy=height*0.5f;
 for(auto& t:layout.targets){t.x-=cx;t.y=cy-t.y;}
 layout.words.reserve(line.words.size());
 for(std::size_t w=0;w<line.words.size();++w){
  const auto& source=line.words[w];
  WordSpan span;
  span.startMs=source.startMs;
  span.endMs=source.endMs>0?source.endMs:(w+1<line.words.size()?line.words[w+1].startMs:(line.endMs>0?line.endMs:source.startMs+500));
  span.left=wordLeft[w]-cx;span.right=wordRight[w]-cx;
  layout.words.push_back(span);
 }
 layout.width=static_cast<float>(width);layout.height=static_cast<float>(height);
 return true;
}

}
