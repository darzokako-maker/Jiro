#include "features/visual/ambiance/ParticleLyricsLogic.hpp"
#include <algorithm>
#include <cmath>

namespace client::features::ambiance::lyrics3d {
namespace {
constexpr float kTau=6.28318530718f;
// Soft karaoke edge as a fraction of the word's own width.
constexpr float kKaraokeEdge=0.10f;
}

float Field::NextRandom(){
 // Deterministic LCG so morph behavior is reproducible in tests.
 rng_=rng_*1664525u+1013904223u;
 return static_cast<float>((rng_>>8)&0xFFFFFFu)/16777216.f;
}

void Field::Clear(){
 for(auto& p:particles_)p.fadeGoal=0; // retire gracefully instead of vanishing
 particles_.clear();wordProgress_.clear();layout_.reset();timeMs_=0;
}

void Field::SetLayout(const LineLayout& layout,std::uint32_t seed){
 layout_=std::make_shared<const LineLayout>(layout);
 wordProgress_.assign(layout.words.size(),0.f);
 rng_=seed?seed:1;
 const auto& targets=layout.targets;
 const bool fresh=particles_.empty();
 if(targets.empty()){
  // No ink in this window: retire everything, keep the field object alive.
  for(auto& p:particles_){p.fadeGoal=0;}
  return;
 }
 // Particle count adapts to real target density; no artificial cap.
 // - deficit  -> spawn the difference with a small gather scatter
 // - surplus  -> surplus particles fade out (fadeGoal=0) while active ones
 //   merge onto targets round-robin; positions are never reset.
 const std::size_t want=targets.size();
 const std::size_t stride=targets.size()>want?(targets.size()+want-1)/want:1;
 std::vector<const ParticleTarget*> picked;
 picked.reserve(want);
 for(std::size_t i=0;i<targets.size()&&picked.size()<want;i+=stride)picked.push_back(&targets[i]);

 if(fresh){
  particles_.clear();particles_.reserve(picked.size());
  for(std::size_t i=0;i<picked.size();++i){
   const auto* t=picked[i];
   Particle p;
   p.seed=NextRandom();p.depth=0.45f+NextRandom()*0.9f;
   p.word=t->word;p.xNorm=t->xNorm;p.weight=t->weight;
   p.targetX=t->x;p.targetY=t->y;
   // Initial gather: particles start on a scattered ring around their target.
   const float angle=p.seed*kTau;
   const float distance=(60.f+90.f*p.depth)*(0.35f+p.seed*0.75f);
   p.x=t->x+std::cos(angle)*distance+(p.seed-0.5f)*90.f;
   p.y=t->y+std::sin(angle)*distance+(p.depth-0.9f)*54.f;
   p.startX=p.x;p.startY=p.y;
   particles_.push_back(p);
  }
  return;
 }
 const std::size_t active=std::min(particles_.size(),want);
 for(std::size_t i=0;i<active;++i){
  auto& p=particles_[i];
  const auto* t=picked[i%picked.size()];
  const float jitter=(NextRandom()-0.5f)*3.f;
  p.startX=p.x;p.startY=p.y;
  p.targetX=t->x+jitter;p.targetY=t->y+jitter;
  p.word=t->word;p.xNorm=t->xNorm;p.weight=t->weight;
  p.fadeGoal=1.f;
 }
 // Surplus particles retire: keep position/target, alpha fades to zero.
 for(std::size_t i=active;i<particles_.size();++i)particles_[i].fadeGoal=0.f;
 // Deficit: spawn the difference with a tight gather so new density flies in
 // quickly instead of re-gathering the whole field.
 while(particles_.size()<want){
  const auto* t=picked[particles_.size()%picked.size()];
  Particle p;
  p.seed=NextRandom();p.depth=0.45f+NextRandom()*0.9f;
  p.word=t->word;p.xNorm=t->xNorm;p.weight=t->weight;
  p.targetX=t->x;p.targetY=t->y;
  const float angle=p.seed*kTau;
  const float distance=18.f+30.f*p.depth;
  p.x=t->x+std::cos(angle)*distance+(p.seed-0.5f)*24.f;
  p.y=t->y+std::sin(angle)*distance+(p.depth-0.9f)*18.f;
  p.startX=p.x;p.startY=p.y;
  p.fade=0.f;p.fadeGoal=1.f;
  particles_.push_back(p);
 }
}

void Field::SetKaraoke(std::int64_t positionMs){
 wordProgress_.assign(layout_?layout_->words.size():0,1.f);
 if(!layout_)return;
 for(std::size_t w=0;w<layout_->words.size();++w){
  const auto& span=layout_->words[w];
  const auto duration=span.endMs-span.startMs;
  float p=1.f;
  if(duration>0)p=Clamp01(static_cast<float>(positionMs-span.startMs)/static_cast<float>(duration));
  else if(positionMs<span.startMs)p=0.f;
  wordProgress_[w]=p;
 }
}

float Field::KaraokeFill(const Particle& particle)const{
 if(particle.word<0||particle.word>=static_cast<int>(wordProgress_.size()))return 0.f;
 const auto progress=wordProgress_[static_cast<std::size_t>(particle.word)];
 // Linear ramp centred on the word's progress point: fully sung below
 // progress-edge/2, fully pending above progress+edge/2.
 return Clamp01((progress+kKaraokeEdge*0.5f-particle.xNorm)/kKaraokeEdge);
}

bool Field::Step(float dtMs,float idleDrift){
 if(dtMs<=0)return false; // paused lyrics clock: freeze exactly, no epsilon drift
 if(dtMs>100)dtMs=100; // clamp hitches; seek jumps are handled by the caller snapping
 timeMs_+=dtMs;
 const float frames=std::max(dtMs/16.6667f,0.001f);
 const float follow=FollowFactor(frames);
 const float fadeRate=std::min(1.f,dtMs/140.f); // ~140 ms fade in/out
 const float time=timeMs_*0.001f;
 bool moving=false;
 for(auto& p:particles_){
  // Fade toward goal; fully retired particles are removed after the loop.
  if(p.fade!=p.fadeGoal){
   p.fade+=(p.fadeGoal-p.fade)*fadeRate;
   if(std::fabs(p.fade-p.fadeGoal)<0.01f)p.fade=p.fadeGoal;
   moving=true;
  }
  float baseX=p.targetX,baseY=p.targetY;
  if(idleDrift>0){
   baseX+=std::sin(time*0.9f+p.seed*10.f)*idleDrift*p.depth;
   baseY+=std::cos(time*0.75f+p.depth*10.f)*idleDrift*p.depth;
  }
  const float moveX=(baseX-p.x)*follow,moveY=(baseY-p.y)*follow;
  p.x+=moveX;p.y+=moveY;
  if(std::fabs(moveX)+std::fabs(moveY)>0.02f)moving=true;
  // Motion heat: distance to target, matching the reference component's
  // HEAT_RANGE/HEAT_DEADZONE. Drives brightness only, never karaoke hue.
  const float dist=std::hypot(p.x-p.targetX,p.y-p.targetY);
  p.heat=Clamp01((dist-3.f)/36.f);
 }
 // Remove fully faded retirees (swap-with-last keeps order irrelevant).
 for(std::size_t i=0;i<particles_.size();){
  if(particles_[i].fadeGoal==0.f&&particles_[i].fade<=0.001f){
   particles_[i]=particles_.back();particles_.pop_back();moving=true;
  }else ++i;
 }
 return moving;
}

std::int64_t SyncLyricsClock(LyricsClock& clock,std::int64_t rawMs,std::int64_t elapsedMs,
                             bool playing,std::int64_t durationMs,bool& seek){
 seek=false;
 const auto clampPos=[](std::int64_t v,std::int64_t dur){
  v=std::max<std::int64_t>(v,0);return dur>0?std::min(v,dur):v;
 };
 if(!playing||!clock.valid){
  clock.heldMs=clampPos(rawMs,durationMs);clock.valid=true;
  return clock.heldMs;
 }
 // Deadband: GSMTC republishes positionMs every few hundred ms and the new
 // sample can sit a few hundred ms off the extrapolated value. Anything inside
 // the band is jitter, not a seek.
 constexpr std::int64_t kDeadbandMs=400;
 // Max per-sync convergence toward rawMs while inside the deadband.
 constexpr std::int64_t kSlewMs=40;
 std::int64_t candidate=clock.heldMs+std::max<std::int64_t>(elapsedMs,0);
 candidate=clampPos(candidate,durationMs);
 const std::int64_t diff=rawMs-candidate;
 if(diff>kDeadbandMs||diff<-kDeadbandMs){
  clock.heldMs=clampPos(rawMs,durationMs);seek=true;
  return clock.heldMs;
 }
 std::int64_t next=candidate;
 if(diff>0)next=candidate+std::min(diff,kSlewMs); // raw ahead: converge quickly
 // diff<=0: raw behind is jitter or a tiny backward nudge; keep advancing at
 // real-time rate so heldMs stays strictly monotonic while playing.
 clock.heldMs=std::max(next,clock.heldMs);
 return clock.heldMs;
}

std::size_t SelectDisplayWord(const std::vector<LyricWord>& words,std::int64_t positionMs){
 std::size_t display=ActiveLyrics::npos;
 for(std::size_t w=0;w<words.size();++w){
  if(words[w].startMs<=positionMs)display=w;else break;
 }
 return display;
}

void ChunkWordRange(const LineLayout& full,std::size_t activeWord,float budgetPx,
                    std::size_t& outFirst,std::size_t& outLast){
 outFirst=activeWord;outLast=activeWord;
 if(full.words.empty()||activeWord>=full.words.size())return;
 std::size_t c0=activeWord,c1=activeWord;
 auto spanW=[&](std::size_t a,std::size_t b){
  float mn=full.words[a].left,mx=full.words[a].right;
  for(std::size_t w=a+1;w<=b;++w){mn=std::min(mn,full.words[w].left);mx=std::max(mx,full.words[w].right);}
  return mx-mn;
 };
 auto fits=[&](std::size_t a,std::size_t b){return spanW(a,b)<=budgetPx;};
 // Greedily expand, preferring the side that keeps the active word centred.
 for(;;){
  const bool canL=c0>0&&fits(c0-1,c1);
  const bool canR=c1+1<full.words.size()&&fits(c0,c1+1);
  if(!canL&&!canR)break;
  const float actC=(full.words[activeWord].left+full.words[activeWord].right)*0.5f;
  const auto centreOff=[&](std::size_t a,std::size_t b){
   const float mn=full.words[a].left,mx=full.words[b].right;
   return std::abs(actC-(mn+mx)*0.5f);
  };
  const float offL=canL?centreOff(c0-1,c1):1e30f;
  const float offR=canR?centreOff(c0,c1+1):1e30f;
  if(offL<=offR){if(canL)--c0;else if(canR)++c1;}
  else{if(canR)++c1;else if(canL)--c0;}
 }
 outFirst=c0;outLast=c1;
}

LineLayout ChunkLayout(const LineLayout& full,std::size_t first,std::size_t last){
 LineLayout out;
 if(full.words.empty()||first>last||last>=full.words.size())return out;
 const float centerX=(full.words[first].left+full.words[last].right)*0.5f;
 float wmin=full.words[first].left,wmax=full.words[last].right;
 for(std::size_t w=first+1;w<=last;++w){wmin=std::min(wmin,full.words[w].left);wmax=std::max(wmax,full.words[w].right);}
 out.width=wmax-wmin;out.height=full.height;
 out.words.reserve(last-first+1);
 for(std::size_t w=first;w<=last;++w){
  auto span=full.words[w];
  span.left-=centerX;span.right-=centerX;
  out.words.push_back(span);
 }
 for(const auto& t:full.targets){
  // Unassigned pixels (glyph overhang, anti-aliased edges, space gaps) attach
  // to the nearest word span so no sampled pixel is silently dropped.
  int w=t.word;
  if(w<0)w=NearestWordIndex(full.words,t.x);
  if(w<0||static_cast<std::size_t>(w)<first||static_cast<std::size_t>(w)>last)continue;
  ParticleTarget nt=t;
  const auto& span=full.words[w]; // original (unshifted) coordinates
  nt.word=w-static_cast<int>(first);
  nt.x-=centerX;
  // xNorm is karaoke fill position inside the word span; recompute for
  // rescued pixels, keep the rasterized value for assigned ones.
  if(t.word<0)
   nt.xNorm=std::clamp((t.x-span.left)/std::max(1.f,span.right-span.left),0.f,1.f);
  out.targets.push_back(nt);
 }
 return out;
}

int NearestWordIndex(const std::vector<WordSpan>& words,float x){
 if(words.empty())return -1;
 // Binary search on span centres; spans are ordered left-to-right.
 std::size_t lo=0,hi=words.size();
 while(lo<hi){
  const std::size_t mid=(lo+hi)/2;
  const float c=(words[mid].left+words[mid].right)*0.5f;
  if(c<x)lo=mid+1;else hi=mid;
 }
 int best=-1;float bestD=1e30f;
 for(int i=static_cast<int>(lo)-1;i<=static_cast<int>(lo);++i){
  if(i<0||i>=static_cast<int>(words.size()))continue;
  const auto& s=words[i];
  const float d=x<s.left?s.left-x:x>s.right?x-s.right:0.f;
  if(d<bestD){bestD=d;best=i;}
 }
 return best<0?0:best;
}

float WorldScale(float layoutPixelWidth,float layoutPixelHeight,float targetWorldHeight,
                 float maxWorldWidth,float maxWorldHeight,
                 float& outWorldWidth,float& outWorldHeight){
 // Uniform scale limited by target height and both world-space clamps.
 float wpp=targetWorldHeight/std::max(1.f,layoutPixelHeight);
 if(layoutPixelWidth>0&&maxWorldWidth>0)
  wpp=std::min(wpp,maxWorldWidth/layoutPixelWidth);
 if(maxWorldHeight>0)
  wpp=std::min(wpp,maxWorldHeight/std::max(1.f,layoutPixelHeight));
 outWorldWidth=layoutPixelWidth*wpp;
 outWorldHeight=layoutPixelHeight*wpp;
 return wpp;
}

bool ShouldSnapOnLayout(std::int64_t positionMs,std::int64_t wordStartMs,
                        std::int64_t thresholdMs){
 return positionMs-wordStartMs>thresholdMs;
}

}
