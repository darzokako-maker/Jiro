#include "features/visual/ambiance/Ambiance.hpp"
#include "features/visual/ambiance/LyricsLogic.hpp"
#include "features/visual/ambiance/LyricsService.hpp"
#include "features/visual/spotify_widget/SpotifySession.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include <Windows.h>
#include <roapi.h>
#include <process.h>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <string>
#include <unordered_map>

namespace client::features::ambiance {
namespace {

constexpr auto kMediaPoll=std::chrono::milliseconds(450);
constexpr auto kTrackDebounce=std::chrono::milliseconds(1200);
constexpr auto kMinRequestInterval=std::chrono::milliseconds(1000);
constexpr std::size_t kCacheCapacity=64;
constexpr auto kFoundTtl=std::chrono::hours(6);
constexpr auto kNotFoundTtl=std::chrono::minutes(15);

std::atomic<bool> g_stop{false};
std::mutex lifecycleMutex;
HANDLE g_mediaThread=nullptr;
HANDLE g_netThread=nullptr;
TrackProvider g_trackProvider;

std::mutex queueMutex;
std::condition_variable queueCv;
struct PendingTrack { TrackInfo track; std::string key; std::uint64_t generation; };
PendingTrack g_pending{};
bool g_pendingValid=false;
std::uint64_t g_generation=0;

struct CacheEntry {
 LyricsStatus status;
 std::shared_ptr<const LyricsContent> content;
 std::string detail;
 std::chrono::steady_clock::time_point expiresAt;
};

bool Active(){const auto options=Options();return options.enabled&&options.lyrics&&!g_stop.load();}

std::string TrackKey(const TrackInfo& track){
 return track.title+"\x1f"+track.artist+"\x1f"+std::to_string(track.durationMs);
}

TrackInfo PollTrack(){
 if(g_trackProvider)return g_trackProvider();
 TrackInfo info;
 if(const auto state=spotify::session::QueryPlayback();state&&state->available){
  info.available=true;
  info.title=state->title;
  info.artist=state->artist;
  info.durationMs=state->durationMs;
  info.positionMs=state->positionMs;
  info.playing=state->playing;
 }
 return info;
}

unsigned __stdcall MediaWorker(void*) {
 RoInitialize(RO_INIT_MULTITHREADED);
 std::string lastKey;
 // GSMTC position samples can stay stale for seconds while playing; the
 // playback clock free-runs between identical samples so the published
 // position never sawtooths or jumps by the stale interval.
 lyricslogic::PlaybackClock playClock;
 auto clockOrigin=std::chrono::steady_clock::now();
 client::scheduler::Cursor mediaCursor;
 bool firstPoll=true;
 while(Active()){
  if(!firstPoll&&!client::scheduler::Consume(client::scheduler::Task::AmbianceMediaPoll,mediaCursor)){Sleep(10);continue;}
  firstPoll=false;
  const auto info=PollTrack();
  const auto now=std::chrono::steady_clock::now();
  const auto tickMs=std::chrono::duration_cast<std::chrono::milliseconds>(now-clockOrigin).count();
  MediaSnapshot snapshot;
  snapshot.available=info.available;
  snapshot.title=info.title;
  snapshot.artist=info.artist;
  snapshot.durationMs=info.durationMs;
  snapshot.playing=info.playing;
  snapshot.positionAt=now;
  if(info.available){
   snapshot.trackKey=TrackKey(info);
   if(snapshot.trackKey!=lastKey){
    lastKey=snapshot.trackKey;
    playClock=lyricslogic::PlaybackClock{}; // new track: adopt fresh position
    std::lock_guard lock(queueMutex);
    g_pending.track=info;
    g_pending.key=snapshot.trackKey;
    g_pending.generation=++g_generation;
    g_pendingValid=true;
    queueCv.notify_one();
   }
   snapshot.positionMs=lyricslogic::AdvancePlaybackClock(playClock,info.positionMs,
    info.playing,info.durationMs,tickMs);
  }else{
   lastKey.clear();
   playClock=lyricslogic::PlaybackClock{};
   snapshot.positionMs=info.positionMs;
  }
  PublishMedia(std::move(snapshot));
 }
 RoUninitialize();
 return 0;
}

lyrics::TrackQuery MakeQuery(const PendingTrack& pending){
 return {pending.key,pending.track.title,pending.track.artist,pending.track.durationMs};
}

void CacheStore(std::unordered_map<std::string,CacheEntry>& cache,std::deque<std::string>& order,
                const std::string& key,const lyrics::FetchResult& result){
 if(result.status==LyricsStatus::Error)return;
 const auto ttl=result.status==LyricsStatus::NotFound?kNotFoundTtl:kFoundTtl;
 if(cache.count(key)==0){
  while(cache.size()>=kCacheCapacity&&!order.empty()){
   cache.erase(order.front());order.pop_front();
  }
  order.push_back(key);
 }
 cache[key]={result.status,result.content,result.detail,std::chrono::steady_clock::now()+ttl};
}

bool CacheFind(std::unordered_map<std::string,CacheEntry>& cache,const std::string& key,
               lyrics::FetchResult& result){
 const auto it=cache.find(key);
 if(it==cache.end())return false;
 if(it->second.expiresAt<=std::chrono::steady_clock::now()){cache.erase(it);return false;}
 result.status=it->second.status;
 result.content=it->second.content;
 result.detail=it->second.detail;
 result.cacheable=false;
 return true;
}

unsigned __stdcall NetWorker(void*) {
 std::unordered_map<std::string,CacheEntry> cache;
 std::deque<std::string> order;
 std::string activeKey;
 auto activeSince=std::chrono::steady_clock::time_point{};
 auto lastHttp=std::chrono::steady_clock::now();
 while(Active()){
  lyrics::TrackQuery job;
  std::uint64_t generation=0;
  {
   std::unique_lock lock(queueMutex);
   if(!g_pendingValid){
    queueCv.wait_for(lock,std::chrono::milliseconds(250));
    continue;
   }
   const auto now=std::chrono::steady_clock::now();
   if(g_pending.key!=activeKey){activeKey=g_pending.key;activeSince=now;}
   const auto waited=now-activeSince;
   if(waited<kTrackDebounce){
    queueCv.wait_for(lock,kTrackDebounce-waited);
    continue;
   }
   job=MakeQuery(g_pending);
   generation=g_pending.generation;
   g_pendingValid=false;
  }
  lyrics::FetchResult result;
  const auto jobStart=std::chrono::steady_clock::now();
  bool cacheHit=CacheFind(cache,job.trackKey,result);
  if(!cacheHit){
   for(;;){
    const auto since=std::chrono::steady_clock::now()-lastHttp;
    if(since>=kMinRequestInterval||!Active())break;
    Sleep(50);
   }
   if(!Active())break;
   result=lyrics::Fetch(job);
   lastHttp=std::chrono::steady_clock::now();
   CacheStore(cache,order,job.trackKey,result);
  }
  {
   const auto done=std::chrono::steady_clock::now();
   const auto totalMs=std::chrono::duration_cast<std::chrono::milliseconds>(done-jobStart).count();
   const auto status=static_cast<int>(result.status);
   AOKI_LOG("[lyrics3d:http] track=\"%s - %s\" cache=%d totalMs=%lld status=%d",
    job.title.c_str(),job.artist.c_str(),cacheHit?1:0,
    static_cast<long long>(totalMs),status);
  }
  {
   std::lock_guard lock(queueMutex);
   if(generation==g_generation&&Active()){
    PublishLyrics({job.trackKey,result.status,result.content,result.detail});
   }
  }
 }
 return 0;
}

}

void PollRuntime(){
 const auto options=Options();
 client::scheduler::Configure(client::scheduler::Task::AmbianceMediaPoll,
  options.enabled&&options.lyrics,static_cast<std::uint32_t>(kMediaPoll.count()));
 if(!options.enabled||!options.lyrics||g_stop.load())return;
 std::lock_guard lock(lifecycleMutex);
 const auto alive=[](HANDLE thread){return thread&&WaitForSingleObject(thread,0)==WAIT_TIMEOUT;};
 if(alive(g_mediaThread)&&alive(g_netThread))return;
 if(g_mediaThread&&!alive(g_mediaThread)){CloseHandle(g_mediaThread);g_mediaThread=nullptr;}
 if(g_netThread&&!alive(g_netThread)){CloseHandle(g_netThread);g_netThread=nullptr;}
 if(!g_mediaThread)g_mediaThread=reinterpret_cast<HANDLE>(_beginthreadex(nullptr,0,&MediaWorker,nullptr,0,nullptr));
 if(!g_netThread)g_netThread=reinterpret_cast<HANDLE>(_beginthreadex(nullptr,0,&NetWorker,nullptr,0,nullptr));
 if(!g_mediaThread||!g_netThread){
  AOKI_LOG("[Ambiance] worker creation failed media=%p net=%p",g_mediaThread,g_netThread);
  auto value=Options();value.enabled=false;SetOptions(value);
 }
}

void Shutdown(){
 {
  std::lock_guard lifecycle(lifecycleMutex);
  g_stop=true;
 }
 {
  std::lock_guard queue(queueMutex);
  queueCv.notify_all();
 }
 std::lock_guard lifecycle(lifecycleMutex);
 for(auto* handle:{&g_mediaThread,&g_netThread}){
  if(*handle){WaitForSingleObject(*handle,20000);CloseHandle(*handle);*handle=nullptr;}
 }
 g_stop=false;
}

void SetTrackProviderForTest(TrackProvider provider){
 std::lock_guard lock(lifecycleMutex);
 g_trackProvider=std::move(provider);
}

}
