#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "game/GuiAtlas.hpp"
#include "game/MappingRepository.hpp"
#include "client/NativeScheduler.hpp"

#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstdint>

namespace client::features::inventory_hud {
namespace {

std::uint64_t Mix(std::uint64_t hash, std::uint64_t value) {
    hash ^= value;
    hash *= 1099511628211ull;
    return hash;
}

} // namespace

void Capture(JNIEnv* env, int, int) {
    static std::uint64_t previousHash = 0;
    static ULONGLONG lastScan = 0;
    static ULONGLONG lastRender = 0;
    static bool wasEnabled = false;
    static game::GuiAtlas atlas;

    if (!Options().enabled || !env || env->ExceptionCheck()) {
        if (wasEnabled) Publish({});
        wasEnabled = false;
        previousHash = 0;
        return;
    }
    wasEnabled = true;

    const auto now = client::scheduler::Now();
    lastScan = now;
    if (env->PushLocalFrame(96) != JNI_OK) return;

    const auto minecraft = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto player = minecraft ? mapping::Object(env, minecraft, "Minecraft.thePlayer") : nullptr;
    const auto inventory = player ? mapping::Object(env, player, "EntityPlayer.inventory") : nullptr;
    const auto stacks = inventory ? static_cast<jobjectArray>(
        mapping::Object(env, inventory, "InventoryPlayer.mainInventory")) : nullptr;
    if (!minecraft || !player || !inventory || !stacks) {
        env->PopLocalFrame(nullptr);
        Publish({});
        previousHash = 0;
        return;
    }

    State output;
    output.available = true;
    output.selectedHotbar = std::clamp(
        mapping::Read<int>(inventory, "InventoryPlayer.currentItem").value_or(0), 0, 8);

    std::array<jobject, 36> rooted{};
    const int length = std::min(36, env->GetArrayLength(stacks));
    std::uint64_t hash = Mix(1469598103934665603ull,
                             static_cast<std::uint64_t>(output.selectedHotbar));
    for (int i = 0; i < length; ++i) {
        rooted[i] = env->GetObjectArrayElement(stacks, i);
        hash = Mix(hash, static_cast<std::uint64_t>(i));
        if (!rooted[i]) continue;
        const int count = std::max(0, mapping::Read<int>(rooted[i], "ItemStack.stackSize").value_or(0));
        const int damage = mapping::Read<int>(rooted[i], "ItemStack.itemDamage").value_or(0);
        output.slots[i].count = count;
        if (count > 0) ++output.occupied;
        hash = Mix(hash, static_cast<std::uint64_t>(mapping::Oop(rooted[i])));
        hash = Mix(hash, static_cast<std::uint32_t>(count));
        hash = Mix(hash, static_cast<std::uint32_t>(damage));
    }

    const bool forceRefresh = now - lastRender >= 2000;
    if (hash == previousHash && !forceRefresh) {
        env->PopLocalFrame(nullptr);
        return;
    }

    const bool hasItems = output.occupied > 0;
    if (hasItems && !atlas.Begin(env, minecraft)) {
        env->PopLocalFrame(nullptr);
        return;
    }
    if (hasItems) {
        for (int i = 0; i < length; ++i) {
            if (rooted[i] && output.slots[i].count > 0) output.slots[i].image = atlas.Item(rooted[i]);
        }
        atlas.End();
    }

    previousHash = hash;
    lastRender = now;
    env->PopLocalFrame(nullptr);
    Publish(std::move(output));
}

} // namespace client::features::inventory_hud
