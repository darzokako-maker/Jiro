#include "features/visual/inventory_hud/InventoryHud.hpp"
#include "features/visual/inventory_hud/InventoryHudRules.hpp"
#include "render/RoundedPanel.hpp"
#include "ui/animation/AnimatedNumber.hpp"
#include "ui/clickgui/ReferencePrimitives.hpp"
#include "ui/font/FontManager.hpp"
#include "ui/hud/HudLayout.hpp"

#include <imgui.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace client::features::inventory_hud {
namespace {

ImU32 Alpha(ImU32 color, float alpha) {
    return (color & 0x00ffffff) |
           (static_cast<ImU32>(std::clamp(alpha, 0.0f, 1.0f) * ((color >> 24) & 255)) << 24);
}

void DashedHorizontal(ImDrawList& list, float left, float right, float y,
                      float dash, float gap, float thickness, ImU32 color) {
    for (float x = left; x < right; x += dash + gap)
        list.AddLine({x, y}, {std::min(x + dash, right), y}, color, thickness);
}

void DashedVertical(ImDrawList& list, float x, float top, float bottom,
                    float dash, float gap, float thickness, ImU32 color) {
    for (float y = top; y < bottom; y += dash + gap)
        list.AddLine({x, y}, {x, std::min(y + dash, bottom)}, color, thickness);
}

void Image(ImDrawList& list, const esp::Image& image, ImVec2 a, float size, ImU32 tint) {
    if (!image.texture) return;
    list.AddImage(static_cast<ImTextureID>(image.texture), a, {a.x + size, a.y + size},
                  {image.u0, image.v0}, {image.u1, image.v1}, tint);
}

} // namespace

void Draw(const ui::FontManager& fonts, ImDrawList& foreground, float width, float height,
          std::vector<render::RoundedPanel>& panels) {
    constexpr float spotifyScale = 0.936f;
    constexpr auto layout = rules::LayoutForScale(spotifyScale);
    static ui::Spring reveal;
    static std::shared_ptr<const State> retained;

    const auto incoming = Snapshot();
    const bool enabled = Options().enabled;
    if (enabled && incoming && incoming->available) retained = incoming;
    const bool visible = enabled && retained && retained->available;
    const float dt = std::clamp(ImGui::GetIO().DeltaTime, 0.0f, 0.05f);
    const float amount = std::clamp(reveal.Update(visible ? 1.0f : 0.0f, dt, 205, 25), 0.0f, 1.0f);
    if (!retained || (!visible && amount < 0.004f)) {
        if (!enabled) retained.reset();
        return;
    }
    if (width < layout.cardWidth + 16 || height < layout.cardHeight + 16) return;

    ui::hud_layout::Report(ui::hud_layout::Element::Inventory, layout.cardWidth, layout.cardHeight);
    const auto position = ui::hud_layout::Position(ui::hud_layout::Element::Inventory, width, height);
    const ImVec2 center{position.x + layout.cardWidth * 0.5f,
                        position.y + layout.cardHeight * 0.5f};
    const float entrance = 1.0f - std::pow(1.0f - amount, 3.0f);
    const float visualScale = 0.94f + 0.06f * entrance;
    const float yShift = (1.0f - entrance) * 7.0f * spotifyScale;
    const ImVec2 a{center.x + (position.x - center.x) * visualScale,
                   center.y + (position.y - center.y) * visualScale + yShift};
    const float scale = spotifyScale * visualScale;
    const auto draw = rules::LayoutForScale(scale);
    const ImVec2 b{a.x + draw.cardWidth, a.y + draw.cardHeight};
    const float radius = 16.0f * scale;

    render::RoundedPanel panel{a.x, a.y, draw.cardWidth, draw.cardHeight, radius};
    panel.color = IM_COL32(0, 0, 0, 0);
    panel.opacity = entrance;
    panel.blur = true;
    panel.border = false;
    panels.push_back(panel);

    const ImU32 glass = Alpha(IM_COL32(8, 10, 14, 76), entrance);
    if (!ui::clickgui::ReferenceRectangle(foreground, a, draw.cardWidth, draw.cardHeight,
                                           radius, 1.0f, glass))
        foreground.AddRectFilled(a, b, glass, radius);
    foreground.AddRect(a, b, Alpha(IM_COL32(255, 255, 255, 28), entrance), radius, 0,
                       std::max(0.65f, 0.75f * scale));

    fonts.Draw(foreground, "INVENTORY", {a.x + draw.gridLeft, a.y + 7.0f * scale},
               14.0f * scale, Alpha(IM_COL32(255, 255, 255, 230), entrance),
               ui::FontWeight::SemiBold);
    char occupied[16];
    std::snprintf(occupied, sizeof(occupied), "%d/36", retained->occupied);
    const float occupiedSize = 12.0f * scale;
    const float occupiedWidth = fonts.Measure(occupied, occupiedSize, ui::FontWeight::Medium).x;
    fonts.Draw(foreground, occupied,
               {a.x + draw.cardWidth - draw.gridLeft - occupiedWidth, a.y + 8.0f * scale},
               occupiedSize, Alpha(IM_COL32(207, 212, 220, 180), entrance),
               ui::FontWeight::Medium);

    const float left = a.x + draw.gridLeft;
    const float top = a.y + draw.gridTop;
    const float right = left + draw.gridWidth;
    const float bottom = top + draw.gridHeight;
    const ImU32 separator = Alpha(IM_COL32(255, 255, 255, 40), entrance);
    foreground.Flags |= ImDrawListFlags_AntiAliasedLines;
    DashedHorizontal(foreground, left, right, top, draw.dashLength, draw.dashGap,
                     draw.lineThickness, separator);
    for (int row = 1; row < 4; ++row)
        DashedHorizontal(foreground, left, right, top + row * draw.cell,
                         draw.dashLength, draw.dashGap, draw.lineThickness, separator);
    for (int column = 1; column < 9; ++column)
        DashedVertical(foreground, left + column * draw.cell, top, bottom,
                       draw.dashLength, draw.dashGap, draw.lineThickness, separator);

    const ImU32 itemTint = Alpha(IM_COL32_WHITE, entrance);
    for (int row = 0; row < 4; ++row) {
        for (int column = 0; column < 9; ++column) {
            const int index = rules::InventoryIndex(row, column);
            const float cellX = left + column * draw.cell;
            const float cellY = top + row * draw.cell;
            if (row == 3 && column == retained->selectedHotbar) {
                const float inset = draw.cell / 14.5f;
                const ImVec2 selectedA{cellX + inset, cellY + inset};
                const ImVec2 selectedB{cellX + draw.cell - inset, cellY + draw.cell - inset};
                foreground.AddRectFilled(selectedA, selectedB,
                    Alpha(IM_COL32(255, 255, 255, 16), entrance), draw.cell / 5.8f);
                foreground.AddRect(selectedA, selectedB,
                    Alpha(IM_COL32(255, 255, 255, 52), entrance), draw.cell / 5.8f, 0,
                    std::max(0.65f, draw.lineThickness));
            }

            const auto& slot = retained->slots[index];
            const float iconInset = (draw.cell - draw.iconSize) * 0.5f;
            const ImVec2 iconAt{cellX + iconInset, cellY + iconInset};
            Image(foreground, slot.image, iconAt, draw.iconSize, itemTint);
            if (slot.count > 1) {
                char count[12];
                std::snprintf(count, sizeof(count), "%d", slot.count);
                const float countSize = 10.0f * scale;
                const float textWidth = fonts.Measure(count, countSize, ui::FontWeight::SemiBold).x;
                const ImVec2 countAt{cellX + draw.cell - textWidth - draw.cell / 10.0f,
                                     cellY + draw.cell - countSize - draw.cell / 12.0f};
                fonts.Draw(foreground, count, {countAt.x + scale, countAt.y + scale}, countSize,
                           Alpha(IM_COL32(0, 0, 0, 220), entrance), ui::FontWeight::SemiBold);
                fonts.Draw(foreground, count, countAt, countSize,
                           Alpha(IM_COL32_WHITE, entrance), ui::FontWeight::SemiBold);
            }
        }
    }
}

} // namespace client::features::inventory_hud
