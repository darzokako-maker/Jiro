#include "features/visual/target_hud/TargetHud.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <atomic>
#include <mutex>

namespace client::features::targethud {
namespace {
std::mutex settingsMutex;
Settings settings;
std::atomic<std::shared_ptr<const State>> state{std::make_shared<const State>()};
}
Settings Options(){std::lock_guard lock(settingsMutex);return settings;}
void SetOptions(Settings value){bool previous;{std::lock_guard lock(settingsMutex);previous=settings.enabled;settings=value;}if(!value.enabled)state.store(std::make_shared<const State>());modules::StateChanged(modules::TargetHud,previous,value.enabled);}
std::shared_ptr<const State> Snapshot(){return state.load();}
void Publish(State value){state.store(std::make_shared<const State>(std::move(value)));}
}
