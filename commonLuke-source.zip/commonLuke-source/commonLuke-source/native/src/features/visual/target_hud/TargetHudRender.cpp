#include "features/visual/target_hud/TargetHud.hpp"
#include "render/RoundedPanel.hpp"
#include "ui/animation/AnimatedNumber.hpp"
#include "ui/clickgui/ReferencePrimitives.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "ui/font/FontManager.hpp"
#include "ui/hud/HudLayout.hpp"
#include "ui/hud/HudState.hpp"
#include <imgui.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>

namespace client::features::targethud {
namespace {
ImU32 Alpha(ImU32 color,float alpha){return (color&0x00ffffff)|(static_cast<ImU32>(std::clamp(alpha,0.f,1.f)*((color>>24)&255))<<24);}
void Image(ImDrawList& list,const esp::Image& image,ImVec2 at,float width,float height,ImU32 tint){if(!image.texture)return;list.AddImage(static_cast<ImTextureID>(image.texture),at,{at.x+width,at.y+height},{image.u0,image.v0},{image.u1,image.v1},tint);}
}
void Draw(const ui::FontManager& fonts,ImDrawList& foreground,ImDrawList& bloom,float width,float height,std::vector<render::RoundedPanel>& panels) {
 static ui::Spring reveal,content,healthMotion;
 static std::shared_ptr<const State> retained;
 static int shownId=-1;
 const auto incoming=Snapshot();const bool enabled=Options().enabled;
 const bool current=enabled&&incoming&&incoming->available;
 if(current){retained=incoming;if(shownId!=incoming->id){shownId=incoming->id;content.Reset(0);healthMotion.Reset(incoming->health);}}
 const bool editing=ui::IsScreenOpen()||ui::input::IsOpen();const bool visible=enabled&&retained&&(current||editing);
 const float dt=std::clamp(ImGui::GetIO().DeltaTime,0.f,.05f);const float r=std::clamp(reveal.Update(visible?1.f:0.f,dt,205,25),0.f,1.f);
 if(!retained)return;
 if(!visible&&r<.004f){if(!enabled){retained.reset();shownId=-1;}return;}
 const float c=std::clamp(content.Update(1,dt,175,23),0.f,1.f),hp=healthMotion.Update(retained->health,dt,150,22);
 constexpr float cardWidth=311,cardHeight=90;
 ui::hud_layout::Report(ui::hud_layout::Element::TargetHud,cardWidth,cardHeight);const auto p=ui::hud_layout::Position(ui::hud_layout::Element::TargetHud,width,height);
 const ImVec2 center{p.x+cardWidth*.5f,p.y+cardHeight*.5f};const float scale=.94f+.06f*r,yShift=(1-r)*6.f;const ImVec2 a{center.x+(p.x-center.x)*scale,center.y+(p.y-center.y)*scale+yShift},b{a.x+cardWidth*scale,a.y+cardHeight*scale};
 render::RoundedPanel panel{a.x,a.y,b.x-a.x,b.y-a.y,14*scale};panel.color=IM_COL32(0,0,0,0);panel.opacity=r;panel.blur=true;panel.border=false;panels.push_back(panel);
 const ImVec2 bloomAt{a.x-1,a.y-1};if(!ui::clickgui::ReferenceRectangle(bloom,bloomAt,b.x-a.x+2,b.y-a.y+2,15*scale,1.f,Alpha(IM_COL32(40,240,127,38),r)))bloom.AddRectFilled(bloomAt,{b.x+1,b.y+1},Alpha(IM_COL32(40,240,127,38),r),15*scale);
 if(!ui::clickgui::ReferenceRectangle(foreground,a,b.x-a.x,b.y-a.y,14*scale,1.f,Alpha(IM_COL32(0,0,0,66),r)))foreground.AddRectFilled(a,b,Alpha(IM_COL32(0,0,0,66),r),14*scale);
 const float fade=r*c,offset=(1-c)*4*scale;const ImU32 white=Alpha(IM_COL32_WHITE,fade);
 const ImVec2 modelAt{a.x+7*scale,a.y+4*scale+offset};
 if(retained->model.texture)Image(foreground,retained->model,modelAt,76*scale,80*scale,white);
 else ui::clickgui::ReferenceRectangle(foreground,{a.x+15*scale,a.y+12*scale+offset},56*scale,64*scale,7*scale,1.f,Alpha(IM_COL32(89,61,42,120),fade));
 fonts.Draw(foreground,retained->name,{a.x+97*scale,a.y+12*scale+offset},20*scale,white,ui::FontWeight::SemiBold);
 char health[48];std::snprintf(health,sizeof(health),"%.0f/%.0f",std::max(0.f,hp),retained->maxHealth);fonts.Draw(foreground,health,{a.x+244*scale,a.y+15*scale+offset},16*scale,Alpha(IM_COL32(117,117,117,255),fade),ui::FontWeight::SemiBold);
 for(int i=0;i<4;++i)Image(foreground,retained->armor[i],{a.x+(97+i*32)*scale,a.y+39*scale+offset},32*scale,32*scale,white);
 Image(foreground,retained->held,{a.x+225*scale,a.y+43*scale+offset},25*scale,25*scale,white);
 const float fraction=std::clamp(hp/std::max(1.f,retained->maxHealth),0.f,1.f),barWidth=200*scale*fraction;const ImVec2 barA{a.x+92*scale,a.y+74*scale};
 const int shade=static_cast<int>(std::lround(255.f*fraction));
 bloom.AddRectFilled({barA.x,barA.y-3*scale},{barA.x+barWidth,barA.y+6*scale},Alpha(IM_COL32(255,shade,shade,120),r),4*scale);
 if(!ui::clickgui::ReferenceRectangle(foreground,barA,barWidth,3*scale,1.5f*scale,1.f,Alpha(IM_COL32(255,shade,shade,255),r)))foreground.AddRectFilled(barA,{barA.x+barWidth,barA.y+3*scale},Alpha(IM_COL32(255,shade,shade,255),r),1.5f*scale);
}
}
