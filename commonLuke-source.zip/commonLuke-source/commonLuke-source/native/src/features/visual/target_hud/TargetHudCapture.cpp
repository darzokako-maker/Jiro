#include "features/visual/target_hud/TargetHud.hpp"
#include "game/GuiAtlas.hpp"
#include "game/MappingRepository.hpp"
#include "client/NativeScheduler.hpp"
#include <algorithm>
#include <chrono>

namespace client::features::targethud {
namespace {
methods::Argument Int(int value){methods::Argument a{methods::Type::Int};a.value.i=value;return a;}
float Float(JNIEnv* env,jobject object,const char* key){auto r=mapping::Invoke(env,object,key);const float value=r.ok?r.value.f:0;r.Release(env);return value;}
}
void Capture(JNIEnv* env,int,int) {
 static int latched=-1,previous=-2,previousSwingProgress=0;
 static bool wasSwinging=false;
 static std::uint64_t expires=0,last=0;
 if(!Options().enabled||!env||env->ExceptionCheck()){
  if(previous!=-2)Publish({});latched=-1;previous=-2;wasSwinging=false;previousSwingProgress=0;return;
 }
 if(env->PushLocalFrame(40)!=JNI_OK)return;
 const auto now=client::scheduler::Now();
 const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft");
 const auto player=mc?mapping::Object(env,mc,"Minecraft.thePlayer"):nullptr;
 const bool swinging=player&&mapping::Read<bool>(player,"EntityLivingBase.isSwingInProgress").value_or(false);
 const int swingProgress=player?mapping::Read<int>(player,"EntityLivingBase.swingProgressInt").value_or(0):0;
 const bool swingStarted=swinging&&(!wasSwinging||swingProgress<previousSwingProgress);
 wasSwinging=swinging;previousSwingProgress=swingProgress;
 if(swingStarted) {
  const auto hit=mc?mapping::Object(env,mc,"Minecraft.objectMouseOver"):nullptr;
  const auto candidate=hit?mapping::Object(env,hit,"MovingObjectPosition.entityHit"):nullptr;
  if(candidate&&(!player||!env->IsSameObject(candidate,player))&&mapping::Instance(candidate,"EntityLivingBase")&&
     !mapping::Read<bool>(candidate,"Entity.isDead").value_or(true)) {
   latched=mapping::Read<int>(candidate,"Entity.entityId").value_or(-1);
   if(latched>=0)expires=now+2000;
  }
 }
 if(latched<0||now>=expires) {
  latched=-1;env->PopLocalFrame(nullptr);
  if(previous!=-1){Publish({});previous=-1;}return;
 }
 if(latched==previous&&now-last<80){env->PopLocalFrame(nullptr);return;}
 previous=latched;last=now;
 State output;output.id=latched;
 const auto world=mc?mapping::Object(env,mc,"Minecraft.theWorld"):nullptr;
 auto entity=world?mapping::Invoke(env,world,"ClientWorld.getEntityByID",{Int(latched)}):methods::Result{};
 if(entity.ok&&entity.value.l&&mapping::Instance(entity.value.l,"EntityLivingBase")&&!mapping::Read<bool>(entity.value.l,"Entity.isDead").value_or(true)) {
  output.health=Float(env,entity.value.l,"EntityLivingBase.getHealth");output.maxHealth=Float(env,entity.value.l,"EntityLivingBase.getMaxHealth");
  output.name=mapping::String(env,entity.value.l,"Entity.getName").value_or("Target");output.available=output.health>0&&output.maxHealth>0;
  static game::GuiAtlas atlas;
  if(output.available&&atlas.Begin(env,mc)) {
   output.model=atlas.Model(entity.value.l);
   for(int i=0;i<4;++i){auto stack=mapping::Invoke(env,entity.value.l,"EntityLivingBase.getArmor",{Int(3-i)});if(stack.ok&&stack.value.l)output.armor[i]=atlas.Item(stack.value.l);stack.Release(env);}
   auto held=mapping::Invoke(env,entity.value.l,"EntityLivingBase.getHeldItem");if(held.ok&&held.value.l)output.held=atlas.Item(held.value.l);held.Release(env);
   atlas.End();
  }
 }
 entity.Release(env);env->PopLocalFrame(nullptr);
 if(!output.available){latched=-1;previous=-1;}
 Publish(std::move(output));
}
}
