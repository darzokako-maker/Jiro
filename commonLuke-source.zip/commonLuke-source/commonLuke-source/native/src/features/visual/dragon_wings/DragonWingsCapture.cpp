#include "features/visual/dragon_wings/DragonWingsCapture.hpp"
#include "features/visual/dragon_wings/DragonWings.hpp"
#include "game/MappingRepository.hpp"
#include "render/GlApi.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include <algorithm>
#include <cmath>
#include <chrono>

namespace client::features::wings {
namespace {
WorldPass pass;
double frameMilliseconds=0;
bool Matrix(JNIEnv* env,const char* key,float* output) {
 const auto buffer=mapping::StaticObject(env,key);if(!buffer)return false;
 const auto data=env->GetDirectBufferAddress(buffer);
 return env->GetDirectBufferCapacity(buffer)>=16&&data&&hotspot::ReadMemory(reinterpret_cast<std::uintptr_t>(data),output,sizeof(float)*16);
}
bool Flag(JNIEnv* env,jobject player,const char* key) {auto value=mapping::Invoke(env,player,key);const bool result=value.ok&&value.value.z;value.Release(env);return result;}
}
void Present(){pass.Present();frameMilliseconds=0;}
double FrameMilliseconds(){return frameMilliseconds;}
void BeforeClear(JNIEnv* env,unsigned mask) {
 if(!Options().enabled)return;
 if(!pass.Clear(mask)||!env||env->ExceptionCheck())return;
 struct Timer {std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();~Timer(){frameMilliseconds+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();}} timerCost;
 // This hook runs before world depth is erased for hand/overlay rendering.
 // Orthographic menu/inventory clears and auxiliary FBOs must never trigger it.
 GLfloat projection[16]{};glGetFloatv(GL_PROJECTION_MATRIX,projection);
 if(std::abs(projection[15])>.0001f||std::abs(projection[11])<.0001f)return;
 if(env->PushLocalFrame(64)!=JNI_OK)return;
 struct Refs {JNIEnv* env;~Refs(){env->PopLocalFrame(nullptr);}} refs{env};
 const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft");if(!mc)return;
 const auto world=mapping::Object(env,mc,"Minecraft.theWorld"),player=mapping::Object(env,mc,"Minecraft.thePlayer");
 if(!world||!player||mapping::Read<bool>(player,"Entity.isDead").value_or(true))return;
 const auto settings=mapping::Object(env,mc,"Minecraft.gameSettings");
 const int perspective=mapping::Read<int>(settings,"GameSettings.thirdPersonView").value_or(0);if(perspective!=1&&perspective!=2)return;
 const auto framebuffer=mapping::Object(env,mc,"Minecraft.framebuffer");if(!framebuffer)return;
 const auto expected=mapping::Read<int>(framebuffer,"Framebuffer.object");if(!expected)return;
 GLint draw=0;glGetIntegerv(0x8CA6,&draw);if(draw!=std::max(0,*expected))return;
 const auto timer=mapping::Object(env,mc,"Minecraft.timer"),manager=mapping::Object(env,mc,"Minecraft.renderManager");if(!timer||!manager)return;
 Pose pose;pose.thirdPerson=true;
 const float partial=std::clamp(mapping::Read<float>(timer,"Timer.partialTicks").value_or(1.f),0.f,1.f);
 auto position=[&](const char* current,const char* previous,const char* origin)->std::optional<double> {
  const auto a=mapping::Read<double>(player,current),b=mapping::Read<double>(player,previous),camera=mapping::Read<double>(manager,origin);
  if(!a||!b||!camera)return {};return *b+(*a-*b)*partial-*camera;
 };
 const auto x=position("Entity.posX","Entity.lastTickPosX","RenderManager.viewerPosX"),y=position("Entity.posY","Entity.lastTickPosY","RenderManager.viewerPosY"),z=position("Entity.posZ","Entity.lastTickPosZ","RenderManager.viewerPosZ");
 const auto yaw=mapping::Read<float>(player,"EntityLivingBase.renderYawOffset"),previousYaw=mapping::Read<float>(player,"EntityLivingBase.prevRenderYawOffset");
 if(!x||!y||!z||!yaw||!previousYaw)return;
 pose.x=*x;pose.y=*y;pose.z=*z;pose.yaw=InterpolateYaw(*previousYaw,*yaw,partial);
 const auto now=client::scheduler::Now();
 static ULONGLONG flagTime=0;static int flagEntity=0;static bool invisible=false,sneaking=false;
 const int entity=mapping::Read<int>(player,"Entity.entityId").value_or(0);
 static client::scheduler::Cursor flagCursor;
 client::scheduler::Configure(client::scheduler::Task::WingsFlags,true,33);
 if(!flagTime||client::scheduler::Consume(client::scheduler::Task::WingsFlags,flagCursor)||entity!=flagEntity){invisible=Flag(env,player,"Entity.isInvisible");sneaking=Flag(env,player,"Entity.isSneaking");flagTime=now;flagEntity=entity;}
 pose.invisible=invisible;pose.sneaking=sneaking;
 if(!Matrix(env,"ActiveRenderInfo.MODELVIEW",pose.model.data())||!Matrix(env,"ActiveRenderInfo.PROJECTION",pose.projection.data()))return;
 glGetIntegerv(GL_VIEWPORT,pose.viewport.data());
 if(Render(pose,Options(),now)) {
  pass.Drawn();static bool logged=false;if(!logged){logged=true;AOKI_LOG("DragonWings: world render active before depth clear; main FBO=%d",draw);}
 }
}
}
