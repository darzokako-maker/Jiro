#include "features/visual/dragon_wings/DragonWings.hpp"
#include "features/core/ModuleRegistry.hpp"
// Geometry/animation: user-provided Tenacity WingModel (senoe / canelex).
#include "render/LegacyGuiState.hpp"
#include "render/GlDiagnostics.hpp"
#include "render/Texture.hpp"
#include "client/Logger.hpp"
#include "DragonWingsTexture.hpp"
#include <algorithm>
#include <cmath>

namespace client::features::wings {
namespace {
Settings options;
GLuint texture=0,lists=0;
constexpr float Degrees=57.2957795131f,ModelScale=.0625f;
struct Point {float x,y,z;};
void Quad(const std::array<Point,8>& points,std::array<int,4> order,float u1,float v1,float u2,float v2) {
 const float uv[4][2]={{u2/30.f,v1/30.f},{u1/30.f,v1/30.f},{u1/30.f,v2/30.f},{u2/30.f,v2/30.f}};
 for(int i=0;i<4;++i){const auto& p=points[order[i]];glTexCoord2fv(uv[i]);glVertex3f(p.x*ModelScale,p.y*ModelScale,p.z*ModelScale);}
}
void Box(float x,float y,float z,float w,float h,float d,float u,float v) {
 const std::array<Point,8> p{{{x,y,z},{x+w,y,z},{x+w,y+h,z},{x,y+h,z},{x,y,z+d},{x+w,y,z+d},{x+w,y+h,z+d},{x,y+h,z+d}}};
 Quad(p,{5,1,2,6},u+d+w,v+d,u+d+w+d,v+d+h);
 Quad(p,{0,4,7,3},u,v+d,u+d,v+d+h);
 Quad(p,{5,4,0,1},u+d,v,u+d+w,v+d);
 Quad(p,{2,3,7,6},u+d+w,v+d,u+d+w+w,v);
 Quad(p,{1,0,3,2},u+d,v+d,u+d+w,v+d+h);
 Quad(p,{4,5,6,7},u+d+w+d,v+d,u+d+w+d+w,v+d+h);
}
bool Assets() {
 if(texture&&lists)return true;
 if(!texture)texture=render::LoadPngTexture(kDragonWingsTexture);
 if(!texture)return false;
 lists=glGenLists(2);if(!lists)return false;
 glNewList(lists,GL_COMPILE);glBegin(GL_QUADS);
 Box(-10,-1,-1,10,2,2,0,0);Box(-10,0,.5f,10,0,10,-10,8);
 glEnd();glEndList();
 glNewList(lists+1,GL_COMPILE);glBegin(GL_QUADS);
 Box(-10,-.5f,-.5f,10,1,1,0,5);Box(-10,0,.5f,10,0,10,-10,18);
 glEnd();glEndList();
 AOKI_LOG("DragonWings: Tenacity PNG and cached wing/wingtip meshes initialized");return true;
}
}
const Settings& Options(){return options;}
void SetOptions(Settings settings){const bool previous=options.enabled;settings.scale=std::isfinite(settings.scale)?std::clamp(settings.scale,.75f,1.25f):1.f;options=settings;modules::StateChanged(modules::DragonWings,previous,options.enabled);}
Angles Animation(std::uint64_t milliseconds) {
 const float phase=static_cast<float>(milliseconds%1500)/1500.f*6.28318530718f;
 return {-1.4f-std::cos(phase)*.2f,.35f+std::sin(phase)*.4f,.35f,-(std::sin(phase+2.f)+.5f)*.75f};
}
float InterpolateYaw(float previous,float current,float partial) {
 const float delta=std::remainder(current-previous,360.f);
 float yaw=std::fmod(previous+delta*std::clamp(partial,0.f,1.f),360.f);return yaw<0?yaw+360:yaw;
}
bool Render(const Pose& pose,const Settings& settings,std::uint64_t milliseconds) {
 if(!settings.enabled||!pose.thirdPerson||pose.invisible||pose.viewport[2]<=0||pose.viewport[3]<=0)return false;
 if(!std::isfinite(settings.scale)||settings.scale<.75f||settings.scale>1.25f||!std::isfinite(pose.yaw)||!std::isfinite(pose.x)||!std::isfinite(pose.y)||!std::isfinite(pose.z))return false;
 for(float value:pose.model)if(!std::isfinite(value))return false;
 for(float value:pose.projection)if(!std::isfinite(value))return false;
 if(!render::gl.BindFramebuffer&&!render::gl.Load())return false;
 render::diagnostics::Scope trace("DragonWings.world");
 render::LegacyGuiState state;
 if(!Assets())return false;
 render::gl.UseProgram(0);render::gl.ActiveTexture(render::Texture1);glDisable(GL_TEXTURE_2D);
 render::gl.ActiveTexture(render::Texture0);glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,texture);
 if(render::gl.BindSampler){render::gl.BindSampler(0,0);render::gl.BindSampler(1,0);}
 glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
 glDisable(GL_LIGHTING);glDisable(GL_FOG);glDisable(GL_STENCIL_TEST);glDisable(GL_SCISSOR_TEST);
 glDisable(GL_COLOR_LOGIC_OP);glDisable(0x8C89);glDisable(0x8F9D);
 glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
 glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_TRUE);glDepthRange(0,1);
 glEnable(GL_ALPHA_TEST);glAlphaFunc(GL_GREATER,.1f);glEnable(GL_BLEND);
 render::gl.BlendEquationSeparate(0x8006,0x8006);render::gl.BlendFuncSeparate(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
 glViewport(pose.viewport[0],pose.viewport[1],pose.viewport[2],pose.viewport[3]);
 glMatrixMode(GL_TEXTURE);glPushMatrix();glLoadIdentity();
 glMatrixMode(GL_PROJECTION);glLoadMatrixf(pose.projection.data());
 glMatrixMode(GL_MODELVIEW);glLoadMatrixf(pose.model.data());glTranslated(pose.x,pose.y,pose.z);
 const double scale=settings.scale;
 glScaled(-scale,-scale,scale);glRotated(pose.yaw+180,0,1,0);
 glTranslated(0,-1.25/scale,.2/scale);if(pose.sneaking)glTranslated(0,.125/scale,0);
 glColor4ub(settings.color&255,(settings.color>>8)&255,(settings.color>>16)&255,(settings.color>>24)&255);
 const auto angles=Animation(milliseconds);
 glEnable(GL_CULL_FACE);glFrontFace(GL_CCW);
 for(int side=0;side<2;++side) {
  glCullFace(side?GL_FRONT:GL_BACK);glPushMatrix();glTranslatef(-2*ModelScale,0,0);
  glRotatef(angles.z*Degrees,0,0,1);glRotatef(angles.y*Degrees,0,1,0);glRotatef(angles.x*Degrees,1,0,0);glCallList(lists);
  glTranslatef(-10*ModelScale,0,0);glRotatef(angles.tip*Degrees,0,0,1);glCallList(lists+1);
  glPopMatrix();glScalef(-1,1,1);
 }
 glMatrixMode(GL_TEXTURE);glPopMatrix();glMatrixMode(GL_MODELVIEW);
 return true;
}
}
