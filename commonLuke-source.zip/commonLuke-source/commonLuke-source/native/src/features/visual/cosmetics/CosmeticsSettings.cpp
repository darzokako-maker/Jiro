#include "features/visual/cosmetics/Cosmetics.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <Windows.h>
#include <algorithm>
#include <cstdio>
#include <mutex>

namespace client::features::cosmetics {
namespace {
std::mutex mutex;
std::mutex debugMutex;
Settings settings;

std::vector<std::string> Choices(const wchar_t* folder,std::initializer_list<const wchar_t*> extensions) {
 std::vector<std::string> result{"None"};std::error_code ec;const auto directory=Root()/folder;
 std::filesystem::create_directories(directory,ec);ec.clear();
 for(const auto& item:std::filesystem::directory_iterator(directory,ec)) {
  if(ec)break;if(!item.is_regular_file(ec))continue;
  auto extension=item.path().extension().wstring();
  const bool accepted=std::any_of(extensions.begin(),extensions.end(),[&](const wchar_t* value){return _wcsicmp(extension.c_str(),value)==0;});
  if(!accepted)continue;
  const auto wide=item.path().filename().wstring();const int count=WideCharToMultiByte(CP_UTF8,0,wide.data(),static_cast<int>(wide.size()),nullptr,0,nullptr,nullptr);
  if(count>0){std::string name(count,'\0');WideCharToMultiByte(CP_UTF8,0,wide.data(),static_cast<int>(wide.size()),name.data(),count,nullptr,nullptr);result.push_back(std::move(name));}
 }
 std::sort(result.begin()+1,result.end(),[](const std::string& a,const std::string& b){return _stricmp(a.c_str(),b.c_str())<0;});return result;
}
}
Settings Options(){std::lock_guard lock(mutex);return settings;}
void SetOptions(Settings value){const auto previous=Options().enabled;const auto model=value.model;const auto skin=value.skin,cape=value.cape;{std::lock_guard lock(mutex);settings=std::move(value);}char line[1024]{};std::snprintf(line,sizeof(line),"settings enabled=%d model=%d skin='%s' cape='%s'",Options().enabled?1:0,static_cast<int>(model),skin.c_str(),cape.c_str());Debug(line);modules::StateChanged(modules::Cosmetics,previous,Options().enabled);}
std::filesystem::path Root(){wchar_t value[32768]{};const DWORD length=GetEnvironmentVariableW(L"APPDATA",value,static_cast<DWORD>(std::size(value)));return length&&length<std::size(value)?std::filesystem::path(value)/L".sonoyuncu"/L"aoki"/L"cosmetics":std::filesystem::path{};}
std::vector<std::string> SkinChoices(){return Choices(L"skin",{L".png"});}
std::vector<std::string> CapeChoices(){return Choices(L"cape",{L".png",L".gif"});}
void Debug(std::string_view message){
 std::lock_guard lock(debugMutex);static bool first=true;std::error_code ec;const auto root=Root();std::filesystem::create_directories(root,ec);const auto path=root/L"cosmetics-debug.log";
 FILE* file=nullptr;if(_wfopen_s(&file,path.c_str(),first?L"wb":L"ab")||!file)return;first=false;SYSTEMTIME time{};GetLocalTime(&time);
 std::fprintf(file,"[%02u:%02u:%02u.%03u] %.*s\r\n",time.wHour,time.wMinute,time.wSecond,time.wMilliseconds,static_cast<int>(message.size()),message.data());std::fclose(file);
}
}
