#include "features/visual/cosmetics/Cosmetics.hpp"
#include "game/MappingRepository.hpp"
#include "client/MethodManager.hpp"
#include "client/NativeScheduler.hpp"
#include <Windows.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <future>
#include <optional>
#include <span>
#include <sstream>
#include <unordered_set>
#include <vector>

namespace client::features::cosmetics {
namespace {
using Microsoft::WRL::ComPtr;
using Clock=std::chrono::steady_clock;
using client::methods::Argument;
using client::methods::Type;

struct Frame {std::vector<jint> pixels;int width=0,height=0,delayMs=100;};
struct Asset {std::vector<Frame> frames;bool Valid()const{return !frames.empty();}};
struct LoadResult {Asset skin,cape;std::string key;};
struct Runtime {
 jobject player=nullptr,info=nullptr,originalPlayerCape=nullptr,originalSkin=nullptr,originalCape=nullptr,originalModel=nullptr;
 jobject modelRecord=nullptr,originalClientModel=nullptr;
 std::vector<jobject> skinTextures,capeTextures;
 std::vector<int> capeDelays;
 std::future<LoadResult> pending;bool loading=false;
 std::string wantedKey,loadedKey,pendingKey;
 Clock::time_point animationStart{};
 bool playerCheckInitialized=false,scanInitialized=false;
 std::size_t capeFrame=static_cast<std::size_t>(-1);
 Model appliedModel=Model::Original;
} runtime;
client::scheduler::Cursor playerCheckCursor,scanCursor;
std::unordered_set<std::string> diagnostics;
void Once(std::string key,std::string message){if(diagnostics.insert(std::move(key)).second)Debug(message);}

Argument Int(int value){Argument a{Type::Int};a.value.i=value;return a;}
Argument Obj(jobject value){Argument a{Type::Object};a.value.l=value;return a;}
bool ClearException(JNIEnv* env){if(!env->ExceptionCheck())return false;env->ExceptionClear();return true;}

jobject ReadObject(JNIEnv* env,jobject object,const char* key) {
 const auto value=mapping::Object(env,object,key);if(!value)Once(std::string("field-read-")+key,std::string("object field unavailable: ")+key);return value;
}
bool WriteObject(JNIEnv* env,jobject object,const char* key,jobject value) {
 return mapping::WriteObject(env,object,key,value);
}

std::optional<std::uint32_t> Metadata(IWICMetadataQueryReader* reader,const wchar_t* name) {
 if(!reader)return {};PROPVARIANT value;PropVariantInit(&value);
 if(FAILED(reader->GetMetadataByName(name,&value)))return {};
 std::optional<std::uint32_t> result;
 switch(value.vt){case VT_UI1:result=value.bVal;break;case VT_UI2:result=value.uiVal;break;case VT_UI4:result=value.ulVal;break;case VT_I1:result=static_cast<std::uint32_t>(value.cVal);break;case VT_I2:result=static_cast<std::uint32_t>(value.iVal);break;case VT_I4:result=static_cast<std::uint32_t>(value.lVal);break;default:break;}
 PropVariantClear(&value);return result;
}

std::vector<unsigned char> ReadBytes(const std::filesystem::path& path) {
 std::vector<unsigned char> bytes;FILE* file=nullptr;if(_wfopen_s(&file,path.c_str(),L"rb")||!file)return bytes;
 _fseeki64(file,0,SEEK_END);const auto length=_ftelli64(file);_fseeki64(file,0,SEEK_SET);
 if(length<=0||length>64ll*1024*1024){std::fclose(file);return bytes;}bytes.resize(static_cast<std::size_t>(length));
 if(std::fread(bytes.data(),1,bytes.size(),file)!=bytes.size())bytes.clear();std::fclose(file);return bytes;
}

Asset Decode(const std::filesystem::path& path,bool skin) {
 Asset output;const auto bytes=ReadBytes(path);Debug(std::string("decode begin type=")+(skin?"skin":"cape")+" path='"+path.string()+"' bytes="+std::to_string(bytes.size()));if(bytes.empty()||bytes.size()>MAXDWORD){Debug("decode rejected: file could not be read");return output;}
 const HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
 ComPtr<IWICImagingFactory> factory;ComPtr<IWICStream> stream;ComPtr<IWICBitmapDecoder> decoder;
 bool ok=SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory)));
 ok=ok&&SUCCEEDED(factory->CreateStream(&stream));ok=ok&&SUCCEEDED(stream->InitializeFromMemory(const_cast<BYTE*>(bytes.data()),static_cast<DWORD>(bytes.size())));
 ok=ok&&SUCCEEDED(factory->CreateDecoderFromStream(stream.Get(),nullptr,WICDecodeMetadataCacheOnLoad,&decoder));
 UINT count=0;if(ok)ok=SUCCEEDED(decoder->GetFrameCount(&count))&&count>0&&count<=512;
 UINT canvasWidth=0,canvasHeight=0;ComPtr<IWICMetadataQueryReader> decoderMeta;
 if(ok&&SUCCEEDED(decoder->GetMetadataQueryReader(&decoderMeta))){canvasWidth=Metadata(decoderMeta.Get(),L"/logscrdesc/Width").value_or(0);canvasHeight=Metadata(decoderMeta.Get(),L"/logscrdesc/Height").value_or(0);}
 std::vector<jint> canvas,saved;UINT previousLeft=0,previousTop=0,previousWidth=0,previousHeight=0;std::uint32_t previousDisposal=0;
 for(UINT index=0;ok&&index<count;++index) {
  ComPtr<IWICBitmapFrameDecode> frame;ComPtr<IWICFormatConverter> converter;ComPtr<IWICMetadataQueryReader> metadata;
  ok=SUCCEEDED(decoder->GetFrame(index,&frame))&&SUCCEEDED(factory->CreateFormatConverter(&converter));
  ok=ok&&SUCCEEDED(converter->Initialize(frame.Get(),GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom));
  UINT width=0,height=0;if(ok)ok=SUCCEEDED(converter->GetSize(&width,&height))&&width&&height&&width<=4096&&height<=4096;
  if(!ok)break;frame->GetMetadataQueryReader(&metadata);
  const UINT left=Metadata(metadata.Get(),L"/imgdesc/Left").value_or(0),top=Metadata(metadata.Get(),L"/imgdesc/Top").value_or(0);
  if(!canvasWidth)canvasWidth=std::max(width,left+width);if(!canvasHeight)canvasHeight=std::max(height,top+height);
  if(!canvasWidth||!canvasHeight||canvasWidth>4096||canvasHeight>4096||left+width>canvasWidth||top+height>canvasHeight){ok=false;break;}
  if(canvas.empty())canvas.assign(static_cast<std::size_t>(canvasWidth)*canvasHeight,0);
  if(index&&previousDisposal==2)for(UINT y=previousTop;y<std::min(canvasHeight,previousTop+previousHeight);++y)std::fill(canvas.begin()+static_cast<std::size_t>(y)*canvasWidth+previousLeft,canvas.begin()+static_cast<std::size_t>(y)*canvasWidth+std::min(canvasWidth,previousLeft+previousWidth),0);
  else if(index&&previousDisposal==3&&!saved.empty())canvas=saved;
  const auto disposal=Metadata(metadata.Get(),L"/grctlext/Disposal").value_or(0);if(disposal==3)saved=canvas;
  std::vector<unsigned char> rgba(static_cast<std::size_t>(width)*height*4);
  if(FAILED(converter->CopyPixels(nullptr,width*4,static_cast<UINT>(rgba.size()),rgba.data()))){ok=false;break;}
  for(UINT y=0;y<height;++y)for(UINT x=0;x<width;++x){const auto source=(static_cast<std::size_t>(y)*width+x)*4;const unsigned a=rgba[source+3];if(!a)continue;const unsigned r=rgba[source],g=rgba[source+1],b=rgba[source+2];const auto at=static_cast<std::size_t>(top+y)*canvasWidth+left+x;canvas[at]=static_cast<jint>((a<<24)|(r<<16)|(g<<8)|b);}
  Frame decoded;decoded.width=static_cast<int>(canvasWidth);decoded.height=static_cast<int>(canvasHeight);decoded.delayMs=std::max(20,static_cast<int>(Metadata(metadata.Get(),L"/grctlext/Delay").value_or(10))*10);decoded.pixels=canvas;output.frames.push_back(std::move(decoded));
  previousLeft=left;previousTop=top;previousWidth=width;previousHeight=height;previousDisposal=disposal;
 }
 if(!ok){output.frames.clear();Debug("decode failed in WIC frame pipeline");}
 if(skin&&output.Valid()) {
  auto& image=output.frames.front();output.frames.resize(1);
  const int scale=image.width/64;const bool validScale=image.width>=64&&image.width%64==0&&scale>0&&(scale&(scale-1))==0;
  if(!validScale||(image.height!=image.width&&image.height*2!=image.width)){Debug("skin rejected dimensions="+std::to_string(image.width)+"x"+std::to_string(image.height));output.frames.clear();}
  else if(image.height*2==image.width) {
   const auto original=image.pixels;const int width=image.width,oldHeight=image.height;image.height=width;image.pixels.resize(static_cast<std::size_t>(width)*width,0);std::copy(original.begin(),original.end(),image.pixels.begin());
   auto blit=[&](int dx0,int dy0,int dx1,int dy1,int sx0,int sy0,int sx1,int sy1){dx0*=scale;dy0*=scale;dx1*=scale;dy1*=scale;sx0*=scale;sy0*=scale;sx1*=scale;sy1*=scale;const int dw=std::abs(dx1-dx0),dh=std::abs(dy1-dy0);for(int y=0;y<dh;++y)for(int x=0;x<dw;++x){const int dx=dx0+(dx1>=dx0?x:-x-1),dy=dy0+(dy1>=dy0?y:-y-1);const int sx=sx0+(sx1>=sx0?x:-x-1),sy=sy0+(sy1>=sy0?y:-y-1);if(dx>=0&&dx<width&&dy>=0&&dy<width&&sx>=0&&sx<width&&sy>=0&&sy<oldHeight)image.pixels[static_cast<std::size_t>(dy)*width+dx]=original[static_cast<std::size_t>(sy)*width+sx];}};
   blit(24,48,20,52,4,16,8,20);blit(28,48,24,52,8,16,12,20);blit(20,52,16,64,8,20,12,32);blit(24,52,20,64,4,20,8,32);blit(28,52,24,64,0,20,4,32);blit(32,52,28,64,12,20,16,32);
   blit(40,48,36,52,44,16,48,20);blit(44,48,40,52,48,16,52,20);blit(36,52,32,64,48,20,52,32);blit(40,52,36,64,44,20,48,32);blit(44,52,40,64,40,20,44,32);blit(48,52,44,64,52,20,56,32);
  }
 }
 if(output.Valid())Debug(std::string("decode success frames=")+std::to_string(output.frames.size())+" dimensions="+std::to_string(output.frames.front().width)+"x"+std::to_string(output.frames.front().height));
 else Debug("decode result is empty");decoderMeta.Reset();decoder.Reset();stream.Reset();factory.Reset();if(SUCCEEDED(com))CoUninitialize();return output;
}

std::wstring Wide(std::string_view value) {if(value.empty())return {};const int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value.data(),static_cast<int>(value.size()),nullptr,0);if(count<=0)return {};std::wstring result(count,L'\0');MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value.data(),static_cast<int>(value.size()),result.data(),count);return result;}
std::filesystem::path Selected(const wchar_t* folder,const std::string& name) {
 if(name.empty()||name=="None")return {};const auto wide=Wide(name);if(wide.empty())return {};const std::filesystem::path leaf(wide);if(leaf.filename()!=leaf)return {};return Root()/folder/leaf;
}
std::string Stamp(const std::filesystem::path& path) {if(path.empty())return "-";std::error_code ec;const auto size=std::filesystem::file_size(path,ec);if(ec)return "missing";const auto time=std::filesystem::last_write_time(path,ec).time_since_epoch().count();return ec?"missing":path.string()+":"+std::to_string(size)+":"+std::to_string(time);}
std::string Key(const Settings& settings){return std::to_string(static_cast<int>(settings.model))+"|"+Stamp(Selected(L"skin",settings.skin))+"|"+Stamp(Selected(L"cape",settings.cape));}
LoadResult Load(Settings settings,std::string key){Debug("worker load requested skin='"+settings.skin+"' cape='"+settings.cape+"'");LoadResult result;result.key=std::move(key);const auto skin=Selected(L"skin",settings.skin),cape=Selected(L"cape",settings.cape);if(!skin.empty())result.skin=Decode(skin,true);if(!cape.empty())result.cape=Decode(cape,false);Debug("worker load complete skinFrames="+std::to_string(result.skin.frames.size())+" capeFrames="+std::to_string(result.cape.frames.size()));return result;}

jobject Minecraft(JNIEnv* env){return mapping::StaticObject(env,"Minecraft.theMinecraft");}
jobject TextureManager(JNIEnv* env,jobject minecraft){auto result=mapping::Invoke(env,minecraft,"Minecraft.textureManager");jobject local=result.ok&&result.value.l?mapping::Root(env,mapping::Oop(result.value.l)):nullptr;result.Release(env);return local;}
jobject CreateTexture(JNIEnv* env,jobject manager,const Frame& frame,int sequence) {
 auto texture=mapping::New(env,"DynamicTexture.constructor",{Int(frame.width),Int(frame.height)});if(!texture){Debug("texture create failed: DynamicTexture constructor");return nullptr;}
 auto pixels=mapping::Invoke(env,texture,"DynamicTexture.pixels");
 const auto pixelLength=pixels.ok&&pixels.value.l?env->GetArrayLength(static_cast<jarray>(pixels.value.l)):0;
 if(!pixels.ok||!pixels.value.l||pixelLength<static_cast<jsize>(frame.pixels.size())){Debug("texture create failed: pixel array expectedAtLeast="+std::to_string(frame.pixels.size())+" actual="+std::to_string(pixelLength)+" error="+pixels.error);pixels.Release(env);env->DeleteLocalRef(texture);ClearException(env);return nullptr;}
 env->SetIntArrayRegion(static_cast<jintArray>(pixels.value.l),0,static_cast<jsize>(frame.pixels.size()),frame.pixels.data());pixels.Release(env);if(ClearException(env)){env->DeleteLocalRef(texture);return nullptr;}
 auto uploaded=mapping::Invoke(env,texture,"DynamicTexture.upload");const bool uploadOk=uploaded.ok;if(!uploadOk)Debug("texture create failed: upload "+uploaded.error);uploaded.Release(env);if(!uploadOk){env->DeleteLocalRef(texture);return nullptr;}
 const auto nameText="aoki/cosmetics/"+std::to_string(sequence);const auto name=env->NewStringUTF(nameText.c_str());auto location=mapping::Invoke(env,manager,"TextureManager.dynamic",{Obj(name),Obj(texture)});env->DeleteLocalRef(name);env->DeleteLocalRef(texture);
 if(!location.ok||!location.value.l){Debug("texture create failed: register "+location.error);location.Release(env);return nullptr;}Debug("texture registered sequence="+std::to_string(sequence)+" dimensions="+std::to_string(frame.width)+"x"+std::to_string(frame.height));return location.value.l;
}
void DeleteTextures(JNIEnv* env,std::vector<jobject>& textures) {
 if(textures.empty())return;const auto minecraft=Minecraft(env),manager=TextureManager(env,minecraft);
 if(manager)for(const auto texture:textures){auto deleted=mapping::Invoke(env,manager,"TextureManager.delete",{Obj(texture)});deleted.Release(env);}
 for(auto& texture:textures)mapping::ReleaseGlobal(env,texture);textures.clear();if(manager)env->DeleteLocalRef(manager);if(minecraft)env->DeleteLocalRef(minecraft);
}
void Assign(JNIEnv* env,const char* key,jobject value){if(runtime.info)WriteObject(env,runtime.info,key,value);}
void SetClientModel(JNIEnv* env,jobject model){if(!runtime.modelRecord||!model){Once("client-model-unavailable","SonOyuncu client model record/value unavailable");return;}if(!WriteObject(env,runtime.modelRecord,"PlayerCosmetic.model",model))Debug("PlayerCosmetic.model field write failed");}
void RestoreFields(JNIEnv* env) {if(runtime.info){Assign(env,"NetworkPlayerInfo.skin",runtime.originalSkin);Assign(env,"NetworkPlayerInfo.cape",runtime.originalCape);Assign(env,"NetworkPlayerInfo.model",runtime.originalModel);}if(runtime.player)WriteObject(env,runtime.player,"CosmeticsPlayer.cape",runtime.originalPlayerCape);SetClientModel(env,runtime.originalClientModel);}
void ReleasePlayer(JNIEnv* env) {
 RestoreFields(env);for(auto* value:{&runtime.player,&runtime.info,&runtime.originalPlayerCape,&runtime.originalSkin,&runtime.originalCape,&runtime.originalModel,&runtime.modelRecord,&runtime.originalClientModel})mapping::ReleaseGlobal(env,*value);
 runtime.player=runtime.info=runtime.originalPlayerCape=runtime.originalSkin=runtime.originalCape=runtime.originalModel=runtime.modelRecord=runtime.originalClientModel=nullptr;
}
void Reset(JNIEnv* env) {ReleasePlayer(env);DeleteTextures(env,runtime.skinTextures);DeleteTextures(env,runtime.capeTextures);runtime.loadedKey.clear();runtime.wantedKey.clear();runtime.capeDelays.clear();runtime.capeFrame=static_cast<std::size_t>(-1);runtime.playerCheckInitialized=false;runtime.scanInitialized=false;}

void CapturePlayer(JNIEnv* env) {
 const auto minecraft=Minecraft(env);if(!minecraft){Once("minecraft","Minecraft singleton unavailable");return;}const auto player=mapping::Object(env,minecraft,"Minecraft.thePlayer");env->DeleteLocalRef(minecraft);if(!player){Once("player","Minecraft.thePlayer unavailable");return;}
 auto result=mapping::Invoke(env,player,"CosmeticsPlayer.info");env->DeleteLocalRef(player);jobject info=result.ok&&result.value.l?mapping::Root(env,mapping::Oop(result.value.l)):nullptr;if(!result.ok||!info)Once("player-info","CosmeticsPlayer.info failed: "+result.error);result.Release(env);
 if(!info)return;const auto currentMinecraft=Minecraft(env),currentPlayer=mapping::Object(env,currentMinecraft,"Minecraft.thePlayer");if(currentMinecraft)env->DeleteLocalRef(currentMinecraft);if(!currentPlayer){env->DeleteLocalRef(info);Once("current-player","current player reacquire failed");return;}
 if(runtime.info&&runtime.player&&env->IsSameObject(runtime.info,info)&&env->IsSameObject(runtime.player,currentPlayer)){env->DeleteLocalRef(info);env->DeleteLocalRef(currentPlayer);return;}
 ReleasePlayer(env);runtime.player=mapping::Global(env,currentPlayer);runtime.info=mapping::Global(env,info);
 if(const auto value=ReadObject(env,currentPlayer,"CosmeticsPlayer.cape")){runtime.originalPlayerCape=mapping::Global(env,value);env->DeleteLocalRef(value);}
 for(auto pair:{std::pair{"NetworkPlayerInfo.skin",&runtime.originalSkin},std::pair{"NetworkPlayerInfo.cape",&runtime.originalCape},std::pair{"NetworkPlayerInfo.model",&runtime.originalModel}}){const auto value=ReadObject(env,info,pair.first);if(value){*pair.second=mapping::Global(env,value);env->DeleteLocalRef(value);}}
 const auto mc=Minecraft(env);const auto clientCosmetics=ReadObject(env,mc,"Minecraft.clientCosmetics");const auto models=ReadObject(env,clientCosmetics,"ClientCosmetics.models");const auto record=ReadObject(env,models,"PlayerModels.local");
 if(record){runtime.modelRecord=mapping::Global(env,record);const auto model=ReadObject(env,record,"PlayerCosmetic.model");if(model){runtime.originalClientModel=mapping::Global(env,model);env->DeleteLocalRef(model);}}
 if(record)env->DeleteLocalRef(record);if(models)env->DeleteLocalRef(models);if(clientCosmetics)env->DeleteLocalRef(clientCosmetics);if(mc)env->DeleteLocalRef(mc);
 Debug(std::string("player captured info=ok skinOriginal=")+(runtime.originalSkin?"yes":"no")+" capeOriginal="+(runtime.originalCape?"yes":"no")+" clientModelRecord="+(runtime.modelRecord?"yes":"no")+" clientModelValue="+(runtime.originalClientModel?"yes":"no"));env->DeleteLocalRef(currentPlayer);env->DeleteLocalRef(info);runtime.appliedModel=static_cast<Model>(-1);runtime.capeFrame=static_cast<std::size_t>(-1);
}
void ApplyModel(JNIEnv* env,Model model) {
 if(!runtime.info)return;if(model==runtime.appliedModel)return;jobject value=runtime.originalModel;
 if(model!=Model::Original)value=env->NewStringUTF(model==Model::Slim?"slim":"default");Assign(env,"NetworkPlayerInfo.model",value);if(model!=Model::Original)env->DeleteLocalRef(value);
 jobject clientModel=runtime.originalClientModel;if(model!=Model::Original)clientModel=mapping::StaticObject(env,model==Model::Slim?"PlayerModel.slim":"PlayerModel.classic");SetClientModel(env,clientModel);if(model!=Model::Original&&clientModel)env->DeleteLocalRef(clientModel);runtime.appliedModel=model;Debug("model applied selection="+std::to_string(static_cast<int>(model))+" networkValue="+(model==Model::Original?std::string("original"):model==Model::Slim?std::string("slim"):std::string("default"))+" clientEnum="+(clientModel?std::string("ok"):std::string("missing")));
}
void Install(JNIEnv* env,LoadResult result) {
 RestoreFields(env);runtime.appliedModel=static_cast<Model>(-1);DeleteTextures(env,runtime.skinTextures);DeleteTextures(env,runtime.capeTextures);runtime.capeDelays.clear();runtime.capeFrame=static_cast<std::size_t>(-1);
 const auto minecraft=Minecraft(env),manager=TextureManager(env,minecraft);int sequence=0;
 if(manager){for(const auto& frame:result.skin.frames)if(auto texture=CreateTexture(env,manager,frame,sequence++))runtime.skinTextures.push_back(texture);for(const auto& frame:result.cape.frames)if(auto texture=CreateTexture(env,manager,frame,sequence++)){runtime.capeTextures.push_back(texture);runtime.capeDelays.push_back(frame.delayMs);}}
 else Debug("install failed: TextureManager unavailable");
 if(manager)env->DeleteLocalRef(manager);if(minecraft)env->DeleteLocalRef(minecraft);
 runtime.loadedKey=std::move(result.key);runtime.animationStart=Clock::now();if(!runtime.skinTextures.empty())Assign(env,"NetworkPlayerInfo.skin",runtime.skinTextures.front());Debug("install complete skinTextures="+std::to_string(runtime.skinTextures.size())+" capeTextures="+std::to_string(runtime.capeTextures.size()));
}
void AnimateCape(JNIEnv* env) {
 if(!runtime.info)return;if(runtime.capeTextures.empty()){Assign(env,"NetworkPlayerInfo.cape",runtime.originalCape);return;}
 const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-runtime.animationStart).count();long long cycle=0;for(const auto delay:runtime.capeDelays)cycle+=delay;
 long long position=cycle?elapsed%cycle:0;std::size_t frame=0;while(frame+1<runtime.capeDelays.size()&&position>=runtime.capeDelays[frame]){position-=runtime.capeDelays[frame];++frame;}
 if(frame!=runtime.capeFrame){Assign(env,"NetworkPlayerInfo.cape",runtime.capeTextures[frame]);if(runtime.player)WriteObject(env,runtime.player,"CosmeticsPlayer.cape",runtime.capeTextures[frame]);runtime.capeFrame=frame;}
}
}

void Poll(JNIEnv* env) {
 if(!env)return;static bool announced=false;const auto settings=Options();
 client::scheduler::Configure(client::scheduler::Task::CosmeticsPlayerCheck,settings.enabled,250);
 client::scheduler::Configure(client::scheduler::Task::CosmeticsScan,settings.enabled,2000);
 if(!settings.enabled){announced=false;if(runtime.info||!runtime.skinTextures.empty()||!runtime.capeTextures.empty()){Debug("module disabled; restoring originals");Reset(env);}return;}if(!announced){announced=true;Debug("runtime poll active model="+std::to_string(static_cast<int>(settings.model))+" skin='"+settings.skin+"' cape='"+settings.cape+"' root='"+Root().string()+"'");}
 if(!runtime.playerCheckInitialized||client::scheduler::Consume(client::scheduler::Task::CosmeticsPlayerCheck,playerCheckCursor)){runtime.playerCheckInitialized=true;CapturePlayer(env);}
 ApplyModel(env,settings.model);
 if(!runtime.scanInitialized||client::scheduler::Consume(client::scheduler::Task::CosmeticsScan,scanCursor)){runtime.scanInitialized=true;std::error_code ec;std::filesystem::create_directories(Root()/L"skin",ec);ec.clear();std::filesystem::create_directories(Root()/L"cape",ec);runtime.wantedKey=Key(settings);}
 if(runtime.loading&&runtime.pending.wait_for(std::chrono::seconds(0))==std::future_status::ready){auto loaded=runtime.pending.get();runtime.loading=false;if(loaded.key==runtime.wantedKey)Install(env,std::move(loaded));}
 if(!runtime.loading&&runtime.wantedKey!=runtime.loadedKey){runtime.pendingKey=runtime.wantedKey;runtime.pending=std::async(std::launch::async,Load,settings,runtime.pendingKey);runtime.loading=true;}
 if(runtime.info){if(!runtime.skinTextures.empty())Assign(env,"NetworkPlayerInfo.skin",runtime.skinTextures.front());AnimateCape(env);ApplyModel(env,settings.model);}
}
}
