#include "features/visual/xray/Xray.hpp"

#include "ui/font/FontManager.hpp"

#include <imgui.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <optional>

namespace client::features::xray {
namespace {

struct V4 { double x, y, z, w; };

V4 Multiply(const std::array<float, 16>& matrix, V4 point) {
    return {
        matrix[0] * point.x + matrix[4] * point.y + matrix[8] * point.z + matrix[12] * point.w,
        matrix[1] * point.x + matrix[5] * point.y + matrix[9] * point.z + matrix[13] * point.w,
        matrix[2] * point.x + matrix[6] * point.y + matrix[10] * point.z + matrix[14] * point.w,
        matrix[3] * point.x + matrix[7] * point.y + matrix[11] * point.z + matrix[15] * point.w};
}

// Same clip-space convention the ESP projector uses, but applied to the eight
// corners of a block cube instead of an entity box.
std::optional<ImVec2> ProjectPoint(const esp::Vec3& point, const esp::Camera& camera) {
    const auto eye = Multiply(camera.model, {
        point.x - camera.origin.x,
        point.y - camera.origin.y,
        point.z - camera.origin.z, 1.0});
    const auto clip = Multiply(camera.projection, eye);
    if (clip.w <= 0.000001 || clip.z < -clip.w || clip.z > clip.w) return std::nullopt;
    return ImVec2(
        static_cast<float>(camera.viewport[0] + (clip.x / clip.w + 1.0) * camera.viewport[2] / 2.0),
        static_cast<float>(camera.framebufferHeight - camera.viewport[1] -
            (clip.y / clip.w + 1.0) * camera.viewport[3] / 2.0));
}

struct ScreenBounds {
    float left = 0, top = 0, right = 0, bottom = 0;
    bool valid = false;
};

ScreenBounds Bounds(const OreBox& box, const esp::Camera& camera) {
    const double xs[2] = {box.min.x, box.max.x};
    const double ys[2] = {box.min.y, box.max.y};
    const double zs[2] = {box.min.z, box.max.z};
    ScreenBounds bounds;
    for (int corner = 0; corner < 8; ++corner) {
        const esp::Vec3 point{
            xs[corner & 1],
            ys[(corner >> 1) & 1],
            zs[(corner >> 2) & 1]};
        const auto projected = ProjectPoint(point, camera);
        if (!projected) continue;
        if (!bounds.valid) {
            bounds.left = bounds.right = projected->x;
            bounds.top = bounds.bottom = projected->y;
            bounds.valid = true;
        } else {
            bounds.left = std::min(bounds.left, projected->x);
            bounds.right = std::max(bounds.right, projected->x);
            bounds.top = std::min(bounds.top, projected->y);
            bounds.bottom = std::max(bounds.bottom, projected->y);
        }
    }
    return bounds;
}

} // namespace

void Draw(const ui::FontManager& fonts, ImDrawList& foreground) {
    const auto& options = Options();
    if (!options.enabled) return;
    const auto frame = Snapshot();
    if (!frame || frame->ores.empty()) return;
    const auto& camera = frame->camera;
    if (camera.viewport[2] <= 0 || camera.viewport[3] <= 0 || camera.framebufferHeight <= 0) return;

    const float width = static_cast<float>(camera.viewport[2]);
    const float height = static_cast<float>(camera.framebufferHeight);
    const ImVec2 center{
        camera.viewport[0] + camera.viewport[2] * 0.5f,
        height - camera.viewport[1] - camera.viewport[3] * 0.5f};

    // Frame is sorted near-to-far; draw far first so close boxes stay on top.
    for (auto it = frame->ores.rbegin(); it != frame->ores.rend(); ++it) {
        const auto bounds = Bounds(*it, camera);
        if (!bounds.valid) continue;
        if (bounds.right < 0 || bounds.bottom < 0 || bounds.left > width || bounds.top > height) continue;

        const ImU32 color = ore::Color(it->kind);
        const ImU32 fill = (color & 0x00ffffffu) | (40u << 24);
        const ImVec2 minimum{bounds.left, bounds.top};
        const ImVec2 maximum{bounds.right, bounds.bottom};
        if (options.boxes) {
            foreground.AddRectFilled(minimum, maximum, fill, 2.f);
            foreground.AddRect(minimum, maximum, color, 2.f, 0, options.lineWidth);
        }
        if (options.tracers) {
            foreground.AddLine(center, {(bounds.left + bounds.right) * 0.5f,
                (bounds.top + bounds.bottom) * 0.5f}, color, std::max(1.f, options.lineWidth * 0.75f));
        }
        if (options.labels) {
            char text[64]{};
            std::snprintf(text, sizeof(text), "%s %.1fm", ore::Name(it->kind), it->distance);
            constexpr float size = 13.f;
            const float textWidth = fonts.Measure(text, size).x;
            const float textX = (bounds.left + bounds.right) * 0.5f - textWidth * 0.5f;
            const float textY = bounds.bottom + 3.f;
            foreground.AddRectFilled(
                {textX - 3.f, textY - 1.f},
                {textX + textWidth + 3.f, textY + size + 2.f},
                IM_COL32(0, 0, 0, 130), 3.f);
            fonts.Draw(foreground, text, {textX, textY}, size, color);
        }
    }
}

} // namespace client::features::xray
