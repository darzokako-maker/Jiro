#include "features/visual/xray/Xray.hpp"

#include <memory>
#include <mutex>
#include <utility>

namespace client::features::xray {
namespace {
Settings options;
std::mutex frameMutex;
std::shared_ptr<const Frame> latest;
std::uint64_t optionsRevision = 1;
}

const Settings& Options() { return options; }

void SetOptions(const Settings& settings) {
    {
        std::scoped_lock lock(frameMutex);
        options = settings;
        ++optionsRevision;
    }
}

std::uint64_t OptionsRevision() { return optionsRevision; }

void Publish(Frame frame) {
    auto next = std::make_shared<Frame>(std::move(frame));
    std::scoped_lock lock(frameMutex);
    latest = std::move(next);
}

void Clear() {
    std::scoped_lock lock(frameMutex);
    latest.reset();
}

std::optional<Frame> Snapshot() {
    std::scoped_lock lock(frameMutex);
    if (!latest) return std::nullopt;
    return *latest;
}

} // namespace client::features::xray
