#include "features/visual/xray/Xray.hpp"

#include "features/utility/ore/OreScan.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <string_view>

namespace client::features::xray {
namespace {
using namespace mapping;

// The scan copies a large slice of the loaded chunk sections, so a stationary
// player reuses the previous frame and only refreshes once per second. Walking
// more than two blocks triggers an immediate rescan.
constexpr std::uint64_t kScanIntervalMs = 1000;
constexpr double kScanMoveThresholdSquared = 4.0;

struct LocalFrame {
    JNIEnv* env;
    bool valid;
    explicit LocalFrame(JNIEnv* value) : env(value), valid(value->PushLocalFrame(64) == JNI_OK) {}
    ~LocalFrame() { if (valid) env->PopLocalFrame(nullptr); }
};

// ActiveRenderInfo exposes the GL matrices through direct FloatBuffer/IntBuffer
// statics; the ESP capture reads them the same way. `elements` is the capacity
// the Java buffer must expose: the two matrices are FloatBuffers of 16 values,
// the viewport is an IntBuffer of 4, so the check is per-buffer.
bool Buffer(JNIEnv* env, std::string_view field, void* output, std::size_t size,
            jlong elements) {
    jobject buffer = StaticObject(env, field);
    if (!buffer) return false;
    if (env->GetDirectBufferCapacity(buffer) < elements) return false;
    const void* address = env->GetDirectBufferAddress(buffer);
    return address && hotspot::ReadMemory(reinterpret_cast<std::uintptr_t>(address), output, size);
}

struct ScanCache {
    jobject world = nullptr;
    std::vector<OreBox> ores;
    double x = 0, y = 0, z = 0;
    float radius = 0;
    ore::Toggles toggles{};
    ore::Filter filter{};
    std::uint64_t updated = 0;
};

ScanCache cache;

void ResetCache(JNIEnv* env) {
    if (cache.world && env) ReleaseGlobal(env, cache.world);
    cache = {};
}

bool SameWorld(JNIEnv* env, jobject world) {
    return cache.world && env && env->IsSameObject(cache.world, world);
}

} // namespace

void Capture(JNIEnv* env, int width, int height) {
    if (!env || env->ExceptionCheck()) return;
    const auto& options = Options();
    if (!options.enabled) {
        if (cache.world) ResetCache(env);
        Clear();
        return;
    }
    LocalFrame frame(env);
    if (!frame.valid) return;

    const auto minecraft = StaticObject(env, "Minecraft.theMinecraft");
    if (!minecraft) { Clear(); return; }
    const auto world = Object(env, minecraft, "Minecraft.theWorld");
    const auto player = Object(env, minecraft, "Minecraft.thePlayer");
    const auto manager = Object(env, minecraft, "Minecraft.renderManager");
    const auto timer = Object(env, minecraft, "Minecraft.timer");
    if (!world || !player || !manager || !timer) {
        ResetCache(env);
        Clear();
        return;
    }

    Frame out;
    auto& camera = out.camera;
    if (!Buffer(env, "ActiveRenderInfo.MODELVIEW", camera.model.data(), sizeof(camera.model), 16) ||
        !Buffer(env, "ActiveRenderInfo.PROJECTION", camera.projection.data(), sizeof(camera.projection), 16) ||
        !Buffer(env, "ActiveRenderInfo.VIEWPORT", camera.viewport.data(), sizeof(camera.viewport), 4)) {
        Clear();
        return;
    }
    for (float value : camera.model) if (!std::isfinite(value)) { Clear(); return; }
    for (float value : camera.projection) if (!std::isfinite(value)) { Clear(); return; }

    const auto viewerX = Read<double>(manager, "RenderManager.viewerPosX");
    const auto viewerY = Read<double>(manager, "RenderManager.viewerPosY");
    const auto viewerZ = Read<double>(manager, "RenderManager.viewerPosZ");
    if (!viewerX || !viewerY || !viewerZ) { Clear(); return; }
    camera.origin = {*viewerX, *viewerY, *viewerZ};
    camera.partial = std::clamp(Read<float>(timer, "Timer.partialTicks").value_or(1.f), 0.f, 1.f);
    camera.framebufferHeight = height;
    if (camera.viewport[2] <= 0 || camera.viewport[3] <= 0 ||
        camera.viewport[2] > width * 2 || camera.viewport[3] > height * 2) {
        Clear();
        return;
    }

    const auto px = Read<double>(player, "Entity.posX");
    const auto py = Read<double>(player, "Entity.posY");
    const auto pz = Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) { Clear(); return; }

    const auto now = client::scheduler::Now();
    const double movedX = *px - cache.x, movedY = *py - cache.y, movedZ = *pz - cache.z;
    const bool moved = movedX * movedX + movedY * movedY + movedZ * movedZ > kScanMoveThresholdSquared;
    if (!SameWorld(env, world)) {
        ResetCache(env);
        cache.world = Global(env, world);
        if (!cache.world) {
            if (env->ExceptionCheck()) env->ExceptionClear();
            Clear();
            return;
        }
    }
    if (cache.radius != options.radius || cache.toggles != options.ores ||
        cache.filter != options.filter ||
        now - cache.updated >= kScanIntervalMs || moved) {
        const auto result = ore::Scan(env, cache.world, *px, *py, *pz, options.radius,
                                      options.ores, options.filter);
        if (result.status == ore::ScanStatus::UnsupportedProvider) {
            static bool warned = false;
            if (!warned) {
                warned = true;
                AOKI_LOG("[Xray] ore scan skipped: unsupported chunk provider");
            }
        }
        cache.ores.clear();
        cache.ores.reserve(result.blocks.size());
        for (const auto& block : result.blocks) {
            OreBox box;
            box.kind = block.kind;
            box.min = {static_cast<double>(block.x), static_cast<double>(block.y), static_cast<double>(block.z)};
            box.max = {box.min.x + 1.0, box.min.y + 1.0, box.min.z + 1.0};
            box.center = {box.min.x + 0.5, box.min.y + 0.5, box.min.z + 0.5};
            box.distance = block.distance;
            cache.ores.push_back(box);
        }
        cache.x = *px; cache.y = *py; cache.z = *pz;
        cache.radius = options.radius;
        cache.toggles = options.ores;
        cache.filter = options.filter;
        cache.updated = now;
    }

    out.ores = cache.ores;
    Publish(std::move(out));
}

} // namespace client::features::xray
