#include "features/visual/item_esp/ItemEsp.hpp"
#include "features/core/ModuleRegistry.hpp"

namespace client::features::item_esp {
namespace {
Settings options;
std::uint64_t optionsRevision = 0;
}

const Settings& Options() { return options; }
void SetOptions(const Settings& settings) {
 const bool previous = options.enabled;
 options = settings;
 options.minecraftFont = false;
 ++optionsRevision;
 modules::StateChanged(modules::ItemEsp, previous, options.enabled);
}
std::uint64_t OptionsRevision() { return optionsRevision; }
}

