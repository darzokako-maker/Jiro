#include "features/visual/freecam/FreeCam.hpp"
#include "features/movement/common/MotionAccess.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "game/MappingRepository.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "client/PacketBridge.hpp"
#include "client/Logger.hpp"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <chrono>
#include <mutex>

namespace client::features::freecam {
namespace {
std::recursive_mutex mutex;
std::atomic<bool> active{false};
std::atomic<std::uint64_t> cancelledPackets{0};

Vector3d originalPos;
Vector3d originalMotion;
Vector2f originalRot;
bool originalSprinting = false;
std::chrono::steady_clock::time_point lastPollTime{};
bool hasPollTime = false;

methods::Argument Double(double v) {
    methods::Argument a{methods::Type::Double};
    a.value.d = v;
    return a;
}

void ResetState(JNIEnv* env, jobject player, jobject mc) {
    if(!active.load()) return;
    if(player) {
        mapping::Write(player, "Entity.noClip", false);
        auto res = mapping::Invoke(env, player, "Entity.setPosition", {
            Double(originalPos.x), Double(originalPos.y), Double(originalPos.z)
        });
        res.Release(env);
        mapping::Write(player, "Entity.rotationYaw", originalRot.yaw);
        mapping::Write(player, "Entity.rotationPitch", originalRot.pitch);
        motion::Set(env, player, originalMotion.x, originalMotion.y, originalMotion.z);
    }
    if(mc) {
        const auto settings = mapping::Object(env, mc, "Minecraft.gameSettings");
        const auto sprintKey = settings ? mapping::Object(env, settings, "GameSettings.keyBindSprint") : nullptr;
        if(sprintKey) mapping::Write(sprintKey, "KeyBinding.pressed", originalSprinting);
    }
    active.store(false);
    AOKI_LOG("[FreeCam] disabled; nativeCancelled=%llu",
        static_cast<unsigned long long>(cancelledPackets.load()));
}

} // namespace

bool IsActive() { return active.load(); }

Vector3d OriginalPosition() {
    std::lock_guard lock(mutex);
    return originalPos;
}

jobject BeforeSend(JNIEnv* env, jobject packet) {
    if(!active.load() || !packet || !env || env->ExceptionCheck()) return packet;
    if(mapping::Instance(packet, "AuraMovementPacket") ||
       mapping::Instance(packet, "AuraAnimationPacket") ||
       mapping::Instance(packet, "AuraAttackPacket") ||
       mapping::Instance(packet, "AuraEntityActionPacket") ||
       mapping::Instance(packet, "AuraPlacePacket") ||
       mapping::Instance(packet, "AuraDigPacket")) {
        return nullptr;
    }
    return packet;
}

native_packets::Action BeforeNativePacket(native_packets::PacketView& packet) {
    if(!active.load()||packet.direction!=native_packets::Direction::Outbound)return native_packets::Action::Pass;
    const auto id=packet.packetId;
    if((id>=2&&id<=8)||id==10||id==11) {
        const auto total=cancelledPackets.fetch_add(1)+1;
        if(total<=8||(total%128)==0)
            AOKI_LOG("[FreeCam] native cancel OUT id=%d total=%llu",id,
                static_cast<unsigned long long>(total));
        return native_packets::Action::Cancel;
    }
    return native_packets::Action::Pass;
}

void Poll(JNIEnv* env) {
    if(!env || env->ExceptionCheck()) return;
    std::lock_guard lock(mutex);

    const auto mc = mapping::StaticObject(env, "Minecraft.theMinecraft");
    if(!mc) return;
    const auto player = mapping::Object(env, mc, "Minecraft.thePlayer");
    const auto world = mapping::Object(env, mc, "Minecraft.theWorld");

    if(!player || !world || mapping::Read<bool>(player, "Entity.isDead").value_or(false)) {
        if(active.load()) ResetState(env, player, mc);
        return;
    }

    const auto& opt = Options();

    if(!active.load() && opt.enabled) {
        originalPos.x = mapping::Read<double>(player, "Entity.posX").value_or(0.0);
        originalPos.y = mapping::Read<double>(player, "Entity.posY").value_or(0.0);
        originalPos.z = mapping::Read<double>(player, "Entity.posZ").value_or(0.0);
        originalMotion.x = mapping::Read<double>(player, "Entity.motionX").value_or(0.0);
        originalMotion.y = mapping::Read<double>(player, "Entity.motionY").value_or(0.0);
        originalMotion.z = mapping::Read<double>(player, "Entity.motionZ").value_or(0.0);
        originalRot.yaw = mapping::Read<float>(player, "Entity.rotationYaw").value_or(0.0f);
        originalRot.pitch = mapping::Read<float>(player, "Entity.rotationPitch").value_or(0.0f);

        const auto settings = mapping::Object(env, mc, "Minecraft.gameSettings");
        const auto sprintKey = settings ? mapping::Object(env, settings, "GameSettings.keyBindSprint") : nullptr;
        originalSprinting = sprintKey ? mapping::Read<bool>(sprintKey, "KeyBinding.pressed").value_or(false) : false;

        active.store(true);
        cancelledPackets.store(0);
        hasPollTime = false;
        AOKI_LOG("[FreeCam] enabled at %.3f %.3f %.3f", originalPos.x,
            originalPos.y, originalPos.z);
    } else if(active.load() && !opt.enabled) {
        ResetState(env, player, mc);
        return;
    }

    if(!active.load()) return;

    // Read current position before anything modifies it
    const double curX = mapping::Read<double>(player, "Entity.posX").value_or(0.0);
    const double curY = mapping::Read<double>(player, "Entity.posY").value_or(0.0);
    const double curZ = mapping::Read<double>(player, "Entity.posZ").value_or(0.0);

    mapping::Write(player, "Entity.noClip", true);
    mapping::Write(player, "Entity.fallDistance", 0.0f);
    mapping::Write(player, "Entity.onGround", false);

    // Frame-rate independent delta time
    const auto now = std::chrono::steady_clock::now();
    double dt = 0.05;
    if(hasPollTime) {
        dt = std::chrono::duration<double>(now - lastPollTime).count();
        dt = std::clamp(dt, 0.001, 0.1);
    }
    lastPollTime = now;
    hasPollTime = true;

    const auto currentScreen = mapping::Object(env, mc, "Minecraft.currentScreen");
    if(currentScreen || ui::input::IsOpen()) {
        // Re-anchor position so game tick physics can't drift us
        mapping::Invoke(env, player, "Entity.setPosition", {Double(curX), Double(curY), Double(curZ)});
        motion::Set(env, player, 0.0, 0.0, 0.0);
        return;
    }

    const auto settings = mapping::Object(env, mc, "Minecraft.gameSettings");
    if(!settings) return;

    const auto keyForward = mapping::Object(env, settings, "GameSettings.keyBindForward");
    const auto keyBack = mapping::Object(env, settings, "GameSettings.keyBindBack");
    const auto keyLeft = mapping::Object(env, settings, "GameSettings.keyBindLeft");
    const auto keyRight = mapping::Object(env, settings, "GameSettings.keyBindRight");
    const auto keyJump = mapping::Object(env, settings, "GameSettings.keyBindJump");
    const auto keySneak = mapping::Object(env, settings, "GameSettings.keyBindSneak");

    const bool fwd = keyForward && mapping::Read<bool>(keyForward, "KeyBinding.pressed").value_or(false);
    const bool back = keyBack && mapping::Read<bool>(keyBack, "KeyBinding.pressed").value_or(false);
    const bool left = keyLeft && mapping::Read<bool>(keyLeft, "KeyBinding.pressed").value_or(false);
    const bool right = keyRight && mapping::Read<bool>(keyRight, "KeyBinding.pressed").value_or(false);
    const bool jump = keyJump && mapping::Read<bool>(keyJump, "KeyBinding.pressed").value_or(false);
    const bool sneak = keySneak && mapping::Read<bool>(keySneak, "KeyBinding.pressed").value_or(false);

    const float speed = std::clamp(opt.speed, 0.1f, 10.0f);
    const float forward = (fwd ? 1.0f : 0.0f) - (back ? 1.0f : 0.0f);
    const float strafe = (left ? 1.0f : 0.0f) - (right ? 1.0f : 0.0f);

    double dx = 0.0, dz = 0.0;
    if(forward != 0.0f || strafe != 0.0f) {
        const float yaw = mapping::Read<float>(player, "Entity.rotationYaw").value_or(0.0f);
        const double length = std::max(1.0, std::hypot(static_cast<double>(forward), static_cast<double>(strafe)));
        constexpr double toRad = 3.14159265358979323846 / 180.0;
        const double rad = static_cast<double>(yaw) * toRad;
        dx = (strafe * std::cos(rad) - forward * std::sin(rad)) * static_cast<double>(speed) / length;
        dz = (forward * std::cos(rad) + strafe * std::sin(rad)) * static_cast<double>(speed) / length;
    }

    double dy = 0.0;
    if(jump) dy += speed;
    if(sneak) dy -= speed;

    // Scale by delta time (speed unit = blocks/tick, 20 ticks/sec)
    const double scale = dt * 20.0;
    const double newX = curX + dx * scale;
    const double newY = curY + dy * scale;
    const double newZ = curZ + dz * scale;

    // Directly set position — bypasses moveEntity collision entirely
    mapping::Invoke(env, player, "Entity.setPosition", {Double(newX), Double(newY), Double(newZ)});
    // Zero motion so game's moveEntity + gravity can't fight us
    motion::Set(env, player, 0.0, 0.0, 0.0);
}

} // namespace client::features::freecam
