#include "features/visual/freecam/FreeCam.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <algorithm>
#include <atomic>
#include <cmath>

namespace client::features::freecam {
namespace {
Settings options;
std::atomic<std::uint64_t> revision{1};
}

const Settings& Options() { return options; }

void SetOptions(Settings settings) {
    if(!std::isfinite(settings.speed) || settings.speed <= 0.05f) settings.speed = 1.0f;
    settings.speed = std::clamp(settings.speed, 0.1f, 10.0f);
    const bool previous = options.enabled;
    options = settings;
    ++revision;
    modules::StateChanged(modules::FreeCam, previous, options.enabled);
}

std::uint64_t Revision() { return revision.load(); }

} // namespace client::features::freecam

