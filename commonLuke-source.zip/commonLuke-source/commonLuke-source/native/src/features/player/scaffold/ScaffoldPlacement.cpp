#include "features/player/scaffold/ScaffoldPlacement.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"

namespace client::features::scaffold {
namespace {

using methods::Argument;
using methods::Type;

Argument ObjectArg(jobject object) {
    Argument argument{Type::Object};
    argument.value.l = object;
    return argument;
}

Argument IntArg(int value) {
    Argument argument{Type::Int};
    argument.value.i = value;
    return argument;
}

Argument DoubleArg(double value) {
    Argument argument{Type::Double};
    argument.value.d = value;
    return argument;
}

struct LocalFrame {
    JNIEnv* env;
    bool ready;
    explicit LocalFrame(JNIEnv* environment)
        : env(environment), ready(env && !env->ExceptionCheck() && env->PushLocalFrame(16) == JNI_OK) {}
    ~LocalFrame() { if (ready) env->PopLocalFrame(nullptr); }
};

jobject JavaPosition(JNIEnv* env, BlockPos pos) {
    return mapping::New(env, "BlockPos.constructor", {IntArg(pos.x), IntArg(pos.y), IntArg(pos.z)});
}

std::optional<bool> Replaceable(JNIEnv* env, jobject world, BlockPos pos) {
    LocalFrame frame(env);
    if (!frame.ready) return std::nullopt;
    const auto position = JavaPosition(env, pos);
    if (!position) return std::nullopt;
    auto state = mapping::Invoke(env, world, "World.getBlockState", {ObjectArg(position)});
    if (!state.ok || !state.value.l) {
        state.Release(env);
        return std::nullopt;
    }
    auto block = mapping::Invoke(env, state.value.l, "BlockState.getBlock");
    state.Release(env);
    if (!block.ok || !block.value.l) {
        block.Release(env);
        return std::nullopt;
    }
    const auto result = mapping::Invoke(env, block.value.l, "Block.isReplaceable",
                                        {ObjectArg(world), ObjectArg(position)});
    block.Release(env);
    if (!result.ok) return std::nullopt;
    return result.value.z != JNI_FALSE;
}

constexpr std::array<const char*, 6> faceFields{{
    "ScaffoldFace.down", "ScaffoldFace.up", "ScaffoldFace.north",
    "ScaffoldFace.south", "ScaffoldFace.west", "ScaffoldFace.east"
}};

}

std::optional<bool> IsReplaceable(JNIEnv* env, jobject world, BlockPos pos) {
    return Replaceable(env, world, pos);
}

jobject JavaFace(JNIEnv* env, Face face) {
    return mapping::StaticObject(env, faceFields[static_cast<unsigned>(face)]);
}

std::optional<Placement> FindPlacement(JNIEnv* env, jobject world, Vec3 player,
                                      Vec3 offset, std::optional<int> plane, float yaw) {
    if (!env || !world) return std::nullopt;
    auto worldLookup = [&](BlockPos pos) { return Replaceable(env, world, pos); };
    ReplaceableCache replaceable(worldLookup);
    const auto target = FindTarget(player, offset, plane, replaceable);
    if (!target) return std::nullopt;
    const auto support = FindSupport(*target, yaw, offset.y < 0, replaceable);
    if (!support) return std::nullopt;
    auto position = Floor(*target);
    position.x += static_cast<int>(support->offset.x);
    position.y += static_cast<int>(support->offset.y);
    position.z += static_cast<int>(support->offset.z);
    return Placement{*target, position, support->face};
}

bool Place(JNIEnv* env, jobject minecraft, jobject player, jobject stack,
           const Placement& placement, RayCast rayCast, std::optional<Vec3> rayHit,
           Vec3 randomHit) {
    LocalFrame frame(env);
    if (!frame.ready || !minecraft || !player || !stack) return false;
    if (rayCast == RayCast::Strict) {
        const auto result = mapping::Invoke(env, minecraft, "Minecraft.rightClickMouse");
        if (!result.ok) AOKI_LOG("[Scaffold] rightClickMouse failed: %s", result.error.c_str());
        return result.ok;
    }

    const auto controller = mapping::Object(env, minecraft, "Minecraft.playerController");
    const auto world = mapping::Object(env, minecraft, "Minecraft.theWorld");
    const auto face = JavaFace(env, placement.face);
    const auto position = JavaPosition(env, placement.support);
    const auto hit = rayHit.value_or(RandomHit(placement.support, placement.face, randomHit));
    const auto hitVector = mapping::New(env, "Vec3.constructor",
                                       {DoubleArg(hit.x), DoubleArg(hit.y), DoubleArg(hit.z)});
    if (!controller || !world || !face || !position || !hitVector) return false;

    const auto clicked = mapping::Invoke(env, controller, "PlayerControllerMP.onPlayerRightClick",
        {ObjectArg(player), ObjectArg(world), ObjectArg(stack), ObjectArg(position),
         ObjectArg(face), ObjectArg(hitVector)});
    if (!clicked.ok) AOKI_LOG("[Scaffold] onPlayerRightClick failed: %s", clicked.error.c_str());
    if (!clicked.ok || !clicked.value.z) return false;

    const auto network = mapping::Object(env, player, "EntityPlayerSP.sendQueue");
    const auto animation = mapping::New(env, "AuraAnimationPacket.constructor");
    if (network && animation) {
        mapping::Invoke(env, network, "ScaffoldNetwork.addToSendQueue", {ObjectArg(animation)});
    }
    return true;
}

}
