#include "features/player/scaffold/Scaffold.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "client/Logger.hpp"

#include <mutex>

namespace client::features::scaffold {
namespace {
std::mutex mutex;
Settings current;

float Bound(float value, float fallback, float max) {
    return std::isfinite(value) ? std::clamp(value, 0.f, max) : fallback;
}
}

Settings Options() {
    std::lock_guard lock(mutex);
    return current;
}

void SetOptions(Settings settings) {
    if (settings.mode < Mode::Normal || settings.mode > Mode::Telly) settings.mode = Mode::Normal;
    if (settings.rayCast < RayCast::Off || settings.rayCast > RayCast::Strict) settings.rayCast = RayCast::Strict;
    if (settings.sameY < SameY::Off || settings.sameY > SameY::AutoJump) settings.sameY = SameY::Off;
    settings.rotationMin = Bound(settings.rotationMin, 5, 10);
    settings.rotationMax = Bound(settings.rotationMax, 10, 10);
    settings.delayMin = Bound(settings.delayMin, 0, 5);
    settings.delayMax = Bound(settings.delayMax, 0, 5);
    settings.expand = Bound(settings.expand, 0, 4);
    if (settings.rotationMin > settings.rotationMax) std::swap(settings.rotationMin, settings.rotationMax);
    if (settings.delayMin > settings.delayMax) std::swap(settings.delayMin, settings.delayMax);
    bool previous;
    {
        std::lock_guard lock(mutex);
        previous = current.enabled;
        current = settings;
    }
    modules::StateChanged(modules::Scaffold, previous, settings.enabled);
    AOKI_LOG("[Scaffold] settings enabled=%d mode=%d sameY=%d rayCast=%d rotation=%.1f..%.1f delay=%.1f..%.1f expand=%.1f safeWalk=%d correction=%d",
             settings.enabled, static_cast<int>(settings.mode), static_cast<int>(settings.sameY),
             static_cast<int>(settings.rayCast), settings.rotationMin, settings.rotationMax,
             settings.delayMin, settings.delayMax, settings.expand, settings.safeWalk, settings.movementCorrection);
}

}
