#include "features/player/scaffold/Scaffold.hpp"
#include "features/movement/ncp/NcpMovement.hpp"
#include "game/MappingRepository.hpp"
#include "ui/clickgui/InputBridge.hpp"
#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"

#include <Windows.h>
#include <atomic>
#include <mutex>
#include <random>
#include <utility>
#include <chrono>
#include <string_view>
#include <cstring>
#include <algorithm>

namespace client::features::scaffold {
namespace {
using namespace mapping;
using methods::Argument;
using methods::Type;

struct State {
    std::optional<double> startY;
    int lastTick = -1;
    int hotbarSlot = -1;
    int ticksOnAir = 0;
    int offGroundTicks = 0;
    float yaw = 0, pitch = 90;
};

State state;
bool requestedJump = false;
std::optional<std::array<float, 2>> requestedAxes;
jobject ownedJumpBinding = nullptr;

int VirtualKey(int lwjgl) {
    switch(lwjgl){case 157:return VK_RCONTROL;case 184:return VK_RMENU;case 199:return VK_HOME;case 200:return VK_UP;case 201:return VK_PRIOR;case 203:return VK_LEFT;case 205:return VK_RIGHT;case 207:return VK_END;case 208:return VK_DOWN;case 209:return VK_NEXT;case 210:return VK_INSERT;case 211:return VK_DELETE;default:return lwjgl>0&&lwjgl<128?static_cast<int>(MapVirtualKeyW(lwjgl,MAPVK_VSC_TO_VK_EX)):0;}
}
void RestoreJumpBinding(JNIEnv* env) {
    if(!env||!ownedJumpBinding)return;
    const int code=Read<int>(ownedJumpBinding,"KeyBinding.keyCode").value_or(0);
    const int key=VirtualKey(code);
    Write(ownedJumpBinding,"KeyBinding.pressed",key&&(GetAsyncKeyState(key)&0x8000)!=0);
    mapping::ReleaseGlobal(env,ownedJumpBinding);
}

void Diagnostic(int channel, std::string_view status, int code = 0) {
    static std::array<std::string_view, 2> previous;
    static std::array<std::uint64_t, 2> last{};
    const auto now = client::scheduler::Now();
    if (previous[channel] == status && now-last[channel] < 5000) return;
    previous[channel] = status;
    last[channel] = now;
    AOKI_LOG("[Scaffold] %.*s code=%d tick=%d air=%d offGround=%d yaw=%.3f pitch=%.3f",
             static_cast<int>(status.size()), status.data(), code, state.lastTick,
             state.ticksOnAir, state.offGroundTicks, state.yaw, state.pitch);
}
std::mt19937 random{std::random_device{}()};
std::atomic<bool> badPackets{false};
std::mutex rotationMutex;
std::optional<std::array<float, 2>> pendingRotation;

void SetRotation(std::optional<std::array<float, 2>> rotation) {
    std::lock_guard lock(rotationMutex);
    pendingRotation = rotation;
}

Argument FloatArg(float value) {
    Argument argument{Type::Float};
    argument.value.f = value;
    return argument;
}

Argument DoubleArg(double value) {
    Argument argument{Type::Double};
    argument.value.d = value;
    return argument;
}

double Sample() { return std::generate_canonical<double, 53>(random); }

float Angle(double radians) {
    return static_cast<float>(radians * (180.0 / std::numbers::pi));
}

Vec3 Position(jobject player) {
    return {Read<double>(player, "Entity.posX").value_or(0),
            Read<double>(player, "Entity.posY").value_or(0),
            Read<double>(player, "Entity.posZ").value_or(0)};
}

jobject FindStack(JNIEnv* env, jobject inventory, int& slot) {
    constexpr std::array blacklist{145, 54, 130, 146, 116, 12, 30, 50, 58, 61, 111,
                                   23, 70, 72, 25, 158, 46, 176, 177, 76, 86};
    const auto stacks = static_cast<jobjectArray>(Object(env, inventory, "InventoryPlayer.mainInventory"));
    if (!stacks) {
        AOKI_LOG("[Scaffold] hotbar scan failed: mainInventory unavailable");
        return nullptr;
    }
    const int count = std::min<int>(9, env->GetArrayLength(stacks));
    int occupied = 0, enough = 0, blockItems = 0, allowed = 0, fullBlocks = 0;
    jobject selected = nullptr;
    int selectedSize = 0, selectedId = 0;
    bool selectedFull = false;
    const int previousSlot = state.hotbarSlot;
    const auto eligible = [&](int index) {
        const auto stack = env->GetObjectArrayElement(stacks, index);
        if (!stack) return false;
        ++occupied;
        const int stackSize = Read<int>(stack, "ItemStack.stackSize").value_or(0);
        if (stackSize <= 5) {
            env->DeleteLocalRef(stack);
            return false;
        }
        ++enough;
        const auto item = Object(env, stack, "ItemStack.item");
        if (!item) {
            env->DeleteLocalRef(stack);
            return false;
        }
        Argument itemArgument{Type::Object};
        itemArgument.value.l = item;
        auto blockResult = Invoke(env, nullptr, "Block.fromItem", {itemArgument});
        env->DeleteLocalRef(item);
        if (!blockResult.ok || !blockResult.value.l) {
            blockResult.Release(env);
            env->DeleteLocalRef(stack);
            return false;
        }
        ++blockItems;
        const auto block = blockResult.value.l;
        Argument argument{Type::Object};
        argument.value.l = block;
        const auto id = Invoke(env, nullptr, "Block.id", {argument});
        if (!id.ok || std::find(blacklist.begin(), blacklist.end(), id.value.i) != blacklist.end()) {
            blockResult.Release(env);
            env->DeleteLocalRef(stack);
            return false;
        }
        ++allowed;
        const auto full = Invoke(env, block, "Block.isFullBlock");
        if ((full.ok && full.value.z) || id.value.i == 20 || id.value.i == 95) {
            ++fullBlocks;
            selected = stack;
            selectedSize = stackSize;
            selectedId = id.value.i;
            selectedFull = full.ok && full.value.z;
            blockResult.Release(env);
            return true;
        }
        blockResult.Release(env);
        env->DeleteLocalRef(stack);
        return false;
    };

    const int found = FindHotbarSlot(count, state.hotbarSlot, eligible);
    env->DeleteLocalRef(stacks);
    if (found >= 0) {
        slot = found;
        state.hotbarSlot = found;
        if (found != previousSlot) {
            AOKI_LOG("[Scaffold] hotbar selected slot=%d size=%d blockId=%d full=%d",
                     found, selectedSize, selectedId, selectedFull);
        }
        return selected;
    }
    state.hotbarSlot = -1;
    if (state.lastTick % 100 < 2) {
        AOKI_LOG("[Scaffold] hotbar rejected slots=%d occupied=%d size>5=%d blockItems=%d allowed=%d full=%d",
                 count, occupied, enough, blockItems, allowed, fullBlocks);
    }
    return nullptr;
}

void UpdateMouseOver(JNIEnv* env, jobject renderer) {
    Argument partialTick{Type::Float};
    partialTick.value.f = 1;
    Invoke(env, renderer, "EntityRenderer.getMouseOver", {partialTick});
}

struct Hit {
    Vec3 position;
    bool sameFace;
};

std::optional<Hit> MouseHit(JNIEnv* env, jobject minecraft, const Placement& placement) {
    const auto result = Object(env, minecraft, "Minecraft.objectMouseOver");
    if (!result) return std::nullopt;
    const auto block = Object(env, result, "MovingObjectPosition.blockPos");
    const auto vector = Object(env, result, "MovingObjectPosition.hitVec");
    if (!block || !vector) return std::nullopt;
    const auto x = Invoke(env, block, "BlockPos.getX");
    const auto y = Invoke(env, block, "BlockPos.getY");
    const auto z = Invoke(env, block, "BlockPos.getZ");
    if (!x.ok || !y.ok || !z.ok || BlockPos{x.value.i, y.value.i, z.value.i} != placement.support) {
        return std::nullopt;
    }
    const auto hitX = Read<double>(vector, "Vec3.x");
    const auto hitY = Read<double>(vector, "Vec3.y");
    const auto hitZ = Read<double>(vector, "Vec3.z");
    if (!hitX || !hitY || !hitZ) return std::nullopt;
    const auto face = Object(env, result, "MovingObjectPosition.sideHit");
    const auto expected = JavaFace(env, placement.face);
    return Hit{{*hitX, *hitY, *hitZ}, face && expected && env->IsSameObject(face, expected)};
}

}

void Reset(JNIEnv* env) {
    RestoreJumpBinding(env);
    state = {};
    requestedJump = false;
    requestedAxes.reset();
    badPackets = false;
    SetRotation(std::nullopt);
}

jobject BeforeSend(JNIEnv* env, jobject packet) {
    if (!env || !packet || !Options().enabled || env->ExceptionCheck()) return packet;
    if (!Instance(packet, "AuraMovementPacket")) {
        if (Instance(packet, "AuraAttackPacket") || Instance(packet, "AuraClickWindowPacket") ||
            Instance(packet, "AuraClosePacket")) {
            badPackets = true;
        } else if (Instance(packet, "AuraStatusPacket")) {
            const auto status = Object(env, packet, "AuraStatusPacket.status");
            const auto open = StaticObject(env, "ScaffoldClientStatus.openInventory");
            if (status && open && env->IsSameObject(status, open)) badPackets = true;
            if (status) env->DeleteLocalRef(status);
            if (open) env->DeleteLocalRef(open);
        }
        return packet;
    }
    badPackets = false;
    std::optional<std::array<float, 2>> rotation;
    {
        std::lock_guard lock(rotationMutex);
        rotation = std::exchange(pendingRotation, std::nullopt);
    }
    if (!rotation) return packet;

    const auto [yaw, pitch] = *rotation;
    if (Instance(packet, "AuraLookPacket") || Instance(packet, "AuraPositionLookPacket")) {
        Write(packet, "AuraMovementPacket.yaw", yaw);
        Write(packet, "AuraMovementPacket.pitch", pitch);
        return packet;
    }
    const auto ground = Read<bool>(packet, "AuraMovementPacket.onGround");
    const auto moving = Read<bool>(packet, "AuraMovementPacket.moving");
    if (!ground || !moving) return packet;
    Argument groundArg{Type::Boolean};
    groundArg.value.z = *ground;
    jobject replacement = nullptr;
    if (*moving) {
        const auto x = Read<double>(packet, "AuraMovementPacket.x");
        const auto y = Read<double>(packet, "AuraMovementPacket.y");
        const auto z = Read<double>(packet, "AuraMovementPacket.z");
        const auto extra = Read<float>(packet, "AuraMovementPacket.extra");
        if (!x || !y || !z || !extra) return packet;
        replacement = New(env, "AuraPositionLookPacket.constructor",
                          {DoubleArg(*x), DoubleArg(*y), DoubleArg(*z),
                           FloatArg(yaw), FloatArg(pitch), groundArg, FloatArg(*extra)});
    } else {
        replacement = New(env, "AuraLookPacket.constructor", {FloatArg(yaw), FloatArg(pitch), groundArg});
    }
    return replacement ? replacement : packet;
}

native_packets::Action BeforeNativePacket(native_packets::PacketView& packet) {
    using native_packets::Action;
    if(packet.direction!=native_packets::Direction::Outbound||!Options().enabled)return Action::Pass;
    if(packet.packetId!=3&&packet.packetId!=4&&packet.packetId!=5&&packet.packetId!=6){if(packet.packetId==2||packet.packetId==13||packet.packetId==14||packet.packetId==22)badPackets=true;return Action::Pass;}
    badPackets=false;std::optional<std::array<float,2>> rotation;{std::lock_guard lock(rotationMutex);rotation=std::exchange(pendingRotation,std::nullopt);}if(!rotation)return Action::Pass;
    auto putFloat=[&](std::vector<std::uint8_t>& data,std::size_t offset,float value){std::uint32_t raw=0;std::memcpy(&raw,&value,4);data[offset]=static_cast<std::uint8_t>(raw>>24);data[offset+1]=static_cast<std::uint8_t>(raw>>16);data[offset+2]=static_cast<std::uint8_t>(raw>>8);data[offset+3]=static_cast<std::uint8_t>(raw);};
    const auto [yaw,pitch]=*rotation;
    if(packet.packetId==5&&packet.payload.size()>=9){putFloat(packet.payload,0,yaw);putFloat(packet.payload,4,pitch);return Action::Modify;}
    if(packet.packetId==6&&packet.payload.size()>=33){putFloat(packet.payload,24,yaw);putFloat(packet.payload,28,pitch);return Action::Modify;}
    if(packet.packetId==3&&packet.payload.size()>=1){const auto ground=packet.payload.back();packet.packetId=5;packet.mappingKey="Play.Serverbound.PlayerLook";packet.className="net/minecraft/em";packet.payload.assign(9,0);putFloat(packet.payload,0,yaw);putFloat(packet.payload,4,pitch);packet.payload[8]=ground;return Action::Replace;}
    if(packet.packetId==4&&packet.payload.size()>=25){const auto original=packet.payload;packet.packetId=6;packet.mappingKey="Play.Serverbound.PlayerPositionLook";packet.className="net/minecraft/es";packet.payload.assign(33,0);std::copy_n(original.begin(),24,packet.payload.begin());putFloat(packet.payload,24,yaw);putFloat(packet.payload,28,pitch);packet.payload[32]=original.back();return Action::Replace;}
    return Action::Pass;
}

void AfterInput(JNIEnv* env, jobject minecraft, jobject player, jobject world, jobject input) {
    RestoreJumpBinding(env);
    requestedJump = false;
    requestedAxes.reset();
    const auto options = Options();
    if (!options.enabled) {
        Reset();
        return;
    }
    if (ui::input::IsOpen() || Object(env, minecraft, "Minecraft.currentScreen") ||
        Read<bool>(player, "Entity.isDead").value_or(false)) {
        SetRotation(std::nullopt);
        return;
    }
    const auto tick = Read<int>(player, "Entity.ticksExisted");
    if (!tick || *tick == state.lastTick) return;
    state.lastTick = *tick;
    SetRotation(std::nullopt);

    const auto position = Position(player);
    const float yaw = Read<float>(player, "Entity.rotationYaw").value_or(0);
    const float pitch = Read<float>(player, "Entity.rotationPitch").value_or(0);
    if (!state.startY) {
        state.startY = std::floor(position.y);
        state.yaw = yaw - 180;
        AOKI_LOG("[Scaffold] first update mode=%d sameY=%d rayCast=%d pos=(%.3f,%.3f,%.3f)",
                 static_cast<int>(options.mode), static_cast<int>(options.sameY),
                 static_cast<int>(options.rayCast), position.x, position.y, position.z);
    }
    const auto gameSettings = Object(env, minecraft, "Minecraft.gameSettings");
    const auto jumpBinding = Object(env, gameSettings, "GameSettings.keyBindJump");
    const bool jump = Read<bool>(jumpBinding, "KeyBinding.pressed").value_or(false);
    const auto forward = Read<float>(input, "AuraMovementInput.forward").value_or(0);
    const auto strafe = Read<float>(input, "AuraMovementInput.strafe").value_or(0);
    const bool moving = forward != 0 || strafe != 0;
    const auto ground = Invoke(env, player, "Entity.onGround");
    const bool grounded = ground.ok && ground.value.z;
    state.offGroundTicks = grounded ? 0 : state.offGroundTicks + 1;
    const bool telly = options.mode == Mode::Telly;
    const auto phase = TellyAt(state.offGroundTicks, options.sameY);
    const bool autoJump = AutoJump(options.mode, options.sameY, grounded, moving,
                                   position.y, *state.startY);
    const bool sameY = !jump && moving &&
        options.sameY != SameY::Off;
    const auto plane = sameY ? std::optional<int>{static_cast<int>(*state.startY)} : std::nullopt;

    const auto empty = [&](Vec3 point) { return IsReplaceable(env, world, Floor(point)).value_or(false); };
    const bool overAir = empty(position + Vec3{0, -1, 0});
    if (overAir && (!sameY || empty({position.x, *state.startY - 1, position.z}))) ++state.ticksOnAir;
    else state.ticksOnAir = 0;
    bool safeWalkStopped = false;
    if (options.safeWalk && grounded && moving && !autoJump && !jump) {
        const auto mx = Read<double>(player, "Entity.motionX").value_or(0);
        const auto mz = Read<double>(player, "Entity.motionZ").value_or(0);
        if (empty(position + Vec3{mx, -1, mz})) {
            safeWalkStopped = true;
            requestedAxes = std::array{0.f, 0.f};
        }
    }
    if (autoJump) {
        requestedJump = true;
        Write(jumpBinding,"KeyBinding.pressed",true);
        ownedJumpBinding=mapping::Global(env,jumpBinding);
    }
    if (jump && std::fmod(position.y, 1.) > .5) state.startY = std::floor(position.y);
    if (!moving && (grounded || position.y < *state.startY)) state.startY = std::floor(position.y);
    const auto delay = static_cast<int>(options.delayMin + (options.delayMax - options.delayMin) * Sample());
    const bool canPlace = state.ticksOnAir > delay && !badPackets.load();
    if (!telly && !canPlace) {
        Diagnostic(1, badPackets.load() ? "waiting: packet gate" : "waiting: air/place delay");
        return;
    }

    const double radians = yaw * (std::numbers::pi / 180.0) +
        std::atan2(-static_cast<double>(strafe), static_cast<double>(forward));
    Vec3 offset{};
    for (int distance = 0; distance <= static_cast<int>(options.expand) && options.expand > 0; ++distance) {
        if (empty(position + Vec3{-std::sin(radians) * distance, -.5, std::cos(radians) * distance})) {
            offset = {static_cast<double>(static_cast<int>(-std::sin(radians) * (distance + 1))),
                      0, static_cast<double>(static_cast<int>(std::cos(radians) * (distance + 1)))};
            break;
        }
    }
    const auto placement = FindPlacement(env, world, position, offset, plane, state.yaw);
    if (!placement) {
        Diagnostic(1, "no placement target: world lookup or support unavailable");
        return;
    }

    const auto inventory = Object(env, player, "EntityPlayer.inventory");
    const auto originalSlot = Read<int>(inventory, "InventoryPlayer.currentItem");
    int slot = -1;
    const auto stack = FindStack(env, inventory, slot);
    const auto renderer = Object(env, minecraft, "Minecraft.entityRenderer");
    if (!originalSlot || !stack || !renderer) {
        Diagnostic(1, !stack ? "no eligible hotbar block" : "inventory or renderer unavailable");
        return;
    }

    UpdateMouseOver(env, renderer);
    if (telly && phase.rightClick && Write(inventory, "InventoryPlayer.currentItem", slot)) {
        Place(env, minecraft, player, stack, *placement, RayCast::Strict, std::nullopt, {});
        Write(inventory, "InventoryPlayer.currentItem", *originalSlot);
    }

    const auto sample = Vec3{Sample(), Sample(), Sample()};
    const auto point = RandomHit(placement->support, placement->face, {.5, .5, .5});
    const auto eye = Invoke(env, player, "Entity.eyeHeight");
    if (!eye.ok) return;
    const auto dx = point.x - position.x, dz = point.z - position.z;
    const auto dy = point.y - position.y - eye.value.f;
    float targetYaw = telly && !phase.aimAtBlock ? yaw : Angle(std::atan2(dz, dx)) - 90;
    float targetPitch = -Angle(std::atan2(dy, std::hypot(dx, dz)));
    if (telly && phase.aimAtBlock) {
        Write(player, "Entity.rotationYaw", state.yaw);
        Write(player, "Entity.rotationPitch", state.pitch);
        UpdateMouseOver(env, renderer);
        Write(player, "Entity.rotationYaw", yaw);
        Write(player, "Entity.rotationPitch", pitch);
        const auto hit = MouseHit(env, minecraft, *placement);
        if (hit && (options.rayCast != RayCast::Strict || hit->sameFace)) {
            targetYaw = state.yaw;
            targetPitch = state.pitch;
        }
    } else if (!telly) {
        const auto hit = MouseHit(env, minecraft, *placement);
        if (hit && hit->sameFace) {
            targetYaw = state.yaw;
            targetPitch = state.pitch;
        }
    }
    const float speed = 36 * static_cast<float>(options.rotationMin +
        (options.rotationMax - options.rotationMin) * Sample());
    state.yaw += std::clamp(std::remainder(targetYaw - state.yaw, 360.f), -speed, speed);
    state.pitch += std::clamp(targetPitch - state.pitch, -speed, speed);
    if (options.movementCorrection && moving && !safeWalkStopped && speed > 0) {
        const auto correction = (yaw - state.yaw) * (std::numbers::pi / 180.0);
        requestedAxes = std::array{
            static_cast<float>(forward * std::cos(correction) + strafe * std::sin(correction)),
            static_cast<float>(strafe * std::cos(correction) - forward * std::sin(correction))};
    }
    if (speed > 0) {
        SetRotation(std::array{state.yaw, state.pitch});
        Write(player, "Entity.rotationYaw", state.yaw);
        Write(player, "Entity.rotationPitch", state.pitch);
    }
    UpdateMouseOver(env, renderer);
    Write(player, "Entity.rotationYaw", yaw);
    Write(player, "Entity.rotationPitch", pitch);
    const auto hit = MouseHit(env, minecraft, *placement);
    const bool allowed = options.rayCast == RayCast::Off ||
        (hit && (options.rayCast != RayCast::Strict || hit->sameFace));
    if (canPlace && (!telly || phase.allowPlacement) && allowed &&
        Write(inventory, "InventoryPlayer.currentItem", slot)) {
        const bool placed = Place(env, minecraft, player, stack, *placement, options.rayCast,
              hit && hit->sameFace ? std::optional{hit->position} : std::nullopt, sample);
        Diagnostic(1, placed ? "placement call completed" : "placement call failed");
        if (state.lastTick % 20 == 0 || !placed) {
            AOKI_LOG("[Scaffold] place tick=%d slot=%d support=(%d,%d,%d) face=%d rayHit=%d sameFace=%d callOk=%d",
                     state.lastTick, slot, placement->support.x, placement->support.y,
                     placement->support.z, static_cast<int>(placement->face),
                     hit.has_value(), hit && hit->sameFace, placed);
        }
        Write(inventory, "InventoryPlayer.currentItem", *originalSlot);
        state.ticksOnAir = 0;
    } else {
        Diagnostic(1, !canPlace ? "waiting: air/delay/packet gate" :
                   telly && !phase.allowPlacement ? "waiting: Telly takeoff" :
                   !allowed ? "waiting: ray cast gate" : "slot write failed");
    }
    UpdateMouseOver(env, renderer);
}

void ApplyInput(JNIEnv*, jobject input) {
    if (!Options().enabled) return;
    if (requestedJump) Write(input, "AuraMovementInput.jump", true);
    if (requestedAxes) {
        Write(input, "AuraMovementInput.forward", (*requestedAxes)[0]);
        Write(input, "AuraMovementInput.strafe", (*requestedAxes)[1]);
    }
}

}
