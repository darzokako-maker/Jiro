#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <mutex>
#include <algorithm>
namespace client::features::disconnect {
namespace {std::mutex mutex;Settings settings;}
Settings Options(){std::lock_guard lock(mutex);return settings;}
void SetOptions(Settings value){value.health=std::isfinite(value.health)?std::clamp(value.health,1.f,20.f):6.f;bool previous;{std::lock_guard lock(mutex);previous=settings.enabled;settings=value;}modules::StateChanged(modules::AutoDisconnect,previous,value.enabled);}
}
