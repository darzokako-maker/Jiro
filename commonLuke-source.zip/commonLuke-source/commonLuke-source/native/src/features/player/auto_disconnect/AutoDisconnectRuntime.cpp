#include "features/player/auto_disconnect/AutoDisconnect.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "client/PacketBridge.hpp"
#include "ui/hud/Notifications.hpp"
#include <atomic>
#include <limits>
#include <string>
#include <stdexcept>
#include <cstring>
namespace client::features::disconnect {
namespace {
std::atomic<float> receivedHealth{std::numeric_limits<float>::infinity()};
jobject worldRoot=nullptr,playerRoot=nullptr;bool triggered=false,wasEnabled=false;
struct Frame {JNIEnv* env;bool ok;Frame(JNIEnv* e):env(e),ok(e&&e->PushLocalFrame(32)==JNI_OK){}~Frame(){if(ok)env->PopLocalFrame(nullptr);}};
jobject Object(JNIEnv* env,jobject object,const char* key){const auto value=mapping::Object(env,object,key);if(!value)throw std::runtime_error(key);return value;}
float Health(JNIEnv* env,jobject player,const char* key){auto result=mapping::Invoke(env,player,key);if(!result.ok)throw std::runtime_error(std::string(key)+": "+result.error);const auto value=result.value.f;result.Release(env);return value;}
methods::Argument Obj(jobject value){methods::Argument arg{methods::Type::Object};arg.value.l=value;return arg;}
bool SendIllegal(JNIEnv* env,jobject player){
 const auto queue=Object(env,player,"DisconnectPlayer.sendQueue");if(!queue)return false;
 const auto message=env->NewString(IllegalMessage.data(),static_cast<jsize>(IllegalMessage.size()));if(!message||env->ExceptionCheck())return false;
 const auto packet=mapping::New(env,"DisconnectChatPacket.constructor",{Obj(message)});if(!packet||env->ExceptionCheck())return false;
 auto result=mapping::Invoke(env,queue,"DisconnectNet.send",{Obj(packet)});const bool sent=result.ok&&!env->ExceptionCheck();result.Release(env);return sent;
}
}
void Stop(JNIEnv* env){if(!env)return;for(auto* root:{&worldRoot,&playerRoot})mapping::ReleaseGlobal(env,*root);triggered=wasEnabled=false;receivedHealth=std::numeric_limits<float>::infinity();}
void Poll(JNIEnv* env){
 if(!env||env->ExceptionCheck())return;Frame frame(env);if(!frame.ok)return;
 const auto s=Options();if(!s.enabled){if(wasEnabled||worldRoot)Stop(env);return;}
 const bool enabling=!wasEnabled;wasEnabled=true;
 try{
  const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft");if(!mc)return;
  const auto player=Object(env,mc,"Minecraft.thePlayer"),world=Object(env,mc,"Minecraft.theWorld");if(!player||!world){if(worldRoot)Stop(env);return;}
  if(!worldRoot||!env->IsSameObject(world,worldRoot)||!env->IsSameObject(player,playerRoot)){
   if(worldRoot)Stop(env);worldRoot=mapping::Global(env,world);playerRoot=mapping::Global(env,player);wasEnabled=true;triggered=false;
   receivedHealth=std::numeric_limits<float>::infinity();
  }
  const auto health=Health(env,player,"EntityLivingBase.getHealth"),absorption=Health(env,player,"DisconnectLiving.absorption");
  const auto packetHealth=receivedHealth.exchange(std::numeric_limits<float>::infinity());
  const bool low=Below(s,health,absorption);if(!low)triggered=false;
  const bool manual=!s.lowHealth&&enabling;
  if(!manual&&(!s.lowHealth||triggered||(!low&&!Below(s,packetHealth,absorption))))return;
  triggered=true;const bool sent=SendIllegal(env,player);
  AOKI_LOG("[AutoDisconnect] Illegal Characters sent=%d hp=%.2f absorption=%.2f threshold=%.0f manual=%d",int(sent),health,absorption,s.health,int(manual));
  ui::notifications::State().Push(sent?ui::notifications::Type::Info:ui::notifications::Type::Disabled,"AutoDisconnect",sent?"Disconnecting...":"Illegal Characters packet failed");
  if(!sent)throw std::runtime_error("Illegal Characters packet submission failed");
  if(manual){auto value=s;value.enabled=false;SetOptions(value);}
 }catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[AutoDisconnect] disabled: %s",e.what());auto value=s;value.enabled=false;SetOptions(value);Stop(env);}
}
bool BeforeReceive(JNIEnv* env,jobject packet){
 const auto s=Options();if(!s.enabled||!s.lowHealth||!env||!packet||env->ExceptionCheck()||!mapping::Instance(packet,"DisconnectHealthPacket"))return true;
 Frame frame(env);if(!frame.ok)return true;
 try{const auto field=mapping::Read<float>(packet,"DisconnectHealthPacket.health");if(!field)throw std::runtime_error("health packet read");const auto value=*field;if(std::isfinite(value)){auto previous=receivedHealth.load();while(value<previous&&!receivedHealth.compare_exchange_weak(previous,value)){} }}
 catch(const std::exception& e){if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[AutoDisconnect] health observation error: %s",e.what());}
 return true;
}
native_packets::Action BeforeNativePacket(native_packets::PacketView& packet){
 const auto s=Options();if(!s.enabled||!s.lowHealth||packet.direction!=native_packets::Direction::Inbound||packet.mappingKey!="Play.Clientbound.UpdateHealth"||packet.payload.size()<4)return native_packets::Action::Pass;
 const std::uint32_t raw=(static_cast<std::uint32_t>(packet.payload[0])<<24)|(static_cast<std::uint32_t>(packet.payload[1])<<16)|(static_cast<std::uint32_t>(packet.payload[2])<<8)|packet.payload[3];float value=0;std::memcpy(&value,&raw,sizeof(value));
 if(std::isfinite(value)){auto previous=receivedHealth.load();while(value<previous&&!receivedHealth.compare_exchange_weak(previous,value)){}}
 return native_packets::Action::Pass;
}
}
