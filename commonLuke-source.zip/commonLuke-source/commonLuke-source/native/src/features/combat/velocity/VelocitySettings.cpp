#include "features/combat/velocity/Velocity.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <algorithm>
#include <cmath>
#include <mutex>
#include <atomic>

namespace client::features::velocity {
namespace {
std::mutex settingsMutex;
Settings options;
std::atomic<std::uint64_t> modified{0}, cancelled{0}, explosions{0}, failed{0};
}
Stats Status() { return {modified.load(), cancelled.load(), explosions.load(), failed.load()}; }
void detail::Record(Outcome outcome) {
    switch (outcome) {
    case Outcome::Modified: ++modified; break;
    case Outcome::Cancelled: ++cancelled; break;
    case Outcome::Explosion: ++explosions; ++modified; break;
    case Outcome::Failed: ++failed; break;
    }
}
Settings Options() { std::lock_guard lock(settingsMutex); return options; }
void SetOptions(Settings settings) {
    auto percent = [](float value, float fallback) {
        return std::isfinite(value) ? std::clamp(value, 0.f, 100.f) : fallback;
    };
    settings.horizontal = percent(settings.horizontal, 0.f);
    settings.vertical = percent(settings.vertical, 0.f);
    settings.chance = percent(settings.chance, 40.f);
    settings.ticks = std::isfinite(settings.ticks) ? std::clamp(std::round(settings.ticks), 0.f, 10.f) : 1.f;
    bool previous;
    {
        std::lock_guard lock(settingsMutex);
        previous = options.enabled;
        options = settings;
    }
    if (previous && !settings.enabled) detail::ResetPending();
    modules::StateChanged(modules::Velocity, previous, settings.enabled);
}
}
