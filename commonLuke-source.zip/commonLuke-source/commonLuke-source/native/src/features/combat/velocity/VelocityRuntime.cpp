#include "features/combat/velocity/Velocity.hpp"
#include "features/combat/velocity/VelocityRules.hpp"
#include "game/MappingRepository.hpp"
#include <array>
#include <atomic>
#include <cmath>
#include <mutex>
#include <random>
#include <string>
#include <cstring>

namespace client::features::velocity {
namespace {
struct Frame {
    JNIEnv* env;
    bool valid;
    explicit Frame(JNIEnv* value, int capacity = 32)
        : env(value), valid(env && env->PushLocalFrame(capacity) == JNI_OK) {}
    ~Frame() { if (valid) env->PopLocalFrame(nullptr); }
};
struct PendingVelocity {
    bool active = false;
    int ticksRemaining = 0;
    double x = 0, y = 0, z = 0;
};

std::mutex runtimeMutex;
PendingVelocity pending;
int lastTick = -1;
std::mt19937 random{std::random_device{}()};
std::atomic<bool> inWater{false}, targeting{false};
std::atomic<int> localEntityId{-1};

bool ReadVarInt(const std::vector<std::uint8_t>& bytes, std::size_t& offset, int& value) {
    std::uint32_t result=0;
    for(unsigned i=0;i<5;++i){if(offset>=bytes.size())return false;const auto byte=bytes[offset++];result|=static_cast<std::uint32_t>(byte&0x7f)<<(i*7);if(!(byte&0x80)){value=static_cast<int>(result);return true;}}
    return false;
}
std::int16_t ReadShort(const std::vector<std::uint8_t>& bytes,std::size_t offset){return static_cast<std::int16_t>((static_cast<unsigned>(bytes[offset])<<8)|bytes[offset+1]);}
void WriteShort(std::vector<std::uint8_t>& bytes,std::size_t offset,std::int16_t value){const auto raw=static_cast<std::uint16_t>(value);bytes[offset]=static_cast<std::uint8_t>(raw>>8);bytes[offset+1]=static_cast<std::uint8_t>(raw);}
std::uint32_t ReadU32(const std::vector<std::uint8_t>& bytes,std::size_t offset){return (static_cast<std::uint32_t>(bytes[offset])<<24)|(static_cast<std::uint32_t>(bytes[offset+1])<<16)|(static_cast<std::uint32_t>(bytes[offset+2])<<8)|bytes[offset+3];}
float ReadFloat(const std::vector<std::uint8_t>& bytes,std::size_t offset){const auto raw=ReadU32(bytes,offset);float value=0;std::memcpy(&value,&raw,sizeof(value));return value;}
void WriteFloat(std::vector<std::uint8_t>& bytes,std::size_t offset,float value){std::uint32_t raw=0;std::memcpy(&raw,&value,sizeof(raw));bytes[offset]=static_cast<std::uint8_t>(raw>>24);bytes[offset+1]=static_cast<std::uint8_t>(raw>>16);bytes[offset+2]=static_cast<std::uint8_t>(raw>>8);bytes[offset+3]=static_cast<std::uint8_t>(raw);}

bool Failure(JNIEnv* env) {
    detail::Record(detail::Outcome::Failed);
    if (env->ExceptionCheck()) env->ExceptionClear();
    return true;
}
bool Chance(float chance) {
    std::lock_guard lock(runtimeMutex);
    return rules::ChanceSucceeds(chance, std::uniform_int_distribution<int>(0, 99)(random));
}
rules::Percents Percents(const Settings& settings) {
    std::lock_guard lock(runtimeMutex);
    return rules::ReducedPercents(settings.horizontal, settings.vertical,
        std::generate_canonical<double, 53>(random));
}
void Queue(double x, double y, double z, int ticks) {
    std::lock_guard lock(runtimeMutex);
    pending = {true, ticks, x, y, z};
}
bool Water(JNIEnv* env, jobject player) {
    if (!player) return false;
    auto result=mapping::Invoke(env,player,"Entity.isInWater");
    const bool value=result.ok&&result.value.z!=0;
    result.Release(env);return value;
}
bool HasTarget(JNIEnv* env, jobject mc, jobject player) {
    const auto hit = mapping::Object(env, mc, "Minecraft.objectMouseOver");
    const auto target = hit ? mapping::Object(env, hit, "MovingObjectPosition.entityHit") : nullptr;
    return target && !env->IsSameObject(target, player) && mapping::Instance(target, "EntityLivingBase");
}
}

void detail::ResetPending() {
    std::lock_guard lock(runtimeMutex);
    pending = {};
}

bool BeforeReceive(JNIEnv* env, jobject packet) {
    const auto settings = Options();
    if (!settings.enabled || !env || !packet || env->ExceptionCheck()) return true;
    const bool velocity = mapping::Instance(packet, "VelocityPacket");
    const bool explosion = !velocity && settings.explosions && mapping::Instance(packet, "ExplosionPacket");
    if (!velocity && !explosion) return true;
    Frame frame(env);
    if (!frame.valid) return Failure(env);
    const auto mc = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto player = mapping::Object(env, mc, "Minecraft.thePlayer");
    const auto world = mapping::Object(env, mc, "Minecraft.theWorld");
    if (env->ExceptionCheck()) return Failure(env);
    if (!player || !world) return true;
    if (velocity) {
        const auto localId = mapping::Read<int>(player, "Entity.entityId");
        const auto packetId = mapping::Read<int>(packet, "VelocityPacket.entityId");
        if (!localId || !packetId) return Failure(env);
        if (*localId != *packetId) return true;
    }
    if (settings.waterCheck && Water(env, player)) return true;
    if (env->ExceptionCheck()) return Failure(env);
    if ((settings.onlyWhenTargeting && !targeting.load()) || !Chance(settings.chance)) return true;
    if (settings.horizontal == 100.f && settings.vertical == 100.f) return true;

    constexpr const char* velocityFields[]={"VelocityPacket.motionX","VelocityPacket.motionY","VelocityPacket.motionZ"};
    constexpr const char* explosionFields[]={"ExplosionPacket.motionX","ExplosionPacket.motionY","ExplosionPacket.motionZ"};
    if (velocity) {
        std::array<jint, 3> values{};
        for (std::size_t i=0;i<values.size();++i){const auto value=mapping::Read<int>(packet,velocityFields[i]);if(!value)return Failure(env);values[i]=*value;}
        if (settings.ticks > 0.f) {
            Queue(values[0] / 8000.0, values[1] / 8000.0, values[2] / 8000.0,
                static_cast<int>(settings.ticks));
            return true;
        }
        const auto reduced = Percents(settings);
        if (reduced.horizontal == 0.f && reduced.vertical == 0.f) {
            detail::Record(detail::Outcome::Cancelled);
            return false;
        }
        const std::array<float, 3> factors{reduced.horizontal / 100.f, reduced.vertical / 100.f, reduced.horizontal / 100.f};
        for (std::size_t i=0;i<values.size();++i)
            if(!mapping::Write(packet,velocityFields[i],static_cast<jint>(static_cast<double>(values[i])*factors[i])))return Failure(env);
        detail::Record(detail::Outcome::Modified);
    } else {
        std::array<jfloat, 3> values{};
        for (std::size_t i=0;i<values.size();++i){const auto value=mapping::Read<float>(packet,explosionFields[i]);if(!value)return Failure(env);values[i]=*value;}
        if (settings.ticks > 0.f) {
            if (std::abs(values[0]) >= .005f || std::abs(values[1]) >= .005f || std::abs(values[2]) >= .005f)
                Queue(values[0], values[1], values[2], static_cast<int>(settings.ticks));
            return true;
        }
        const auto reduced = Percents(settings);
        const std::array<float, 3> factors{reduced.horizontal / 100.f, reduced.vertical / 100.f, reduced.horizontal / 100.f};
        for (std::size_t i=0;i<values.size();++i)if(!mapping::Write(packet,explosionFields[i],values[i]*factors[i]))return Failure(env);
        detail::Record(detail::Outcome::Explosion);
    }
    if (env->ExceptionCheck()) return Failure(env);
    return true;
}

native_packets::Action BeforeNativePacket(native_packets::PacketView& packet) {
    using native_packets::Action;
    if(packet.direction!=native_packets::Direction::Inbound)return Action::Pass;
    const auto settings=Options();
    if(!settings.enabled)return Action::Pass;
    const bool velocity=packet.mappingKey=="Play.Clientbound.Velocity";
    const bool explosion=settings.explosions&&packet.mappingKey=="Play.Clientbound.Explosion";
    if(!velocity&&!explosion)return Action::Pass;
    if(settings.waterCheck&&inWater.load())return Action::Pass;
    if(settings.onlyWhenTargeting&&!targeting.load())return Action::Pass;
    if(!Chance(settings.chance))return Action::Pass;
    if(settings.horizontal==100.f&&settings.vertical==100.f)return Action::Pass;

    const auto reduced=Percents(settings);
    if(velocity){
        std::size_t offset=0;int entityId=-1;
        if(!ReadVarInt(packet.payload,offset,entityId)||entityId!=localEntityId.load()||offset+6>packet.payload.size())return Action::Pass;
        std::array<std::int16_t,3> values{ReadShort(packet.payload,offset),ReadShort(packet.payload,offset+2),ReadShort(packet.payload,offset+4)};
        if(settings.ticks>0.f){Queue(values[0]/8000.0,values[1]/8000.0,values[2]/8000.0,static_cast<int>(settings.ticks));return Action::Pass;}
        if(reduced.horizontal==0.f&&reduced.vertical==0.f){detail::Record(detail::Outcome::Cancelled);return Action::Cancel;}
        const std::array<float,3> factors{reduced.horizontal/100.f,reduced.vertical/100.f,reduced.horizontal/100.f};
        for(std::size_t i=0;i<3;++i)WriteShort(packet.payload,offset+i*2,static_cast<std::int16_t>(static_cast<double>(values[i])*factors[i]));
        detail::Record(detail::Outcome::Modified);return Action::Modify;
    }

    if(packet.payload.size()<32)return Action::Pass;
    const auto count=ReadU32(packet.payload,16);
    const std::size_t motionOffset=20+static_cast<std::size_t>(count)*3;
    if(count>0x100000||motionOffset+12>packet.payload.size())return Action::Pass;
    std::array<float,3> values{ReadFloat(packet.payload,motionOffset),ReadFloat(packet.payload,motionOffset+4),ReadFloat(packet.payload,motionOffset+8)};
    if(settings.ticks>0.f){if(std::abs(values[0])>=.005f||std::abs(values[1])>=.005f||std::abs(values[2])>=.005f)Queue(values[0],values[1],values[2],static_cast<int>(settings.ticks));return Action::Pass;}
    const std::array<float,3> factors{reduced.horizontal/100.f,reduced.vertical/100.f,reduced.horizontal/100.f};
    for(std::size_t i=0;i<3;++i)WriteFloat(packet.payload,motionOffset+i*4,values[i]*factors[i]);
    detail::Record(detail::Outcome::Explosion);return Action::Modify;
}

void Poll(JNIEnv* env) {
    const auto settings = Options();
    if (!settings.enabled || !env || env->ExceptionCheck()) {
        inWater.store(false); targeting.store(false); localEntityId.store(-1); detail::ResetPending(); return;
    }
    Frame frame(env);
    if (!frame.valid) return;
    const auto mc = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto player = mapping::Object(env, mc, "Minecraft.thePlayer");
    const auto world = mapping::Object(env, mc, "Minecraft.theWorld");
    if (!player || !world || env->ExceptionCheck()) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        inWater.store(false); targeting.store(false); localEntityId.store(-1); detail::ResetPending(); return;
    }
    localEntityId.store(mapping::Read<int>(player,"Entity.entityId").value_or(-1));
    const bool water = Water(env, player);
    if (env->ExceptionCheck()) env->ExceptionClear();
    inWater.store(water);
    targeting.store(HasTarget(env, mc, player));
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (settings.waterCheck && water) { detail::ResetPending(); return; }

    const auto tick = mapping::Read<int>(player, "Entity.ticksExisted");
    if (!tick) return;
    PendingVelocity release;
    {
        std::lock_guard lock(runtimeMutex);
        if (*tick == lastTick) return;
        lastTick = *tick;
        if (pending.active) {
            if (pending.ticksRemaining <= 0) { release = pending; pending = {}; }
            else --pending.ticksRemaining;
        }
    }
    if (!release.active) return;
    const auto x = mapping::Read<double>(player, "Entity.motionX");
    const auto y = mapping::Read<double>(player, "Entity.motionY");
    const auto z = mapping::Read<double>(player, "Entity.motionZ");
    if (!x || !y || !z) { detail::Record(detail::Outcome::Failed); return; }
    const auto reduced = Percents(settings);
    const bool wroteX = mapping::Write(player, "Entity.motionX", *x * reduced.horizontal / 100.0);
    const bool wroteZ = mapping::Write(player, "Entity.motionZ", *z * reduced.horizontal / 100.0);
    const bool wroteY = release.y == 0.0 || *y <= 0.0 ||
        mapping::Write(player, "Entity.motionY", *y * reduced.vertical / 100.0);
    detail::Record(wroteX && wroteY && wroteZ ? detail::Outcome::Modified : detail::Outcome::Failed);
}
}
