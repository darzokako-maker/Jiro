#include "features/combat/auto_harm/AutoHarm.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <algorithm>
#include <atomic>
#include <cmath>

namespace client::features::autoharm {
namespace {
Settings options;
std::atomic<std::uint64_t> revision{1};
}

const Settings& Options() { return options; }

void SetOptions(Settings settings) {
    if(!std::isfinite(settings.targetMaxHealth)) settings.targetMaxHealth = 18.f;
    if(!std::isfinite(settings.minSafeDistance)) settings.minSafeDistance = 4.25f;
    if(!std::isfinite(settings.maxDistance)) settings.maxDistance = 6.5f;
    if(!std::isfinite(settings.delayMin)) settings.delayMin = 600.f;
    if(!std::isfinite(settings.delayMax)) settings.delayMax = 950.f;
    if(!std::isfinite(settings.rotationSpeedMin)) settings.rotationSpeedMin = 8.f;
    if(!std::isfinite(settings.rotationSpeedMax)) settings.rotationSpeedMax = 10.f;
    if(!std::isfinite(settings.refillSlot)) settings.refillSlot = 8.f;
    settings.targetMaxHealth = std::clamp(settings.targetMaxHealth, 1.f, 20.f);
    settings.minSafeDistance = std::clamp(settings.minSafeDistance, 3.8f, 6.f);
    settings.maxDistance = std::clamp(settings.maxDistance, 4.3f, 8.5f);
    settings.delayMin = std::clamp(settings.delayMin, 200.f, 2500.f);
    settings.delayMax = std::clamp(settings.delayMax, 200.f, 2500.f);
    settings.rotationSpeedMin = std::clamp(settings.rotationSpeedMin, 2.f, 10.f);
    settings.rotationSpeedMax = std::clamp(settings.rotationSpeedMax, 2.f, 10.f);
    settings.refillSlot = std::clamp(settings.refillSlot, 1.f, 9.f);
    const bool previous = options.enabled;
    options = settings;
    ++revision;
    modules::StateChanged(modules::AutoHarm, previous, options.enabled);
}

std::uint64_t Revision() { return revision.load(); }

} // namespace client::features::autoharm

