#include "features/combat/kill_aura/KillAura.hpp"
#include "features/core/ModuleRegistry.hpp"
#include "features/visual/esp/Esp.hpp"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <mutex>
namespace client::features::aura {
namespace {Settings options;std::atomic<std::uint64_t> revision{1};std::mutex statusMutex;Stats stats;std::atomic<int> target{-1};std::atomic<void(*)(bool)> attackGate{nullptr};}
void SetAttackGate(void (*gate)(bool)){attackGate=gate;}
const Settings& Options(){return options;}
void SetOptions(Settings settings){
    auto number=[](float x,float lo,float hi,float fallback){return std::isfinite(x)?std::clamp(x,lo,hi):fallback;};
    settings.range=number(settings.range,3,6,6);
    settings.criticalDelay=number(settings.criticalDelay,0,1000,500);
    settings.cpsMin=number(settings.cpsMin,1,20,10);settings.cpsMax=number(settings.cpsMax,1,20,15);
    settings.rotationMin=number(settings.rotationMin,0,10,5);settings.rotationMax=number(settings.rotationMax,0,10,10);
    settings.switchMin=number(settings.switchMin,0,10,0);settings.switchMax=number(settings.switchMax,0,10,0);
    settings.slowSwingSpeed=number(settings.slowSwingSpeed,6,30,15);
    const bool old=options.enabled;if(old&&!settings.enabled)if(const auto gate=attackGate.load())gate(false);
    options=std::move(settings);++revision;
    modules::StateChanged(modules::KillAura,old,options.enabled);
}
std::uint64_t Revision(){return revision.load();}
Stats Status(){std::lock_guard lock(statusMutex);return stats;}
void Publish(Stats value){std::lock_guard lock(statusMutex);stats=std::move(value);}
void SetTarget(int id){target=id;}
int Target(){return target.load();}
}
