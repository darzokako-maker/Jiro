#include "features/combat/aim_assist/AimAssist.hpp"

#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "features/combat/common/AttackTargetManager.hpp"
#include "features/combat/kill_aura/KillAura.hpp"
#include "game/MappingRepository.hpp"
#include "ui/clickgui/InputBridge.hpp"

#include <Windows.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace client::features::aimassist {
namespace {
using Clock=std::chrono::steady_clock;
using methods::Argument;
using methods::Type;

struct Vec3 { double x=0,y=0,z=0; };
struct Box { double minX=0,minY=0,minZ=0,maxX=0,maxY=0,maxZ=0; };
struct Candidate {
 jobject object=nullptr;
 int id=0;
 Vec3 position,motion;
 Box box;
 float health=0;
 bool player=false;
};
struct LocalFrame {
 JNIEnv* env=nullptr;bool ok=false;
 explicit LocalFrame(JNIEnv* value,int capacity=4096):env(value),ok(env&&env->PushLocalFrame(capacity)==JNI_OK){}
 ~LocalFrame(){if(ok)env->PopLocalFrame(nullptr);}
};
struct AdaptiveState {
 bool initialized=false,aimPointInitialized=false;
 Vec3 aim{},lead{};
 float aimStrength=0,yawBias=0,pitchBias=0,yawVelocity=0,pitchVelocity=0,yawAccel=0,pitchAccel=0;
 float lastYawError=0,lastPitchError=0,lastTargetYaw=0,lastTargetPitch=0,lastPlayerYaw=0,lastPlayerPitch=0;
 float pendingYaw=0,pendingPitch=0,airFactor=0,verticalVelocity=0;
 double lastEyeY=0,lastGroundEyeY=0;
 Clock::time_point noiseStart=Clock::now();
 void Reset(){*this={};noiseStart=Clock::now();}
};
struct SimpleState {float pendingYaw=0,pendingPitch=0;void Reset(){*this={};}};

jobject targetRoot=nullptr;
Clock::time_point lastFrame{};
std::uint64_t nextAcquire=0,blockBreakUntil=0;
client::scheduler::Cursor frameCursor;
AdaptiveState adaptive;
SimpleState simple;
Mode activeMode=Mode::Adaptive;
Settings activeSettings{};
bool settingsKnown=false;

template<class T>T Value(jobject object,const char* key) {
 const auto value=mapping::Read<T>(object,key);
 if(!value)throw std::runtime_error(std::string("missing field ")+key);
 return *value;
}
Argument Obj(jobject value){Argument argument{Type::Object};argument.value.l=value;return argument;}
Argument Float(float value){Argument argument{Type::Float};argument.value.f=value;return argument;}
Argument Int(int value){Argument argument{Type::Int};argument.value.i=value;return argument;}

methods::Result Invoke(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={}) {
 auto result=mapping::Invoke(env,receiver,key,args);
 if(!result.ok)throw std::runtime_error(std::string(key)+": "+result.error);
 if(env->ExceptionCheck())throw std::runtime_error(std::string("JNI exception in ")+key);
 return result;
}
float CallFloat(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={}) {
 auto result=Invoke(env,receiver,key,args);const float value=result.value.f;result.Release(env);return value;
}
bool CallBool(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={}) {
 auto result=Invoke(env,receiver,key,args);const bool value=result.value.z!=0;result.Release(env);return value;
}
jobject CallObject(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={}) {
 auto result=Invoke(env,receiver,key,args);jobject value=result.value.l?env->NewLocalRef(result.value.l):nullptr;result.Release(env);return value;
}
void CallVoid(JNIEnv* env,jobject receiver,const char* key,const std::vector<Argument>& args={}) {
 auto result=Invoke(env,receiver,key,args);result.Release(env);
}

float Wrap(float value){while(value<=-180.f)value+=360.f;while(value>180.f)value-=360.f;return value;}
float SmoothStep(float low,float high,float value){const float x=std::clamp((value-low)/(high-low),0.f,1.f);return x*x*(3.f-2.f*x);}
float Lerp(float amount,float low,float high){return low+amount*(high-low);}
double Distance(Vec3 a,Vec3 b){return std::sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));}
Vec3 Position(jobject object){return {Value<double>(object,"Entity.posX"),Value<double>(object,"Entity.posY"),Value<double>(object,"Entity.posZ")};}
Vec3 Motion(jobject object){return {Value<double>(object,"Entity.motionX"),Value<double>(object,"Entity.motionY"),Value<double>(object,"Entity.motionZ")};}
Box Bounds(JNIEnv* env,jobject object){const auto box=mapping::Object(env,object,"Entity.boundingBox");if(!box)throw std::runtime_error("missing entity bounds");return {Value<double>(box,"AxisAlignedBB.minX"),Value<double>(box,"AxisAlignedBB.minY"),Value<double>(box,"AxisAlignedBB.minZ"),Value<double>(box,"AxisAlignedBB.maxX"),Value<double>(box,"AxisAlignedBB.maxY"),Value<double>(box,"AxisAlignedBB.maxZ")};}
Vec3 Eye(JNIEnv* env,jobject player){auto result=Position(player);auto height=Invoke(env,player,"Entity.eyeHeight");result.y+=height.value.f;height.Release(env);return result;}
std::array<float,2> Aim(Vec3 from,Vec3 to){const double x=to.x-from.x,z=to.z-from.z,y=to.y-from.y,h=std::hypot(x,z);return {static_cast<float>(std::atan2(z,x)*180.0/3.14159265358979323846-90.0),static_cast<float>(-std::atan2(y,std::max(h,1e-4))*180.0/3.14159265358979323846)};}

bool Named(std::string_view list,std::string_view name) {
 for(std::size_t start=0;start<list.size();) {
  const auto end=list.find(',',start);auto token=list.substr(start,end==std::string_view::npos?list.size()-start:end-start);
  while(!token.empty()&&std::isspace(static_cast<unsigned char>(token.front())))token.remove_prefix(1);
  while(!token.empty()&&std::isspace(static_cast<unsigned char>(token.back())))token.remove_suffix(1);
  if(token.size()==name.size()&&_strnicmp(token.data(),name.data(),token.size())==0)return true;
  if(end==std::string_view::npos)break;start=end+1;
 }
 return false;
}
bool AttackDown(JNIEnv* env,jobject mc){const auto game=mapping::Object(env,mc,"Minecraft.gameSettings"),key=mapping::Object(env,game,"GameSettings.keyBindAttack");return key&&Value<bool>(key,"KeyBinding.pressed");}
bool AllowedItem(JNIEnv* env,jobject player,const Settings& settings) {
 if(!settings.limitItems)return true;
 const auto held=CallObject(env,player,"EntityLivingBase.getHeldItem");
 const auto item=held?mapping::Object(env,held,"ItemStack.item"):nullptr;
 return item&&mapping::Instance(item,"ItemSword");
}
bool IsBlockHit(JNIEnv* env,jobject mc) {
 const auto hit=mapping::Object(env,mc,"Minecraft.objectMouseOver");
 if(!hit)return false;
 return !mapping::Object(env,hit,"MovingObjectPosition.entityHit")&&mapping::Object(env,hit,"MovingObjectPosition.blockPos");
}
bool TargetType(jobject entity,const Settings& settings,bool& isPlayer) {
 isPlayer=mapping::Instance(entity,"EntityPlayer");
 if(isPlayer)return settings.players;
 if(mapping::Instance(entity,"EntityAnimal")||mapping::Instance(entity,"AuraAmbient")||mapping::Instance(entity,"AuraWaterMob"))return settings.animals;
 if(mapping::Instance(entity,"AuraHostile")||mapping::Instance(entity,"AuraNpc"))return settings.mobs;
 return false;
}
bool Teammate(JNIEnv* env,jobject player,jobject entity) {
 const auto one=CallObject(env,player,"EntityLivingBase.getTeam"),two=CallObject(env,entity,"EntityLivingBase.getTeam");
 return one&&two&&env->IsSameObject(one,two);
}
bool BaseValid(JNIEnv* env,jobject player,jobject entity,const Settings& settings,Candidate* output=nullptr) {
 if(!entity||env->IsSameObject(player,entity)||!mapping::Instance(entity,"EntityLivingBase")||mapping::Instance(entity,"AuraArmorStand"))return false;
 bool isPlayer=false;if(!TargetType(entity,settings,isPlayer))return false;
 if(Value<bool>(entity,"Entity.isDead")||CallFloat(env,entity,"EntityLivingBase.getHealth")<=0)return false;
 if(!settings.invisibles&&CallBool(env,entity,"Entity.isInvisible"))return false;
 if(isPlayer&&combat::targets::IsNpcPlayer(env,entity))return false;
 const auto riding=mapping::Object(env,player,"Entity.ridingEntity");if(riding&&env->IsSameObject(riding,entity))return false;
 const auto playerPos=Position(player),position=Position(entity);if(Distance(playerPos,position)>=static_cast<int>(settings.distance))return false;
 const auto eye=Eye(env,player);
 const auto box=Bounds(env,entity);
 const auto angle=Aim(eye,{position.x,box.minY+(box.maxY-box.minY)*.65,position.z});
 const float yaw=Wrap(angle[0]-Value<float>(player,"Entity.rotationYaw")),pitch=angle[1]-Value<float>(player,"Entity.rotationPitch");
 if(std::hypot(yaw,pitch)>settings.maxAngle*.5f)return false;
 if(isPlayer){const auto name=mapping::String(env,entity,"Entity.getName");const auto filters=aura::Options();if(name&&(Named(filters.friends,*name)||Named(filters.bots,*name)))return false;if(!settings.teammates&&Teammate(env,player,entity))return false;}
 if(settings.visibleOnly&&!CallBool(env,player,"EntityLivingBase.canEntityBeSeen",{Obj(entity)}))return false;
 if(output)*output={entity,Value<int>(entity,"Entity.entityId"),position,Motion(entity),box,CallFloat(env,entity,"EntityLivingBase.getHealth"),isPlayer};
 return true;
}
bool FastValid(JNIEnv* env,jobject player,jobject entity,const Settings& settings,Candidate& output) {
 if(!entity||Value<bool>(entity,"Entity.isDead"))return false;
 const float health=CallFloat(env,entity,"EntityLivingBase.getHealth");if(health<=0)return false;
 const auto playerPosition=Position(player),position=Position(entity);if(Distance(playerPosition,position)>=static_cast<int>(settings.distance))return false;
 const auto box=Bounds(env,entity);
 const auto angle=Aim(Eye(env,player),{position.x,box.minY+(box.maxY-box.minY)*.65,position.z});
 if(std::hypot(Wrap(angle[0]-Value<float>(player,"Entity.rotationYaw")),angle[1]-Value<float>(player,"Entity.rotationPitch"))>settings.maxAngle*.5f)return false;
 output={entity,Value<int>(entity,"Entity.entityId"),position,Motion(entity),box,health,mapping::Instance(entity,"EntityPlayer")};return true;
}
float ArmorScore(JNIEnv* env,jobject entity) {
 float equipped=0;for(int slot=1;slot<=4;++slot)if(CallObject(env,entity,"EntityLivingBase.getArmor",{Int(slot)}))equipped+=1.f;return equipped;
}
double Score(JNIEnv* env,jobject player,const Candidate& target,const Settings& settings) {
 const auto eye=Eye(env,player),point=Vec3{target.position.x,target.box.minY+(target.box.maxY-target.box.minY)*.65,target.position.z};const auto angle=Aim(eye,point);
 const double yaw=std::abs(Wrap(angle[0]-Value<float>(player,"Entity.rotationYaw"))),distance=Distance(Position(player),target.position);
 switch(settings.targetMode){
  case TargetMode::Distance:return distance;
  case TargetMode::Health:return target.health;
  case TargetMode::Armor:return target.player?-ArmorScore(env,target.object)*100.+distance:distance;
  case TargetMode::Threat:return target.player?ArmorScore(env,target.object)*-50.+distance+yaw*.02:distance;
  default:return yaw+distance*.01;
 }
}
void DropTarget(JNIEnv* env) {
 if(targetRoot&&env)mapping::ReleaseGlobal(env,targetRoot);targetRoot=nullptr;adaptive.Reset();simple.Reset();nextAcquire=0;
}
void Acquire(JNIEnv* env,jobject world,jobject player,const Settings& settings) {
 const auto list=mapping::Object(env,world,"World.loadedEntityList");
 const auto elements=list?static_cast<jobjectArray>(mapping::Object(env,list,"ArrayList.elements")):nullptr;
 if(!elements)return;
 const int count=std::min({Value<int>(list,"ArrayList.size"),env->GetArrayLength(elements),2048});
 jobject best=nullptr;double bestScore=std::numeric_limits<double>::max();
 for(int i=0;i<count;++i){const auto entity=env->GetObjectArrayElement(elements,i);Candidate candidate;if(!BaseValid(env,player,entity,settings,&candidate))continue;const double score=Score(env,player,candidate,settings);if(score<bestScore){bestScore=score;best=entity;}}
 if(best){targetRoot=mapping::Global(env,best);adaptive.Reset();simple.Reset();}
 nextAcquire=client::scheduler::Now()+(settings.requireMouseDown?50u:700u);
}
Vec3 ResolvePoint(Vec3 eye,const Candidate& target,const Settings& settings) {
 const double height=target.box.maxY-target.box.minY,centerY=target.box.minY+height*.65;
 double airborne=adaptive.airFactor,eyeOffset=.1+std::min(.85,airborne),blend=std::clamp(airborne/.55,0.,1.);
 if(settings.targetArea==TargetArea::Closest){Vec3 point{std::clamp(eye.x,target.box.minX,target.box.maxX),std::clamp(eye.y-eyeOffset,target.box.minY+.01,target.box.maxY-.01),std::clamp(eye.z,target.box.minZ,target.box.maxZ)};point.y=std::clamp(point.y+(centerY-point.y)*blend,target.box.minY+.01,target.box.maxY-.01);return point;}
 return {target.position.x,std::clamp((eye.y-eyeOffset)+(centerY-(eye.y-eyeOffset))*blend,target.box.minY+.01,target.box.maxY-.01),target.position.z};
}
float SensitivityScale(JNIEnv* env,jobject mc){const auto game=mapping::Object(env,mc,"Minecraft.gameSettings");const float sensitivity=Value<float>(game,"GameSettings.mouseSensitivity"),base=sensitivity*.6f+.2f;return base*base*base*8.f;}
void ApplyMouse(JNIEnv* env,jobject player,float sensitivityScale,float& pendingYaw,float& pendingPitch) {
 const int yawSteps=static_cast<int>(pendingYaw),pitchSteps=static_cast<int>(pendingPitch);pendingYaw-=yawSteps;pendingPitch-=pitchSteps;if(!yawSteps&&!pitchSteps)return;
 CallVoid(env,player,"ExtraEntity.setAngles",{Float(yawSteps*sensitivityScale),Float(-pitchSteps*sensitivityScale)});
}
void SimpleTick(JNIEnv* env,jobject player,jobject mc,const Candidate& target,const Settings& settings,float dt) {
 const auto eye=Eye(env,player);
 const auto desired=Aim(eye,ResolvePoint(eye,target,settings));
 const float yaw=Value<float>(player,"Entity.rotationYaw"),pitch=Value<float>(player,"Entity.rotationPitch");
 const float yawError=Wrap(desired[0]-yaw),pitchError=settings.aimVertically?Wrap(desired[1]-pitch):0.f;
 const float yawGain=.8f+settings.horizontalSpeed*.34f,pitchGain=.7f+settings.verticalSpeed*.28f;
 const float yawLimit=22.f+settings.horizontalSpeed*16.f,pitchLimit=18.f+settings.verticalSpeed*13.f;
 const auto movement=mapping::Object(env,player,"ClientPlayer.movementInput");const float strafe=movement?Value<float>(movement,"AuraMovementInput.strafe"):0.f;
 float yawRate=std::clamp(yawError*yawGain,-yawLimit,yawLimit);if(settings.strafeIncrease&&std::abs(strafe)>.01f&&((yawError>0&&strafe<0)||(yawError<0&&strafe>0)))yawRate*=1.15f;
 const float sensitivityScale=SensitivityScale(env,mc),pitchRate=std::clamp(pitchError*pitchGain,-pitchLimit,pitchLimit),unit=sensitivityScale*.15f;
 if(unit>1e-5f){simple.pendingYaw+=yawRate*dt/unit;simple.pendingPitch+=pitchRate*dt/unit;}ApplyMouse(env,player,sensitivityScale,simple.pendingYaw,simple.pendingPitch);
}
void AdaptiveTick(JNIEnv* env,jobject player,jobject mc,const Candidate& target,const Settings& settings,float dt) {
 const auto now=Clock::now();
 const auto playerMotion=Motion(player);
 const auto eye=Eye(env,player);
 const auto resolved=ResolvePoint(eye,target,settings);
 const Vec3 relative{target.motion.x-playerMotion.x,target.motion.y-playerMotion.y,target.motion.z-playerMotion.z};const Vec3 targetLead{target.motion.x+relative.x*.08,target.motion.y+relative.y*.1,target.motion.z+relative.z*.08};
 if(!adaptive.aimPointInitialized){adaptive.aim=resolved;adaptive.lead=targetLead;adaptive.aimPointInitialized=true;}
 const double targetHorizontal=std::hypot(target.motion.x,target.motion.z),relativeHorizontal=std::hypot(relative.x,relative.z),distance=Distance(Position(player),target.position),frameScale=std::clamp(dt*60.f,.45f,2.4f);
 const double aimSmoothing=std::clamp((settings.targetArea==TargetArea::Closest?.30:.28)+std::min(.35,relativeHorizontal*.5),.08,.75),leadSmoothing=std::clamp(.18+std::min(.42,(targetHorizontal+relativeHorizontal*.25)*.72),.12,.68);
 const double aimBlend=1-std::pow(1-aimSmoothing,frameScale),leadBlend=1-std::pow(1-leadSmoothing,frameScale);
 adaptive.aim.x+=(resolved.x-adaptive.aim.x)*aimBlend;adaptive.aim.y+=(resolved.y-adaptive.aim.y)*aimBlend;adaptive.aim.z+=(resolved.z-adaptive.aim.z)*aimBlend;
 adaptive.lead.x+=(targetLead.x-adaptive.lead.x)*leadBlend;adaptive.lead.y+=(targetLead.y-adaptive.lead.y)*leadBlend;adaptive.lead.z+=(targetLead.z-adaptive.lead.z)*leadBlend;
 const double lag=std::hypot(resolved.x-adaptive.aim.x,resolved.z-adaptive.aim.z),maximumLag=.3+targetHorizontal*1.3+relativeHorizontal*.4;if(lag>maximumLag){adaptive.aim=resolved;adaptive.lead=targetLead;}
 const bool grounded=CallBool(env,player,"Entity.onGround");const float measured=adaptive.initialized&&adaptive.lastEyeY!=0.0?static_cast<float>((eye.y-adaptive.lastEyeY)/dt):0.f;adaptive.verticalVelocity+=(measured-adaptive.verticalVelocity)*.65f;adaptive.lastEyeY=eye.y;
 if(grounded){adaptive.lastGroundEyeY=eye.y;adaptive.airFactor*=.35f;}else{if(adaptive.lastGroundEyeY==0)adaptive.lastGroundEyeY=eye.y;adaptive.airFactor=std::max(adaptive.airFactor*.92f,std::max(std::min(.7f,std::max(0.f,adaptive.verticalVelocity)*.34f),static_cast<float>(std::min(.82,std::max(0.,eye.y-adaptive.lastGroundEyeY)*.58))));}
 double leadAmount=std::clamp(.35+distance*.045+targetHorizontal*.95+std::min(.18,relativeHorizontal*.12),.1,1.05);leadAmount*=.3+.7*std::clamp((distance-.8)/2.5,0.,1.);leadAmount=std::max(.05,leadAmount);
 const double verticalDelta=adaptive.aim.y-eye.y,verticalScale=std::clamp(std::abs(verticalDelta)/.7,0.,1.),verticalLeadAmount=std::min(leadAmount,.7+distance*.04),verticalLimit=.16+distance*.055;
 const double verticalLead=std::clamp(adaptive.lead.y*verticalLeadAmount*(.28+.52*verticalScale),-verticalLimit,verticalLimit);const Vec3 point{adaptive.aim.x,adaptive.aim.y+verticalLead,adaptive.aim.z};auto desired=Aim(eye,point);
 if(adaptive.initialized){const float yawChange=std::abs(Wrap(desired[0]-adaptive.lastTargetYaw)),pitchChange=std::abs(Wrap(desired[1]-adaptive.lastTargetPitch));const float yawMax=std::clamp(static_cast<float>(120+relativeHorizontal*700)*(1+std::min(2.f,yawChange/60.f)),90.f,1080.f),pitchMax=std::clamp(static_cast<float>(95+std::abs(adaptive.lead.y)*550)*(1+std::min(2.f,pitchChange/60.f)),70.f,500.f);desired[0]=adaptive.lastTargetYaw+std::clamp(Wrap(desired[0]-adaptive.lastTargetYaw),-yawMax*dt,yawMax*dt);desired[1]=adaptive.lastTargetPitch+std::clamp(Wrap(desired[1]-adaptive.lastTargetPitch),-pitchMax*dt,pitchMax*dt);}
 const float playerYaw=Value<float>(player,"Entity.rotationYaw"),playerPitch=Value<float>(player,"Entity.rotationPitch"),yawError=Wrap(desired[0]-playerYaw),pitchError=settings.aimVertically?Wrap(desired[1]-playerPitch):0.f,absoluteYaw=std::abs(yawError),absolutePitch=std::abs(pitchError),combined=std::hypot(absoluteYaw,absolutePitch);
 float desiredStrength=1-SmoothStep(1.5f,8.f,combined);if(adaptive.initialized)desiredStrength=std::clamp(desiredStrength+std::clamp(-(absoluteYaw-std::abs(adaptive.lastYawError))/dt/20.f,-.3f,.3f),0.f,1.f);const float strengthBlend=desiredStrength>adaptive.aimStrength?std::clamp(dt*3.f,.01f,.25f):std::clamp(dt*20.f,.05f,.8f);adaptive.aimStrength+=(desiredStrength-adaptive.aimStrength)*strengthBlend;
 float targetYawRate=0,targetPitchRate=0,playerYawRate=0,playerPitchRate=0;if(adaptive.initialized){targetYawRate=Wrap(desired[0]-adaptive.lastTargetYaw)/dt;targetPitchRate=Wrap(desired[1]-adaptive.lastTargetPitch)/dt;playerYawRate=Wrap(playerYaw-adaptive.lastPlayerYaw)/dt;playerPitchRate=Wrap(playerPitch-adaptive.lastPlayerPitch)/dt;const float blend=std::clamp(dt*12.f,.05f,.45f);adaptive.yawAccel+=(targetYawRate-adaptive.yawAccel)*blend;adaptive.pitchAccel+=(targetPitchRate-adaptive.pitchAccel)*blend;targetYawRate=adaptive.yawAccel;targetPitchRate=adaptive.pitchAccel;}
 const float horizontal=settings.horizontalSpeed*.75f,vertical=settings.verticalSpeed*.75f,hLimited=std::min(horizontal,10.f),vLimited=std::min(vertical,10.f),hInput=std::pow(std::clamp((hLimited-1)/9.f,0.f,1.f),2.f),vInput=std::pow(std::clamp((vLimited-1)/9.f,0.f,1.f),2.f),hScale=.15f+.85f*hInput,vScale=.15f+.85f*vInput,strength=adaptive.aimStrength;
 adaptive.yawBias=std::clamp((adaptive.yawBias+yawError*dt*strength*strength)*(1-(1-strength)*std::clamp(dt*5.f,0.f,.5f)),-15.f,15.f);adaptive.pitchBias=std::clamp((adaptive.pitchBias+pitchError*dt*strength*strength)*(1-(1-strength)*std::clamp(dt*5.f,0.f,.5f)),-10.f,10.f);
 const float yawErrorVelocity=adaptive.initialized?(yawError-adaptive.lastYawError)/dt:0,pitchErrorVelocity=adaptive.initialized?(pitchError-adaptive.lastPitchError)/dt:0;adaptive.yawVelocity=adaptive.yawVelocity*.85f+yawErrorVelocity*.15f;adaptive.pitchVelocity=adaptive.pitchVelocity*.85f+pitchErrorVelocity*.15f;
 float yawRate=Lerp(strength,8.f,2.5f+hLimited*.15f)*hScale*yawError+Lerp(strength,.15f,.8f+hLimited*.04f)*hScale*adaptive.yawBias+Lerp(strength,.08f,.25f)*hScale*adaptive.yawVelocity+(.85f+hLimited*.015f)*hScale*targetYawRate-Lerp(strength,.1f,.3f)*playerYawRate;
 float pitchRate=settings.aimVertically?Lerp(strength,7.f,2.2f+vLimited*.13f)*vScale*pitchError+Lerp(strength,.12f,.65f+vLimited*.035f)*vScale*adaptive.pitchBias+Lerp(strength,.06f,.2f)*vScale*adaptive.pitchVelocity+(.82f+vLimited*.013f)*vScale*targetPitchRate-Lerp(strength,.08f,.25f)*playerPitchRate:0.f;
 const auto movement=mapping::Object(env,player,"ClientPlayer.movementInput");const float strafe=movement?Value<float>(movement,"AuraMovementInput.strafe"):0;if(settings.strafeIncrease&&std::abs(strafe)>.01f&&((yawError>0&&strafe<0)||(yawError<0&&strafe>0)))yawRate*=1.15f;
 const float wide=SmoothStep(8,40,absoluteYaw),wideMultiplier=1+wide*2.5f,yawLimit=(22+hLimited*15)*hScale*wideMultiplier,pitchLimit=(18+vLimited*13)*vScale;yawRate=std::clamp(yawRate,-std::max(yawLimit,std::abs(targetYawRate)*.4f+18),std::max(yawLimit,std::abs(targetYawRate)*.4f+18));pitchRate=std::clamp(pitchRate,-std::max(pitchLimit,std::abs(targetPitchRate)*.38f+14),std::max(pitchLimit,std::abs(targetPitchRate)*.38f+14));
 const float elapsed=std::chrono::duration<float>(now-adaptive.noiseStart).count(),noiseStrength=.15f+.85f*strength,speedNoise=.5f+.5f*(1-hInput);yawRate+=(std::sin(elapsed*62.83f)*.4f+std::sin(elapsed*12.57f)*.8f+std::sin(elapsed*1.26f)*.3f)*noiseStrength*speedNoise*1.5f;if(settings.aimVertically)pitchRate+=(std::sin(elapsed*56.55f+1.3f)*.35f+std::sin(elapsed*10.47f+.9f)*.6f+std::sin(elapsed*.94f+.5f)*.2f)*noiseStrength*speedNoise;
 const float sensitivityScale=SensitivityScale(env,mc),unit=sensitivityScale*.15f;if(unit>1e-5f){adaptive.pendingYaw+=yawRate*dt/unit;adaptive.pendingPitch+=pitchRate*dt/unit;}ApplyMouse(env,player,sensitivityScale,adaptive.pendingYaw,adaptive.pendingPitch);
 adaptive.initialized=true;adaptive.lastYawError=yawError;adaptive.lastPitchError=pitchError;adaptive.lastTargetYaw=desired[0];adaptive.lastTargetPitch=desired[1];adaptive.lastPlayerYaw=playerYaw;adaptive.lastPlayerPitch=playerPitch;
}
void ResetRuntime(JNIEnv* env){DropTarget(env);lastFrame={};blockBreakUntil=0;activeMode=Mode::Adaptive;settingsKnown=false;}
}

void Stop(JNIEnv* env){ResetRuntime(env);}

void Poll(JNIEnv* env) {
 if(!env||env->ExceptionCheck())return;
 const Settings settings=Options();
 client::scheduler::Configure(client::scheduler::Task::AimAssistFrame,
  settings.enabled,3);
 if(!settings.enabled){if(targetRoot||settingsKnown)ResetRuntime(env);return;}
 if(!client::scheduler::Consume(client::scheduler::Task::AimAssistFrame,frameCursor))return;
 const auto now=Clock::now();
 const auto nowMs=client::scheduler::Now();
 float dt=lastFrame==Clock::time_point{}?1.f/60.f:std::clamp(std::chrono::duration<float>(now-lastFrame).count(),1.f/120.f,.12f);lastFrame=now;
 LocalFrame frame(env);if(!frame.ok)return;
 try {
  const auto mc=mapping::StaticObject(env,"Minecraft.theMinecraft"),player=mc?mapping::Object(env,mc,"Minecraft.thePlayer"):nullptr,world=mc?mapping::Object(env,mc,"Minecraft.theWorld"):nullptr;
  if(!mc||!player||!world||mapping::Object(env,mc,"Minecraft.currentScreen")||ui::input::IsOpen()||Value<bool>(player,"Entity.isDead")){DropTarget(env);return;}
  if(!settingsKnown||settings!=activeSettings){DropTarget(env);activeSettings=settings;settingsKnown=true;}
  if(activeMode!=settings.mode){adaptive.Reset();simple.Reset();activeMode=settings.mode;}
  if(!AllowedItem(env,player,settings)){DropTarget(env);return;}
  if(settings.checkBlockBreak&&IsBlockHit(env,mc)&&AttackDown(env,mc)){blockBreakUntil=nowMs+250;DropTarget(env);return;}
  if(nowMs<blockBreakUntil){DropTarget(env);return;}
  if(settings.requireMouseDown&&!AttackDown(env,mc)){DropTarget(env);return;}
  Candidate target;
  if(targetRoot&&!FastValid(env,player,targetRoot,settings,target))DropTarget(env);
  if(targetRoot&&!settings.requireMouseDown&&nowMs>=nextAcquire){DropTarget(env);Acquire(env,world,player,settings);target={};}
  if(!targetRoot&&nowMs>=nextAcquire)Acquire(env,world,player,settings);
  if(!targetRoot)return;
  if(!target.object&&!FastValid(env,player,targetRoot,settings,target))return;
  if(settings.mode==Mode::Adaptive)AdaptiveTick(env,player,mc,target,settings,dt);else SimpleTick(env,player,mc,target,settings,dt);
 } catch(const std::exception& error) {
  if(env->ExceptionCheck())env->ExceptionClear();AOKI_LOG("[AimAssist] disabled: %s",error.what());DropTarget(env);auto disabled=settings;disabled.enabled=false;SetOptions(disabled);
 }
}
}
