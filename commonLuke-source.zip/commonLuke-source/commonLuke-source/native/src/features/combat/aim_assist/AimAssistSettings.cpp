#include "features/combat/aim_assist/AimAssist.hpp"
#include "features/core/ModuleRegistry.hpp"

#include <algorithm>
#include <cmath>
#include <mutex>

namespace client::features::aimassist {
namespace {
Settings settings;
std::mutex settingsMutex;
}

Settings Options() {
 std::lock_guard lock(settingsMutex);
 return settings;
}

void SetOptions(Settings value) {
 const auto finite=[](float value,float low,float high,float fallback) {
  return std::isfinite(value)?std::clamp(value,low,high):fallback;
 };
 value.mode=static_cast<Mode>(std::clamp(static_cast<int>(value.mode),0,1));
 value.targetMode=static_cast<TargetMode>(std::clamp(static_cast<int>(value.targetMode),0,4));
 value.targetArea=static_cast<TargetArea>(std::clamp(static_cast<int>(value.targetArea),0,1));
 value.horizontalSpeed=finite(value.horizontalSpeed,1.f,10.f,7.f);
 value.verticalSpeed=finite(value.verticalSpeed,1.f,10.f,4.5f);
 value.maxAngle=finite(value.maxAngle,1.f,360.f,120.f);
 value.distance=finite(value.distance,1.f,8.f,4.2f);
 bool previous=false;
 {
  std::lock_guard lock(settingsMutex);
  previous=settings.enabled;
  settings=value;
 }
 modules::StateChanged(modules::AimAssist,previous,value.enabled);
}
}
