#include "features/movement/fly/Fly.hpp"
#include "features/core/ModuleRegistry.hpp"

#include <mutex>

namespace client::features::fly {
namespace {
std::mutex mutex;
Settings options;
}

Settings Options() {
    std::lock_guard lock(mutex);
    return options;
}

void SetOptions(Settings settings) {
    settings = Normalize(settings);
    bool previous = false;
    {
        std::lock_guard lock(mutex);
        previous = options.enabled;
        options = settings;
    }
    modules::StateChanged(modules::Fly, previous, settings.enabled);
}

} // namespace client::features::fly
