#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "game/MappingRepository.hpp"
#include "client/Logger.hpp"
#include "ui/clickgui/InputBridge.hpp"
namespace client::features::nojump {
namespace {
void Disable(const char* reason){AOKI_LOG("[NoJumpCooldown] disabled: %s",reason);auto settings=Options();settings.enabled=false;SetOptions(settings);}
}
void Poll(JNIEnv* env){
 if(!Options().enabled||!env||env->ExceptionCheck()||ui::input::IsOpen())return;
 const auto minecraft=mapping::StaticObject(env,"Minecraft.theMinecraft");if(!minecraft)return;
 const auto screen=mapping::Object(env,minecraft,"Minecraft.currentScreen");if(screen){env->DeleteLocalRef(screen);env->DeleteLocalRef(minecraft);return;}
 const auto player=mapping::Object(env,minecraft,"Minecraft.thePlayer");env->DeleteLocalRef(minecraft);if(!player)return;
 // Unlike vertical motion, Recaf shows no polymorphic accessor for this state:
 // ClientPlayer delegates to OQ.E(), and only OQ.E() accesses private _g:I.
 if(!mapping::Write(player,"MovementLiving.jumpCooldown",0)){env->DeleteLocalRef(player);Disable("jump cooldown write failed");return;}
 env->DeleteLocalRef(player);
}
}
