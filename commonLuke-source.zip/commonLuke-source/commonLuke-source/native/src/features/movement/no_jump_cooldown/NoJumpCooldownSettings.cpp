#include "features/movement/no_jump_cooldown/NoJumpCooldown.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <mutex>
namespace client::features::nojump {
namespace {std::mutex mutex;Settings value;}
Settings Options(){std::lock_guard lock(mutex);return value;}
void SetOptions(Settings settings){bool previous;{std::lock_guard lock(mutex);previous=value.enabled;value=settings;}modules::StateChanged(modules::NoJumpCooldown,previous,settings.enabled);}
}
