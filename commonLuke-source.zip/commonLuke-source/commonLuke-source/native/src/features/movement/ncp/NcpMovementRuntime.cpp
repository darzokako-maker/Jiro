#include "features/movement/ncp/NcpMovement.hpp"

#include "client/Logger.hpp"
#include "client/NativeScheduler.hpp"
#include "features/player/scaffold/Scaffold.hpp"
#include "features/utility/extra_modules/ExtraModules.hpp"
#include "game/MappingRepository.hpp"

#include <limits>
#include <mutex>
#include <stdexcept>

namespace client::features::movement {
namespace {

std::recursive_mutex g_mutex;
std::uintptr_t g_lastPlayer = 0;
int g_lastTick = std::numeric_limits<int>::min();
bool g_inside = false;
bool g_loggedActive = false;

struct Frame {
    JNIEnv* env;
    bool ok;
    explicit Frame(JNIEnv* value)
        : env(value), ok(value && value->PushLocalFrame(64) == JNI_OK) {}
    ~Frame() { if (ok) env->PopLocalFrame(nullptr); }
};

void Check(JNIEnv* env)
{
    if (env->ExceptionCheck()) throw std::runtime_error("game call exception");
}

jobject Object(JNIEnv* env, jobject object, const char* key)
{
    const auto value = mapping::Object(env, object, key);
    Check(env);
    return value;
}

void ResetState(JNIEnv* env = nullptr)
{
    g_lastPlayer = 0;
    g_lastTick = std::numeric_limits<int>::min();
    scaffold::Reset(env);
}

} // namespace

void Stop(JNIEnv* env)
{
    std::lock_guard lock(g_mutex);
    ResetState(env);
}

void Poll(JNIEnv* env)
{
    if (!env || env->ExceptionCheck()) return;
    std::lock_guard lock(g_mutex);
    if (g_inside) return;
    struct Guard { Guard() { g_inside = true; } ~Guard() { g_inside = false; } } guard;
    Frame frame(env);
    if (!frame.ok) return;

    try {
        const bool inputActive = extras::NeedsInput() || scaffold::Options().enabled;
        client::scheduler::Configure(client::scheduler::Task::InputModules,
            inputActive, 1);
        if (!inputActive) {
            ResetState(env);
            return;
        }
        static client::scheduler::Cursor inputCursor;
        if (!client::scheduler::Consume(client::scheduler::Task::InputModules,
                inputCursor)) return;

        const auto minecraft = mapping::StaticObject(env, "Minecraft.theMinecraft");
        const auto player = minecraft
            ? Object(env, minecraft, "Minecraft.thePlayer") : nullptr;
        const auto world = minecraft
            ? Object(env, minecraft, "Minecraft.theWorld") : nullptr;
        if (!minecraft || !player || !world) {
            ResetState(env);
            return;
        }

        const auto playerOop = mapping::Oop(player);
        const auto tick = mapping::Read<int>(player, "Entity.ticksExisted");
        if (!playerOop || !tick) return;
        if (g_lastPlayer == playerOop && g_lastTick == *tick) return;
        g_lastPlayer = playerOop;
        g_lastTick = *tick;

        const auto input = Object(env, player, "ClientPlayer.movementInput");
        if (!input) return;
        extras::AfterInput(env, input);
        scaffold::AfterInput(env, minecraft, player, world, input);
        scaffold::ApplyInput(env, input);
        Check(env);
        if (!g_loggedActive) {
            g_loggedActive = true;
            AOKI_LOG("[MovementRender] native render-thread tick path active");
        }
    } catch (const std::exception& error) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        AOKI_LOG("[MovementRender] tick callback failed: %s", error.what());
        ResetState(env);
    }
}

} // namespace client::features::movement
