#include "features/movement/ncp/NcpMovement.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <array>
#include <algorithm>
#include <cmath>
#include <mutex>
namespace client::features::movement {
Settings Defaults(Kind kind){Settings s;if(kind==Kind::LongJump)s.groundSpeed=.4f;return s;}
namespace {std::mutex mutex;std::array<Settings,2> values{Defaults(Kind::Speed),Defaults(Kind::LongJump)};}
Settings Options(Kind kind){std::lock_guard lock(mutex);return values[static_cast<int>(kind)];}
void SetOptions(Kind kind,Settings s){
 auto clamp=[](float v,float low,float high,float fallback){return std::isfinite(v)?std::clamp(v,low,high):fallback;};
 const auto defaults=Defaults(kind);
 s.jumpMotion=clamp(s.jumpMotion,.4f,.42f,.4f);s.groundSpeed=clamp(s.groundSpeed,.1f,kind==Kind::Speed?2.5f:3.f,defaults.groundSpeed);
 s.bunnySlope=clamp(s.bunnySlope,0,1,.66f);s.boostSpeed=clamp(s.boostSpeed,.1f,9.5f,.8f);s.hurtTime=clamp(s.hurtTime,1,10,6);
 s.bunnyFriction=clamp(s.bunnyFriction,59,259,159);s.jumpSpeed=clamp(s.jumpSpeed,0,3,1.4f);s.glide=clamp(s.glide,0,3,0);
 bool previous;{std::lock_guard lock(mutex);auto& value=values[static_cast<int>(kind)];previous=value.enabled;value=s;}
 modules::StateChanged(kind==Kind::Speed?modules::Speed:modules::LongJump,previous,s.enabled);
}
}
