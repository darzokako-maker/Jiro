#include "features/movement/clips/Clips.hpp"
#include "features/core/ModuleRegistry.hpp"
#include <algorithm>
#include <array>
#include <cmath>
namespace client::features::clips {
namespace {
std::array<Settings,3> options=[](){std::array<Settings,3> values;values[2].distance=10;return values;}();
std::array<bool,3> requests{};
Visual visual;
Settings Normalize(Kind kind,Settings settings){
 settings.distance=std::isfinite(settings.distance)?std::clamp(settings.distance,0.f,10.f):(kind==Kind::Look?10.f:5.f);return settings;
}
}
const Settings& Options(Kind kind){return options[static_cast<int>(kind)];}
void SetOptions(Kind kind,Settings settings) {
 const int index=static_cast<int>(kind);const bool previous=options[index].enabled;
 settings=Normalize(kind,settings);
 options[index]=settings;
 if(previous!=settings.enabled) {
  requests[index]=settings.enabled;
  modules::StateChanged(static_cast<modules::Id>(modules::UpClip+index),previous,settings.enabled);
  if(kind==Kind::Look&&!settings.enabled)visual={};
 }
}
void Request(Kind kind){if(Options(kind).enabled)requests[static_cast<int>(kind)]=true;}
void CancelRequest(Kind kind){requests[static_cast<int>(kind)]=false;}
void RequestLook(){Request(Kind::Look);}
bool TakeRequest(Kind kind){const int i=static_cast<int>(kind);const bool value=requests[i];requests[i]=false;return value;}
int PaperPacketCount(double distance){
 if(!std::isfinite(distance)||distance<0||distance>200)return 0;
 const int packets=std::max(1,static_cast<int>(std::ceil(distance/10.)));
 return packets;
}
esp::Bounds PlayerBox(const Body& body,esp::Vec3 p){return {{p.x-body.halfWidth+.001,p.y+.001,p.z-body.halfWidth+.001},{p.x+body.halfWidth-.001,p.y+body.height-.001,p.z+body.halfWidth-.001}};}
namespace {
std::optional<esp::Vec3> Landing(const Body& body,double x,int y,double z,const Probe& probe,const Fits& fits) {
 if(y<0||y>254)return {};
 const auto floor=probe(static_cast<int>(std::floor(x)),y,static_cast<int>(std::floor(z)));
 if(!floor.loaded||floor.hazard||!floor.collision)return {};
 const auto& support=*floor.collision;
 // The center must actually rest on the support (thin fences/partial shapes are
 // handled conservatively); final body collision uses the game's full shape list.
 if(x<support.min.x||x>support.max.x||z<support.min.z||z>support.max.z)return {};
 const esp::Vec3 feet{x,support.max.y,z};
 if(feet.y<0||feet.y+body.height>256)return {};
 if(fits(PlayerBox(body,feet)))return feet;
 return {};
}
}
std::optional<esp::Vec3> FindVertical(const Body& body,double range,int direction,const Probe& probe,const Fits& fits) {
 if(!std::isfinite(range)||range<0||range>10||(direction!=1&&direction!=-1))return {};
 const int start=static_cast<int>(std::floor(body.position.y));
 for(int step=0;step<=static_cast<int>(std::ceil(range))+1;++step) {
  const int y=direction>0?start+step:start-1-step;
  const auto result=Landing(body,body.position.x,y,body.position.z,probe,[&](const esp::Bounds& bounds){
   const double delta=direction*(bounds.min.y-.001-body.position.y);
   return delta>=.5&&delta<=range+.001&&fits(bounds);
  });
  if(result)return result;
 }
 return {};
}
std::optional<esp::Vec3> FindLook(const Body& body,esp::Vec3 block,bool smart,const Probe& probe,const Fits& fits) {
 const int bx=static_cast<int>(std::floor(block.x)),by=static_cast<int>(std::floor(block.y)),bz=static_cast<int>(std::floor(block.z));
 struct Candidate {int x,y,z;int score;};std::vector<Candidate> candidates;
 for(int dy=smart?-2:0;dy<=(smart?2:0);++dy)for(int dx=smart?-1:0;dx<=(smart?1:0);++dx)for(int dz=smart?-1:0;dz<=(smart?1:0);++dz)
  candidates.push_back({bx+dx,by+dy,bz+dz,dx*dx+dz*dz+dy*dy*2});
 std::stable_sort(candidates.begin(),candidates.end(),[](const Candidate& a,const Candidate& b){return a.score<b.score;});
 int checked=0;for(const auto& c:candidates){if(++checked>32)break;if(const auto p=Landing(body,c.x+.5,c.y,c.z+.5,probe,fits))return p;}
 return {};
}
void Publish(Visual value){visual=std::move(value);}
const Visual& Current(){return visual;}
}
