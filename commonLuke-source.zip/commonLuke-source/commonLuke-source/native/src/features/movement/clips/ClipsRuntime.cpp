#include "features/movement/clips/ClipsRuntime.hpp"

#include "client/Logger.hpp"
#include "features/movement/clips/Clips.hpp"
#include "game/MappingRepository.hpp"

#include <cmath>

namespace client::features::clips {
namespace {

constexpr double DegreesToRadians = 0.017453292519943295;

methods::Argument Double(double value)
{
    methods::Argument argument{methods::Type::Double};
    argument.value.d = value;
    return argument;
}

const char* Name(Kind kind)
{
    switch (kind) {
    case Kind::Up: return "UpClip";
    case Kind::Down: return "DownClip";
    case Kind::Look: return "LookClip";
    }
    return "Clip";
}

void Disable(Kind kind)
{
    auto settings = Options(kind);
    if (!settings.enabled) return;
    settings.enabled = false;
    SetOptions(kind, settings);
}

bool Direction(jobject player, Kind kind, double& x, double& y, double& z)
{
    if (kind == Kind::Up) {
        x = 0; y = 1; z = 0;
        return true;
    }
    if (kind == Kind::Down) {
        x = 0; y = -1; z = 0;
        return true;
    }

    const auto yaw = mapping::Read<float>(player, "Entity.rotationYaw");
    const auto pitch = mapping::Read<float>(player, "Entity.rotationPitch");
    if (!yaw || !pitch || !std::isfinite(*yaw) || !std::isfinite(*pitch)) return false;
    const double yawRadians = static_cast<double>(*yaw) * DegreesToRadians;
    const double pitchRadians = static_cast<double>(*pitch) * DegreesToRadians;
    const double horizontal = std::cos(pitchRadians);
    x = -std::sin(yawRadians) * horizontal;
    y = -std::sin(pitchRadians);
    z = std::cos(yawRadians) * horizontal;
    return std::isfinite(x) && std::isfinite(y) && std::isfinite(z);
}

bool Move(JNIEnv* env, jobject player, double dx, double dy, double dz)
{
    const auto px = mapping::Read<double>(player, "Entity.posX");
    const auto py = mapping::Read<double>(player, "Entity.posY");
    const auto pz = mapping::Read<double>(player, "Entity.posZ");
    if (!px || !py || !pz) return false;

    auto position = mapping::Invoke(env, player, "Entity.setPosition", {
        Double(*px + dx), Double(*py + dy), Double(*pz + dz)});
    const bool positioned = position.ok;
    position.Release(env);
    if (!positioned || env->ExceptionCheck()) return false;

    auto velocity = mapping::Invoke(env, player, "Entity.setVelocity", {
        Double(0), Double(0), Double(0)});
    const bool stopped = velocity.ok;
    velocity.Release(env);
    return stopped && !env->ExceptionCheck();
}

void Execute(JNIEnv* env, jobject player, Kind kind)
{
    const double distance = Options(kind).distance;
    double x = 0, y = 0, z = 0;
    const bool valid = std::isfinite(distance) && distance > 0 &&
        Direction(player, kind, x, y, z);
    const bool moved = valid && Move(env, player,
        x * distance, y * distance, z * distance);
    AOKI_LOG("[Clip] %s instant distance=%.2f result=%s",
        Name(kind), distance, moved ? "PASS" : "FAIL");
    Disable(kind);
}

}

void Poll(JNIEnv* env)
{
    if (!env || env->ExceptionCheck() || env->PushLocalFrame(16) != JNI_OK) return;
    const auto minecraft = mapping::StaticObject(env, "Minecraft.theMinecraft");
    const auto player = minecraft ? mapping::Object(env, minecraft, "Minecraft.thePlayer") : nullptr;

    for (const auto kind : {Kind::Up, Kind::Down, Kind::Look}) {
        if (!TakeRequest(kind) || !Options(kind).enabled) continue;
        if (player) Execute(env, player, kind);
        else Disable(kind);
        break;
    }
    env->PopLocalFrame(nullptr);
}

}
