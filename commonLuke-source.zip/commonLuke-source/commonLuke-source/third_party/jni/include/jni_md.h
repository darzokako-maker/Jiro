#ifndef _JAVASOFT_JNI_MD_H_
#define _JAVASOFT_JNI_MD_H_

// Windows-specific JNI ABI definitions.  The project vendors jni.h, so keep
// this companion header local as well instead of requiring JAVA_HOME to build
// the native DLL.
#ifndef JNIEXPORT
#define JNIEXPORT __declspec(dllexport)
#endif

#define JNIIMPORT __declspec(dllimport)
#define JNICALL __stdcall

typedef int jint;
typedef long long jlong;
typedef signed char jbyte;

#endif // _JAVASOFT_JNI_MD_H_
