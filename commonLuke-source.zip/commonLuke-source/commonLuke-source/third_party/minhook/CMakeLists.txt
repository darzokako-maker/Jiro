add_library(minhook STATIC
    src/buffer.c
    src/hook.c
    src/trampoline.c
    src/hde/hde64.c
)

target_include_directories(minhook
    PUBLIC include
    PRIVATE src src/hde
)

target_compile_definitions(minhook PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)

if(MSVC)
    set_property(TARGET minhook PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(minhook PRIVATE /W3)
endif()
