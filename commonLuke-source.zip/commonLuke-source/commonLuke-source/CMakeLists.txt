cmake_minimum_required(VERSION 3.24)

project(sonoyuncu_jni LANGUAGES C CXX)
include(CTest)

if(NOT WIN32)
    message(FATAL_ERROR "This project only supports Windows.")
endif()

if(NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
    message(FATAL_ERROR "Configure an x64 build; the target client is 64-bit.")
endif()

add_subdirectory(third_party/minhook)
include(cmake/ImGui.cmake)
add_subdirectory(native)
add_subdirectory(loader)
