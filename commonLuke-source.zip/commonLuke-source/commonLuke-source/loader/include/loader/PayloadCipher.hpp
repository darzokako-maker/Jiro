#pragma once

#include <string_view>
#include <vector>

namespace loader {

// The access key is used to derive the in-memory payload key. The fixed key is
// never stored as plaintext in the executable.
bool DecryptEmbeddedPayload(std::string_view accessKey,
    std::vector<unsigned char>& output);

} // namespace loader
