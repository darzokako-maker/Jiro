#pragma once

#include <Windows.h>

#include <optional>
#include <string>
#include <vector>

namespace loader {

struct TargetProcess {
    DWORD processId = 0;
    std::wstring imagePath;
};

struct TargetSearch {
    std::optional<TargetProcess> target;
    std::vector<TargetProcess> matches;
    std::wstring error;
};

// Finds a running SonOyuncu game process. The launcher process has the same
// executable name, so a candidate must also have the custom JVM and LWJGL
// OpenGL native library loaded.
TargetSearch FindTargetProcess();

} // namespace loader
