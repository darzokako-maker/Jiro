#pragma once

#include <Windows.h>

namespace loader {

int RunUi(HINSTANCE instance, int showCommand);

} // namespace loader
