#pragma once

#include <Windows.h>
#include <atomic>
#include <cstddef>
#include <filesystem>
#include <string>

namespace loader {

struct LoadResult {
    bool success = false;
    std::wstring message;
};

// Maps an in-memory commonLuke.dll image. Progress measures loader stages, not DLL bootstrap.
LoadResult ManualMap(DWORD processId,const unsigned char* dllBytes,std::size_t dllSize,
    std::atomic<int>& progress);
#if !defined(AOKI_EMBEDDED_PAYLOAD)
LoadResult ManualMap(DWORD processId, const std::filesystem::path& dllPath,
    std::atomic<int>& progress);
#endif

} // namespace loader
