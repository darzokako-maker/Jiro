# The isolated manual-VM experiment reuses this UI with a different embedded DLL.
if(NOT AOKI_LOADER_PAYLOAD_TARGET)
    set(AOKI_LOADER_PAYLOAD_TARGET sonoyuncu_jni)
endif()

add_library(aoki_imgui STATIC
    ${imgui_SOURCE_DIR}/imgui.cpp
    ${imgui_SOURCE_DIR}/imgui_draw.cpp
    ${imgui_SOURCE_DIR}/imgui_tables.cpp
    ${imgui_SOURCE_DIR}/imgui_widgets.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_dx11.cpp
    ${imgui_SOURCE_DIR}/backends/imgui_impl_win32.cpp
)

find_package(Python3 REQUIRED COMPONENTS Interpreter)

target_include_directories(aoki_imgui PUBLIC
    ${imgui_SOURCE_DIR}
    ${imgui_SOURCE_DIR}/backends
)

target_compile_definitions(aoki_imgui PRIVATE
    WIN32_LEAN_AND_MEAN
    NOMINMAX
    UNICODE
    _UNICODE
)

set(embedded_dll_header "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedAokiDll.hpp")
set(embedded_dll_source "${CMAKE_CURRENT_BINARY_DIR}/generated/EmbeddedAokiDll.cpp")
add_custom_command(OUTPUT "${embedded_dll_header}" "${embedded_dll_source}"
    COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/embed-binary.py"
        "$<TARGET_FILE:${AOKI_LOADER_PAYLOAD_TARGET}>" "${embedded_dll_header}" "${embedded_dll_source}" kEmbeddedAokiDll
        --cipher-config "${CMAKE_CURRENT_SOURCE_DIR}/payload-cipher.json"
    DEPENDS ${AOKI_LOADER_PAYLOAD_TARGET} "${PROJECT_SOURCE_DIR}/tools/embed-binary.py"
        "${CMAKE_CURRENT_SOURCE_DIR}/payload-cipher.json" VERBATIM)
set_source_files_properties("${embedded_dll_source}" PROPERTIES GENERATED TRUE)

add_executable(payload_cipher_test EXCLUDE_FROM_ALL
    "${embedded_dll_source}"
    src/PayloadCipher.cpp
    ${PROJECT_SOURCE_DIR}/tools/loader-smoke/PayloadCipherTest.cpp)
target_compile_features(payload_cipher_test PRIVATE cxx_std_20)
target_include_directories(payload_cipher_test PRIVATE include "${CMAKE_CURRENT_BINARY_DIR}/generated")
target_compile_definitions(payload_cipher_test PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_link_libraries(payload_cipher_test PRIVATE bcrypt)

add_executable(aoki_loader WIN32
    "${embedded_dll_source}"
    resources/LoaderResources.rc
    src/Main.cpp
    src/LoaderUi.cpp
    src/PayloadCipher.cpp
    src/TargetProcess.cpp
    src/ManualMap.cpp
    src/MappingStub.cpp
)

target_compile_features(aoki_loader PRIVATE cxx_std_20)

target_include_directories(aoki_loader PRIVATE include "${CMAKE_CURRENT_BINARY_DIR}/generated")

target_compile_definitions(aoki_loader PRIVATE
    WIN32_LEAN_AND_MEAN
    NOMINMAX
    UNICODE
    _UNICODE
    AOKI_EMBEDDED_PAYLOAD=1
)

target_link_libraries(aoki_loader PRIVATE
    aoki_imgui
    d3d11
    dxgi
    dwmapi
    ole32
    windowscodecs
    bcrypt
)

if(MSVC)
    # The copied remote routine must not reference CRT instrumentation or be
    # folded/reordered with unrelated functions by link-time optimization.
    set_source_files_properties(src/MappingStub.cpp PROPERTIES
        COMPILE_OPTIONS "/GS-;/JMC-;/Od;/GL-;/guard:cf-")
    set_property(TARGET aoki_imgui PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    set_property(TARGET aoki_loader PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_compile_options(aoki_imgui PRIVATE /W4 /permissive- /EHsc)
    target_compile_options(aoki_loader PRIVATE /W4 /permissive- /EHsc)
    target_link_options(aoki_loader PRIVATE /INCREMENTAL:NO /OPT:NOICF)
endif()

add_dependencies(aoki_loader ${AOKI_LOADER_PAYLOAD_TARGET})

set_target_properties(aoki_loader PROPERTIES
    OUTPUT_NAME "commonLukeLoader"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_DEBUG "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_RELWITHDEBINFO "${CMAKE_BINARY_DIR}/bin"
    RUNTIME_OUTPUT_DIRECTORY_MINSIZEREL "${CMAKE_BINARY_DIR}/bin"
)

if(AOKI_LOADER_PROBE_ONLY)
    set_target_properties(aoki_loader PROPERTIES OUTPUT_NAME "AokiManualProbeLoader")
    add_custom_command(TARGET aoki_loader POST_BUILD
        COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/manual-vm-probe/VerifyEmbedding.py"
            "$<TARGET_FILE:${AOKI_LOADER_PAYLOAD_TARGET}>" "$<TARGET_FILE:aoki_loader>"
            "${CMAKE_CURRENT_SOURCE_DIR}/payload-cipher.json"
        VERBATIM)
else()
set(aoki_distribution_verify_options)
if(AOKI_ENABLE_LOGGING)
    list(APPEND aoki_distribution_verify_options --allow-native-logs)
endif()
add_custom_command(TARGET aoki_loader POST_BUILD
    COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/tools/verify-embedded-distribution.py"
        "$<TARGET_FILE:sonoyuncu_jni>"
        "$<TARGET_FILE:aoki_loader>"
        "${PROJECT_SOURCE_DIR}/native"
        --cipher-config "${CMAKE_CURRENT_SOURCE_DIR}/payload-cipher.json"
        ${aoki_distribution_verify_options}
    VERBATIM)
endif()

set(AOKI_LOADER_OUTPUT_NAME "" CACHE STRING "Optional loader filename override for side-by-side diagnostic builds")
if(AOKI_LOADER_OUTPUT_NAME)
    set_target_properties(aoki_loader PROPERTIES OUTPUT_NAME "${AOKI_LOADER_OUTPUT_NAME}")
endif()
