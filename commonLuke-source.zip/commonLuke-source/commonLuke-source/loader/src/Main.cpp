#include "loader/LoaderUi.hpp"

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand)
{
    return loader::RunUi(instance, showCommand);
}
