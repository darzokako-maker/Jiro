#include "loader/TargetProcess.hpp"

#include <TlHelp32.h>

#include <cwchar>
#include <string_view>

namespace {

constexpr std::wstring_view kProcessName = L"sonoyuncuclient.exe";

bool EqualsIgnoreCase(std::wstring_view left, std::wstring_view right)
{
    return left.size() == right.size() &&
        _wcsnicmp(left.data(), right.data(), left.size()) == 0;
}

std::wstring GetExpectedImagePath()
{
    const DWORD required = GetEnvironmentVariableW(L"APPDATA", nullptr, 0);
    if (required == 0) return {};

    std::wstring appData(required, L'\0');
    const DWORD written = GetEnvironmentVariableW(
        L"APPDATA", appData.data(), static_cast<DWORD>(appData.size()));
    if (written == 0 || written >= appData.size()) return {};

    appData.resize(written);
    if (!appData.empty() && appData.back() != L'\\') appData.push_back(L'\\');
    appData += L".sonoyuncu\\sonoyuncuclient.exe";
    return appData;
}

std::optional<std::wstring> QueryImagePath(DWORD processId)
{
    const HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, processId);
    if (process == nullptr) return {};

    std::wstring path(32768, L'\0');
    DWORD length = static_cast<DWORD>(path.size());
    const BOOL ok = QueryFullProcessImageNameW(process, 0, path.data(), &length);
    CloseHandle(process);
    if (!ok) return {};

    path.resize(length);
    return path;
}

bool HasRequiredModules(DWORD processId)
{
    HANDLE snapshot = INVALID_HANDLE_VALUE;
    for (unsigned attempt = 0; attempt < 4; ++attempt) {
        snapshot = CreateToolhelp32Snapshot(
            TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processId);
        if (snapshot != INVALID_HANDLE_VALUE || GetLastError() != ERROR_BAD_LENGTH) break;
    }
    if (snapshot == INVALID_HANDLE_VALUE) return false;

    bool hasJvm = false;
    bool hasLwjglOpenGl = false;
    MODULEENTRY32W module{};
    module.dwSize = sizeof(module);
    if (Module32FirstW(snapshot, &module)) {
        do {
            hasJvm = hasJvm || EqualsIgnoreCase(module.szModule, L"jvm.dll");
            hasLwjglOpenGl = hasLwjglOpenGl ||
                EqualsIgnoreCase(module.szModule, L"lwjgl_opengl.dll");
        } while ((!hasJvm || !hasLwjglOpenGl) && Module32NextW(snapshot, &module));
    }

    CloseHandle(snapshot);
    return hasJvm && hasLwjglOpenGl;
}

} // namespace

namespace loader {

TargetSearch FindTargetProcess()
{
    TargetSearch result;
    const std::wstring expectedPath = GetExpectedImagePath();
    if (expectedPath.empty()) {
        result.error = L"APPDATA yolu okunamadi.";
        return result;
    }

    const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        result.error = L"Process listesi okunamadi.";
        return result;
    }

    PROCESSENTRY32W process{};
    process.dwSize = sizeof(process);
    if (Process32FirstW(snapshot, &process)) {
        do {
            if (!EqualsIgnoreCase(process.szExeFile, kProcessName)) continue;

            const auto imagePath = QueryImagePath(process.th32ProcessID);
            if (!imagePath || !EqualsIgnoreCase(*imagePath, expectedPath)) continue;
            if (!HasRequiredModules(process.th32ProcessID)) continue;

            result.matches.push_back(TargetProcess{process.th32ProcessID, *imagePath});
        } while (Process32NextW(snapshot, &process));
    }
    CloseHandle(snapshot);

    if (result.matches.size() == 1) {
        result.target = result.matches.front();
    } else if (result.matches.empty()) {
        result.error = L"Oyun bulunamadi veya JVM/LWJGL henuz yuklenmedi.";
    } else {
        result.error = L"Birden fazla calisan oyun bulundu; guvenli otomatik secim yapilmadi.";
    }
    return result;
}

} // namespace loader
