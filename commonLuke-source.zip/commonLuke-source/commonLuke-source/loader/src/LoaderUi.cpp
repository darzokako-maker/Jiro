#include "loader/LoaderUi.hpp"
#include "loader/ResourceIds.h"
#include "loader/ManualMap.hpp"
#include "loader/PayloadCipher.hpp"
#include "loader/TargetProcess.hpp"
#include "EmbeddedAokiDll.hpp"

#include <d3d11.h>
#include <dwmapi.h>
#include <wincodec.h>
#include <windowsx.h>
#include <wrl/client.h>

#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <atomic>
#include <filesystem>
#include <future>
#include <memory>
#include <string>
#include <vector>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND window, UINT message, WPARAM wParam, LPARAM lParam);

namespace {

using Microsoft::WRL::ComPtr;

// One four-pixel unit at 96 DPI drives the complete 85:22 design grid.
constexpr float kDesignUnitPixels = 4.0f;
constexpr float kCardUnitsX = 85.0f;
constexpr float kCardUnitsY = 22.0f;
constexpr float kDpiBaseline = 96.0f;

int g_windowWidth = static_cast<int>(kCardUnitsX * kDesignUnitPixels);
int g_windowHeight = static_cast<int>(kCardUnitsY * kDesignUnitPixels);
float g_dpiScale = 1.0f;

ID3D11Device* g_device = nullptr;
ID3D11DeviceContext* g_deviceContext = nullptr;
IDXGISwapChain* g_swapChain = nullptr;
ID3D11RenderTargetView* g_renderTarget = nullptr;
bool g_hasBackdrop = false;

struct TextureResource {
    ComPtr<ID3D11ShaderResourceView> view;
    UINT width = 0;
    UINT height = 0;

    ImTextureRef Reference() const
    {
        const auto address = reinterpret_cast<std::uintptr_t>(view.Get());
        return ImTextureRef(static_cast<ImTextureID>(address));
    }
};

struct FontSet {
    ImFont* regular = nullptr;
    ImFont* medium = nullptr;
    ImFont* semibold = nullptr;
};

struct Layout {
    float unit = 1.0f;
    ImVec2 cardMin{};
    ImVec2 cardMax{};
    ImVec2 logoMin{};
    ImVec2 logoMax{};
    float contentLeft = 0.0f;
    float contentRight = 0.0f;
    float centerY = 0.0f;
    float underlineY = 0.0f;
    float progressHeight = 0.0f;
    float progressGap = 0.0f;
};

struct UiState {
    std::array<char, 64> accessKey{};
    std::chrono::steady_clock::time_point started = std::chrono::steady_clock::now();
    double progressStarted = -1.0;
    double keyFocusStarted = -1.0;
    bool reducedMotion = false;
    std::shared_ptr<std::atomic<int>> progress = std::make_shared<std::atomic<int>>(0);
    std::future<loader::LoadResult> loading;
    bool failed = false;
    bool succeeded = false;
    std::string errorMessage;
    float displayedProgress = 0.0f;
    double lastProgressFrame = -1.0;
    double completionStarted = -1.0;
};

struct ResourceData {
    const std::uint8_t* bytes = nullptr;
    DWORD size = 0;
};

void RecordLoadResult(const loader::LoadResult& result, int progress)
{
    wchar_t executable[32768]{};
    if (!GetModuleFileNameW(nullptr, executable, static_cast<DWORD>(std::size(executable)))) return;
    const auto path = std::filesystem::path(executable).parent_path() / L"commonLukeLoader.log";
    FILE* file = nullptr;
    if (_wfopen_s(&file, path.c_str(), L"ab") != 0 || !file) return;
    SYSTEMTIME now{}; GetLocalTime(&now);
    const int length = WideCharToMultiByte(CP_UTF8, 0, result.message.data(), static_cast<int>(result.message.size()), nullptr, 0, nullptr, nullptr);
    std::string message(length, '\0');
    if (length) WideCharToMultiByte(CP_UTF8, 0, result.message.data(), static_cast<int>(result.message.size()), message.data(), length, nullptr, nullptr);
    std::fprintf(file, "%04u-%02u-%02u %02u:%02u:%02u %s progress=%d message=%s\r\n", now.wYear, now.wMonth, now.wDay, now.wHour, now.wMinute, now.wSecond, result.success ? "SUCCESS" : "ERROR", progress, message.c_str());
    std::fclose(file);
}

float Saturate(float value)
{
    return std::clamp(value, 0.0f, 1.0f);
}

float SmoothStep(float value)
{
    value = Saturate(value);
    return value * value * (3.0f - 2.0f * value);
}

ImU32 WithAlpha(ImU32 color, float alpha)
{
    const unsigned value = static_cast<unsigned>(255.0f * Saturate(alpha) + 0.5f);
    return (color & 0x00FFFFFFu) | (value << IM_COL32_A_SHIFT);
}

bool GetResourceData(HINSTANCE instance, int identifier, ResourceData& output)
{
    const HRSRC resource = FindResourceW(
        instance, MAKEINTRESOURCEW(identifier), RT_RCDATA);
    if (resource == nullptr) return false;
    const HGLOBAL loaded = LoadResource(instance, resource);
    if (loaded == nullptr) return false;
    output.size = SizeofResource(instance, resource);
    output.bytes = static_cast<const std::uint8_t*>(LockResource(loaded));
    return output.bytes != nullptr && output.size != 0;
}

Layout CalculateLayout(const ImVec2 viewport, const TextureResource& logo)
{
    Layout layout;
    layout.unit = std::min(viewport.x / kCardUnitsX, viewport.y / kCardUnitsY);

    const ImVec2 cardSize(kCardUnitsX * layout.unit, kCardUnitsY * layout.unit);
    layout.cardMin = ImVec2(
        (viewport.x - cardSize.x) * 0.5f,
        (viewport.y - cardSize.y) * 0.5f);
    layout.cardMax = ImVec2(
        layout.cardMin.x + cardSize.x,
        layout.cardMin.y + cardSize.y);
    layout.centerY = (layout.cardMin.y + layout.cardMax.y) * 0.5f;

    const float outerPadding = 4.0f * layout.unit;
    const float logoHeight = 10.0f * layout.unit;
    const float sourceAspect = logo.height == 0 ? 1.0f :
        static_cast<float>(logo.width) / static_cast<float>(logo.height);
    const float logoWidth = logoHeight * sourceAspect;
    layout.logoMin = ImVec2(
        layout.cardMin.x + outerPadding,
        layout.centerY - logoHeight * 0.5f);
    layout.logoMax = ImVec2(
        layout.logoMin.x + logoWidth,
        layout.logoMin.y + logoHeight);

    layout.contentLeft = layout.logoMax.x + 3.0f * layout.unit;
    layout.contentRight = layout.cardMax.x - outerPadding;
    layout.underlineY = layout.centerY + 3.25f * layout.unit;
    layout.progressHeight = 1.5f * layout.unit;
    layout.progressGap = 3.0f * layout.unit;
    return layout;
}

void CreateRenderTarget()
{
    ID3D11Texture2D* backBuffer = nullptr;
    if (SUCCEEDED(g_swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) {
        g_device->CreateRenderTargetView(backBuffer, nullptr, &g_renderTarget);
        backBuffer->Release();
    }
}

void CleanupRenderTarget()
{
    if (g_renderTarget != nullptr) {
        g_renderTarget->Release();
        g_renderTarget = nullptr;
    }
}

bool CreateDevice(HWND window)
{
    DXGI_SWAP_CHAIN_DESC description{};
    description.BufferCount = 2;
    description.BufferDesc.Width = static_cast<UINT>(g_windowWidth);
    description.BufferDesc.Height = static_cast<UINT>(g_windowHeight);
    description.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    description.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    description.OutputWindow = window;
    description.SampleDesc.Count = 1;
    description.Windowed = TRUE;
    description.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    constexpr D3D_FEATURE_LEVEL levels[] = {
        D3D_FEATURE_LEVEL_11_0,
        D3D_FEATURE_LEVEL_10_0,
    };
    D3D_FEATURE_LEVEL selected{};
    const HRESULT result = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
        D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        levels, static_cast<UINT>(std::size(levels)), D3D11_SDK_VERSION,
        &description, &g_swapChain, &g_device, &selected, &g_deviceContext);
    if (FAILED(result)) return false;

    CreateRenderTarget();
    return g_renderTarget != nullptr;
}

void CleanupDevice()
{
    CleanupRenderTarget();
    if (g_swapChain != nullptr) { g_swapChain->Release(); g_swapChain = nullptr; }
    if (g_deviceContext != nullptr) { g_deviceContext->Release(); g_deviceContext = nullptr; }
    if (g_device != nullptr) { g_device->Release(); g_device = nullptr; }
}

bool LoadTexture(const ResourceData& source, UINT targetHeight,
    TextureResource& output)
{
    ComPtr<IWICImagingFactory> factory;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr,
            CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)))) return false;

    ComPtr<IWICStream> stream;
    if (FAILED(factory->CreateStream(&stream))) return false;
    if (FAILED(stream->InitializeFromMemory(
            const_cast<BYTE*>(source.bytes), source.size))) return false;

    ComPtr<IWICBitmapDecoder> decoder;
    if (FAILED(factory->CreateDecoderFromStream(stream.Get(), nullptr,
            WICDecodeMetadataCacheOnDemand, &decoder))) return false;

    ComPtr<IWICBitmapFrameDecode> frame;
    if (FAILED(decoder->GetFrame(0, &frame))) return false;
    UINT sourceWidth = 0;
    UINT sourceHeight = 0;
    if (FAILED(frame->GetSize(&sourceWidth, &sourceHeight)) ||
        sourceWidth == 0 || sourceHeight == 0 || targetHeight == 0) return false;

    output.height = targetHeight;
    output.width = std::max<UINT>(1, static_cast<UINT>(std::lround(
        static_cast<double>(targetHeight) * sourceWidth / sourceHeight)));

    ComPtr<IWICBitmapScaler> scaler;
    if (FAILED(factory->CreateBitmapScaler(&scaler))) return false;
    if (FAILED(scaler->Initialize(frame.Get(), output.width, output.height,
            WICBitmapInterpolationModeFant))) return false;

    ComPtr<IWICFormatConverter> converter;
    if (FAILED(factory->CreateFormatConverter(&converter))) return false;
    if (FAILED(converter->Initialize(scaler.Get(), GUID_WICPixelFormat32bppRGBA,
            WICBitmapDitherTypeNone, nullptr, 0.0,
            WICBitmapPaletteTypeCustom))) return false;

    const UINT stride = output.width * 4;
    std::vector<std::uint8_t> pixels(
        static_cast<std::size_t>(stride) * output.height);
    if (FAILED(converter->CopyPixels(nullptr, stride,
            static_cast<UINT>(pixels.size()), pixels.data()))) return false;

    D3D11_TEXTURE2D_DESC textureDescription{};
    textureDescription.Width = output.width;
    textureDescription.Height = output.height;
    textureDescription.MipLevels = 1;
    textureDescription.ArraySize = 1;
    textureDescription.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    textureDescription.SampleDesc.Count = 1;
    textureDescription.Usage = D3D11_USAGE_IMMUTABLE;
    textureDescription.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    const D3D11_SUBRESOURCE_DATA initialData{pixels.data(), stride, 0};
    ComPtr<ID3D11Texture2D> texture;
    if (FAILED(g_device->CreateTexture2D(
            &textureDescription, &initialData, &texture))) return false;
    return SUCCEEDED(g_device->CreateShaderResourceView(
        texture.Get(), nullptr, &output.view));
}

HICON CreateIconFromPng(const ResourceData& source, UINT edge)
{
    ComPtr<IWICImagingFactory> factory;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr,
            CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)))) return nullptr;

    ComPtr<IWICStream> stream;
    if (FAILED(factory->CreateStream(&stream)) ||
        FAILED(stream->InitializeFromMemory(
            const_cast<BYTE*>(source.bytes), source.size))) return nullptr;

    ComPtr<IWICBitmapDecoder> decoder;
    if (FAILED(factory->CreateDecoderFromStream(stream.Get(), nullptr,
            WICDecodeMetadataCacheOnDemand, &decoder))) return nullptr;
    ComPtr<IWICBitmapFrameDecode> frame;
    if (FAILED(decoder->GetFrame(0, &frame))) return nullptr;

    ComPtr<IWICBitmapScaler> scaler;
    if (FAILED(factory->CreateBitmapScaler(&scaler)) ||
        FAILED(scaler->Initialize(frame.Get(), edge, edge,
            WICBitmapInterpolationModeFant))) return nullptr;

    ComPtr<IWICFormatConverter> converter;
    if (FAILED(factory->CreateFormatConverter(&converter)) ||
        FAILED(converter->Initialize(scaler.Get(), GUID_WICPixelFormat32bppPBGRA,
            WICBitmapDitherTypeNone, nullptr, 0.0,
            WICBitmapPaletteTypeCustom))) return nullptr;

    const UINT stride = edge * 4;
    std::vector<std::uint8_t> pixels(static_cast<std::size_t>(stride) * edge);
    if (FAILED(converter->CopyPixels(nullptr, stride,
            static_cast<UINT>(pixels.size()), pixels.data()))) return nullptr;

    BITMAPV5HEADER header{};
    header.bV5Size = sizeof(header);
    header.bV5Width = static_cast<LONG>(edge);
    header.bV5Height = -static_cast<LONG>(edge);
    header.bV5Planes = 1;
    header.bV5BitCount = 32;
    header.bV5Compression = BI_BITFIELDS;
    header.bV5RedMask = 0x00FF0000;
    header.bV5GreenMask = 0x0000FF00;
    header.bV5BlueMask = 0x000000FF;
    header.bV5AlphaMask = 0xFF000000;

    void* bitmapData = nullptr;
    HDC screen = GetDC(nullptr);
    HBITMAP color = CreateDIBSection(screen,
        reinterpret_cast<const BITMAPINFO*>(&header), DIB_RGB_COLORS,
        &bitmapData, nullptr, 0);
    ReleaseDC(nullptr, screen);
    if (color == nullptr || bitmapData == nullptr) return nullptr;
    std::memcpy(bitmapData, pixels.data(), pixels.size());

    HBITMAP mask = CreateBitmap(static_cast<int>(edge), static_cast<int>(edge),
        1, 1, nullptr);
    ICONINFO information{TRUE, 0, 0, mask, color};
    HICON icon = CreateIconIndirect(&information);
    DeleteObject(mask);
    DeleteObject(color);
    return icon;
}

enum class AccentState : int {
    BlurBehind = 3,
};

struct AccentPolicy {
    AccentState state;
    DWORD flags;
    DWORD gradientColor;
    DWORD animationId;
};

struct CompositionAttributeData {
    int attribute;
    void* data;
    SIZE_T size;
};

bool EnableBlur(HWND window)
{
    constexpr BOOL enabled = TRUE;
    DwmSetWindowAttribute(window, 20, &enabled, sizeof(enabled));

    constexpr MARGINS glass{-1, -1, -1, -1};
    DwmExtendFrameIntoClientArea(window, &glass);

    using SetWindowCompositionAttributeFunction = BOOL(WINAPI*)(
        HWND, CompositionAttributeData*);
    const HMODULE user32 = GetModuleHandleW(L"user32.dll");
    const auto setComposition = reinterpret_cast<SetWindowCompositionAttributeFunction>(
        GetProcAddress(user32, "SetWindowCompositionAttribute"));
    if (setComposition == nullptr) return false;

    AccentPolicy policy{AccentState::BlurBehind, 0, 0, 0};
    CompositionAttributeData data{19, &policy, sizeof(policy)};
    return setComposition(window, &data) != FALSE;
}

void PositionWindow(HWND window)
{
    POINT cursor{};
    GetCursorPos(&cursor);
    const HMONITOR monitor = MonitorFromPoint(cursor, MONITOR_DEFAULTTONEAREST);
    MONITORINFO information{sizeof(information)};
    GetMonitorInfoW(monitor, &information);
    const RECT& work = information.rcWork;
    const int x = work.left + (work.right - work.left - g_windowWidth) / 2;
    const int y = work.top + (work.bottom - work.top - g_windowHeight) / 2;
    SetWindowPos(window, nullptr, x, y, g_windowWidth, g_windowHeight,
        SWP_NOACTIVATE | SWP_NOZORDER);
}

void RenderInput(UiState& state, double elapsed, float opacity,
    const Layout& layout, ImFont* font)
{
    if (opacity <= 0.001f) return;

    const float inputTop = layout.centerY - font->LegacySize * 0.5f -
        0.5f * layout.unit;
    const float inputWidth = std::max(1.0f,
        layout.contentRight - layout.contentLeft);

    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGui::SetCursorScreenPos(ImVec2(layout.contentLeft, inputTop));
    ImGui::SetNextItemWidth(inputWidth);

    ImGui::PushFont(font);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,
        ImVec2(0.0f, 0.5f * layout.unit));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Text,
        WithAlpha(IM_COL32(255, 255, 255, 255), opacity));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled,
        WithAlpha(IM_COL32(120, 120, 120, 255), opacity));
    ImGui::PushStyleColor(ImGuiCol_TextSelectedBg,
        WithAlpha(IM_COL32(255, 255, 255, 70), opacity));

    const bool submitted = ImGui::InputTextWithHint(
        "##access-key", "key", state.accessKey.data(), state.accessKey.size(),
        ImGuiInputTextFlags_EnterReturnsTrue);
    const bool active = ImGui::IsItemActive();

    ImGui::PopStyleColor(6);
    ImGui::PopStyleVar(2);
    ImGui::PopFont();

    const ImU32 idleLine = WithAlpha(IM_COL32(112, 112, 112, 255), opacity);
    draw->AddLine(
        ImVec2(layout.contentLeft, layout.underlineY),
        ImVec2(layout.contentRight, layout.underlineY),
        idleLine, 1.0f);

    if (active) {
        if (state.keyFocusStarted < 0.0) state.keyFocusStarted = elapsed;
        constexpr double revealSeconds = 0.55;
        const float reveal = state.reducedMotion ? 1.0f :
            SmoothStep(static_cast<float>((elapsed - state.keyFocusStarted) / revealSeconds));
        if (reveal > 0.0f) {
            const float center = (layout.contentLeft + layout.contentRight) * 0.5f;
            const float halfWidth = (layout.contentRight - layout.contentLeft) * 0.5f * reveal;
            draw->AddLine(
                ImVec2(center - halfWidth, layout.underlineY),
                ImVec2(center + halfWidth, layout.underlineY),
                WithAlpha(IM_COL32_WHITE, opacity), 1.0f);
        }
    } else {
        state.keyFocusStarted = -1.0;
    }

    if (state.progressStarted < 0.0 && submitted && state.accessKey[0] != '\0') {
        state.progressStarted = elapsed;
        std::string accessKey(state.accessKey.data());
        SecureZeroMemory(state.accessKey.data(),state.accessKey.size());
        state.loading = std::async(std::launch::async, [progress = state.progress,accessKey=std::move(accessKey)]() mutable {
            try {
                std::vector<unsigned char> decryptedPayload;
                const bool authorized=loader::DecryptEmbeddedPayload(accessKey,decryptedPayload);
                SecureZeroMemory(accessKey.data(),accessKey.size());
                if(!authorized)return loader::LoadResult{false,L"Key gecersiz."};
                const auto search = loader::FindTargetProcess();
                if (!search.target){SecureZeroMemory(decryptedPayload.data(),decryptedPayload.size());return loader::LoadResult{false,search.error};}
                auto result=loader::ManualMap(search.target->processId,
                    decryptedPayload.data(),decryptedPayload.size(),*progress);
                SecureZeroMemory(decryptedPayload.data(),decryptedPayload.size());return result;
            } catch (...) {
                SecureZeroMemory(accessKey.data(),accessKey.size());
                return loader::LoadResult{false, L"Yukleme sirasinda beklenmeyen hata olustu."};
            }
        });
    }
}

void RenderProgress(UiState& state, double elapsed, float opacity,
    const Layout& layout, ImFont* font)
{
    if (state.progressStarted < 0.0 || opacity <= 0.001f) return;

    const float target = static_cast<float>(state.progress->load());
    if (state.lastProgressFrame < 0.0) state.lastProgressFrame = elapsed;
    const float deltaSeconds = static_cast<float>(std::clamp(
        elapsed - state.lastProgressFrame, 0.0, 0.1));
    state.lastProgressFrame = elapsed;
    constexpr float kProgressUnitsPerSecond = 55.0f;
    state.displayedProgress = std::min(target,
        state.displayedProgress + kProgressUnitsPerSecond * deltaSeconds);

    if(state.succeeded&&state.displayedProgress>=99.95f&&state.completionStarted<0.0)
        state.completionStarted=elapsed;
    const float completion=state.completionStarted<0.0?0.0f:
        SmoothStep(static_cast<float>((elapsed-state.completionStarted)/.38));

    const int percentage = static_cast<int>(std::lround(state.displayedProgress));
    const float progress = Saturate(state.displayedProgress / 100.0f);

    char label[8]{};
    if (state.failed) std::snprintf(label, sizeof(label), "Hata");
    else std::snprintf(label, sizeof(label), "%d%%", percentage);
    const ImVec2 labelSize = font->CalcTextSizeA(
        font->LegacySize, FLT_MAX, 0.0f, label);
    const ImVec2 maximumLabel = font->CalcTextSizeA(
        font->LegacySize, FLT_MAX, 0.0f, "100%");

    const float availableWidth = std::max(1.0f,
        layout.contentRight - layout.contentLeft);
    const float maximumBarWidth = std::max(1.0f,
        availableWidth - layout.progressGap - maximumLabel.x);
    const float filledWidth = std::max(0.25f * layout.unit,
        maximumBarWidth * progress);
    const float lineTop = layout.centerY - layout.progressHeight * 0.5f;
    const float textTop = layout.centerY - labelSize.y * 0.5f;

    ImDrawList* draw = ImGui::GetWindowDrawList();
    const ImU32 white = WithAlpha(IM_COL32(255, 255, 255, 255), opacity*(1-completion));
    draw->AddRectFilled(
        ImVec2(layout.contentLeft, lineTop),
        ImVec2(layout.contentLeft + filledWidth,
            lineTop + layout.progressHeight),
        white, layout.progressHeight * 0.5f);
    draw->AddText(
        font, font->LegacySize,
        ImVec2(layout.contentLeft + filledWidth + layout.progressGap, textTop),
        white, label);

    if(completion>0.001f){
        constexpr char message[]="discord.gg/harakiri";
        const ImVec2 size=font->CalcTextSizeA(font->LegacySize,FLT_MAX,0.0f,message);
        float x=layout.contentLeft+(availableWidth-size.x)*.5f;
        const float baseY=layout.centerY-size.y*.5f+(1-completion)*1.25f*layout.unit;
        for(std::size_t i=0;i<sizeof(message)-1;++i){
            const char glyph[2]{message[i],0};
            const float stagger=Saturate(completion*1.14f-static_cast<float>(i)*.14f/(sizeof(message)-2));
            const float wave=.10f*layout.unit*std::sin(static_cast<float>(elapsed*3.2+i*.52))*stagger;
            const float glow=.82f+.18f*std::sin(static_cast<float>(elapsed*2.1+i*.28));
            draw->AddText(font,font->LegacySize,ImVec2(x,baseY+wave),
                WithAlpha(IM_COL32_WHITE,opacity*stagger*glow),glyph);
            x+=font->CalcTextSizeA(font->LegacySize,FLT_MAX,0.0f,glyph).x;
        }
    }
}

void RenderFrame(UiState& state,
    const TextureResource& logo, const FontSet& fonts)
{
    if (state.loading.valid() && state.loading.wait_for(std::chrono::seconds(0)) == std::future_status::ready) {
        const auto result = state.loading.get();
        state.failed = !result.success;
        state.succeeded = result.success;
        RecordLoadResult(result, state.progress->load());
        const int length = WideCharToMultiByte(CP_UTF8, 0, result.message.data(), static_cast<int>(result.message.size()), nullptr, 0, nullptr, nullptr);
        state.errorMessage.resize(length);
        if (length) WideCharToMultiByte(CP_UTF8, 0, result.message.data(), static_cast<int>(result.message.size()), state.errorMessage.data(), length, nullptr, nullptr);
    }
    const double elapsed = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - state.started).count();
    const float cardOpacity = state.reducedMotion ? 1.0f :
        SmoothStep(static_cast<float>(elapsed / 0.32));

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    const ImGuiIO& io = ImGui::GetIO();
    const Layout layout = CalculateLayout(io.DisplaySize, logo);
    ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f));
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::Begin("##loader-card", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoBringToFrontOnFocus);

    ImDrawList* draw = ImGui::GetWindowDrawList();
    if (!g_hasBackdrop) {
        draw->AddRectFilled(layout.cardMin, layout.cardMax,
            WithAlpha(IM_COL32(24, 24, 24, 255), cardOpacity));
    }
    draw->AddImage(logo.Reference(), layout.logoMin, layout.logoMax,
        ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f),
        WithAlpha(IM_COL32_WHITE, cardOpacity));

    float inputOpacity = 1.0f;
    float progressOpacity = 0.0f;
    if (!state.reducedMotion) {
        inputOpacity = SmoothStep(static_cast<float>((elapsed - 0.28) / 0.28));
    }
    if (state.progressStarted >= 0.0) {
        const float transition = state.reducedMotion ? 1.0f :
            SmoothStep(static_cast<float>((elapsed - state.progressStarted) / 0.28));
        inputOpacity *= 1.0f - transition;
        progressOpacity = transition;
    }

    RenderInput(state, elapsed, inputOpacity, layout, fonts.regular);
    RenderProgress(state, elapsed, progressOpacity, layout, fonts.medium);
    if (state.failed && !state.errorMessage.empty() && ImGui::IsWindowHovered())
        ImGui::SetTooltip("%s", state.errorMessage.c_str());

    ImGui::End();
    ImGui::PopStyleVar();

    ImGui::Render();
    constexpr float clearColor[4] = {0.0f, 0.0f, 0.0f, 0.0f};
    g_deviceContext->OMSetRenderTargets(1, &g_renderTarget, nullptr);
    g_deviceContext->ClearRenderTargetView(g_renderTarget, clearColor);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    g_swapChain->Present(1, 0);
}

LRESULT WINAPI WindowProcedure(HWND window, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(window, message, wParam, lParam)) return TRUE;

    switch (message) {
    case WM_ERASEBKGND:
        return 1;
    case WM_SIZE:
        if (g_device != nullptr && wParam != SIZE_MINIMIZED) {
            CleanupRenderTarget();
            g_swapChain->ResizeBuffers(0, LOWORD(lParam), HIWORD(lParam),
                DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_NCHITTEST: {
        const LRESULT hit = DefWindowProcW(window, message, wParam, lParam);
        if (hit == HTCLIENT) {
            POINT point{GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)};
            ScreenToClient(window, &point);
            if (point.y < static_cast<int>(4.0f * kDesignUnitPixels * g_dpiScale))
                return HTCAPTION;
        }
        return hit;
    }
    case WM_SYSCOMMAND:
        if ((wParam & 0xFFF0u) == SC_KEYMENU) return 0;
        break;
    case WM_NCCALCSIZE:
        if (wParam == TRUE) return 0;
        break;
    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) {
            DestroyWindow(window);
            return 0;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    default:
        break;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}

} // namespace

namespace loader {

int RunUi(HINSTANCE instance, int showCommand)
{
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    const UINT dpi = GetDpiForSystem();
    g_dpiScale = static_cast<float>(dpi) / kDpiBaseline;
    g_windowWidth = static_cast<int>(std::lround(
        kCardUnitsX * kDesignUnitPixels * g_dpiScale));
    g_windowHeight = static_cast<int>(std::lround(
        kCardUnitsY * kDesignUnitPixels * g_dpiScale));

    const WNDCLASSEXW windowClass{
        sizeof(WNDCLASSEXW), CS_CLASSDC, WindowProcedure, 0, 0,
        instance, nullptr, nullptr, nullptr, nullptr, L"commonLukeLoaderWindow", nullptr};
    RegisterClassExW(&windowClass);

    HWND window = CreateWindowExW(
        WS_EX_APPWINDOW,
        windowClass.lpszClassName, L"commonLuke Loader", WS_POPUP,
        0, 0, g_windowWidth, g_windowHeight,
        nullptr, nullptr, instance, nullptr);
    if (window == nullptr) {
        UnregisterClassW(windowClass.lpszClassName, instance);
        return 1;
    }

    PositionWindow(window);

    constexpr DWORD cornerPreference = 2;
    DwmSetWindowAttribute(window, 33, &cornerPreference, sizeof(cornerPreference));
    constexpr COLORREF borderColor = 0xFFFFFFFE;
    DwmSetWindowAttribute(window, 34, &borderColor, sizeof(borderColor));
    g_hasBackdrop = EnableBlur(window);

    if (!CreateDevice(window)) {
        CleanupDevice();
        DestroyWindow(window);
        UnregisterClassW(windowClass.lpszClassName, instance);
        return 2;
    }

    const HRESULT comResult = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    const bool uninitializeCom = SUCCEEDED(comResult);
    ResourceData logoResource;
    ResourceData regularResource;
    ResourceData mediumResource;
    ResourceData semiboldResource;
    if (!GetResourceData(instance, IDR_COMMONLUKE_LOGO_PNG, logoResource) ||
        !GetResourceData(instance, IDR_FREDOKA_REGULAR, regularResource) ||
        !GetResourceData(instance, IDR_FREDOKA_MEDIUM, mediumResource) ||
        !GetResourceData(instance, IDR_FREDOKA_SEMIBOLD, semiboldResource)) {
        CleanupDevice();
        DestroyWindow(window);
        UnregisterClassW(windowClass.lpszClassName, instance);
        if (uninitializeCom) CoUninitialize();
        return 3;
    }

    const UINT largeIconEdge = static_cast<UINT>(
        GetSystemMetricsForDpi(SM_CXICON, dpi));
    const UINT smallIconEdge = static_cast<UINT>(
        GetSystemMetricsForDpi(SM_CXSMICON, dpi));
    HICON largeIcon = CreateIconFromPng(logoResource, largeIconEdge);
    HICON smallIcon = CreateIconFromPng(logoResource, smallIconEdge);
    SendMessageW(window, WM_SETICON, ICON_BIG,
        reinterpret_cast<LPARAM>(largeIcon));
    SendMessageW(window, WM_SETICON, ICON_SMALL,
        reinterpret_cast<LPARAM>(smallIcon));

    TextureResource logo;
    const UINT targetLogoHeight = std::max<UINT>(1, static_cast<UINT>(std::lround(
        10.0f * kDesignUnitPixels * g_dpiScale)));
    if (!LoadTexture(logoResource, targetLogoHeight, logo)) {
        if (largeIcon != nullptr) DestroyIcon(largeIcon);
        if (smallIcon != nullptr) DestroyIcon(smallIcon);
        CleanupDevice();
        DestroyWindow(window);
        UnregisterClassW(windowClass.lpszClassName, instance);
        if (uninitializeCom) CoUninitialize();
        return 4;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.Fonts->Clear();

    const float usernameFontSize = 3.5f * kDesignUnitPixels * g_dpiScale;
    const float progressFontSize = 3.0f * kDesignUnitPixels * g_dpiScale;
    ImFontConfig fontConfiguration;
    fontConfiguration.FontDataOwnedByAtlas = false;
    FontSet fonts;
    fonts.regular = io.Fonts->AddFontFromMemoryTTF(
        const_cast<std::uint8_t*>(regularResource.bytes),
        static_cast<int>(regularResource.size), usernameFontSize,
        &fontConfiguration);
    fonts.medium = io.Fonts->AddFontFromMemoryTTF(
        const_cast<std::uint8_t*>(mediumResource.bytes),
        static_cast<int>(mediumResource.size), progressFontSize,
        &fontConfiguration);
    fonts.semibold = io.Fonts->AddFontFromMemoryTTF(
        const_cast<std::uint8_t*>(semiboldResource.bytes),
        static_cast<int>(semiboldResource.size), usernameFontSize,
        &fontConfiguration);
    if (fonts.regular == nullptr) fonts.regular = io.Fonts->AddFontDefault();
    if (fonts.medium == nullptr) fonts.medium = fonts.regular;
    if (fonts.semibold == nullptr) fonts.semibold = fonts.medium;
    io.FontDefault = fonts.regular;

    ImGuiStyle& style = ImGui::GetStyle();
    style.AntiAliasedLines = true;
    style.AntiAliasedFill = true;

    ImGui_ImplWin32_Init(window);
    ImGui_ImplDX11_Init(g_device, g_deviceContext);

    UiState state;
    BOOL animationsEnabled = TRUE;
    if (SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0,
            &animationsEnabled, 0)) {
        state.reducedMotion = animationsEnabled == FALSE;
    }

    RenderFrame(state, logo, fonts);
    ShowWindow(window, showCommand == SW_HIDE ? SW_SHOWNORMAL : showCommand);
    UpdateWindow(window);

    bool running = true;
    while (running) {
        MSG message{};
        while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
            if (message.message == WM_QUIT) running = false;
        }
        if (running) RenderFrame(state, logo, fonts);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    logo.view.Reset();
    if (largeIcon != nullptr) DestroyIcon(largeIcon);
    if (smallIcon != nullptr) DestroyIcon(smallIcon);
    CleanupDevice();
    DestroyWindow(window);
    UnregisterClassW(windowClass.lpszClassName, instance);
    if (uninitializeCom) CoUninitialize();
    return 0;
}

} // namespace loader
