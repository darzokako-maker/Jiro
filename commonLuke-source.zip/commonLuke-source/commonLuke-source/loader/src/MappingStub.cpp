#include "MappingStub.hpp"
#pragma runtime_checks("", off)

// Ordered sections delimit the copied code. No CRT calls or stack instrumentation
// may be emitted into this translation unit.
#pragma code_seg(push, ".aokistub$a")
__declspec(noinline) DWORD WINAPI loader::MappingStub(MappingData* data)
{
    // This first call publishes this copied routine's own unwind metadata.
    // It deliberately happens before entering the guarded region below.
    if (!data || !data->stubFunctionTable || !data->stubFunctionCount ||
        !data->stubImageBase || !data->addFunctionTable(data->stubFunctionTable,
            data->stubFunctionCount, data->stubImageBase)) return 10;

    __try {
        BYTE* base = data->base;
        auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(base +
            reinterpret_cast<IMAGE_DOS_HEADER*>(base)->e_lfanew);
        auto& opt = nt->OptionalHeader;
        const ULONG_PTR delta = reinterpret_cast<ULONG_PTR>(base) - opt.ImageBase;
        const auto reloc = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (delta != 0) {
            if (!reloc.Size) return 1;
            auto* block = reinterpret_cast<IMAGE_BASE_RELOCATION*>(base + reloc.VirtualAddress);
            BYTE* end = base + reloc.VirtualAddress + reloc.Size;
            while (reinterpret_cast<BYTE*>(block) < end) {
                if (block->SizeOfBlock < sizeof(*block) ||
                    block->SizeOfBlock > static_cast<SIZE_T>(end - reinterpret_cast<BYTE*>(block))) return 2;
                auto* entries = reinterpret_cast<WORD*>(block + 1);
                const DWORD count = (block->SizeOfBlock - sizeof(*block)) / sizeof(WORD);
                for (DWORD i = 0; i < count; ++i, ++entries) {
                    const WORD type = *entries >> 12;
                    if (type == IMAGE_REL_BASED_ABSOLUTE) continue;
                    if (type != IMAGE_REL_BASED_DIR64) return 3;
                    const ULONG_PTR rva = static_cast<ULONG_PTR>(block->VirtualAddress) + (*entries & 0xFFF);
                    if (rva > opt.SizeOfImage - sizeof(ULONG_PTR)) return 4;
                    *reinterpret_cast<ULONG_PTR*>(base + rva) += delta;
                }
                block = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<BYTE*>(block) + block->SizeOfBlock);
            }
        }
        const auto imports = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
        if (imports.Size) {
            auto* descriptor = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + imports.VirtualAddress);
            for (; descriptor->Name; ++descriptor) {
                HMODULE module = data->loadLibrary(reinterpret_cast<char*>(base + descriptor->Name));
                if (!module) return 5;
                auto* source = reinterpret_cast<ULONG_PTR*>(base +
                    (descriptor->OriginalFirstThunk ? descriptor->OriginalFirstThunk : descriptor->FirstThunk));
                auto* target = reinterpret_cast<ULONG_PTR*>(base + descriptor->FirstThunk);
                for (; *source; ++source, ++target) {
                    const char* name = IMAGE_SNAP_BY_ORDINAL64(*source)
                        ? reinterpret_cast<const char*>(*source & 0xFFFF)
                        : reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + *source)->Name;
                    *target = reinterpret_cast<ULONG_PTR>(data->getProcAddress(module, name));
                    if (!*target) return 6;
                }
            }
        }
        if (data->pcToFileHeaderIatRva && data->pcToFileHeaderShimRva &&
            data->runtimeContextRva) {
            auto* iat = reinterpret_cast<ULONG_PTR*>(
                base + data->pcToFileHeaderIatRva);
            auto* context = reinterpret_cast<ManualMapRuntimeContext*>(
                base + data->runtimeContextRva);
            context->imageBase = base;
            context->imageSize = opt.SizeOfImage;
            context->originalPcToFileHeader =
                reinterpret_cast<RtlPcToFileHeaderFunction>(*iat);
            *iat = reinterpret_cast<ULONG_PTR>(base + data->pcToFileHeaderShimRva);
        }
        const auto exceptions = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
        if (exceptions.Size && !data->addFunctionTable(
            reinterpret_cast<PRUNTIME_FUNCTION>(base + exceptions.VirtualAddress),
            exceptions.Size / sizeof(RUNTIME_FUNCTION), reinterpret_cast<DWORD64>(base))) return 7;
        // From this point, the host retains the image on failure: unwind registration
        // and callbacks may already have published addresses into the target.
        const auto tlsDirectory = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS];
        if (tlsDirectory.Size) {
            auto* tls = reinterpret_cast<IMAGE_TLS_DIRECTORY64*>(base + tlsDirectory.VirtualAddress);
            auto* callback = reinterpret_cast<PIMAGE_TLS_CALLBACK*>(tls->AddressOfCallBacks);
            for (; callback && *callback; ++callback) (*callback)(base, DLL_PROCESS_ATTACH, nullptr);
        }
        if (opt.AddressOfEntryPoint) {
            using Entry = BOOL(WINAPI*)(HINSTANCE, DWORD, LPVOID);
            if (!reinterpret_cast<Entry>(base + opt.AddressOfEntryPoint)(
                reinterpret_cast<HINSTANCE>(base), DLL_PROCESS_ATTACH, nullptr)) return 8;
        }
        using Initialize = DWORD(WINAPI*)(const wchar_t*);
        const DWORD initialization = reinterpret_cast<Initialize>(base + data->initializeRva)(data->logPath);
        if (initialization != 0) return 0x10000u | (initialization & 0xFFFFu);
        return 0;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return static_cast<DWORD>(GetExceptionCode());
    }
}
#pragma code_seg(pop)
