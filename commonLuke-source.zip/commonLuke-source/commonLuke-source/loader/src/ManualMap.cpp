#include "loader/ManualMap.hpp"
#include "MappingStub.hpp"

#include <TlHelp32.h>
#include <algorithm>
#include <cstring>
#include <cwchar>
#include <fstream>
#include <limits>
#include <optional>
#include <vector>

namespace {
struct Handle {
    HANDLE value = nullptr;
    ~Handle() { if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value); }
};
struct RemoteMemory {
    HANDLE process;
    void* address;
    ~RemoteMemory() { if (address) VirtualFreeEx(process, address, 0, MEM_RELEASE); }
    void Keep() { address = nullptr; }
};
struct StubBlob {
    std::vector<BYTE> bytes;
    DWORD codeOffset = 0;
    DWORD functionTableOffset = 0;
    DWORD functionCount = 0;
};
#pragma pack(push, 1)
struct UnwindHeader {
    BYTE versionAndFlags;
    BYTE prologSize;
    BYTE codeCount;
    BYTE frame;
};
struct ScopeRecord {
    DWORD begin;
    DWORD end;
    DWORD handler;
    DWORD target;
};
#pragma pack(pop)
constexpr BYTE kUnwindExceptionHandler = 1;
constexpr BYTE kUnwindTerminationHandler = 2;
constexpr BYTE kUnwindChainInfo = 4;

SIZE_T AlignUp(SIZE_T value, SIZE_T alignment)
{
    return (value + alignment - 1) & ~(alignment - 1);
}
bool Fits(SIZE_T offset, SIZE_T size, SIZE_T total)
{
    return offset <= total && size <= total - offset;
}
bool HasString(const std::vector<BYTE>& image, DWORD rva, SIZE_T prefix = 0)
{
    if (!Fits(rva, prefix + 1, image.size())) return false;
    const char* begin = reinterpret_cast<const char*>(image.data() + rva + prefix);
    return std::memchr(begin, '\0', image.size() - rva - prefix) != nullptr;
}
bool ValidateImports(const std::vector<BYTE>& image,
    const IMAGE_DATA_DIRECTORY& directory)
{
    if (!directory.Size) return true;
    if (directory.Size < sizeof(IMAGE_IMPORT_DESCRIPTOR) ||
        !Fits(directory.VirtualAddress, directory.Size, image.size())) return false;
    const SIZE_T maximumDescriptors = directory.Size / sizeof(IMAGE_IMPORT_DESCRIPTOR);
    for (SIZE_T index = 0; index < maximumDescriptors; ++index) {
        IMAGE_IMPORT_DESCRIPTOR descriptor{};
        std::memcpy(&descriptor, image.data() + directory.VirtualAddress +
            index * sizeof(descriptor), sizeof(descriptor));
        if (!descriptor.Name && !descriptor.FirstThunk &&
            !descriptor.OriginalFirstThunk) return true;
        if (!descriptor.Name || !descriptor.FirstThunk || !HasString(image, descriptor.Name))
            return false;
        SIZE_T source = descriptor.OriginalFirstThunk ?
            descriptor.OriginalFirstThunk : descriptor.FirstThunk;
        SIZE_T target = descriptor.FirstThunk;
        for (SIZE_T count = 0; count < image.size() / sizeof(ULONGLONG); ++count) {
            if (!Fits(source, sizeof(ULONGLONG), image.size()) ||
                !Fits(target, sizeof(ULONGLONG), image.size())) return false;
            ULONGLONG thunk = 0;
            std::memcpy(&thunk, image.data() + source, sizeof(thunk));
            if (!thunk) break;
            if (!IMAGE_SNAP_BY_ORDINAL64(thunk)) {
                if (thunk > std::numeric_limits<DWORD>::max() ||
                    !HasString(image, static_cast<DWORD>(thunk), sizeof(WORD))) return false;
            }
            source += sizeof(ULONGLONG);
            target += sizeof(ULONGLONG);
            if (count + 1 == image.size() / sizeof(ULONGLONG)) return false;
        }
    }
    return false;
}
std::optional<DWORD> FindImportIat(const std::vector<BYTE>& image,
    const IMAGE_DATA_DIRECTORY& directory, const char* wanted)
{
    if (!directory.Size) return {};
    const SIZE_T maximumDescriptors = directory.Size / sizeof(IMAGE_IMPORT_DESCRIPTOR);
    for (SIZE_T descriptorIndex = 0; descriptorIndex < maximumDescriptors;
            ++descriptorIndex) {
        IMAGE_IMPORT_DESCRIPTOR descriptor{};
        std::memcpy(&descriptor, image.data() + directory.VirtualAddress +
            descriptorIndex * sizeof(descriptor), sizeof(descriptor));
        if (!descriptor.Name && !descriptor.FirstThunk &&
            !descriptor.OriginalFirstThunk) break;
        SIZE_T source = descriptor.OriginalFirstThunk ?
            descriptor.OriginalFirstThunk : descriptor.FirstThunk;
        SIZE_T target = descriptor.FirstThunk;
        for (SIZE_T count = 0; count < image.size() / sizeof(ULONGLONG); ++count) {
            ULONGLONG thunk = 0;
            std::memcpy(&thunk, image.data() + source, sizeof(thunk));
            if (!thunk) break;
            if (!IMAGE_SNAP_BY_ORDINAL64(thunk)) {
                const char* name = reinterpret_cast<const char*>(image.data() +
                    static_cast<SIZE_T>(thunk) + sizeof(WORD));
                if (std::strcmp(name, wanted) == 0) {
                    if (target > std::numeric_limits<DWORD>::max()) return {};
                    return static_cast<DWORD>(target);
                }
            }
            source += sizeof(ULONGLONG);
            target += sizeof(ULONGLONG);
        }
    }
    return {};
}
bool ValidateExceptions(const std::vector<BYTE>& image,
    const IMAGE_DATA_DIRECTORY& directory)
{
    if (!directory.Size) return true;
    if (directory.Size % sizeof(RUNTIME_FUNCTION) != 0 ||
        !Fits(directory.VirtualAddress, directory.Size, image.size())) return false;
    DWORD previous = 0;
    const SIZE_T count = directory.Size / sizeof(RUNTIME_FUNCTION);
    for (SIZE_T index = 0; index < count; ++index) {
        RUNTIME_FUNCTION function{};
        std::memcpy(&function, image.data() + directory.VirtualAddress +
            index * sizeof(function), sizeof(function));
        if (function.BeginAddress >= function.EndAddress ||
            function.EndAddress > image.size() || function.UnwindData >= image.size() ||
            (index && function.BeginAddress < previous)) return false;
        previous = function.BeginAddress;
    }
    return true;
}
std::optional<DWORD> FindExport(const std::vector<BYTE>& image,
    const IMAGE_DATA_DIRECTORY& directory, const char* wanted)
{
    if (directory.Size < sizeof(IMAGE_EXPORT_DIRECTORY) ||
        !Fits(directory.VirtualAddress, directory.Size, image.size())) return {};
    IMAGE_EXPORT_DIRECTORY exports{};
    std::memcpy(&exports, image.data() + directory.VirtualAddress, sizeof(exports));
    const SIZE_T namesSize = static_cast<SIZE_T>(exports.NumberOfNames) * sizeof(DWORD);
    const SIZE_T ordinalsSize = static_cast<SIZE_T>(exports.NumberOfNames) * sizeof(WORD);
    const SIZE_T functionsSize = static_cast<SIZE_T>(exports.NumberOfFunctions) * sizeof(DWORD);
    if (!exports.NumberOfNames || !exports.NumberOfFunctions ||
        !Fits(exports.AddressOfNames, namesSize, image.size()) ||
        !Fits(exports.AddressOfNameOrdinals, ordinalsSize, image.size()) ||
        !Fits(exports.AddressOfFunctions, functionsSize, image.size())) return {};
    for (DWORD index = 0; index < exports.NumberOfNames; ++index) {
        DWORD nameRva = 0;
        WORD ordinal = 0;
        std::memcpy(&nameRva, image.data() + exports.AddressOfNames +
            static_cast<SIZE_T>(index) * sizeof(nameRva), sizeof(nameRva));
        std::memcpy(&ordinal, image.data() + exports.AddressOfNameOrdinals +
            static_cast<SIZE_T>(index) * sizeof(ordinal), sizeof(ordinal));
        if (ordinal >= exports.NumberOfFunctions || !HasString(image, nameRva)) return {};
        if (std::strcmp(reinterpret_cast<const char*>(image.data() + nameRva), wanted) != 0)
            continue;
        DWORD functionRva = 0;
        std::memcpy(&functionRva, image.data() + exports.AddressOfFunctions +
            static_cast<SIZE_T>(ordinal) * sizeof(functionRva), sizeof(functionRva));
        // Forwarded exports point back into the export directory; initialization
        // must be implemented by the mapped image itself.
        if (!functionRva || functionRva >= image.size() ||
            (functionRva >= directory.VirtualAddress &&
                functionRva < directory.VirtualAddress + directory.Size)) return {};
        return functionRva;
    }
    return {};
}
bool Write(HANDLE process, void* target, const void* source, SIZE_T size)
{
    SIZE_T written = 0;
    return WriteProcessMemory(process, target, source, size, &written) && written == size;
}
// Resolve forwarded exports against their actual owning module in the target.
ULONG_PTR RemoteFunction(DWORD pid, const void* function)
{
    HMODULE owner = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
        GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        reinterpret_cast<LPCWSTR>(function), &owner)) return 0;
    wchar_t path[32768]{};
    if (!GetModuleFileNameW(owner, path, static_cast<DWORD>(std::size(path)))) return 0;
    const auto name = std::filesystem::path(path).filename().wstring();
    Handle snapshot{CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid)};
    if (snapshot.value == INVALID_HANDLE_VALUE) return 0;
    MODULEENTRY32W module{sizeof(module)};
    if (Module32FirstW(snapshot.value, &module)) {
        do {
            if (_wcsicmp(name.c_str(), module.szModule) == 0) {
                return reinterpret_cast<ULONG_PTR>(module.modBaseAddr) +
                    (reinterpret_cast<ULONG_PTR>(function) - reinterpret_cast<ULONG_PTR>(owner));
            }
        } while (Module32NextW(snapshot.value, &module));
    }
    return 0;
}
std::optional<StubBlob> BuildStubBlob(ULONG_PTR remoteExceptionHandler,
    std::wstring& error)
{
    DWORD64 localImageBase = 0;
    const auto* function = RtlLookupFunctionEntry(
        reinterpret_cast<DWORD64>(&loader::MappingStub), &localImageBase, nullptr);
    if (!function || !localImageBase || function->BeginAddress >= function->EndAddress) {
        error = L"Mapping stub unwind kaydi bulunamadi.";
        return {};
    }
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(localImageBase);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        error = L"Loader PE basligi gecersiz.";
        return {};
    }
    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(
        localImageBase + dos->e_lfanew);
    const SIZE_T imageSize = nt->OptionalHeader.SizeOfImage;
    if (!Fits(function->BeginAddress,
            function->EndAddress - function->BeginAddress, imageSize) ||
        !Fits(function->UnwindData, sizeof(UnwindHeader), imageSize)) {
        error = L"Mapping stub unwind sinirlari gecersiz.";
        return {};
    }
    const BYTE* localUnwind = reinterpret_cast<const BYTE*>(
        localImageBase + function->UnwindData);
    UnwindHeader header{};
    std::memcpy(&header, localUnwind, sizeof(header));
    const BYTE version = header.versionAndFlags & 0x7;
    const BYTE flags = header.versionAndFlags >> 3;
    if ((version != 1 && version != 2) ||
        !(flags & kUnwindExceptionHandler) ||
        (flags & (kUnwindTerminationHandler | kUnwindChainInfo))) {
        error = L"Mapping stub beklenen SEH unwind biciminde degil.";
        return {};
    }
    const SIZE_T handlerOffset = AlignUp(sizeof(UnwindHeader) +
        static_cast<SIZE_T>(header.codeCount) * sizeof(WORD), sizeof(DWORD));
    if (!Fits(function->UnwindData, handlerOffset + sizeof(DWORD) * 2, imageSize)) {
        error = L"Mapping stub SEH verisi eksik.";
        return {};
    }
    DWORD scopeCount = 0;
    std::memcpy(&scopeCount, localUnwind + handlerOffset + sizeof(DWORD),
        sizeof(scopeCount));
    if (!scopeCount || scopeCount > 32) {
        error = L"Mapping stub SEH scope tablosu gecersiz.";
        return {};
    }
    const SIZE_T unwindSize = handlerOffset + sizeof(DWORD) * 2 +
        static_cast<SIZE_T>(scopeCount) * sizeof(ScopeRecord);
    if (!Fits(function->UnwindData, unwindSize, imageSize)) {
        error = L"Mapping stub SEH scope sinirlari gecersiz.";
        return {};
    }

    struct AuxiliaryFunction {
        RUNTIME_FUNCTION function{};
        SIZE_T unwindSize = 0;
        DWORD copiedUnwindOffset = 0;
    };
    const auto* originalScopes = reinterpret_cast<const ScopeRecord*>(
        localUnwind + handlerOffset + sizeof(DWORD) * 2);
    std::vector<AuxiliaryFunction> auxiliaries;
    DWORD codeEnd = function->EndAddress;
    for (DWORD index = 0; index < scopeCount; ++index) {
        const DWORD handler = originalScopes[index].handler;
        if (handler <= 1 || (handler >= function->BeginAddress &&
                handler < function->EndAddress)) continue;
        DWORD64 auxiliaryBase = 0;
        const auto* auxiliary = RtlLookupFunctionEntry(
            localImageBase + handler, &auxiliaryBase, nullptr);
        if (!auxiliary || auxiliaryBase != localImageBase ||
            handler < auxiliary->BeginAddress || handler >= auxiliary->EndAddress ||
            !Fits(auxiliary->UnwindData, sizeof(UnwindHeader), imageSize)) {
            error = L"Mapping stub SEH filter fonksiyonu bulunamadi.";
            return {};
        }
        if (std::any_of(auxiliaries.begin(), auxiliaries.end(),
                [&](const AuxiliaryFunction& item) {
                    return item.function.BeginAddress == auxiliary->BeginAddress;
                })) continue;
        UnwindHeader auxiliaryHeader{};
        std::memcpy(&auxiliaryHeader,
            reinterpret_cast<const void*>(localImageBase + auxiliary->UnwindData),
            sizeof(auxiliaryHeader));
        const BYTE auxiliaryVersion = auxiliaryHeader.versionAndFlags & 0x7;
        const BYTE auxiliaryFlags = auxiliaryHeader.versionAndFlags >> 3;
        const SIZE_T auxiliaryUnwindSize = AlignUp(sizeof(UnwindHeader) +
            static_cast<SIZE_T>(auxiliaryHeader.codeCount) * sizeof(WORD),
            sizeof(DWORD));
        if ((auxiliaryVersion != 1 && auxiliaryVersion != 2) || auxiliaryFlags ||
            !Fits(auxiliary->BeginAddress,
                auxiliary->EndAddress - auxiliary->BeginAddress, imageSize) ||
            !Fits(auxiliary->UnwindData, auxiliaryUnwindSize, imageSize)) {
            error = L"Mapping stub SEH filter unwind verisi desteklenmiyor.";
            return {};
        }
        auxiliaries.push_back({*auxiliary, auxiliaryUnwindSize, 0});
        codeEnd = (std::max)(codeEnd, auxiliary->EndAddress);
    }
    if (auxiliaries.empty()) {
        error = L"Mapping stub SEH filter fonksiyonu uretilmedi.";
        return {};
    }

    StubBlob output;
    output.codeOffset = 0x100;
    const DWORD codeStart = function->BeginAddress;
    const SIZE_T codeSize = codeEnd - codeStart;
    const DWORD unwindOffset = static_cast<DWORD>(AlignUp(
        output.codeOffset + codeSize, 16));
    DWORD nextOffset = static_cast<DWORD>(AlignUp(unwindOffset + unwindSize, 4));
    for (auto& auxiliary : auxiliaries) {
        auxiliary.copiedUnwindOffset = nextOffset;
        nextOffset = static_cast<DWORD>(AlignUp(nextOffset + auxiliary.unwindSize, 4));
    }
    const DWORD handlerThunkOffset = static_cast<DWORD>(AlignUp(
        nextOffset, 16));
    output.functionCount = 1 + static_cast<DWORD>(auxiliaries.size());
    output.functionTableOffset = static_cast<DWORD>(AlignUp(
        handlerThunkOffset + 12, alignof(RUNTIME_FUNCTION)));
    output.bytes.resize(AlignUp(output.functionTableOffset +
        static_cast<SIZE_T>(output.functionCount) * sizeof(RUNTIME_FUNCTION), 16));
    std::memcpy(output.bytes.data() + output.codeOffset,
        reinterpret_cast<const void*>(localImageBase + codeStart), codeSize);
    std::memcpy(output.bytes.data() + unwindOffset, localUnwind, unwindSize);
    for (const auto& auxiliary : auxiliaries) {
        std::memcpy(output.bytes.data() + auxiliary.copiedUnwindOffset,
            reinterpret_cast<const void*>(localImageBase + auxiliary.function.UnwindData),
            auxiliary.unwindSize);
    }

    DWORD copiedHandler = handlerThunkOffset;
    std::memcpy(output.bytes.data() + unwindOffset + handlerOffset,
        &copiedHandler, sizeof(copiedHandler));
    auto* copiedScopes = reinterpret_cast<ScopeRecord*>(output.bytes.data() +
        unwindOffset + handlerOffset + sizeof(DWORD) * 2);
    const auto translateCodeRva = [&](DWORD& rva, bool zeroAllowed,
        bool endAllowed) {
        if (zeroAllowed && !rva) return true;
        if (rva < codeStart || rva > codeEnd || (!endAllowed && rva == codeEnd))
            return false;
        rva = output.codeOffset + (rva - codeStart);
        return true;
    };
    for (DWORD index = 0; index < scopeCount; ++index) {
        if (!translateCodeRva(copiedScopes[index].begin, false, false) ||
            !translateCodeRva(copiedScopes[index].end, false, true) ||
            (copiedScopes[index].handler > 1 &&
                !translateCodeRva(copiedScopes[index].handler, false, false)) ||
            !translateCodeRva(copiedScopes[index].target, true, false)) {
            error = L"Mapping stub SEH adresleri tasinamadi.";
            return {};
        }
    }

    BYTE* thunk = output.bytes.data() + handlerThunkOffset;
    thunk[0] = 0x48; // mov rax, immediate64
    thunk[1] = 0xB8;
    std::memcpy(thunk + 2, &remoteExceptionHandler, sizeof(remoteExceptionHandler));
    thunk[10] = 0xFF; // jmp rax
    thunk[11] = 0xE0;
    std::vector<RUNTIME_FUNCTION> copiedFunctions;
    copiedFunctions.push_back({
        output.codeOffset + (function->BeginAddress - codeStart),
        output.codeOffset + (function->EndAddress - codeStart), unwindOffset});
    for (const auto& auxiliary : auxiliaries) {
        copiedFunctions.push_back({
            output.codeOffset + (auxiliary.function.BeginAddress - codeStart),
            output.codeOffset + (auxiliary.function.EndAddress - codeStart),
            auxiliary.copiedUnwindOffset});
    }
    std::sort(copiedFunctions.begin(), copiedFunctions.end(),
        [](const RUNTIME_FUNCTION& left, const RUNTIME_FUNCTION& right) {
            return left.BeginAddress < right.BeginAddress;
        });
    std::memcpy(output.bytes.data() + output.functionTableOffset,
        copiedFunctions.data(), copiedFunctions.size() * sizeof(RUNTIME_FUNCTION));
    return output;
}
bool RemoveRemoteFunctionTable(HANDLE process, ULONG_PTR deleteFunction,
    PRUNTIME_FUNCTION table)
{
    Handle thread{CreateRemoteThread(process, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(deleteFunction), table, 0, nullptr)};
    if (!thread.value || WaitForSingleObject(thread.value, 5000) != WAIT_OBJECT_0)
        return false;
    DWORD result = 0;
    return GetExitCodeThread(thread.value, &result) && result != 0;
}
DWORD Protection(DWORD flags)
{
    const bool execute = (flags & IMAGE_SCN_MEM_EXECUTE) != 0;
    const bool read = (flags & IMAGE_SCN_MEM_READ) != 0;
    const bool write = (flags & IMAGE_SCN_MEM_WRITE) != 0;
    if (execute) return write ? PAGE_EXECUTE_READWRITE : read ? PAGE_EXECUTE_READ : PAGE_EXECUTE;
    return write ? PAGE_READWRITE : read ? PAGE_READONLY : PAGE_NOACCESS;
}
}

#if !defined(AOKI_EMBEDDED_PAYLOAD)
loader::LoadResult loader::ManualMap(DWORD processId, const std::filesystem::path& dllPath,
    std::atomic<int>& progress)
{
    const auto fail = [](const wchar_t* message) { return LoadResult{false, message}; };
    progress = 10;
    std::ifstream file(dllPath, std::ios::binary | std::ios::ate);
    if (!file) return fail(L"commonLuke.dll loader'in yaninda bulunamadi.");
    const auto length = file.tellg();
    if (length < static_cast<std::streamoff>(sizeof(IMAGE_DOS_HEADER)) || length > 128 * 1024 * 1024)
        return fail(L"DLL boyutu gecersiz.");
    std::vector<BYTE> bytes(static_cast<SIZE_T>(length));
    file.seekg(0);
    if (!file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size())))
        return fail(L"DLL okunamadi.");
    return ManualMap(processId,bytes.data(),bytes.size(),progress);
}
#endif

loader::LoadResult loader::ManualMap(DWORD processId,const unsigned char* dllBytes,
    std::size_t dllSize,std::atomic<int>& progress)
{
    const auto fail = [](const wchar_t* message) { return LoadResult{false, message}; };
    progress = 10;
    if(!dllBytes||dllSize<sizeof(IMAGE_DOS_HEADER)||dllSize>128ULL*1024*1024)
        return fail(L"Gomulu DLL boyutu gecersiz.");
    std::vector<BYTE> bytes(dllBytes,dllBytes+dllSize);
    IMAGE_DOS_HEADER dos{};
    std::memcpy(&dos, bytes.data(), sizeof(dos));
    if (dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew < 0 ||
        !Fits(dos.e_lfanew, sizeof(IMAGE_NT_HEADERS64), bytes.size())) return fail(L"Gecersiz PE basligi.");
    IMAGE_NT_HEADERS64 nt{};
    std::memcpy(&nt, bytes.data() + dos.e_lfanew, sizeof(nt));
    const auto& opt = nt.OptionalHeader;
    if (nt.Signature != IMAGE_NT_SIGNATURE || nt.FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64 ||
        !(nt.FileHeader.Characteristics & IMAGE_FILE_DLL) ||
        nt.FileHeader.SizeOfOptionalHeader != sizeof(IMAGE_OPTIONAL_HEADER64) ||
        opt.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC || opt.NumberOfRvaAndSizes != IMAGE_NUMBEROF_DIRECTORY_ENTRIES ||
        !opt.SizeOfImage || opt.SizeOfImage > 512 * 1024 * 1024 ||
        !opt.SizeOfHeaders || opt.SizeOfHeaders > opt.SizeOfImage || opt.SizeOfHeaders > bytes.size() ||
        opt.AddressOfEntryPoint >= opt.SizeOfImage) return fail(L"Desteklenen bir x64 DLL degil.");
    const SIZE_T sectionOffset = static_cast<SIZE_T>(dos.e_lfanew) + sizeof(nt);
    const SIZE_T sectionBytes = static_cast<SIZE_T>(nt.FileHeader.NumberOfSections) * sizeof(IMAGE_SECTION_HEADER);
    if (!nt.FileHeader.NumberOfSections || !Fits(sectionOffset, sectionBytes, opt.SizeOfHeaders))
        return fail(L"Section tablosu gecersiz.");
    std::vector<IMAGE_SECTION_HEADER> sections(nt.FileHeader.NumberOfSections);
    std::memcpy(sections.data(), bytes.data() + sectionOffset, sectionBytes);
    for (const auto& section : sections) {
        if (!Fits(section.PointerToRawData, section.SizeOfRawData, bytes.size()) ||
            !Fits(section.VirtualAddress, (std::max)(section.Misc.VirtualSize, section.SizeOfRawData), opt.SizeOfImage))
            return fail(L"DLL section sinirlari gecersiz.");
    }
    for (unsigned i = 0; i < IMAGE_NUMBEROF_DIRECTORY_ENTRIES; ++i) {
        if (i == IMAGE_DIRECTORY_ENTRY_SECURITY) continue; // Certificate uses file offsets.
        const auto& directory = opt.DataDirectory[i];
        if (directory.Size && !Fits(directory.VirtualAddress, directory.Size, opt.SizeOfImage))
            return fail(L"DLL directory sinirlari gecersiz.");
    }
    // This mapper supports TLS callbacks, not allocation of static thread-local storage.
    // Inspect the mapped layout before executing any code in the target.
    std::vector<BYTE> image(opt.SizeOfImage);
    std::memcpy(image.data(), bytes.data(), opt.SizeOfHeaders);
    for (const auto& section : sections) {
        if (section.SizeOfRawData) std::memcpy(image.data() + section.VirtualAddress,
            bytes.data() + section.PointerToRawData, section.SizeOfRawData);
    }
    if (!ValidateImports(image, opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT]))
        return fail(L"DLL import tablosu gecersiz.");
    if (!ValidateExceptions(image, opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION]))
        return fail(L"DLL exception tablosu gecersiz.");
    const auto initializeRva = FindExport(image,
        opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT], "AokiInitialize");
    if (!initializeRva)
        return fail(L"commonLuke DLL baslatma noktasi bulunamadi.");
    const auto pcToFileHeaderIat = FindImportIat(image,
        opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT], "RtlPcToFileHeader");
    const auto pcToFileHeaderShim = FindExport(image,
        opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT], "AokiRtlPcToFileHeader");
    const auto runtimeContext = FindExport(image,
        opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT], "AokiManualMapContext");
    const bool hasAnyRuntimeShim = pcToFileHeaderIat || pcToFileHeaderShim ||
        runtimeContext;
    if (hasAnyRuntimeShim && (!pcToFileHeaderIat || !pcToFileHeaderShim ||
            !runtimeContext))
        return fail(L"DLL C++ EH manual-map shim'i eksik.");
    const auto& tlsDir = opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS];
    if (tlsDir.Size) {
        if (tlsDir.Size < sizeof(IMAGE_TLS_DIRECTORY64)) return fail(L"TLS directory gecersiz.");
        IMAGE_TLS_DIRECTORY64 tls{};
        std::memcpy(&tls, image.data() + tlsDir.VirtualAddress, sizeof(tls));
        if (tls.EndAddressOfRawData != tls.StartAddressOfRawData || tls.SizeOfZeroFill)
            return fail(L"Bu DLL static TLS kullaniyor; manual map desteklemiyor.");
    }
    if (opt.DataDirectory[IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT].Size)
        return fail(L"Delay import kullanan DLL desteklenmiyor.");
    progress = 25;
    Handle process{OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
        PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ | SYNCHRONIZE, FALSE, processId)};
    if (!process.value) return fail(L"Hedef process acilamadi.");
    USHORT machine = 0, nativeMachine = 0;
    if (!IsWow64Process2(process.value, &machine, &nativeMachine) ||
        machine != IMAGE_FILE_MACHINE_UNKNOWN || nativeMachine != IMAGE_FILE_MACHINE_AMD64)
        return fail(L"Hedef x64 process degil.");
    MappingData data{};
    constexpr wchar_t logName[] = L"commonLuke.log";
    const auto pathCapacity = static_cast<DWORD>(std::size(data.logPath));
    const auto pathLength = GetModuleFileNameW(nullptr, data.logPath, pathCapacity);
    auto* separator = pathLength && pathLength < pathCapacity
        ? std::wcsrchr(data.logPath, L'\\') : nullptr;
    if (separator && static_cast<size_t>(separator + 1 - data.logPath) + std::size(logName) <= pathCapacity) {
        std::wmemcpy(separator + 1, logName, std::size(logName));
    } else {
        data.logPath[0] = L'\0';
    }
    data.loadLibrary = reinterpret_cast<decltype(data.loadLibrary)>(RemoteFunction(processId, reinterpret_cast<const void*>(&LoadLibraryA)));
    data.getProcAddress = reinterpret_cast<decltype(data.getProcAddress)>(RemoteFunction(processId, reinterpret_cast<const void*>(&GetProcAddress)));
    data.addFunctionTable = reinterpret_cast<decltype(data.addFunctionTable)>(RemoteFunction(processId, reinterpret_cast<const void*>(&RtlAddFunctionTable)));
    const ULONG_PTR deleteFunctionTable = RemoteFunction(processId,
        reinterpret_cast<const void*>(&RtlDeleteFunctionTable));
    const HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    const auto localExceptionHandler = ntdll ?
        GetProcAddress(ntdll, "__C_specific_handler") : nullptr;
    const ULONG_PTR remoteExceptionHandler = localExceptionHandler ?
        RemoteFunction(processId, reinterpret_cast<const void*>(localExceptionHandler)) : 0;
    if (!data.loadLibrary || !data.getProcAddress || !data.addFunctionTable ||
        !deleteFunctionTable || !remoteExceptionHandler)
        return fail(L"Hedef Windows API adresleri bulunamadi.");
    std::wstring stubError;
    const auto stubBlob = BuildStubBlob(remoteExceptionHandler, stubError);
    if (!stubBlob) return {false, std::move(stubError)};
    RemoteMemory allocation{process.value, VirtualAllocEx(process.value,
        reinterpret_cast<void*>(opt.ImageBase), opt.SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE)};
    if (!allocation.address) allocation.address = VirtualAllocEx(process.value, nullptr,
        opt.SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!allocation.address) return fail(L"DLL icin bellek ayrilamadi.");
    data.base = static_cast<BYTE*>(allocation.address);
    if (!Write(process.value, data.base, image.data(), image.size())) return fail(L"DLL bellege yazilamadi.");
    progress = 50;
    RemoteMemory parameters{process.value, VirtualAllocEx(process.value, nullptr, sizeof(data), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)};
    RemoteMemory code{process.value, VirtualAllocEx(process.value, nullptr,
        stubBlob->bytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)};
    if (!parameters.address || !code.address)
        return fail(L"Mapping kodu yazilamadi.");
    data.stubImageBase = reinterpret_cast<DWORD64>(code.address);
    data.stubFunctionTable = reinterpret_cast<PRUNTIME_FUNCTION>(
        static_cast<BYTE*>(code.address) + stubBlob->functionTableOffset);
    data.stubFunctionCount = stubBlob->functionCount;
    data.initializeRva = *initializeRva;
    if (hasAnyRuntimeShim) {
        data.pcToFileHeaderIatRva = *pcToFileHeaderIat;
        data.pcToFileHeaderShimRva = *pcToFileHeaderShim;
        data.runtimeContextRva = *runtimeContext;
    }
    if (!Write(process.value, parameters.address, &data, sizeof(data)) ||
        !Write(process.value, code.address, stubBlob->bytes.data(), stubBlob->bytes.size()))
        return fail(L"Mapping kodu yazilamadi.");
    DWORD previous = 0;
    if (!VirtualProtectEx(process.value, code.address, stubBlob->bytes.size(), PAGE_EXECUTE_READ, &previous) ||
        !FlushInstructionCache(process.value, code.address, stubBlob->bytes.size()) ||
        !FlushInstructionCache(process.value, data.base, opt.SizeOfImage))
        return fail(L"Mapping kodu hazirlanamadi.");
    Handle thread{CreateRemoteThread(process.value, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(static_cast<BYTE*>(code.address) +
            stubBlob->codeOffset), parameters.address, 0, nullptr)};
    if (!thread.value) return fail(L"Hedef thread baslatilamadi.");
    progress = 75;
    const DWORD wait = WaitForSingleObject(thread.value, 15000);
    if (wait != WAIT_OBJECT_0) {
        // Never free code/data while the target might still be executing it.
        allocation.Keep(); parameters.Keep(); code.Keep();
        return fail(L"Yukleme sonucu belirsiz (15 sn bekleme/hata). Tekrar denemeden oyunu yeniden baslatin.");
    }
    DWORD result = 0;
    if (!GetExitCodeThread(thread.value, &result)) {
        allocation.Keep(); code.Keep();
        return fail(L"Thread sonucu okunamadi; oyunu yeniden baslatin.");
    }
    const bool stubTableRemoved = RemoveRemoteFunctionTable(process.value,
        deleteFunctionTable, data.stubFunctionTable);
    if (!stubTableRemoved && result != 10) code.Keep();
    if (result) {
        if (result == 8 || (result & 0xFFFF0000u) == 0x10000u ||
            (result & 0x80000000u)) allocation.Keep();
        wchar_t codeText[16]{};
        swprintf_s(codeText, L"0x%08X", result);
        if (result & 0x80000000u)
            return {false, L"DLL baslatilirken SEH olustu (" +
                std::wstring(codeText) + L"). Oyunu yeniden baslatin."};
        if ((result & 0xFFFF0000u) == 0x10000u)
            return {false, L"commonLuke baslatilamadi (" +
                std::wstring(codeText) + L"). Oyunu yeniden baslatin."};
        return {false, L"DLL baslatilamadi (kod " + std::to_wstring(result) +
            L"). Oyunu yeniden baslatin."};
    }
    allocation.Keep();
    if (!VirtualProtectEx(process.value, data.base, opt.SizeOfHeaders, PAGE_READONLY, &previous))
        return fail(L"DLL calisti fakat baslik izinleri ayarlanamadi; oyunu yeniden baslatin.");
    for (const auto& section : sections) {
        const SIZE_T size = (std::max)(section.Misc.VirtualSize, section.SizeOfRawData);
        if (size && !VirtualProtectEx(process.value, data.base + section.VirtualAddress,
            size, Protection(section.Characteristics), &previous))
            return fail(L"DLL calisti fakat section izinleri ayarlanamadi; oyunu yeniden baslatin.");
    }
    progress = 100;
    return {true, L"commonLuke basariyla yuklendi."};
}
