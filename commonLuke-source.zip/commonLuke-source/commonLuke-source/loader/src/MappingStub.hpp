#pragma once
#include <Windows.h>

namespace loader {
using RtlPcToFileHeaderFunction = PVOID(NTAPI*)(PVOID, PVOID*);
struct ManualMapRuntimeContext {
    BYTE* imageBase;
    SIZE_T imageSize;
    RtlPcToFileHeaderFunction originalPcToFileHeader;
};
struct MappingData {
    decltype(&LoadLibraryA) loadLibrary;
    decltype(&GetProcAddress) getProcAddress;
    decltype(&RtlAddFunctionTable) addFunctionTable;
    PRUNTIME_FUNCTION stubFunctionTable;
    DWORD stubFunctionCount;
    DWORD64 stubImageBase;
    BYTE* base;
    DWORD initializeRva;
    DWORD pcToFileHeaderIatRva;
    DWORD pcToFileHeaderShimRva;
    DWORD runtimeContextRva;
    wchar_t logPath[32768];
};
DWORD WINAPI MappingStub(MappingData* data);
}
