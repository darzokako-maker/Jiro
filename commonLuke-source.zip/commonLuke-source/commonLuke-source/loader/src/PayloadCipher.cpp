#include "loader/PayloadCipher.hpp"
#include "EmbeddedAokiDll.hpp"

#include <Windows.h>
#include <bcrypt.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

namespace {

bool Success(NTSTATUS status) { return status >= 0; }

std::uint32_t RotateLeft(std::uint32_t value,unsigned amount)
{
    return (value<<amount)|(value>>(32-amount));
}

void QuarterRound(std::array<std::uint32_t,16>& state,int a,int b,int c,int d)
{
    state[a]+=state[b];state[d]=RotateLeft(state[d]^state[a],16);
    state[c]+=state[d];state[b]=RotateLeft(state[b]^state[c],12);
    state[a]+=state[b];state[d]=RotateLeft(state[d]^state[a],8);
    state[c]+=state[d];state[b]=RotateLeft(state[b]^state[c],7);
}

std::uint32_t Load32(const unsigned char* value)
{
    return static_cast<std::uint32_t>(value[0])|
        static_cast<std::uint32_t>(value[1])<<8|
        static_cast<std::uint32_t>(value[2])<<16|
        static_cast<std::uint32_t>(value[3])<<24;
}

void Store32(unsigned char* output,std::uint32_t value)
{
    output[0]=static_cast<unsigned char>(value);
    output[1]=static_cast<unsigned char>(value>>8);
    output[2]=static_cast<unsigned char>(value>>16);
    output[3]=static_cast<unsigned char>(value>>24);
}

void ChaCha20(std::vector<unsigned char>& bytes,const std::array<unsigned char,32>& key)
{
    constexpr std::array<std::uint32_t,4> constants{
        0x61707865u,0x3320646eu,0x79622d32u,0x6b206574u};
    for(std::size_t offset=0;offset<bytes.size();offset+=64){
        std::array<std::uint32_t,16> initial{};
        std::copy(constants.begin(),constants.end(),initial.begin());
        for(int i=0;i<8;++i)initial[4+i]=Load32(key.data()+i*4);
        initial[12]=1u+static_cast<std::uint32_t>(offset/64);
        for(int i=0;i<3;++i)initial[13+i]=Load32(kEmbeddedAokiDllNonce+i*4);
        auto state=initial;
        for(int round=0;round<10;++round){
            QuarterRound(state,0,4,8,12);QuarterRound(state,1,5,9,13);
            QuarterRound(state,2,6,10,14);QuarterRound(state,3,7,11,15);
            QuarterRound(state,0,5,10,15);QuarterRound(state,1,6,11,12);
            QuarterRound(state,2,7,8,13);QuarterRound(state,3,4,9,14);
        }
        std::array<unsigned char,64> stream{};
        for(int i=0;i<16;++i)Store32(stream.data()+i*4,state[i]+initial[i]);
        const auto count=std::min<std::size_t>(64,bytes.size()-offset);
        for(std::size_t i=0;i<count;++i)bytes[offset+i]^=stream[i];
        SecureZeroMemory(stream.data(),stream.size());
    }
}

bool Sha256(std::string_view input,std::array<unsigned char,32>& digest)
{
    BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
    DWORD objectSize=0,received=0;std::vector<unsigned char> object;
    bool ok=Success(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0));
    if(ok)ok=Success(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,
        reinterpret_cast<PUCHAR>(&objectSize),sizeof(objectSize),&received,0));
    if(ok){object.resize(objectSize);ok=Success(BCryptCreateHash(algorithm,&hash,object.data(),objectSize,nullptr,0,0));}
    if(ok)ok=Success(BCryptHashData(hash,reinterpret_cast<PUCHAR>(const_cast<char*>(input.data())),static_cast<ULONG>(input.size()),0));
    if(ok)ok=Success(BCryptFinishHash(hash,digest.data(),static_cast<ULONG>(digest.size()),0));
    if(hash)BCryptDestroyHash(hash);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);
    if(!object.empty())SecureZeroMemory(object.data(),object.size());return ok;
}

bool DeriveKey(const std::array<unsigned char,32>& digest,std::array<unsigned char,32>& key)
{
    BCRYPT_ALG_HANDLE algorithm=nullptr;
    bool ok=Success(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,BCRYPT_ALG_HANDLE_HMAC_FLAG));
    if(ok)ok=Success(BCryptDeriveKeyPBKDF2(algorithm,
        const_cast<PUCHAR>(digest.data()),static_cast<ULONG>(digest.size()),
        const_cast<PUCHAR>(kEmbeddedAokiDllSalt),16,kEmbeddedAokiDllIterations,
        key.data(),static_cast<ULONG>(key.size()),0));
    if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);return ok;
}

}

bool loader::DecryptEmbeddedPayload(std::string_view accessKey,
    std::vector<unsigned char>& output)
{
    std::array<unsigned char,32> digest{},key{};
    bool ok=!accessKey.empty()&&Sha256(accessKey,digest)&&DeriveKey(digest,key);
    if(ok){output.assign(kEmbeddedAokiDll,kEmbeddedAokiDll+kEmbeddedAokiDllSize);ChaCha20(output,key);}
    SecureZeroMemory(digest.data(),digest.size());SecureZeroMemory(key.data(),key.size());
    ok=ok&&output.size()>=2&&output[0]=='M'&&output[1]=='Z';
    if(!ok){if(!output.empty())SecureZeroMemory(output.data(),output.size());output.clear();}
    return ok;
}
