#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cstdint>

#include "client/ObjectResultLifecycle.hpp"

namespace {

void PromotionRunsAfterWrapperReturnsToVm()
{
    enum class State { Java, Vm };
    State state = State::Java;
    std::uintptr_t rooted = 0;
    constexpr std::uintptr_t oop = 0x12345678;
    constexpr std::uintptr_t global = 0x87654321;

    const auto result = client::methods::FinalizeObjectResult(
        oop,
        &rooted,
        [&] {
            assert(rooted == oop);
            state = State::Vm;
        },
        [&](std::uintptr_t* root) {
            return state == State::Vm && root == &rooted && *root == oop
                ? global
                : std::uintptr_t{};
        });

    assert(result == global);
    assert(state == State::Vm);
    assert(rooted == oop);
}

} // namespace

int main()
{
    PromotionRunsAfterWrapperReturnsToVm();
}
