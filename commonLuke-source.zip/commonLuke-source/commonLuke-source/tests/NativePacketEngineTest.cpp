#include "client/NativePacketEngine.hpp"

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <algorithm>
#include <array>
#include <cassert>
#include <cstring>
#include <cstdint>
#include <random>
#include <vector>
#include "miniz/miniz.h"

using namespace client::native_packets;

namespace {

std::array<std::uint8_t, 16> Bytes16(
    std::initializer_list<std::uint8_t> values)
{
    std::array<std::uint8_t, 16> result{};
    std::copy(values.begin(), values.end(), result.begin());
    return result;
}

void WriteVarInt(std::vector<std::uint8_t>& output, std::int32_t signedValue)
{
    auto value=static_cast<std::uint32_t>(signedValue);
    do {auto byte=static_cast<std::uint8_t>(value&0x7f);value>>=7;if(value)byte|=0x80;output.push_back(byte);} while(value);
}

std::vector<std::uint8_t> Deflate(const std::vector<std::uint8_t>& input)
{
    mz_ulong size=mz_compressBound(static_cast<mz_ulong>(input.size()));
    std::vector<std::uint8_t> output(size);
    assert(mz_compress2(output.data(),&size,input.data(),static_cast<mz_ulong>(input.size()),MZ_DEFAULT_COMPRESSION)==MZ_OK);
    output.resize(size);return output;
}

std::vector<std::uint8_t> ProofFrames(bool compression=false)
{
    if (compression)
        return {3,0,1,0x10,3,0,1,0x11,3,0,1,0x12};
    return {2,1,0x10,2,1,0x11,2,1,0x12};
}

void Cfb8KnownVector()
{
    const auto key = Bytes16({0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,
        0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c});
    const auto iv = Bytes16({0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f});
    const std::vector<std::uint8_t> plain{
        0x6b,0xc1,0xbe,0xe2,0x2e,0x40,0x9f,0x96,
        0xe9,0x3d,0x7e,0x11,0x73,0x93,0x17,0x2a};
    const std::vector<std::uint8_t> expected{
        0x3b,0x79,0x42,0x4c,0x9c,0x0d,0xd4,0x36,
        0xba,0xce,0x9e,0x0e,0xd4,0x58,0x6a,0x4f};
    const auto encrypted = testing::Cfb8Encrypt(key, iv, plain);
    assert(encrypted == expected);
    assert(testing::Cfb8Decrypt(key, iv, encrypted) == plain);
}

void ParserNotReadyPassesTrafficThrough()
{
    Reset();
    SetHandler([](PacketView&) { return Action::Pass; });
    const std::vector<std::uint8_t> ciphertext{0x91,0x02,0xfe,0x7c};
    assert(!CanRewrite(Direction::Outbound));
    assert(Transform(Direction::Inbound, ciphertext) == ciphertext);
    assert(Transform(Direction::Outbound, ciphertext) == ciphertext);
    SetHandler({});
    Reset();
}

void TransportResetPreservesRulesAndDisablesCipherState()
{
    const auto key = Bytes16({1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16});
    Reset();
    assert(SetMappedAction("Play.Clientbound.Velocity", Action::Cancel));
    PublishCipher(Direction::Inbound, key, key);
    assert(IsStreamActive(Direction::Inbound));
    ResetStreams();
    assert(!IsStreamActive(Direction::Inbound));
    assert(HasHandler());
    ClearMappedActions();
    assert(!HasHandler());
    Reset();
}

void InvalidBoundaryShadowsWithoutDroppingTraffic()
{
    const auto key=Bytes16({9,8,7,6,5,4,3,2,1,0,1,2,3,4,5,6});
    const auto iv=key;
    // A four-byte VarInt whose decoded frame size is larger than the engine's
    // maximum. This reproduces the live "invalid frame boundary" suspension.
    const std::vector<std::uint8_t> invalidPlain{0xff,0xff,0xff,0x7f};
    const auto invalidCipher=testing::Cfb8Encrypt(key,iv,invalidPlain);
    const std::vector<std::uint8_t> followingCipher{0x31,0x41,0x59,0x26};

    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView&) { return Action::Pass; });
    assert(!NeedsCipherResync(Direction::Inbound));
    PublishCipher(Direction::Inbound,key,iv);
    assert(Transform(Direction::Inbound,invalidCipher)==invalidCipher);
    assert(!NeedsCipherResync(Direction::Inbound));
    assert(Transform(Direction::Inbound,followingCipher)==followingCipher);
    PublishCipher(Direction::Inbound,key,iv);
    assert(!NeedsCipherResync(Direction::Inbound));
    SetHandler({});
    Reset();
}

void InitialPartialFrameNeverHoldsSocketTraffic()
{
    const auto key=Bytes16({6,5,4,3,2,1,0,9,8,7,6,5,4,3,2,1});
    const auto iv=key;
    // A plausible 1000-byte outer length followed by only a few bytes. With a
    // misaligned live register this is exactly how the outbound stream became
    // stuck waiting while keepalives were silently consumed.
    const std::vector<std::uint8_t> partialPlain{0xe8,0x07,0x10,0x20,0x30};
    const auto partialCipher=testing::Cfb8Encrypt(key,iv,partialPlain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView&) { return Action::Pass; });
    PublishCipher(Direction::Outbound,key,iv);
    assert(!CanRewrite(Direction::Outbound));
    assert(Transform(Direction::Outbound,partialCipher)==partialCipher);
    SetHandler({});
    Reset();
}

void MisalignedCfb8FindsFrameBoundaryAfterSelfSynchronization()
{
    const auto key=Bytes16({4,8,15,16,23,42,1,2,3,5,8,13,21,34,55,89});
    const auto iv=key;
    const auto stale=Bytes16({9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9});
    std::vector<std::uint8_t> plain(16,0x5a);
    plain.insert(plain.end(),{2,1,0x10,2,1,0x11,2,1,0x12,2,2,0x7e});
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);

    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Outbound,key,stale);
    const auto first=std::span<const std::uint8_t>(cipher).first(25);
    assert(Transform(Direction::Outbound,first)==std::vector<std::uint8_t>(first.begin(),first.end()));
    const auto next=std::span<const std::uint8_t>(cipher).subspan(25);
    assert(Transform(Direction::Outbound,next).empty());
    assert(!NeedsCipherResync(Direction::Outbound));
    SetHandler({});
    Reset();
}

void FragmentedMisalignedCfb8DoesNotRestartBeforeSelfSynchronization()
{
    const auto key=Bytes16({4,8,15,16,23,42,1,2,3,5,8,13,21,34,55,89});
    const auto iv=key;
    const auto stale=Bytes16({9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9});
    std::vector<std::uint8_t> plain(16,0x5a);
    plain.insert(plain.end(),{2,1,0x10,2,1,0x11,2,1,0x12,2,2,0x7e});
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);

    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Outbound,key,stale);
    std::size_t offset=0;
    for(const std::size_t size:{4u,4u,17u}) {
        const auto chunk=std::span<const std::uint8_t>(cipher).subspan(offset,size);
        assert(Transform(Direction::Outbound,chunk)==
            std::vector<std::uint8_t>(chunk.begin(),chunk.end()));
        assert(!NeedsCipherResync(Direction::Outbound));
        offset+=size;
    }
    const auto finalChunk=std::span<const std::uint8_t>(cipher).subspan(offset);
    assert(Transform(Direction::Outbound,finalChunk).empty());
    assert(!NeedsCipherResync(Direction::Outbound));
    SetHandler({});
    Reset();
}

void StaleRegistersDoNotCauseAResyncLoop()
{
    const auto key=Bytes16({4,8,15,16,23,42,1,2,3,5,8,13,21,34,55,89});
    const auto iv=key;
    std::vector<std::uint8_t> plain(16,0x5a);
    plain.insert(plain.end(),{2,1,0x10,2,1,0x11,2,1,0x12,2,2,0x7e});
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);

    for(unsigned seed=0;seed<256;++seed) {
        std::array<std::uint8_t,16> stale{};
        stale.fill(static_cast<std::uint8_t>(seed));
        Reset();
        SetCompressionEnabled(false);
        SetHandler([](PacketView& packet) {
            return packet.packetId==2 ? Action::Cancel : Action::Pass;
        });
        PublishCipher(Direction::Outbound,key,stale);
        std::size_t offset=0;
        for(const std::size_t size:{4u,4u,4u,13u}) {
            const auto chunk=std::span<const std::uint8_t>(cipher).subspan(offset,size);
            assert(Transform(Direction::Outbound,chunk)==
                std::vector<std::uint8_t>(chunk.begin(),chunk.end()));
            assert(!NeedsCipherResync(Direction::Outbound));
            offset+=size;
        }
        const auto finalChunk=std::span<const std::uint8_t>(cipher).subspan(offset);
        assert(Transform(Direction::Outbound,finalChunk).empty());
        assert(!NeedsCipherResync(Direction::Outbound));
    }
    SetHandler({});
    Reset();
}

void SplitValidationPassesRawThenEnablesEditing()
{
    const auto key=Bytes16({1,3,3,7,9,2,4,6,8,0,1,2,3,4,5,6});
    const auto iv=key;
    // First frame is split across NIO writes. Shadow validation deliberately
    // waits beyond CFB8's 16-byte self-sync window. A sacrificial valid frame
    // at offset 16 proves the boundary; the following frame is editable.
    const std::vector<std::uint8_t> plain{
        3,1,0xaa,0xbb,
        2,1,0x10, 2,1,0x11, 2,1,0x12, 2,1,0x13,
        2,1,0x7f,
        2,2,0xcc};
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Outbound,key,iv);
    assert(Transform(Direction::Outbound,
        std::span<const std::uint8_t>(cipher).first(2))==
        std::vector<std::uint8_t>(cipher.begin(),cipher.begin()+2));
    assert(Transform(Direction::Outbound,
        std::span<const std::uint8_t>(cipher).subspan(2,17))==
        std::vector<std::uint8_t>(cipher.begin()+2,cipher.begin()+19));
    assert(CanRewrite(Direction::Outbound));
    assert(Transform(Direction::Outbound,
        std::span<const std::uint8_t>(cipher).subspan(19)).empty());
    SetHandler({});
    Reset();
}

void PartialFrameAfterValidationNeverStarvesTheSocket()
{
    const auto key=Bytes16({8,6,7,5,3,0,9,1,2,4,6,8,10,12,14,16});
    const auto iv=key;
    // First frame proves a clean boundary. The next frame is split across
    // socket writes. A socket-layer hook must forward the partial ciphertext
    // immediately instead of waiting for a future write that may never come.
    const std::vector<std::uint8_t> plain{
        2,1,0x10,2,1,0x11,2,1,0x12,
        4,2,0xaa,0xbb,0xcc};
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Outbound,key,iv);
    const auto first=std::span<const std::uint8_t>(cipher).first(9);
    assert(Transform(Direction::Outbound,first)==
        std::vector<std::uint8_t>(first.begin(),first.end()));
    const auto partial=std::span<const std::uint8_t>(cipher).subspan(9,2);
    assert(Transform(Direction::Outbound,partial)==
        std::vector<std::uint8_t>(partial.begin(),partial.end()));
    assert(!NeedsCipherResync(Direction::Outbound));
    SetHandler({});
    Reset();
}

void FragmentedFrameBypassPreservesNextBoundary()
{
    const auto key=Bytes16({8,6,7,5,3,0,9,1,2,4,6,8,10,12,14,16});
    const auto iv=key;
    const std::vector<std::uint8_t> plain{
        2,1,0x10,2,1,0x11,2,1,0x12,
        4,1,0xaa,0xbb,0xcc,
        2,2,0x7f};
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Inbound,key,iv);
    const auto proof=std::span<const std::uint8_t>(cipher).first(9);
    assert(Transform(Direction::Inbound,proof)==
        std::vector<std::uint8_t>(proof.begin(),proof.end()));
    const auto partial=std::span<const std::uint8_t>(cipher).subspan(9,2);
    assert(Transform(Direction::Inbound,partial)==
        std::vector<std::uint8_t>(partial.begin(),partial.end()));
    const auto completionAndTarget=std::span<const std::uint8_t>(cipher).subspan(11);
    const auto translated=Transform(Direction::Inbound,completionAndTarget);
    assert(translated==std::vector<std::uint8_t>(cipher.begin()+11,cipher.begin()+14));
    SetHandler({});
    Reset();
}

void RecoveryProofWithTrailingPartialPreservesNextBoundary()
{
    const auto key=Bytes16({5,4,3,2,1,0,9,8,7,6,5,4,3,2,1,0});
    const auto iv=key;
    auto plain=ProofFrames();
    plain.insert(plain.end(),{
        4,1,0xaa,0xbb,0xcc,
        2,2,0x7f});
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);

    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId==2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Inbound,key,iv);

    const auto proofAndPartial=std::span<const std::uint8_t>(cipher).first(11);
    assert(Transform(Direction::Inbound,proofAndPartial)==
        std::vector<std::uint8_t>(proofAndPartial.begin(),proofAndPartial.end()));
    assert(CanRewrite(Direction::Inbound));

    const auto completionAndTarget=std::span<const std::uint8_t>(cipher).subspan(11);
    const auto translated=Transform(Direction::Inbound,completionAndTarget);
    assert(translated==std::vector<std::uint8_t>(cipher.begin()+11,cipher.begin()+14));
    SetHandler({});
    Reset();
}

void StreamHealthTracksTrafficAndExplicitResync()
{
    const auto key=Bytes16({1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16});
    const auto plain=ProofFrames();
    const auto cipher=testing::Cfb8Encrypt(key,key,plain);
    Reset();
    SetCompressionEnabled(false);
    PublishCipher(Direction::Inbound,key,key);
    assert(Transform(Direction::Inbound,cipher)==cipher);
    const auto health=GetStreamHealth(Direction::Inbound);
    assert(health.active && health.validated && !health.failed);
    assert(health.inputCalls==1 && health.inputBytes==cipher.size());
    assert(health.recoveries==1);
    RequestCipherResync(Direction::Inbound,"unit test");
    assert(!IsStreamActive(Direction::Inbound));
    assert(NeedsCipherResync(Direction::Inbound));
    PublishCipher(Direction::Inbound,key,key);
    assert(IsStreamActive(Direction::Inbound));
    assert(!NeedsCipherResync(Direction::Inbound));
    Reset();
}

void SinglePlausibleFrameCannotEnableEditing()
{
    const auto key=Bytes16({2,7,1,8,2,8,1,8,2,8,4,5,9,0,4,5});
    const auto iv=key;
    const auto stale=Bytes16({9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9});
    std::vector<std::uint8_t> plain(16,0x5a);
    // Three proof packets are required. The first two must remain transparent;
    // only the packet following the third proof may be cancelled.
    plain.insert(plain.end(),{2,1,0x10,2,1,0x11,2,1,0x12,2,2,0x7f});
    const auto cipher=testing::Cfb8Encrypt(key,iv,plain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet){return packet.packetId==2?Action::Cancel:Action::Pass;});
    PublishCipher(Direction::Outbound,key,stale);
    const auto prefix=std::span<const std::uint8_t>(cipher).first(22);
    assert(Transform(Direction::Outbound,prefix)==
        std::vector<std::uint8_t>(prefix.begin(),prefix.end()));
    const auto proof3=std::span<const std::uint8_t>(cipher).subspan(22,3);
    assert(Transform(Direction::Outbound,proof3)==
        std::vector<std::uint8_t>(proof3.begin(),proof3.end()));
    const auto target=std::span<const std::uint8_t>(cipher).subspan(25);
    assert(Transform(Direction::Outbound,target).empty());
    SetHandler({});Reset();
}

void RandomFragmentationNeverStarvesOrMutatesPassTraffic()
{
    std::mt19937 random(0xA01C0DEu);
    for (unsigned round=0;round<2000;++round) {
        std::array<std::uint8_t,16> key{};
        std::array<std::uint8_t,16> iv{};
        std::array<std::uint8_t,16> snapshot{};
        for(auto& byte:key)byte=static_cast<std::uint8_t>(random());
        for(auto& byte:iv)byte=static_cast<std::uint8_t>(random());
        snapshot=(round%2)==0?iv:std::array<std::uint8_t,16>{};

        std::vector<std::uint8_t> plain;
        const auto packetCount=8u+(random()%64u);
        for(unsigned packet=0;packet<packetCount;++packet) {
            const auto payloadSize=1u+(random()%48u);
            WriteVarInt(plain,static_cast<std::int32_t>(payloadSize+1));
            plain.push_back(static_cast<std::uint8_t>(random()%26u));
            for(unsigned i=0;i<payloadSize;++i)
                plain.push_back(static_cast<std::uint8_t>(random()));
        }
        const auto cipher=testing::Cfb8Encrypt(key,iv,plain);
        Reset();SetCompressionEnabled(false);
        SetHandler([](PacketView&){return Action::Pass;});
        PublishCipher(Direction::Outbound,key,snapshot);
        std::size_t offset=0;
        while(offset<cipher.size()) {
            const auto count=(std::min)(cipher.size()-offset,
                static_cast<std::size_t>(1u+(random()%97u)));
            const auto chunk=std::span<const std::uint8_t>(cipher).subspan(offset,count);
            const auto output=Transform(Direction::Outbound,chunk);
            assert(output.size()==chunk.size());
            assert(std::equal(output.begin(),output.end(),chunk.begin(),chunk.end()));
            assert(!NeedsCipherResync(Direction::Outbound));
            offset+=count;
        }
    }
    SetHandler({});Reset();
}

void CancelKeepsWireCipherCoherent()
{
    const auto key = Bytes16({0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15});
    const auto iv = key;
    // Prove the boundary, then pass id=1 and cancel id=2.
    auto plain=ProofFrames();
    plain.insert(plain.end(),{3,1,0xaa,0xbb,2,2,0xcc});
    const auto original = testing::Cfb8Encrypt(key, iv, plain);

    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        return packet.packetId == 2 ? Action::Cancel : Action::Pass;
    });
    PublishCipher(Direction::Outbound, key, iv);
    const auto proofSize=ProofFrames().size();
    assert(Transform(Direction::Outbound,
        std::span<const std::uint8_t>(original).first(proofSize))==
        std::vector<std::uint8_t>(original.begin(),original.begin()+proofSize));
    const auto translated = Transform(Direction::Outbound,
        std::span<const std::uint8_t>(original).subspan(proofSize));
    std::vector<std::uint8_t> combined(original.begin(),original.begin()+proofSize);
    combined.insert(combined.end(),translated.begin(),translated.end());
    const auto decoded = testing::Cfb8Decrypt(key, iv, combined);
    auto expected=ProofFrames();
    expected.insert(expected.end(),{3,1,0xaa,0xbb});
    assert(decoded == expected);
    SetHandler({});
    Reset();
}

void ModifyRebuildsFrame()
{
    const auto key = Bytes16({15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0});
    const auto iv = key;
    auto plain=ProofFrames();
    plain.insert(plain.end(),{3,7,0x10,0x20});
    const auto original = testing::Cfb8Encrypt(key, iv, plain);
    Reset();
    SetCompressionEnabled(false);
    SetHandler([](PacketView& packet) {
        packet.payload[1] = 0x99;
        return Action::Modify;
    });
    PublishCipher(Direction::Inbound, key, iv);
    const auto proofSize=ProofFrames().size();
    Transform(Direction::Inbound,std::span<const std::uint8_t>(original).first(proofSize));
    const auto translated = Transform(Direction::Inbound,
        std::span<const std::uint8_t>(original).subspan(proofSize));
    std::vector<std::uint8_t> combined(original.begin(),original.begin()+proofSize);
    combined.insert(combined.end(),translated.begin(),translated.end());
    const auto decoded = testing::Cfb8Decrypt(key, iv, combined);
    auto expected=ProofFrames();
    expected.insert(expected.end(),{3,7,0x10,0x99});
    assert(decoded == expected);
    SetHandler({});
    Reset();
}

void RegistryNameAndMappedCancel()
{
    assert(PacketName(Direction::Inbound, 18) == "Velocity");
    assert(PacketClassName(Direction::Inbound, 18) == "net/minecraft/Bi");
    assert(PacketName(Direction::Inbound, 21) == "EntityRelativeMove");
    assert(PacketName(Direction::Outbound, 18) == "UpdateSign");

    const auto key = Bytes16({1,1,2,3,5,8,13,21,34,55,89,144,233,1,2,3});
    const auto iv = key;
    auto plain=ProofFrames();
    plain.insert(plain.end(),{2,18,0x7f});
    const auto original = testing::Cfb8Encrypt(key, iv, plain);
    Reset();
    SetCompressionEnabled(false);
    assert(SetMappedAction("Play.Clientbound.Velocity", Action::Cancel));
    assert(HasHandler());
    PublishCipher(Direction::Inbound, key, iv);
    const auto proofSize=ProofFrames().size();
    Transform(Direction::Inbound,std::span<const std::uint8_t>(original).first(proofSize));
    assert(Transform(Direction::Inbound,
        std::span<const std::uint8_t>(original).subspan(proofSize)).empty());
    assert(SetMappedAction("Play.Clientbound.Velocity", Action::Pass));
    assert(!HasHandler());
    Reset();
}

void MutationReappliesCompressionThreshold()
{
    const auto key=Bytes16({3,1,4,1,5,9,2,6,5,3,5,8,9,7,9,3});
    const auto iv=key;
    std::vector<std::uint8_t> packetData{18};
    packetData.resize(301,0x5a);
    const auto zipped=Deflate(packetData);
    std::vector<std::uint8_t> envelope;
    WriteVarInt(envelope,static_cast<std::int32_t>(packetData.size()));
    envelope.insert(envelope.end(),zipped.begin(),zipped.end());
    std::vector<std::uint8_t> framed=ProofFrames(true);
    WriteVarInt(framed,static_cast<std::int32_t>(envelope.size()));
    framed.insert(framed.end(),envelope.begin(),envelope.end());

    Reset();SetCompressionThreshold(256);
    SetHandler([](PacketView& packet){packet.payload.assign(9,0x11);return Action::Modify;});
    PublishCipher(Direction::Inbound,key,iv);
    const auto encrypted=testing::Cfb8Encrypt(key,iv,framed);
    const auto proofSize=ProofFrames(true).size();
    Transform(Direction::Inbound,std::span<const std::uint8_t>(encrypted).first(proofSize));
    const auto translated=Transform(Direction::Inbound,
        std::span<const std::uint8_t>(encrypted).subspan(proofSize));
    std::vector<std::uint8_t> combined(encrypted.begin(),encrypted.begin()+proofSize);
    combined.insert(combined.end(),translated.begin(),translated.end());
    const auto decoded=testing::Cfb8Decrypt(key,iv,combined);
    // outer length=11, dataLength=0, packetId=18, nine payload bytes
    assert(decoded.size()==proofSize+12);
    assert(decoded[proofSize]==11&&decoded[proofSize+1]==0&&decoded[proofSize+2]==18);
    SetHandler({});SetCompressionThreshold(-1);Reset();
}

} // namespace

int main(int argc, char** argv)
{
    if (argc == 2 && std::strcmp(argv[1], "--fragmented-frame-regression") == 0) {
        FragmentedFrameBypassPreservesNextBoundary();
        return 0;
    }
    Cfb8KnownVector();
    InvalidBoundaryShadowsWithoutDroppingTraffic();
    InitialPartialFrameNeverHoldsSocketTraffic();
    MisalignedCfb8FindsFrameBoundaryAfterSelfSynchronization();
    FragmentedMisalignedCfb8DoesNotRestartBeforeSelfSynchronization();
    StaleRegistersDoNotCauseAResyncLoop();
    SplitValidationPassesRawThenEnablesEditing();
    PartialFrameAfterValidationNeverStarvesTheSocket();
    FragmentedFrameBypassPreservesNextBoundary();
    RecoveryProofWithTrailingPartialPreservesNextBoundary();
    StreamHealthTracksTrafficAndExplicitResync();
    SinglePlausibleFrameCannotEnableEditing();
    RandomFragmentationNeverStarvesOrMutatesPassTraffic();
    ParserNotReadyPassesTrafficThrough();
    TransportResetPreservesRulesAndDisablesCipherState();
    CancelKeepsWireCipherCoherent();
    ModifyRebuildsFrame();
    RegistryNameAndMappedCancel();
    MutationReappliesCompressionThreshold();
    return 0;
}
