include(FetchContent)
FetchContent_Declare(imgui
    GIT_REPOSITORY https://github.com/ocornut/imgui.git
    GIT_TAG c1aaac65e896a45f81f47a4d68f9959e0f86c859
    GIT_SHALLOW FALSE
)
FetchContent_MakeAvailable(imgui)
