package client.packethook;
/** One callback per real input update; the original input object owns key handling. */
public final class MovementInput extends net.minecraft.VB {
    public final net.minecraft.VB delegate;
    public MovementInput(net.minecraft.VB delegate) { this.delegate = delegate; }
    private static native void afterInput(Object owner);
    @Override public void f() {
        delegate.f();
        J = delegate.J; M = delegate.M; W = delegate.W; w = delegate.w;
        afterInput(this);
    }
}
