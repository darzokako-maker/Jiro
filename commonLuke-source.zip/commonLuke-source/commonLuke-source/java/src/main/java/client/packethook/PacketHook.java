package client.packethook;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.LinkedHashSet;
import java.util.Set;

/** Proxy hook adapted from the reference PacketHook; no automatic startup. */
public final class PacketHook implements AutoCloseable {
    public static int payloadVersion() { return 1; }
    public static native int nativeBridgeVersion();
    public static native Object beforeSend(Object packet);
    public static native boolean beforeReceive(Object packet);

    private static final class NativeListener implements Listener {
        NativeListener() { }
        public Object onSend(Object packet) {
            return beforeSend(packet);
        }
        public boolean onReceive(Object packet) { return beforeReceive(packet); }
    }

    public static PacketHook installNative(Object manager, Class<?> packetType,
            Field channel, Field listener) throws ReflectiveOperationException {
        return install(manager, packetType, channel, listener, new NativeListener());
    }

    public interface Listener {
        /** Return a replacement packet, or null to cancel the send. */
        Object onSend(Object packet);
        /** Return false to cancel packet delivery. Runs on the calling network thread. */
        boolean onReceive(Object packet);
    }

    private final Object manager;
    private final Class<?> packetType;
    private final Field channelField;
    private final Field listenerField;
    private final Object originalChannel;
    private final Object originalListener;
    private final Object channelProxy;
    private final Object listenerProxy;

    private PacketHook(Object manager, Class<?> packetType, Field channelField,
                       Field listenerField, Listener listener) throws ReflectiveOperationException {
        this.manager = manager;
        this.packetType = packetType;
        this.channelField = channelField;
        this.listenerField = listenerField;
        channelField.setAccessible(true);
        listenerField.setAccessible(true);
        originalChannel = channelField.get(manager);
        originalListener = listenerField.get(manager);
        if (originalChannel == null || originalListener == null)
            throw new IllegalStateException("Connection channel/listener is not ready");
        if (isOurProxy(originalChannel) || isOurProxy(originalListener))
            throw new IllegalStateException("Close the previous PacketHook before reinstalling");
        channelProxy = proxy(originalChannel, packetType, listener, true);
        listenerProxy = proxy(originalListener, packetType, listener, false);
        if (!channelField.getType().isInstance(channelProxy)
                || !listenerField.getType().isInstance(listenerProxy))
            throw new IllegalArgumentException("Mapped fields must accept interface proxies");
        channelField.set(manager, channelProxy);
        try {
            listenerField.set(manager, listenerProxy);
        } catch (IllegalAccessException | RuntimeException failure) {
            channelField.set(manager, originalChannel);
            throw failure;
        }
    }

    /** Supply verified fields from mappings; no fixed memory offsets are assumed. */
    public static PacketHook install(Object manager, Class<?> packetType,
                                     Field channelField, Field listenerField,
                                     Listener listener) throws ReflectiveOperationException {
        if (manager == null || packetType == null || channelField == null
                || listenerField == null || listener == null)
            throw new NullPointerException("PacketHook arguments must be non-null");
        if (channelField.equals(listenerField)
                || Modifier.isStatic(channelField.getModifiers())
                || Modifier.isStatic(listenerField.getModifiers()))
            throw new IllegalArgumentException("Expected two distinct instance fields");
        return new PacketHook(manager, packetType, channelField, listenerField, listener);
    }

    public synchronized boolean isInstalled() throws IllegalAccessException {
        return channelField.get(manager) == channelProxy
            && listenerField.get(manager) == listenerProxy;
    }

    public void receive(Object packet) throws ReflectiveOperationException {
        if(packet==null||!packetType.isInstance(packet))throw new IllegalArgumentException("packet");
        Method dispatch=null;
        for(Method method:packetType.getMethods()) {
            Class<?>[] arguments=method.getParameterTypes();
            if(arguments.length==1&&arguments[0].isInstance(originalListener)&&method.getReturnType()==Void.TYPE) {
                if(dispatch!=null)throw new NoSuchMethodException("ambiguous packet dispatch");
                dispatch=method;
            }
        }
        if(dispatch==null)throw new NoSuchMethodException("packet listener dispatch");
        dispatch.invoke(packet,originalListener);
    }

    /** Direct native-requested send; bypasses beforeSend to avoid callback recursion. */
    public Object send(Object packet) throws Throwable {
        if (!packetType.isInstance(packet)) throw new IllegalArgumentException("Expected a packet");
        try {
            return channelField.getType().getMethod("writeAndFlush", Object.class)
                .invoke(originalChannel, packet);
        } catch (InvocationTargetException failure) {
            throw failure.getCause();
        }
    }

    /** Restore only fields still owned by this hook. */
    @Override
    public synchronized void close() throws IllegalAccessException {
        try {
            if (channelField.get(manager) == channelProxy)
                channelField.set(manager, originalChannel);
        } finally {
            if (listenerField.get(manager) == listenerProxy)
                listenerField.set(manager, originalListener);
        }
    }

    private static boolean isOurProxy(Object object) {
        return Proxy.isProxyClass(object.getClass())
            && Proxy.getInvocationHandler(object) instanceof Handler;
    }

    private static Object proxy(Object original, Class<?> packetType,
                                Listener listener, boolean send) {
        Set<Class<?>> interfaces = new LinkedHashSet<Class<?>>();
        collectInterfaces(original.getClass(), interfaces);
        if (interfaces.isEmpty()) throw new IllegalArgumentException("No proxy interfaces");
        return Proxy.newProxyInstance(original.getClass().getClassLoader(),
            interfaces.toArray(new Class<?>[interfaces.size()]),
            new Handler(original, packetType, listener, send));
    }

    private static void collectInterfaces(Class<?> type, Set<Class<?>> interfaces) {
        if (type == null) return;
        for (Class<?> iface : type.getInterfaces()) {
            if (interfaces.add(iface)) collectInterfaces(iface, interfaces);
        }
        collectInterfaces(type.getSuperclass(), interfaces);
    }

    private static final class Handler implements InvocationHandler {
        private final Object original;
        private final Class<?> packetType;
        private final Listener listener;
        private final boolean send;

        Handler(Object original, Class<?> packetType, Listener listener, boolean send) {
            this.original = original;
            this.packetType = packetType;
            this.listener = listener;
            this.send = send;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (args != null && args.length > 0 && packetType.isInstance(args[0])) {
                if (send && (method.getName().equals("write")
                        || method.getName().equals("writeAndFlush"))) {
                    Object packet = listener.onSend(args[0]);
                    if (packet == null) return cancelledSend(method, args);
                    if (!packetType.isInstance(packet))
                        throw new IllegalArgumentException("Replacement must be a packet");
                    args = args.clone();
                    args[0] = packet;
                } else if (!send && args.length == 1 && !listener.onReceive(args[0])) {
                    return defaultValue(method.getReturnType());
                }
            }
            try {
                return method.invoke(original, args);
            } catch (InvocationTargetException failure) {
                throw failure.getCause();
            }
        }

        private Object cancelledSend(Method method, Object[] args) throws Throwable {
            // Netty write(packet, promise) must complete the supplied promise too.
            if (args.length == 2) {
                try {
                    Class<?> promise = Class.forName("io.netty.channel.ChannelPromise", false,
                        original.getClass().getClassLoader());
                    if (promise.isInstance(args[1])) {
                        promise.getMethod("trySuccess").invoke(args[1]);
                        return args[1];
                    }
                } catch (ClassNotFoundException ignored) {
                    // Plain Java test interfaces have no Netty promise.
                }
            }
            if (!method.getReturnType().isPrimitive()) {
                try {
                    Class<?> channel = Class.forName("io.netty.channel.Channel", false,
                        original.getClass().getClassLoader());
                    Object future = channel.getMethod("newSucceededFuture").invoke(original);
                    if (method.getReturnType().isInstance(future)) return future;
                } catch (ClassNotFoundException ignored) {
                    // Allows testing with plain Java interfaces without Netty.
                }
            }
            return defaultValue(method.getReturnType());
        }
    }

    private static Object defaultValue(Class<?> type) {
        if (type == boolean.class) return Boolean.FALSE;
        if (type == char.class) return Character.valueOf('\0');
        if (type == byte.class) return Byte.valueOf((byte) 0);
        if (type == short.class) return Short.valueOf((short) 0);
        if (type == int.class) return Integer.valueOf(0);
        if (type == long.class) return Long.valueOf(0);
        if (type == float.class) return Float.valueOf(0);
        if (type == double.class) return Double.valueOf(0);
        return null;
    }
}
