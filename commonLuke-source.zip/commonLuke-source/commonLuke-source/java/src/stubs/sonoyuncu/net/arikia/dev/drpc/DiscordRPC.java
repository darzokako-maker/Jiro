package sonoyuncu.net.arikia.dev.drpc;

/** Compile-only signature stub; the game/native library provides the real class. */
public final class DiscordRPC {
    public static native byte[] nhd();
}
