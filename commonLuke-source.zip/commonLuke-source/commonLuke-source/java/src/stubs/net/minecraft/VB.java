package net.minecraft;
/** Compile-only signature stub; supplied by the game. */
public class VB {
    public float J, M;
    public boolean W, w;
    public void f() {}
}
