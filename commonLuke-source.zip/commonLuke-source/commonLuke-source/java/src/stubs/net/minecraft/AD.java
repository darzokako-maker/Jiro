package net.minecraft;

/** Compile-only signature stub; the game provides the real class. */
public class AD {
    public byte[] N;
}
