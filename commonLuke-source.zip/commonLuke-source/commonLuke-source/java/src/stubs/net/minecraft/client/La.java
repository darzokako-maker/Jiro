package net.minecraft.client;

import net.minecraft.Oj;

/** Compile-only signature stub; the game provides the real class. */
public class La {
    public La(S client, S2 resources) {
    }

    public byte[] K(Oj target) {
        return null;
    }
}
