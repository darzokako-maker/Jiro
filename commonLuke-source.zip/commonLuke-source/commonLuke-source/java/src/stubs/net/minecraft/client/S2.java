package net.minecraft.client;

/** Compile-only signature stub; the game provides the real class. */
public class S2 {
}
