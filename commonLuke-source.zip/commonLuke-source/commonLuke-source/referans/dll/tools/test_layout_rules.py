"""Resolver audit tests. No C++/Java build and no JVM execution."""
import contextlib
import io
import unittest

from audit_layout import PE, audit


class Image:
    def __init__(self, functions):
        self.functions = functions

    def function(self, name):
        return [(0x1000, self.functions[name])]


class LayoutTests(unittest.TestCase):
    rule = ('Test', 'member', 'accessor', '48 8B 41 ?', '3', '1', '8')

    def run_audit(self, functions, rules=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return audit(Image(functions), rules or [self.rule])

    def test_valid(self):
        self.assertTrue(self.run_audit({'accessor': bytes.fromhex('48 8B 41 38')}))

    def test_missing(self):
        self.assertFalse(self.run_audit({'accessor': b'\x90' * 16}))

    def test_ambiguous(self):
        self.assertFalse(self.run_audit({'accessor': bytes.fromhex('48 8B 41 38') * 2}))

    def test_unaligned(self):
        self.assertFalse(self.run_audit({'accessor': bytes.fromhex('48 8B 41 39')}))

    def test_signed_negative(self):
        self.assertFalse(self.run_audit({'accessor': bytes.fromhex('48 8B 41 F8')}))

    def test_cross_evidence_conflict(self):
        second = (*self.rule[:2], 'second', *self.rule[3:])
        self.assertFalse(self.run_audit({
            'accessor': bytes.fromhex('48 8B 41 38'),
            'second': bytes.fromhex('48 8B 41 40'),
        }, [self.rule, second]))


class LeafAnchorTests(unittest.TestCase):
    def fixture(self, leaf):
        image = PE.__new__(PE)
        image.data = bytearray(1024)
        image.sections = [(0x1000, 1024, 0, 1024)]
        image.bounds = {0x1000: 0x1006}
        # Caller prologue followed by E8 rel32 to the leaf at RVA 0x1100.
        image.data[:6] = b'\x90\xE8' + (0x1100 - 0x1006).to_bytes(4, 'little', signed=True)
        image.data[0x100:0x100 + len(leaf)] = leaf
        return image

    def test_direct_leaf(self):
        image = self.fixture(bytes.fromhex('48 89 41 70 33 C0 C3'))
        self.assertEqual(image.function('>90 E8 ? ? ? ?'),
                         [(0x1100, bytes.fromhex('48 89 41 70 33 C0 C3'))])

    def test_branch_rejected(self):
        with self.assertRaises(ValueError):
            self.fixture(bytes.fromhex('EB 00 C3')).function('>90 E8 ? ? ? ?')

    def test_missing_return_rejected(self):
        with self.assertRaises(ValueError):
            self.fixture(bytes.fromhex('33 C0') * 256).function('>90 E8 ? ? ? ?')

    def test_invalid_target_rejected(self):
        image = self.fixture(b'\xC3')
        image.data[2:6] = (0x70000000).to_bytes(4, 'little', signed=True)
        with self.assertRaises(ValueError):
            image.function('>90 E8 ? ? ? ?')


if __name__ == '__main__':
    unittest.main()
