"""Read-only PE/rule audit; never loads the JVM, builds code, or injects anything.

This checks byte signatures and cross-evidence, not HDE64 execution or JVM safety.
Usage: python dll/tools/audit_layout.py path/to/unpacked_jvm.dll
"""
import argparse
import hashlib
import re
import struct
from pathlib import Path


class PE:
    def __init__(self, data):
        self.data = data
        self.pe = self.u32(0x3C)
        if data[self.pe:self.pe + 4] != b'PE\0\0':
            raise ValueError('Not a PE image')
        optional = self.pe + 24
        if self.u16(optional) != 0x20B:
            raise ValueError('Requires PE32+')
        section_start = optional + self.u16(self.pe + 20)
        self.sections = []
        for i in range(self.u16(self.pe + 6)):
            at = section_start + i * 40
            virtual_size, rva, size, raw = struct.unpack_from('<4I', data, at + 8)
            self.sections.append((rva, max(virtual_size, size), raw, size))
        self.export_rva, self.export_size = struct.unpack_from('<II', data, optional + 112)
        pdata, size = struct.unpack_from('<II', data, optional + 112 + 3 * 8)
        self.bounds = {}
        self.chains = {}
        for i in range(size // 12):
            begin, end, unwind = struct.unpack('<III', self.read(pdata + i * 12, 12))
            self.bounds[begin] = end
            root = begin
            for depth in range(32):
                header = self.read(unwind, 4)
                if header[0] & 7 not in (1, 2):
                    break
                if not header[0] & 32:
                    self.chains[begin] = root
                    break
                at = unwind + 4 + ((header[2] + 1) & ~1) * 2
                root, _, unwind = struct.unpack('<III', self.read(at, 12))
        export = self.read(self.export_rva, 40)
        count = struct.unpack_from('<I', export, 24)[0]
        functions, names, ordinals = struct.unpack_from('<III', export, 28)
        self.exports = {}
        for i in range(count):
            name_rva = struct.unpack('<I', self.read(names + i * 4, 4))[0]
            offset = self.offset(name_rva, 1)
            name = data[offset:data.index(b'\0', offset)].decode('ascii')
            ordinal = struct.unpack('<H', self.read(ordinals + i * 2, 2))[0]
            self.exports[name] = struct.unpack('<I', self.read(functions + ordinal * 4, 4))[0]

    def u16(self, at):
        return struct.unpack_from('<H', self.data, at)[0]

    def u32(self, at):
        return struct.unpack_from('<I', self.data, at)[0]

    def offset(self, rva, size):
        for start, _, raw, raw_size in self.sections:
            if start <= rva and rva + size <= start + raw_size:
                return raw + rva - start
        raise ValueError(f'Unbacked RVA: {rva:#x}+{size}')

    def read(self, rva, size):
        at = self.offset(rva, size)
        return self.data[at:at + size]

    def function(self, name):
        if name.startswith(('@', '>')):
            anchor = [None if t == '?' else int(t, 16) for t in name[1:].split()]
            candidates = []
            for begin, end in self.bounds.items():
                if end - begin < len(anchor):
                    continue
                data = self.read(begin, len(anchor))
                if all(b is None or data[i] == b for i, b in enumerate(anchor)):
                    candidates.append(begin)
            if len(candidates) != 1:
                raise ValueError(f'Internal anchor has {len(candidates)} matches')
            start = candidates[0]
            if name.startswith('>'):
                if len(anchor) < 5 or anchor[-5] != 0xE8:
                    raise ValueError('Leaf anchor must end with a direct call')
                start += len(anchor) + int.from_bytes(self.read(start + len(anchor) - 4, 4), 'little', signed=True)
                # Conservative decoder for the supported straight-line leaf's
                # MOV/LEA/XOR/C7 subset; not a general x86 disassembler.
                n = 0
                while n < 512:
                    data = self.read(start + n, 16)
                    at = 1 if 0x40 <= data[0] <= 0x4F else 0
                    op = data[at]
                    at += 1
                    if op == 0xC3:
                        return [(start, self.read(start, n + at))]
                    if op not in (0x89, 0x8B, 0x8D, 0x33, 0xC7):
                        raise ValueError('Unsupported leaf instruction')
                    modrm = data[at]
                    at += 1
                    mod, rm = modrm >> 6, modrm & 7
                    if mod != 3 and rm == 4:
                        raise ValueError('Unsupported leaf SIB encoding')
                    if mod == 1:
                        at += 1
                    elif mod == 2 or (mod == 0 and rm == 5):
                        at += 4
                    if op == 0xC7:
                        at += 4
                    n += at
                raise ValueError('Leaf has no bounded return')
        else:
            start = self.exports[name]
        if self.export_rva <= start < self.export_rva + self.export_size:
            raise ValueError('Forwarded export')
        ranges = []
        for begin, end in self.bounds.items():
            if self.chains.get(begin) != start and not (name.startswith('@') and begin == start):
                continue
            if ranges and ranges[-1][1] == begin:
                ranges[-1] = (ranges[-1][0], end)
            else:
                ranges.append((begin, end))
        if not ranges or sum(b - a for a, b in ranges) > 0x10000:
            raise ValueError('Unsupported function bounds')
        return [(a, self.read(a, b - a)) for a, b in ranges]


RULE = re.compile(r'JVM_LAYOUT_RULE\((\w+),\s*(\w+),\s*"([^"]+)",\s*"([^"]+)",\s*(\d+),\s*(\d+),\s*(\d+)\)')


def audit(image, rules):
    values = {}
    errors = []
    for group, field, symbol, text, capture, width, alignment in rules:
        key = f'{group}.{field}'
        capture, width, alignment = map(int, (capture, width, alignment))
        pattern = [None if token == '?' else int(token, 16) for token in text.split()]
        try:
            matches = [(start, data, i) for start, data in image.function(symbol)
                       for i in range(len(data) - len(pattern) + 1)
                       if all(b is None or data[i + j] == b for j, b in enumerate(pattern))]
            if len(matches) != 1:
                raise ValueError(f'{len(matches)} matches, expected exactly 1')
            if width not in (1, 4) or capture + width > len(pattern):
                raise ValueError('Invalid capture')
            if any(b is not None for b in pattern[capture:capture + width]):
                raise ValueError('Captured offset must be wildcarded')
            start, data, position = matches[0]
            at = position + capture
            value = int.from_bytes(data[at:at + width], 'little', signed=True)
            if not 0 < value < 0x1000 or value % alignment:
                raise ValueError(f'Invalid/alignment-mismatched value {value}')
            if key in values and values[key] != value:
                raise ValueError(f'Conflicting evidence {values[key]:#x} versus {value:#x}')
            values[key] = value
            print(f'OK {key}={value:#x} via {symbol} RVA={start + position:#x}')
        except (ValueError, KeyError) as error:
            errors.append(f'{key} via {symbol}: {error}')
    for error in errors:
        print(f'FAIL {error}')
    print(f'SUMMARY: {len(values)} fields, {len(rules)} rules, {len(errors)} errors')
    return not errors


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('image', type=Path)
    args = parser.parse_args()
    data = args.image.read_bytes()
    print(f'SHA256={hashlib.sha256(data).hexdigest()}')
    rules_path = Path(__file__).resolve().parents[1] / 'src' / 'core' / 'JvmLayoutRules.inc'
    rules = RULE.findall(rules_path.read_text(encoding='utf-8'))
    if not rules:
        raise SystemExit('No rules parsed')
    raise SystemExit(0 if audit(PE(data), rules) else 1)
