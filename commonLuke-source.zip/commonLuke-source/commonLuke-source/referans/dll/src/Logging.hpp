#pragma once

inline constexpr bool kEnableLogging = false;

void LogImpl(const char* fmt, ...);

#define Log(...)                                                           \
    do {                                                                   \
        if constexpr (kEnableLogging) {                                    \
            LogImpl(__VA_ARGS__);                                          \
        }                                                                  \
    } while (false)
