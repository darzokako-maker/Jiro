#pragma once

#include <Windows.h>

#include <algorithm>
#include <cstdio>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "Logging.hpp"
#include "JvmApi.hpp"
#include "JvmMapper.hpp"
#include "miniz/miniz.h"

class ClassFileReconstructor {
private:
    enum : uint8_t {
        CP_Invalid                  = 0,
        CP_Utf8                     = 1,
        CP_Integer                  = 3,
        CP_Float                    = 4,
        CP_Long                     = 5,
        CP_Double                   = 6,
        CP_Class                    = 7,
        CP_String                   = 8,
        CP_Fieldref                 = 9,
        CP_Methodref                = 10,
        CP_InterfaceMethodref       = 11,
        CP_NameAndType              = 12,
        CP_MethodHandle             = 15,
        CP_MethodType               = 16,
        CP_InvokeDynamic            = 18,

        CP_UnresolvedClass          = 100,
        CP_ClassIndex               = 101,
        CP_StringIndex              = 102,
        CP_UnresolvedClassInError   = 103,
        CP_MethodHandleInError      = 104,
        CP_MethodTypeInError        = 105
    };

    enum : uint16_t {
        CM_HasLineNumbers       = 0x0001,
        CM_HasCheckedExceptions = 0x0002,
        CM_HasLocalVariables    = 0x0004,
        CM_HasExceptionTable    = 0x0008,
        CM_HasGenericSignature  = 0x0010,
        CM_HasMethodParameters  = 0x0020,
        CM_IsOverpass           = 0x0040,
        CM_HasMethodAnnotations = 0x0080,
        CM_HasParamAnnotations  = 0x0100,
        CM_HasTypeAnnotations   = 0x0200,
        CM_HasDefaultAnnotation = 0x0400
    };

    static constexpr uint16_t CLASS_ACCESS_MASK  = 0x7631;
    static constexpr uint16_t FIELD_ACCESS_MASK  = 0x50DF;
    static constexpr uint16_t METHOD_ACCESS_MASK = 0x1DFF;

    struct Buffer {
        std::vector<uint8_t> data;

        void u1(uint8_t value) {
            data.push_back(value);
        }

        void u2(uint16_t value) {
            data.push_back(static_cast<uint8_t>((value >> 8) & 0xFF));
            data.push_back(static_cast<uint8_t>(value & 0xFF));
        }

        void u4(uint32_t value) {
            data.push_back(static_cast<uint8_t>((value >> 24) & 0xFF));
            data.push_back(static_cast<uint8_t>((value >> 16) & 0xFF));
            data.push_back(static_cast<uint8_t>((value >> 8) & 0xFF));
            data.push_back(static_cast<uint8_t>(value & 0xFF));
        }

        void u8(uint64_t value) {
            u4(static_cast<uint32_t>(value >> 32));
            u4(static_cast<uint32_t>(value));
        }

        void bytes(const uint8_t* value, size_t size) {
            data.insert(data.end(), value, value + size);
        }

        void bytes(const std::vector<uint8_t>& value) {
            data.insert(data.end(), value.begin(), value.end());
        }
    };

    struct Context {
        uintptr_t klass = 0;
        uintptr_t cp = 0;
        uintptr_t tags = 0;
        int cpLength = 0;

        std::unordered_map<uintptr_t, uint16_t> symbolIndexes;
        std::unordered_map<std::string, uint16_t> utf8Indexes;
        std::unordered_map<std::string, uint16_t> classIndexes;

        std::string error;
    };

    template<typename T>
    static T Read(uintptr_t address) {
        return JvmApi::SafeRead<T>(address);
    }

    static bool ValidPointer(uintptr_t pointer) {
        return pointer > 0x10000;
    }

    static std::string ReadSymbolValue(uintptr_t symbol) {
        if (!ValidPointer(symbol))
            return {};

        const uint16_t length =
            Read<uint16_t>(symbol + JvmMapper::Symbol::length);

        if (length > 65535)
            return {};

        std::string result;
        result.resize(length);

        for (uint16_t i = 0; i < length; ++i) {
            result[i] = static_cast<char>(
                Read<uint8_t>(symbol + JvmMapper::Symbol::body + i));
        }

        return result;
    }

    static uint8_t CpTag(const Context& ctx, int index) {
        if (index <= 0 || index >= ctx.cpLength)
            return CP_Invalid;

        return Read<uint8_t>(
            ctx.tags + JvmMapper::CompactU2Array::data + index);
    }

    static uintptr_t CpSlot(const Context& ctx, int index) {
        return ctx.cp
            + JvmMapper::ConstantPool::base
            + static_cast<uintptr_t>(index) * sizeof(uintptr_t);
    }

    static uint16_t Low16(uint32_t value) {
        return static_cast<uint16_t>(value & 0xFFFF);
    }

    static uint16_t High16(uint32_t value) {
        return static_cast<uint16_t>((value >> 16) & 0xFFFF);
    }

    static uintptr_t ClassNameSymbol(const Context& ctx, int index) {
        const uint8_t tag = CpTag(ctx, index);
        uintptr_t slot = Read<uintptr_t>(CpSlot(ctx, index));

        if (tag == CP_Class) {
            if (!ValidPointer(slot))
                return 0;

            return Read<uintptr_t>(slot + JvmMapper::Klass::name);
        }

        if (tag == CP_UnresolvedClass ||
            tag == CP_UnresolvedClassInError) {

            return slot & ~static_cast<uintptr_t>(1);
        }

        if (tag == CP_ClassIndex) {
            const uint16_t utf8Index =
                Low16(Read<uint32_t>(CpSlot(ctx, index)));

            return Read<uintptr_t>(CpSlot(ctx, utf8Index));
        }

        return 0;
    }

    static uint16_t SymbolIndex(
        const Context& ctx,
        uintptr_t symbol)
    {
        symbol &= ~static_cast<uintptr_t>(1);

        auto byPointer = ctx.symbolIndexes.find(symbol);
        if (byPointer != ctx.symbolIndexes.end())
            return byPointer->second;

        const std::string value = ReadSymbolValue(symbol);
        auto byValue = ctx.utf8Indexes.find(value);

        return byValue == ctx.utf8Indexes.end()
            ? 0
            : byValue->second;
    }

    static uint16_t AttributeIndex(
        const Context& ctx,
        const char* name)
    {
        auto found = ctx.utf8Indexes.find(name);
        return found == ctx.utf8Indexes.end() ? 0 : found->second;
    }

    static bool PrepareConstantPool(Context& ctx) {
        ctx.cp = Read<uintptr_t>(
            ctx.klass + JvmMapper::InstanceKlass::constants);

        if (!ValidPointer(ctx.cp)) {
            ctx.error = "constant pool null";
            return false;
        }

        ctx.cpLength = Read<int32_t>(
            ctx.cp + JvmMapper::ConstantPool::length);

        if (ctx.cpLength <= 1 || ctx.cpLength > 65535) {
            ctx.error = "invalid constant pool length";
            return false;
        }

        ctx.tags = Read<uintptr_t>(
            ctx.cp + JvmMapper::ConstantPool::tags);

        if (!ValidPointer(ctx.tags)) {
            ctx.error = "constant pool tags null";
            return false;
        }

        const int tagLength = Read<int32_t>(
            ctx.tags + JvmMapper::CompactU2Array::length);

        if (tagLength < ctx.cpLength) {
            ctx.error = "constant pool tag array too short";
            return false;
        }


        for (int i = 1; i < ctx.cpLength; ++i) {
            const uint8_t tag = CpTag(ctx, i);

            if (tag == CP_Utf8) {
                uintptr_t symbol = Read<uintptr_t>(CpSlot(ctx, i));
                symbol &= ~static_cast<uintptr_t>(1);

                if (!ValidPointer(symbol)) {
                    ctx.error = "invalid UTF8 symbol";
                    return false;
                }

                const std::string value = ReadSymbolValue(symbol);

                ctx.symbolIndexes.emplace(symbol, static_cast<uint16_t>(i));
                ctx.utf8Indexes.emplace(value, static_cast<uint16_t>(i));
            }

            if (tag == CP_Long || tag == CP_Double)
                ++i;
        }


        for (int i = 1; i < ctx.cpLength; ++i) {
            const uint8_t tag = CpTag(ctx, i);

            if (tag == CP_Class ||
                tag == CP_UnresolvedClass ||
                tag == CP_UnresolvedClassInError ||
                tag == CP_ClassIndex) {

                uintptr_t symbol = ClassNameSymbol(ctx, i);
                const std::string name = ReadSymbolValue(symbol);

                if (!name.empty())
                    ctx.classIndexes.emplace(name, static_cast<uint16_t>(i));
            }

            if (tag == CP_Long || tag == CP_Double)
                ++i;
        }

        return true;
    }

    static bool WriteConstantPool(
        Context& ctx,
        Buffer& out)
    {
        out.u2(static_cast<uint16_t>(ctx.cpLength));

        for (int i = 1; i < ctx.cpLength; ++i) {
            const uint8_t tag = CpTag(ctx, i);
            const uintptr_t slot = CpSlot(ctx, i);

            switch (tag) {
            case CP_Utf8: {
                const uintptr_t symbol =
                    Read<uintptr_t>(slot) & ~static_cast<uintptr_t>(1);

                const std::string value = ReadSymbolValue(symbol);

                if (value.size() > 65535) {
                    ctx.error = "UTF8 constant too long";
                    return false;
                }

                out.u1(CP_Utf8);
                out.u2(static_cast<uint16_t>(value.size()));
                out.bytes(
                    reinterpret_cast<const uint8_t*>(value.data()),
                    value.size());
                break;
            }

            case CP_Integer:
            case CP_Float:
                out.u1(tag);
                out.u4(Read<uint32_t>(slot));
                break;

            case CP_Long:
            case CP_Double:
                out.u1(tag);
                out.u8(Read<uint64_t>(slot));
                ++i;
                break;

            case CP_Class:
            case CP_UnresolvedClass:
            case CP_UnresolvedClassInError: {
                const uintptr_t symbol = ClassNameSymbol(ctx, i);
                const uint16_t nameIndex = SymbolIndex(ctx, symbol);

                if (!nameIndex) {
                    ctx.error = "class name UTF8 index missing";
                    return false;
                }

                out.u1(CP_Class);
                out.u2(nameIndex);
                break;
            }

            case CP_ClassIndex:
                out.u1(CP_Class);
                out.u2(Low16(Read<uint32_t>(slot)));
                break;

            case CP_String: {
                uintptr_t symbol = Read<uintptr_t>(slot);
                const uint16_t stringIndex = SymbolIndex(ctx, symbol);

                if (!stringIndex) {
                    ctx.error = "string UTF8 index missing";
                    return false;
                }

                out.u1(CP_String);
                out.u2(stringIndex);
                break;
            }

            case CP_StringIndex:
                out.u1(CP_String);
                out.u2(Low16(Read<uint32_t>(slot)));
                break;

            case CP_Fieldref:
            case CP_Methodref:
            case CP_InterfaceMethodref:
            case CP_NameAndType:
            case CP_InvokeDynamic: {
                const uint32_t packed = Read<uint32_t>(slot);

                out.u1(tag);
                out.u2(Low16(packed));
                out.u2(High16(packed));
                break;
            }

            case CP_MethodHandle:
            case CP_MethodHandleInError: {
                const uint32_t packed = Read<uint32_t>(slot);

                out.u1(CP_MethodHandle);
                out.u1(static_cast<uint8_t>(Low16(packed)));
                out.u2(High16(packed));
                break;
            }

            case CP_MethodType:
            case CP_MethodTypeInError:
                out.u1(CP_MethodType);
                out.u2(Low16(Read<uint32_t>(slot)));
                break;

            default:
                ctx.error =
                    "unsupported constant pool tag "
                    + std::to_string(tag)
                    + " at index "
                    + std::to_string(i);
                return false;
            }
        }

        return true;
    }

    static int JavaOpcode(uint8_t raw) {
        if (raw <= 201)
            return raw;


        if (raw == 0xCA)
            return -1;

        if (raw >= 0xCB && raw <= 0xD2)
            return 0xB4;

        if (raw >= 0xD3 && raw <= 0xDB)
            return 0xB5;

        if (raw >= 0xDC && raw <= 0xDF)
            return 0x2A;

        if (raw >= 0xE0 && raw <= 0xE2)
            return 0x15;

        switch (raw) {
        case 0xE3: return 0xB6;
        case 0xE4: return 0xAB;
        case 0xE5: return 0xAB;
        case 0xE6: return 0x12;
        case 0xE7: return 0x13;
        case 0xE8: return 0xB1;
        case 0xE9: return 0xB6;
        default:   return -1;
        }
    }

    static int32_t ReadJavaS4(
        const std::vector<uint8_t>& code,
        size_t offset)
    {
        return static_cast<int32_t>(
            (static_cast<uint32_t>(code[offset]) << 24) |
            (static_cast<uint32_t>(code[offset + 1]) << 16) |
            (static_cast<uint32_t>(code[offset + 2]) << 8) |
            static_cast<uint32_t>(code[offset + 3]));
    }

    static int InstructionLength(
        const std::vector<uint8_t>& code,
        size_t bci,
        int opcode)
    {
        switch (opcode) {
        case 16:
        case 18:
        case 21:
        case 22:
        case 23:
        case 24:
        case 25:
        case 54:
        case 55:
        case 56:
        case 57:
        case 58:
        case 169:
        case 188:
            return 2;

        case 17:
        case 19:
        case 20:
        case 132:
        case 153:
        case 154:
        case 155:
        case 156:
        case 157:
        case 158:
        case 159:
        case 160:
        case 161:
        case 162:
        case 163:
        case 164:
        case 165:
        case 166:
        case 167:
        case 168:
        case 178:
        case 179:
        case 180:
        case 181:
        case 182:
        case 183:
        case 184:
        case 187:
        case 189:
        case 192:
        case 193:
        case 198:
        case 199:
            return 3;

        case 197:
            return 4;

        case 185:
        case 186:
        case 200:
        case 201:
            return 5;

        case 196:
            if (bci + 1 >= code.size())
                return -1;

            return code[bci + 1] == 132 ? 6 : 4;

        case 170: {
            const size_t aligned = (bci + 4) & ~static_cast<size_t>(3);

            if (aligned + 12 > code.size())
                return -1;

            const int32_t low = ReadJavaS4(code, aligned + 4);
            const int32_t high = ReadJavaS4(code, aligned + 8);

            if (high < low)
                return -1;

            const uint64_t count =
                static_cast<uint64_t>(
                    static_cast<int64_t>(high) -
                    static_cast<int64_t>(low) + 1);

            const uint64_t length =
                (aligned - bci) + 12 + count * 4;

            return length > 65535 ? -1 : static_cast<int>(length);
        }

        case 171: {
            const size_t aligned = (bci + 4) & ~static_cast<size_t>(3);

            if (aligned + 8 > code.size())
                return -1;

            const int32_t pairs = ReadJavaS4(code, aligned + 4);

            if (pairs < 0)
                return -1;

            const uint64_t length =
                (aligned - bci) + 8 +
                static_cast<uint64_t>(pairs) * 8;

            return length > 65535 ? -1 : static_cast<int>(length);
        }

        default:
            return 1;
        }
    }

    static bool CacheToCpIndex(
        const Context& ctx,
        uint32_t cacheIndex,
        uint16_t& cpIndex)
    {
        const uintptr_t cache = Read<uintptr_t>(
            ctx.cp + JvmMapper::ConstantPool::cache);

        if (!ValidPointer(cache))
            return false;

        const int32_t length = Read<int32_t>(
            cache + JvmMapper::ConstantPoolCache::length);

        if (cacheIndex >= static_cast<uint32_t>(length))
            return false;

        const uintptr_t entry =
            cache
            + JvmMapper::ConstantPoolCache::entries
            + static_cast<uintptr_t>(cacheIndex)
            * JvmMapper::ConstantPoolCacheEntry::size;

        const uintptr_t indices = Read<uintptr_t>(
            entry + JvmMapper::ConstantPoolCacheEntry::indices);

        cpIndex = static_cast<uint16_t>(indices & 0xFFFF);

        return cpIndex > 0 && cpIndex < ctx.cpLength;
    }

    static bool ReferenceToCpIndex(
        const Context& ctx,
        uint32_t referenceIndex,
        uint16_t& cpIndex)
    {
        const uintptr_t map = Read<uintptr_t>(
            ctx.cp + JvmMapper::ConstantPool::reference_map);

        if (!ValidPointer(map))
            return false;

        const int32_t length = Read<int32_t>(
            map + JvmMapper::CompactU2Array::length);

        if (referenceIndex >= static_cast<uint32_t>(length))
            return false;

        cpIndex = Read<uint16_t>(
            map
            + JvmMapper::CompactU2Array::data
            + static_cast<uintptr_t>(referenceIndex) * sizeof(uint16_t));

        return cpIndex > 0 && cpIndex < ctx.cpLength;
    }

    static bool ReconstructBytecode(
        Context& ctx,
        uintptr_t constMethod,
        std::vector<uint8_t>& result)
    {
        const uint16_t codeSize = Read<uint16_t>(
            constMethod + JvmMapper::ConstMethod::code_size);

        result.resize(codeSize);

        for (uint32_t i = 0; i < codeSize; ++i) {
            result[i] = Read<uint8_t>(
                constMethod + JvmMapper::ConstMethod::bytecode + i);
        }

        const uintptr_t cache = Read<uintptr_t>(
            ctx.cp + JvmMapper::ConstantPool::cache);

        for (size_t bci = 0; bci < result.size();) {
            const uint8_t rawOpcode = result[bci];
            const int opcode = JavaOpcode(rawOpcode);

            if (opcode < 0) {
                ctx.error =
                    "unsupported/breakpoint bytecode at bci "
                    + std::to_string(bci);
                return false;
            }

            const int length =
                InstructionLength(result, bci, opcode);

            if (length <= 0 ||
                bci + static_cast<size_t>(length) > result.size()) {
                ctx.error =
                    "invalid bytecode length at bci "
                    + std::to_string(bci);
                return false;
            }

            result[bci] = static_cast<uint8_t>(opcode);

            const bool memberInstruction =
                opcode == 178 ||
                opcode == 179 ||
                opcode == 180 ||
                opcode == 181 ||
                opcode == 182 ||
                opcode == 183 ||
                opcode == 184 ||
                opcode == 185;

            if (memberInstruction && length >= 3 &&
                ValidPointer(cache)) {

                const uint16_t cacheIndex =
                    static_cast<uint16_t>(
                        result[bci + 1] |
                        (static_cast<uint16_t>(result[bci + 2]) << 8));

                uint16_t cpIndex = 0;

                if (!CacheToCpIndex(ctx, cacheIndex, cpIndex)) {
                    ctx.error =
                        "bad CP-cache index at bci "
                        + std::to_string(bci);
                    return false;
                }

                result[bci + 1] =
                    static_cast<uint8_t>((cpIndex >> 8) & 0xFF);
                result[bci + 2] =
                    static_cast<uint8_t>(cpIndex & 0xFF);
            }

            if (opcode == 186 && length == 5 &&
                ValidPointer(cache)) {

                const uint32_t encoded =
                    static_cast<uint32_t>(result[bci + 1]) |
                    (static_cast<uint32_t>(result[bci + 2]) << 8) |
                    (static_cast<uint32_t>(result[bci + 3]) << 16) |
                    (static_cast<uint32_t>(result[bci + 4]) << 24);

                const uint32_t cacheIndex = ~encoded;
                uint16_t cpIndex = 0;

                if (!CacheToCpIndex(ctx, cacheIndex, cpIndex)) {
                    ctx.error =
                        "bad invokedynamic cache index at bci "
                        + std::to_string(bci);
                    return false;
                }

                result[bci + 1] =
                    static_cast<uint8_t>((cpIndex >> 8) & 0xFF);
                result[bci + 2] =
                    static_cast<uint8_t>(cpIndex & 0xFF);
                result[bci + 3] = 0;
                result[bci + 4] = 0;
            }

            if (rawOpcode == 0xE6) {
                uint16_t cpIndex = 0;

                if (!ReferenceToCpIndex(
                        ctx,
                        result[bci + 1],
                        cpIndex) ||
                    cpIndex > 255) {

                    ctx.error =
                        "bad fast_aldc reference at bci "
                        + std::to_string(bci);
                    return false;
                }

                result[bci + 1] = static_cast<uint8_t>(cpIndex);
            }

            if (rawOpcode == 0xE7) {
                const uint16_t referenceIndex =
                    static_cast<uint16_t>(
                        result[bci + 1] |
                        (static_cast<uint16_t>(result[bci + 2]) << 8));

                uint16_t cpIndex = 0;

                if (!ReferenceToCpIndex(
                        ctx,
                        referenceIndex,
                        cpIndex)) {

                    ctx.error =
                        "bad fast_aldc_w reference at bci "
                        + std::to_string(bci);
                    return false;
                }

                result[bci + 1] =
                    static_cast<uint8_t>((cpIndex >> 8) & 0xFF);
                result[bci + 2] =
                    static_cast<uint8_t>(cpIndex & 0xFF);
            }

            bci += static_cast<size_t>(length);
        }

        return true;
    }

    static uintptr_t LastU2Element(
        uintptr_t constMethod,
        uint16_t flags)
    {
        const int32_t sizeWords = Read<int32_t>(
            constMethod + JvmMapper::ConstMethod::const_method_size);

        if (sizeWords <= 0 || sizeWords > 0x100000)
            return 0;

        uintptr_t end =
            constMethod + static_cast<uintptr_t>(sizeWords) * 8;

        int annotationPointers = 0;

        if (flags & CM_HasMethodAnnotations) ++annotationPointers;
        if (flags & CM_HasParamAnnotations) ++annotationPointers;
        if (flags & CM_HasTypeAnnotations) ++annotationPointers;
        if (flags & CM_HasDefaultAnnotation) ++annotationPointers;

        return end
            - static_cast<uintptr_t>(annotationPointers) * sizeof(uintptr_t)
            - sizeof(uint16_t);
    }

    static uintptr_t MethodParametersStart(
        uintptr_t constMethod,
        uint16_t flags)
    {
        if (!(flags & CM_HasMethodParameters))
            return 0;

        uintptr_t lengthAddress =
            LastU2Element(constMethod, flags);

        if (flags & CM_HasGenericSignature)
            lengthAddress -= sizeof(uint16_t);

        const uint16_t length = Read<uint16_t>(lengthAddress);


        return lengthAddress
            - static_cast<uintptr_t>(length) * 2 * sizeof(uint16_t);
    }

    static uintptr_t CheckedExceptionsLengthAddress(
        uintptr_t constMethod,
        uint16_t flags)
    {
        if (!(flags & CM_HasCheckedExceptions))
            return 0;

        if (flags & CM_HasMethodParameters)
            return MethodParametersStart(constMethod, flags) - sizeof(uint16_t);

        uintptr_t result = LastU2Element(constMethod, flags);

        if (flags & CM_HasGenericSignature)
            result -= sizeof(uint16_t);

        return result;
    }

    static uintptr_t CheckedExceptionsStart(
        uintptr_t constMethod,
        uint16_t flags)
    {
        const uintptr_t lengthAddress =
            CheckedExceptionsLengthAddress(constMethod, flags);

        if (!lengthAddress)
            return 0;

        const uint16_t length = Read<uint16_t>(lengthAddress);

        return lengthAddress
            - static_cast<uintptr_t>(length) * sizeof(uint16_t);
    }

    static uintptr_t ExceptionTableLengthAddress(
        uintptr_t constMethod,
        uint16_t flags)
    {
        if (!(flags & CM_HasExceptionTable))
            return 0;

        if (flags & CM_HasCheckedExceptions)
            return CheckedExceptionsStart(constMethod, flags) - sizeof(uint16_t);

        if (flags & CM_HasMethodParameters)
            return MethodParametersStart(constMethod, flags) - sizeof(uint16_t);

        uintptr_t result = LastU2Element(constMethod, flags);

        if (flags & CM_HasGenericSignature)
            result -= sizeof(uint16_t);

        return result;
    }

    static bool BuildFieldSection(
        Context& ctx,
        Buffer& out)
    {
        const uint16_t fieldCount = Read<uint16_t>(
            ctx.klass + JvmMapper::InstanceKlass::java_fields_count);

        out.u2(fieldCount);

        if (!fieldCount)
            return true;

        const uintptr_t fields = Read<uintptr_t>(
            ctx.klass + JvmMapper::InstanceKlass::fields);

        if (!ValidPointer(fields)) {
            ctx.error = "fields array null";
            return false;
        }

        const int32_t arrayLength = Read<int32_t>(
            fields + JvmMapper::CompactU2Array::length);

        if (arrayLength < fieldCount * 6) {
            ctx.error = "fields array too short";
            return false;
        }

        const uintptr_t base =
            fields + JvmMapper::CompactU2Array::data;

        for (uint16_t i = 0; i < fieldCount; ++i) {
            const uintptr_t entry =
                base
                + static_cast<uintptr_t>(i)
                * JvmMapper::FieldInfo::entry_words
                * sizeof(uint16_t);

            const uint16_t access = Read<uint16_t>(
                entry
                + JvmMapper::FieldInfo::access_flags_word
                * sizeof(uint16_t));

            const uint16_t name = Read<uint16_t>(
                entry
                + JvmMapper::FieldInfo::name_index_word
                * sizeof(uint16_t));

            const uint16_t descriptor = Read<uint16_t>(
                entry
                + JvmMapper::FieldInfo::signature_index_word
                * sizeof(uint16_t));

            const uint16_t constantValue = Read<uint16_t>(
                entry
                + JvmMapper::FieldInfo::initval_index_word
                * sizeof(uint16_t));

            if (!name || !descriptor ||
                CpTag(ctx, name) != CP_Utf8 ||
                CpTag(ctx, descriptor) != CP_Utf8) {
                ctx.error =
                    "invalid field name/descriptor CP index at field "
                    + std::to_string(i);
                return false;
            }

            if (constantValue) {
                const uint8_t valueTag = CpTag(ctx, constantValue);
                const bool validConstant =
                    valueTag == CP_Integer ||
                    valueTag == CP_Float ||
                    valueTag == CP_Long ||
                    valueTag == CP_Double ||
                    valueTag == CP_String ||
                    valueTag == CP_StringIndex;

                if (!validConstant) {
                    ctx.error =
                        "invalid ConstantValue CP tag at field "
                        + std::to_string(i);
                    return false;
                }
            }

            out.u2(access & FIELD_ACCESS_MASK);
            out.u2(name);
            out.u2(descriptor);

            const uint16_t constantValueName =
                AttributeIndex(ctx, "ConstantValue");

            if (constantValue && constantValueName) {
                out.u2(1);
                out.u2(constantValueName);
                out.u4(2);
                out.u2(constantValue);
            } else {
                out.u2(0);
            }
        }

        return true;
    }

    static bool BuildMethodRecord(
        Context& ctx,
        uintptr_t method,
        std::vector<uint8_t>& record)
    {
        const uintptr_t constMethod = Read<uintptr_t>(
            method + JvmMapper::Method::const_method);

        if (!ValidPointer(constMethod)) {
            ctx.error = "method ConstMethod null";
            return false;
        }

        const uint16_t flags = Read<uint16_t>(
            constMethod + JvmMapper::ConstMethod::flags);

        const uint32_t rawAccess = Read<uint32_t>(
            method + JvmMapper::Method::access_flags);

        const uint16_t nameIndex = Read<uint16_t>(
            constMethod + JvmMapper::ConstMethod::name_index);

        const uint16_t descriptorIndex = Read<uint16_t>(
            constMethod + JvmMapper::ConstMethod::signature_index);

        const uint16_t codeSize = Read<uint16_t>(
            constMethod + JvmMapper::ConstMethod::code_size);

        Buffer methodOut;
        methodOut.u2(static_cast<uint16_t>(rawAccess) & METHOD_ACCESS_MASK);
        methodOut.u2(nameIndex);
        methodOut.u2(descriptorIndex);

        std::vector<std::vector<uint8_t>> attributes;

        if (codeSize) {
            const uint16_t codeName = AttributeIndex(ctx, "Code");

            if (!codeName) {
                ctx.error = "Code attribute name missing";
                return false;
            }

            std::vector<uint8_t> bytecode;

            if (!ReconstructBytecode(ctx, constMethod, bytecode))
                return false;

            Buffer codeBody;

            codeBody.u2(Read<uint16_t>(
                constMethod + JvmMapper::ConstMethod::max_stack));

            codeBody.u2(Read<uint16_t>(
                constMethod + JvmMapper::ConstMethod::max_locals));

            codeBody.u4(static_cast<uint32_t>(bytecode.size()));
            codeBody.bytes(bytecode);

            uint16_t exceptionCount = 0;
            uintptr_t exceptionStart = 0;

            if (flags & CM_HasExceptionTable) {
                const uintptr_t lengthAddress =
                    ExceptionTableLengthAddress(constMethod, flags);

                exceptionCount = Read<uint16_t>(lengthAddress);

                exceptionStart =
                    lengthAddress
                    - static_cast<uintptr_t>(exceptionCount)
                    * 4 * sizeof(uint16_t);
            }

            codeBody.u2(exceptionCount);

            for (uint16_t i = 0; i < exceptionCount; ++i) {
                const uintptr_t entry =
                    exceptionStart
                    + static_cast<uintptr_t>(i)
                    * 4 * sizeof(uint16_t);

                codeBody.u2(Read<uint16_t>(entry + 0));
                codeBody.u2(Read<uint16_t>(entry + 2));
                codeBody.u2(Read<uint16_t>(entry + 4));
                codeBody.u2(Read<uint16_t>(entry + 6));
            }


            codeBody.u2(0);

            Buffer codeAttribute;
            codeAttribute.u2(codeName);
            codeAttribute.u4(static_cast<uint32_t>(codeBody.data.size()));
            codeAttribute.bytes(codeBody.data);

            attributes.push_back(std::move(codeAttribute.data));
        }

        if (flags & CM_HasCheckedExceptions) {
            const uint16_t exceptionsName =
                AttributeIndex(ctx, "Exceptions");

            if (!exceptionsName) {
                ctx.error = "Exceptions attribute name missing";
                return false;
            }

            const uintptr_t lengthAddress =
                CheckedExceptionsLengthAddress(constMethod, flags);

            const uint16_t count = Read<uint16_t>(lengthAddress);
            const uintptr_t start =
                lengthAddress
                - static_cast<uintptr_t>(count) * sizeof(uint16_t);

            Buffer body;
            body.u2(count);

            for (uint16_t i = 0; i < count; ++i) {
                body.u2(Read<uint16_t>(
                    start + static_cast<uintptr_t>(i) * sizeof(uint16_t)));
            }

            Buffer attribute;
            attribute.u2(exceptionsName);
            attribute.u4(static_cast<uint32_t>(body.data.size()));
            attribute.bytes(body.data);

            attributes.push_back(std::move(attribute.data));
        }

        methodOut.u2(static_cast<uint16_t>(attributes.size()));

        for (const auto& attribute : attributes)
            methodOut.bytes(attribute);

        record = std::move(methodOut.data);
        return true;
    }

    static bool BuildMethodSection(
        Context& ctx,
        Buffer& out)
    {
        const uintptr_t methods = Read<uintptr_t>(
            ctx.klass + JvmMapper::InstanceKlass::methods);

        if (!ValidPointer(methods)) {
            out.u2(0);
            return true;
        }

        const int32_t methodCount = Read<int32_t>(
            methods + JvmMapper::Array::length);

        if (methodCount < 0 || methodCount > 65535) {
            ctx.error = "invalid method count";
            return false;
        }

        const uintptr_t base =
            methods + JvmMapper::Array::data;

        std::vector<std::vector<uint8_t>> records;
        records.reserve(methodCount);

        for (int32_t i = 0; i < methodCount; ++i) {
            const uintptr_t method = Read<uintptr_t>(
                base + static_cast<uintptr_t>(i) * sizeof(uintptr_t));

            if (!ValidPointer(method))
                continue;

            const uintptr_t constMethod = Read<uintptr_t>(
                method + JvmMapper::Method::const_method);

            if (!ValidPointer(constMethod))
                continue;

            const uint16_t flags = Read<uint16_t>(
                constMethod + JvmMapper::ConstMethod::flags);


            if (flags & CM_IsOverpass)
                continue;

            std::vector<uint8_t> record;

            if (!BuildMethodRecord(ctx, method, record))
                return false;

            records.push_back(std::move(record));
        }

        if (records.size() > 65535) {
            ctx.error = "too many methods";
            return false;
        }

        out.u2(static_cast<uint16_t>(records.size()));

        for (const auto& record : records)
            out.bytes(record);

        return true;
    }

    static bool BuildBootstrapMethods(
        Context& ctx,
        std::vector<uint8_t>& attribute)
    {
        const uintptr_t operands = Read<uintptr_t>(
            ctx.cp + JvmMapper::ConstantPool::operands);

        if (!ValidPointer(operands))
            return true;

        const int32_t operandLength = Read<int32_t>(
            operands + JvmMapper::CompactU2Array::length);

        if (operandLength <= 0)
            return true;

        const uintptr_t base =
            operands + JvmMapper::CompactU2Array::data;

        const uint32_t firstOffset =
            static_cast<uint32_t>(Read<uint16_t>(base)) |
            (static_cast<uint32_t>(Read<uint16_t>(base + 2)) << 16);

        const uint32_t bootstrapCount = firstOffset / 2;

        if (!bootstrapCount || bootstrapCount > 65535)
            return true;

        const uint16_t nameIndex =
            AttributeIndex(ctx, "BootstrapMethods");

        if (!nameIndex) {
            ctx.error = "BootstrapMethods attribute name missing";
            return false;
        }

        Buffer body;
        body.u2(static_cast<uint16_t>(bootstrapCount));

        for (uint32_t i = 0; i < bootstrapCount; ++i) {
            const uintptr_t offsetEntry =
                base + static_cast<uintptr_t>(i) * 4;

            const uint32_t tupleOffset =
                static_cast<uint32_t>(Read<uint16_t>(offsetEntry)) |
                (static_cast<uint32_t>(Read<uint16_t>(offsetEntry + 2)) << 16);

            if (tupleOffset + 2 > static_cast<uint32_t>(operandLength)) {
                ctx.error = "invalid bootstrap operand offset";
                return false;
            }

            const uintptr_t tuple =
                base + static_cast<uintptr_t>(tupleOffset) * sizeof(uint16_t);

            const uint16_t methodRef = Read<uint16_t>(tuple);
            const uint16_t argumentCount = Read<uint16_t>(tuple + 2);

            if (tupleOffset + 2 + argumentCount >
                static_cast<uint32_t>(operandLength)) {
                ctx.error = "invalid bootstrap argument count";
                return false;
            }

            body.u2(methodRef);
            body.u2(argumentCount);

            for (uint16_t argument = 0;
                 argument < argumentCount;
                 ++argument) {

                body.u2(Read<uint16_t>(
                    tuple + 4
                    + static_cast<uintptr_t>(argument)
                    * sizeof(uint16_t)));
            }
        }

        Buffer complete;
        complete.u2(nameIndex);
        complete.u4(static_cast<uint32_t>(body.data.size()));
        complete.bytes(body.data);

        attribute = std::move(complete.data);
        return true;
    }

    static bool BuildClass(
        uintptr_t klass,
        std::vector<uint8_t>& output,
        std::string& error)
    {
        Context ctx;
        ctx.klass = klass;

        if (!PrepareConstantPool(ctx)) {
            error = ctx.error;
            return false;
        }

        Buffer out;
        out.u4(0xCAFEBABE);

        out.u2(Read<uint16_t>(
            klass + JvmMapper::InstanceKlass::minor_version));

        out.u2(Read<uint16_t>(
            klass + JvmMapper::InstanceKlass::major_version));

        if (!WriteConstantPool(ctx, out)) {
            error = ctx.error;
            return false;
        }

        const std::string className = JvmApi::GetClassName(klass);
        auto thisClass = ctx.classIndexes.find(className);

        if (thisClass == ctx.classIndexes.end()) {
            error = "this_class CP entry missing";
            return false;
        }

        out.u2(
            Read<uint16_t>(klass + JvmMapper::Klass::access_flags)
            & CLASS_ACCESS_MASK);

        out.u2(thisClass->second);

        const uintptr_t super =
            Read<uintptr_t>(klass + JvmMapper::Klass::super_klass);

        if (ValidPointer(super)) {
            const std::string superName = JvmApi::GetClassName(super);
            auto superClass = ctx.classIndexes.find(superName);

            if (superClass == ctx.classIndexes.end()) {
                error = "super_class CP entry missing: " + superName;
                return false;
            }

            out.u2(superClass->second);
        } else {
            out.u2(0);
        }

        const uintptr_t interfaces = Read<uintptr_t>(
            klass + JvmMapper::InstanceKlass::local_interfaces);

        if (ValidPointer(interfaces)) {
            const int32_t count = Read<int32_t>(
                interfaces + JvmMapper::Array::length);

            if (count < 0 || count > 65535) {
                error = "invalid interface count";
                return false;
            }

            out.u2(static_cast<uint16_t>(count));

            const uintptr_t base =
                interfaces + JvmMapper::Array::data;

            for (int32_t i = 0; i < count; ++i) {
                const uintptr_t interfaceKlass =
                    Read<uintptr_t>(
                        base + static_cast<uintptr_t>(i)
                        * sizeof(uintptr_t));

                const std::string interfaceName =
                    JvmApi::GetClassName(interfaceKlass);

                auto cpIndex = ctx.classIndexes.find(interfaceName);

                if (cpIndex == ctx.classIndexes.end()) {
                    error =
                        "interface CP entry missing: "
                        + interfaceName;
                    return false;
                }

                out.u2(cpIndex->second);
            }
        } else {
            out.u2(0);
        }

        if (!BuildFieldSection(ctx, out)) {
            error = ctx.error;
            return false;
        }

        if (!BuildMethodSection(ctx, out)) {
            error = ctx.error;
            return false;
        }

        std::vector<uint8_t> bootstrapAttribute;

        if (!BuildBootstrapMethods(ctx, bootstrapAttribute)) {
            error = ctx.error;
            return false;
        }

        if (!bootstrapAttribute.empty()) {
            out.u2(1);
            out.bytes(bootstrapAttribute);
        } else {
            out.u2(0);
        }

        output = std::move(out.data);
        return true;
    }

    static std::string SafeRelativeName(std::string name) {
        std::replace(name.begin(), name.end(), '\\', '/');

        for (char& value : name) {
            switch (value) {
            case '<':
            case '>':
            case ':':
            case '"':
            case '|':
            case '?':
            case '*':
                value = '_';
                break;
            default:
                break;
            }
        }

        while (!name.empty() && name.front() == '/')
            name.erase(name.begin());

        while (name.find("..") != std::string::npos)
            name.replace(name.find(".."), 2, "__");

        return name;
    }

    static std::string UniqueRelativeName(
        const std::string& className,
        uintptr_t klass)
    {
        char address[2 * sizeof(uintptr_t) + 1]{};

        sprintf_s(
            address,
            "%016llX",
            static_cast<unsigned long long>(klass));

        return SafeRelativeName(className)
            + "__"
            + address
            + ".class";
    }

public:
    // Writes all loaded classes directly to a single JAR file at jarPath.
    // progress(processed, total, dumped) is called periodically and on
    // completion. Returns true if the archive was written and finalised.
    static bool DumpJar(
        const char* jarPath,
        void (*progress)(std::size_t processed, std::size_t total, std::size_t dumped))
    {
        const std::vector<ClassInfo> classes =
            JvmApi::GetLoadedClasses(false);
        const std::size_t total = classes.size();
        std::size_t dumped = 0;

        mz_zip_archive jar{};
        if (!mz_zip_writer_init_file(&jar, jarPath, 0)) {
            Log("[ClassDump] DumpJar: cannot create %s", jarPath);
            return false;
        }
        const char manifest[] =
            "Manifest-Version: 1.0\r\n"
            "Created-By: ClassFileReconstructor\r\n"
            "\r\n";
        if (!mz_zip_writer_add_mem(&jar, "META-INF/MANIFEST.MF",
                manifest, sizeof(manifest) - 1, MZ_BEST_SPEED)) {
            mz_zip_writer_end(&jar);
            return false;
        }

        std::unordered_set<std::string> seen;
        for (std::size_t i = 0; i < total; ++i) {
            const ClassInfo& info = classes[i];
            if (!JvmApi::IsInstanceKlass(info.klass_ptr)) {
                if (progress) progress(i + 1, total, dumped);
                continue;
            }
            std::vector<uint8_t> bytes;
            std::string error;
            if (BuildClass(info.klass_ptr, bytes, error)) {
                const std::string entry = SafeRelativeName(info.name) + ".class";
                if (seen.emplace(entry).second) {
                    if (mz_zip_writer_add_mem(&jar, entry.c_str(),
                            bytes.data(), bytes.size(), MZ_BEST_SPEED))
                        ++dumped;
                }
            }
            if (progress) progress(i + 1, total, dumped);
        }

        const bool ok = mz_zip_writer_finalize_archive(&jar) == MZ_TRUE;
        mz_zip_writer_end(&jar);
        Log("[ClassDump] DumpJar: dumped=%zu total=%zu ok=%s path=%s",
            dumped, total, ok ? "YES" : "NO", jarPath);
        return ok;
    }

    static void DumpAll(const char* rootPath) {
        namespace fs = std::filesystem;

        const fs::path root(rootPath);
        std::error_code directoryError;
        fs::create_directories(root, directoryError);

        if (directoryError) {
            Log("[ClassDump] Cannot create root: %s error=%d",
                rootPath,
                directoryError.value());
            return;
        }

        std::ofstream manifest(
            root / "dump_manifest.txt",
            std::ios::binary | std::ios::trunc);

        const fs::path jarPath = root / "reconstructed_classes.jar";
        mz_zip_archive jar{};

        if (!mz_zip_writer_init_file(
                &jar,
                jarPath.string().c_str(),
                0)) {
            Log("[ClassDump] Cannot create JAR: %s",
                jarPath.string().c_str());
            return;
        }

        const char jarManifest[] =
            "Manifest-Version: 1.0\r\n"
            "Created-By: son ClassFileReconstructor\r\n"
            "\r\n";

        if (!mz_zip_writer_add_mem(
                &jar,
                "META-INF/MANIFEST.MF",
                jarManifest,
                sizeof(jarManifest) - 1,
                MZ_BEST_SPEED)) {
            Log("[ClassDump] Cannot add JAR manifest");
            mz_zip_writer_end(&jar);
            return;
        }

        const std::vector<ClassInfo> classes =
            JvmApi::GetLoadedClasses(false);

        size_t dumped = 0;
        size_t failed = 0;
        size_t skipped = 0;
        size_t jarAdded = 0;
        size_t jarDuplicates = 0;
        size_t jarFailed = 0;


        std::unordered_set<std::string> jarEntries;

        Log("[ClassDump] Starting reconstruction: %zu classes -> %s",
            classes.size(),
            rootPath);

        for (const ClassInfo& info : classes) {
            if (!JvmApi::IsInstanceKlass(info.klass_ptr)) {
                ++skipped;
                continue;
            }

            std::vector<uint8_t> bytes;
            std::string error;

            if (!BuildClass(info.klass_ptr, bytes, error)) {
                ++failed;

                if (manifest) {
                    manifest
                        << "[FAILED] "
                        << info.name
                        << " | "
                        << error
                        << "\r\n";
                }

                if (failed <= 50) {
                    Log("[ClassDump] FAILED %s: %s",
                        info.name.c_str(),
                        error.c_str());
                }

                continue;
            }

            const std::string archiveName =
                SafeRelativeName(info.name) + ".class";

            if (jarEntries.emplace(archiveName).second) {
                if (mz_zip_writer_add_mem(
                        &jar,
                        archiveName.c_str(),
                        bytes.data(),
                        bytes.size(),
                        MZ_BEST_SPEED)) {
                    ++jarAdded;
                } else {
                    ++jarFailed;

                    if (manifest) {
                        manifest
                            << "[JAR_FAILED] "
                            << info.name
                            << " | miniz add failed\r\n";
                    }
                }
            } else {
                ++jarDuplicates;

                if (manifest) {
                    manifest
                        << "[DUPLICATE] "
                        << info.name
                        << " | same internal name already in JAR\r\n";
                }
            }


            const std::string relative =
                UniqueRelativeName(info.name, info.klass_ptr);

            const fs::path outputPath = root / fs::path(relative);

            std::error_code parentError;
            fs::create_directories(
                outputPath.parent_path(),
                parentError);

            if (parentError) {
                ++failed;

                if (manifest) {
                    manifest
                        << "[FAILED] "
                        << info.name
                        << " | directory error "
                        << parentError.value()
                        << "\r\n";
                }

                continue;
            }

            std::ofstream file(
                outputPath,
                std::ios::binary | std::ios::trunc);

            if (!file) {
                ++failed;

                if (manifest)
                    manifest << "[FAILED] " << info.name
                             << " | cannot open output\r\n";

                continue;
            }

            file.write(
                reinterpret_cast<const char*>(bytes.data()),
                static_cast<std::streamsize>(bytes.size()));

            if (!file.good()) {
                ++failed;

                if (manifest)
                    manifest << "[FAILED] " << info.name
                             << " | write failure\r\n";

                continue;
            }

            ++dumped;

            if (manifest) {
                manifest
                    << "[OK] "
                    << info.name
                    << " | "
                    << bytes.size()
                    << " bytes\r\n";
            }

            if ((dumped % 500) == 0) {
                Log("[ClassDump] Progress: dumped=%zu failed=%zu skipped=%zu",
                    dumped,
                    failed,
                    skipped);
            }
        }

        const bool jarFinalized =
            mz_zip_writer_finalize_archive(&jar) == MZ_TRUE;

        mz_zip_writer_end(&jar);

        Log("[ClassDump] JAR: added=%zu duplicates=%zu failed=%zu finalized=%s path=%s",
            jarAdded,
            jarDuplicates,
            jarFailed,
            jarFinalized ? "YES" : "NO",
            jarPath.string().c_str());

        Log("[ClassDump] COMPLETE: dumped=%zu failed=%zu skipped=%zu root=%s",
            dumped,
            failed,
            skipped,
            rootPath);
    }
};
