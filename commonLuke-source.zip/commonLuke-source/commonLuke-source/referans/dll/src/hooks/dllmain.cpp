#include <Windows.h>
#include <ShlObj.h>
#include <gl/GL.h>
#include <cstdint>
#include <cerrno>
#include <cstdio>
#include <cstdarg>
#include <vector>
#include <string>
#include <jni.h>
#include <MinHook.h>
#include "Logging.hpp"
#include "ClassScanner.hpp"
#include "MethodInvoker.hpp"
#include "JvmApi.hpp"
#include "KlassInjector.hpp"
#include "MethodBuilder.hpp"
#include "NativeMethodBuilder.hpp"
#include "JarLoader.hpp"
#include "JCFPNativeBridge.hpp"
#include "ClassFileReconstructor.hpp"

uintptr_t MethodInvoker::g_TlsIndexAddr = 0;
uintptr_t MethodInvoker::g_CallStubPtrAddr = 0;
uintptr_t MethodInvoker::g_SerializeMemAddr = 0;
uintptr_t MethodInvoker::g_GetEnvAddr = 0;


static FILE* g_log = nullptr;

void LogImpl(const char* fmt, ...)
{
    if constexpr (!kEnableLogging) {
        return;
    }

    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    OutputDebugStringA(buf);
    OutputDebugStringA("\n");
    if (g_log) { fprintf(g_log, "%s\n", buf); fflush(g_log); }
}

static void InitLog()
{
    if constexpr (!kEnableLogging) {
        return;
    }


    CreateDirectoryA("C:\\Saori", nullptr);
    CreateDirectoryA("C:\\Saori\\logs", nullptr);
    const char* path = "C:\\Saori\\logs\\ghostmasheen.log";

    g_log = _fsopen(path, "a", _SH_DENYNO);

    if (!g_log) {
        char error[512]{};
        sprintf_s(error, "[Logger] Failed to open %s (errno=%d)\n", path, errno);
        OutputDebugStringA(error);
    }
}

static void DescribeExceptionIfLogging(JNIEnv* env)
{
    if constexpr (kEnableLogging) {
        env->ExceptionDescribe();
    }
}


static JNIEnv* g_env  = nullptr;
static bool    g_init = false;
static bool    g_jvmApiReady = false;

static constexpr bool kEnableClassDump = false;
static BOOL (WINAPI* o_wglSwapBuffers)(HDC) = nullptr;
using lwjglGlOrtho_t = void (JNICALL*)(
    JNIEnv*, jclass, jdouble, jdouble, jdouble, jdouble, jdouble, jdouble);
static lwjglGlOrtho_t o_lwjglGlOrtho = nullptr;
using lwjglGlLoadIdentity_t = void (JNICALL*)(JNIEnv*, jclass);
static lwjglGlLoadIdentity_t o_lwjglGlLoadIdentity = nullptr;
using lwjglGlClear_t = void (JNICALL*)(JNIEnv*, jclass, jint);
static lwjglGlClear_t o_lwjglGlClear = nullptr;
using glGetIntegerv_t = void (APIENTRY*)(GLenum, GLint*);
using glGetFloatv_t = void (APIENTRY*)(GLenum, GLfloat*);
using glMatrixMode_t = void (APIENTRY*)(GLenum);
using glLoadIdentity_t = void (APIENTRY*)();
using glLoadMatrixf_t = void (APIENTRY*)(const GLfloat*);
static glGetIntegerv_t g_glGetIntegerv = nullptr;
static glGetFloatv_t g_glGetFloatv = nullptr;
static glMatrixMode_t g_glMatrixMode = nullptr;
static glLoadIdentity_t g_glLoadIdentity = nullptr;
static glLoadMatrixf_t g_glLoadMatrixf = nullptr;
static GLfloat g_worldProjection[16]{};
static volatile LONG g_worldProjectionReady = 0;
static volatile LONG g_espBoundaryConsumed = 0;
static volatile LONG g_glOrthoSeen = 0;
static volatile LONG g_guiProjectionSeen = 0;
static jclass g_watermarkClass = nullptr;
static jmethodID g_watermarkMethod = nullptr;
static jclass g_espClass = nullptr;
static jmethodID g_espRenderMethod = nullptr;
static jclass g_wingsClass = nullptr;
static jmethodID g_wingsRenderMethod = nullptr;
static bool g_worldDepthPending = false;

static void JNICALL hk_lwjglGlClear(JNIEnv* env, jclass owner, jint mask)
{


    if (env == g_env && (mask & GL_DEPTH_BUFFER_BIT) != 0) {
        if ((mask & GL_COLOR_BUFFER_BIT) != 0) {
            g_worldDepthPending = true;
        } else {
            const bool worldDepthPending = g_worldDepthPending;
            g_worldDepthPending = false;
            if (worldDepthPending && g_wingsClass && g_wingsRenderMethod &&
                g_glGetFloatv && !env->ExceptionCheck()) {
                GLfloat projection[16]{};
                g_glGetFloatv(GL_PROJECTION_MATRIX, projection);


                if (projection[15] > -0.01f && projection[15] < 0.01f &&
                    projection[11] < -0.5f) {
                    static bool boundaryReported = false;
                    if (!boundaryReported) {
                        boundaryReported = true;
                        Log("[Wings] boundary=pre-depth-clear sceneDepth=preserved");
                    }
                    env->CallStaticVoidMethod(g_wingsClass, g_wingsRenderMethod);
                    if (env->ExceptionCheck()) {
                        static bool exceptionReported = false;
                        if (!exceptionReported) {
                            exceptionReported = true;
                            Log("[-] Wings pre-depth-clear callback threw an exception");
                            DescribeExceptionIfLogging(env);
                        }
                        env->ExceptionClear();
                    }
                }
            }
        }
    }
    o_lwjglGlClear(env, owner, mask);
}

static void JNICALL hk_lwjglGlLoadIdentity(JNIEnv* env, jclass owner)
{
    if (g_glGetIntegerv && g_glGetFloatv) {
        GLint matrixMode = 0;
        g_glGetIntegerv(GL_MATRIX_MODE, &matrixMode);
        if (matrixMode == GL_PROJECTION) {
            GLfloat candidate[16]{};
            g_glGetFloatv(GL_PROJECTION_MATRIX, candidate);


            if (candidate[15] > -0.01f && candidate[15] < 0.01f &&
                candidate[11] < -0.5f) {
                for (int i = 0; i < 16; ++i)
                    g_worldProjection[i] = candidate[i];
                InterlockedExchange(&g_worldProjectionReady, 1);
            }
        }
    }
    o_lwjglGlLoadIdentity(env, owner);
}

static void JNICALL hk_lwjglGlOrtho(JNIEnv* env, jclass owner,
                                    jdouble left, jdouble right,
                                    jdouble bottom, jdouble top,
                                    jdouble zNear, jdouble zFar)
{
    if (InterlockedCompareExchange(&g_glOrthoSeen, 1, 0) == 0) {
        Log("[*] hk_lwjglGlOrtho first call: left=%.3f right=%.3f bottom=%.3f top=%.3f near=%.3f far=%.3f",
            left, right, bottom, top, zNear, zFar);
    }
    const bool guiProjection =
        left == 0.0 && top == 0.0 && right > 0.0 && bottom > 0.0;
    if (guiProjection) {
        if (env == g_env) g_worldDepthPending = false;
        InterlockedExchange(&g_guiProjectionSeen, 1);
        if (g_espClass && g_espRenderMethod &&
            InterlockedCompareExchange(&g_espBoundaryConsumed, 1, 0) == 0 &&
            InterlockedCompareExchange(&g_worldProjectionReady, 1, 1) != 0 &&
            g_glGetIntegerv && g_glGetFloatv && g_glMatrixMode &&
            g_glLoadMatrixf) {
            GLint previousMode = GL_PROJECTION;
            GLfloat previousProjection[16]{};
            GLfloat previousModelview[16]{};
            g_glGetIntegerv(GL_MATRIX_MODE, &previousMode);


            g_glMatrixMode(GL_PROJECTION);
            g_glGetFloatv(GL_PROJECTION_MATRIX, previousProjection);
            g_glMatrixMode(GL_MODELVIEW);
            g_glGetFloatv(GL_MODELVIEW_MATRIX, previousModelview);

            g_glMatrixMode(GL_PROJECTION);
            g_glLoadMatrixf(g_worldProjection);
            g_glMatrixMode(GL_MODELVIEW);
            g_glLoadMatrixf(previousModelview);
            env->CallStaticVoidMethod(g_espClass, g_espRenderMethod);
            if (env->ExceptionCheck()) {
                static bool espExceptionReported = false;
                if (!espExceptionReported) {
                    espExceptionReported = true;
                    Log("[-] ESP glOrtho callback threw an exception");
                    DescribeExceptionIfLogging(env);
                }
                env->ExceptionClear();
            }
            g_glMatrixMode(GL_PROJECTION);
            g_glLoadMatrixf(previousProjection);
            g_glMatrixMode(GL_MODELVIEW);
            g_glLoadMatrixf(previousModelview);
            g_glMatrixMode(static_cast<GLenum>(previousMode));
        }
    }
    o_lwjglGlOrtho(env, owner, left, right, bottom, top, zNear, zFar);
}


static void RegisterInDictionary(uintptr_t injectedKlass, void* threadPtr)
{
    uintptr_t nameSym = *reinterpret_cast<uintptr_t*>(
        injectedKlass + JvmMapper::Klass::name);
    Log("[Dict] klass=%p nameSym=%p thread=%p", (void*)injectedKlass, (void*)nameSym, threadPtr);

    if (!nameSym || !threadPtr) {
        Log("[-] RegisterInDictionary: nameSym or thread is null");
        return;
    }

    uintptr_t dictGlobal = JvmApi::SystemDictionaryAddr();
    uintptr_t dictPtr = dictGlobal ? JvmApi::SafeRead<uintptr_t>(dictGlobal) : 0;
    Log("[Dict] Dictionary: %p", (void*)dictPtr);

    uintptr_t ownerCld = JvmApi::SafeRead<uintptr_t>(
        injectedKlass + JvmMapper::Klass::class_loader_data);


    uintptr_t loaderOop = ownerCld
        ? JvmApi::SafeRead<uintptr_t>(
            ownerCld + JvmMapper::ClassLoaderData::class_loader) : 0;
    uintptr_t loaderHandleSlot = loaderOop;
    uintptr_t* loaderArg = loaderOop ? &loaderHandleSlot : nullptr;
    Log("[Dict] ownerCld=%p loaderOop=%p loaderHandleSlot=%p",
        (void*)ownerCld, (void*)loaderOop, (void*)loaderArg);


    using fn_update_dict_t = void(__fastcall*)(
        int hash_row, int hash_col,
        uintptr_t a3, uintptr_t a4,
        uintptr_t klass, uintptr_t* loader, void* thread);
    fn_update_dict_t update_dict = reinterpret_cast<fn_update_dict_t>(
        JvmApi::UpdateDictionaryAddr());
    if (!update_dict) {
        Log("[-] RegisterInDictionary: update_dictionary unresolved");
        return;
    }

    __try {


        update_dict(0, 0, 0, 0, injectedKlass, loaderArg, threadPtr);
        Log("[+] SystemDictionary::update_dictionary OK");
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Log("[-] update_dictionary SEH: 0x%08X", GetExceptionCode());
    }
}


static bool AcquireJNIEnv()
{
    if (g_env) return true;
    HMODULE hJvm = GetModuleHandleA("jvm.dll");
    if (!hJvm) { Log("[-] jvm.dll not loaded"); return false; }
    using fn_t = jint(JNICALL*)(JavaVM*, JNIEnv**, jint);
    if (!MethodInvoker::g_GetEnvAddr) { Log("[-] g_GetEnvAddr is null"); return false; }
    auto fn = reinterpret_cast<fn_t>(MethodInvoker::g_GetEnvAddr);
    jint rc = fn(nullptr, &g_env, JNI_VERSION_1_8);
    if (rc != JNI_OK || !g_env) { Log("[-] GetEnv failed rc=%d", rc); g_env = nullptr; return false; }
    Log("[+] JNIEnv: %p", g_env);
    return true;
}


typedef void(__fastcall* fn_resolve_ldc)(void* thread, int bytecode);
typedef void(__fastcall* fn_resolve_get_put)(void* thread, int bytecode);
typedef void(__fastcall* fn_resolve_invoke)(void* thread, int bytecode);
typedef void(__fastcall* fn_throw_StackOverflowError)(void* thread);
typedef void(__fastcall* fn_throw_msg)(void* thread, const char* file, int line, void* name, const char* message);
typedef void(__fastcall* fn_throw)(void* thread, const char* file, int line, void* h_exception, const char* message);

static fn_resolve_ldc o_resolve_ldc = nullptr;
static fn_resolve_get_put o_resolve_get_put = nullptr;
static fn_resolve_invoke o_resolve_invoke = nullptr;
static fn_throw_StackOverflowError o_throw_StackOverflowError = nullptr;
static fn_throw_msg o_throw_msg = nullptr;
static fn_throw o_throw = nullptr;

static void __fastcall hk_resolve_ldc(void* thread, int bytecode) {
    Log("[RESOLVE] resolve_ldc called! bytecode=%d thread=%p", bytecode, thread);
    return o_resolve_ldc(thread, bytecode);
}

static void __fastcall hk_resolve_get_put(void* thread, int bytecode) {
    Log("[RESOLVE] resolve_get_put called! bytecode=%d thread=%p", bytecode, thread);
    return o_resolve_get_put(thread, bytecode);
}

static void __fastcall hk_resolve_invoke(void* thread, int bytecode) {


    o_resolve_invoke(thread, bytecode);
}

static void __fastcall hk_throw_StackOverflowError(void* thread) {
    Log("[-] [EXCEPTION] throw_StackOverflowError called! thread=%p", thread);
    return o_throw_StackOverflowError(thread);
}

static void __fastcall hk_throw_msg(void* thread, const char* file, int line, void* name, const char* message) {
    Log("[-] [EXCEPTION] Exceptions::_throw_msg called from %s:%d! msg=%s", file ? file : "null", line, message ? message : "null");
    return o_throw_msg(thread, file, line, name, message);
}

static void __fastcall hk_throw(void* thread, const char* file, int line, void* h_exception, const char* message) {
    Log("[-] [EXCEPTION] Exceptions::_throw called from %s:%d!", file ? file : "null", line);
    return o_throw(thread, file, line, h_exception, message);
}


static BOOL WINAPI hk_wglSwapBuffers(HDC hdc)
{
    if (!g_init)
    {
        g_init = true;
        Log("[*] hk_wglSwapBuffers first call");

        HMODULE hJvm = GetModuleHandleA("jvm.dll");
        if (!MethodInvoker::Initialize(hJvm)) {
            Log("[-] MethodInvoker::Initialize failed");
            return o_wglSwapBuffers(hdc);
        }

        if (!AcquireJNIEnv()) {
            Log("[-] AcquireJNIEnv failed");
            return o_wglSwapBuffers(hdc);
        }

        auto jvmBase = reinterpret_cast<uintptr_t>(hJvm);
        Log("[*] jvm.dll base: %p", (void*)jvmBase);


        if (!JvmApi::Initialize(hJvm)) {
            Log("[-] JvmApi::Initialize failed");
            return o_wglSwapBuffers(hdc);
        }
        g_jvmApiReady = true;
        Log("[*] JvmApi ready. CLD graph: %s", JvmApi::HasCLDGraph() ? "YES" : "NO");

        if (kEnableClassDump) {

            char classDumpDesktop[MAX_PATH]{};
            char classDumpPath[MAX_PATH]{};
            if (SUCCEEDED(SHGetFolderPathA(nullptr, CSIDL_DESKTOPDIRECTORY, nullptr,
                                           SHGFP_TYPE_CURRENT, classDumpDesktop))) {
                sprintf_s(classDumpPath, "%s\\son_classes_cld.txt", classDumpDesktop);
                JvmApi::DumpToFile(classDumpPath, true);
            } else {
                Log("[JvmApi] CLD text dump skipped: Desktop path unavailable");
            }
            Log("[*] Reconstructing all loaded InstanceKlass objects...");
            ClassFileReconstructor::DumpAll("C:\\Saori\\class_dump_v2");
        }

        if (!JvmMapper::CanAttemptInjection()) {
            Log("[JvmMapper] Injection prerequisites missing or test mode disabled; stopping.");
            return o_wglSwapBuffers(hdc);
        }
        if (!JvmMapper::WriteLayoutVerified())
            Log("[JvmMapper] UNVERIFIED INJECTION TEST enabled. Crash/metadata corruption remains possible. Exception hooks stay disabled; classDump=%s.", kEnableClassDump ? "on" : "off");


        if (JvmMapper::WriteLayoutVerified()) {
        Log("[*] Interpreter hooks partially ENABLED for Exception debugging");


        if (!MH_CreateHook((void*)o_throw_msg, (void*)&hk_throw_msg, (void**)&o_throw_msg)) {
            MH_EnableHook((void*)o_throw_msg);
        }
        if (!MH_CreateHook((void*)o_throw, (void*)&hk_throw, (void**)&o_throw)) {
            MH_EnableHook((void*)o_throw);
        }

        }


        constexpr bool kEnableLegacyJarInjection = true;
        if (!kEnableLegacyJarInjection) {
            Log("[*] External mapper mode: legacy JAR injection disabled");
        }

        if (kEnableLegacyJarInjection) {
        Log("[*] Starting JarLoader for Saori...");
        std::string saoriJar = "C:\\Saori\\saori.jar";
        auto parsedClasses = JarLoader::LoadClassesFromJar(saoriJar);
        if (parsedClasses.empty()) {
            Log("[-] JAR injection aborted: no validated Java 8 classes");
            return o_wglSwapBuffers(hdc);
        }


        struct InjectedRecord {
            std::string name;
            uintptr_t klass;
            uintptr_t method;
            uintptr_t clinit;
        };
        std::vector<InjectedRecord> injected;

        auto classNameOf = [](jcfp::ClassFile& cf, jcfp::u2 classIndex) -> std::string {
            auto& cp = cf.constant_pool;
            if (!classIndex || classIndex >= cp.count()) return {};
            auto& ci = cp.get_entry(classIndex)
                .get<jcfp::ConstantPoolEntry::ClassInfo>();
            if (!ci.name_index || ci.name_index >= cp.count()) return {};
            return cp.get_entry(ci.name_index)
                .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
        };


        std::vector<std::string> jarClassNames(parsedClasses.size());
        std::vector<std::string> jarSuperNames(parsedClasses.size());
        std::vector<std::vector<std::string>> jarInterfaceNames(parsedClasses.size());
        for (size_t i = 0; i < parsedClasses.size(); ++i) {
            jarClassNames[i] = classNameOf(
                parsedClasses[i].class_file, parsedClasses[i].class_file.this_class);
            jarSuperNames[i] = classNameOf(
                parsedClasses[i].class_file, parsedClasses[i].class_file.super_class);
            for (jcfp::u2 interfaceIndex : parsedClasses[i].class_file.interfaces)
                jarInterfaceNames[i].push_back(classNameOf(
                    parsedClasses[i].class_file, interfaceIndex));
        }

        std::vector<JarLoader::ParsedClass> orderedClasses;
        orderedClasses.reserve(parsedClasses.size());
        std::vector<bool> emitted(parsedClasses.size(), false);
        bool classOrderingFailed = false;

        while (orderedClasses.size() < parsedClasses.size()) {
            bool progressed = false;
            for (size_t i = 0; i < parsedClasses.size(); ++i) {
                if (emitted[i]) continue;

                bool parentIsInJar = false;
                bool parentAlreadyEmitted = false;
                for (size_t j = 0; j < jarClassNames.size(); ++j) {
                    if (jarClassNames[j] == jarSuperNames[i]) {
                        parentIsInJar = true;
                        parentAlreadyEmitted = emitted[j];
                        break;
                    }
                }
                if (parentIsInJar && !parentAlreadyEmitted) continue;

                bool waitingForInterface = false;
                for (const auto& interfaceName : jarInterfaceNames[i]) {
                    for (size_t j = 0; j < jarClassNames.size(); ++j) {
                        if (jarClassNames[j] == interfaceName && !emitted[j]) {
                            waitingForInterface = true;
                            break;
                        }
                    }
                    if (waitingForInterface) break;
                }
                if (waitingForInterface) continue;

                emitted[i] = true;
                orderedClasses.push_back(std::move(parsedClasses[i]));
                progressed = true;
            }
            if (!progressed) {
                Log("[-] JAR hierarchy contains a cycle or unresolved in-JAR dependency");
                classOrderingFailed = true;
                break;
            }
        }
        if (classOrderingFailed) {
            Log("[-] JAR injection aborted before publishing a partial hierarchy");
            return o_wglSwapBuffers(hdc);
        }
        if (!orderedClasses.empty())
            parsedClasses = std::move(orderedClasses);


        DWORD tlsIdx = *reinterpret_cast<DWORD*>(MethodInvoker::g_TlsIndexAddr);
        void* threadPtr = TlsGetValue(tlsIdx);
        uintptr_t nullCld = JvmApi::SafeRead<uintptr_t>(JvmApi::BootstrapCLDPtrAddr());
        uintptr_t templateKlass = KlassInjector::FindObjectKlass(hJvm);
        if (!threadPtr || !nullCld || !templateKlass || !g_env) {
            Log("[-] Injection blocked: missing thread, bootstrap CLD, Object template or JNIEnv");
            return o_wglSwapBuffers(hdc);
        }


        uintptr_t payloadOwnerCld = 0;
        auto isJarClassName = [&](const std::string& name) {
            for (const auto& jarName : jarClassNames)
                if (jarName == name) return true;
            return false;
        };
        auto considerExternalOwner = [&](const std::string& name) {
            if (payloadOwnerCld || name.empty() ||
                name == "java/lang/Object" || isJarClassName(name)) return;
            const uintptr_t dependency = JvmApi::FindClass(name.c_str());
            const uintptr_t dependencyCld = dependency
                ? JvmApi::SafeRead<uintptr_t>(
                    dependency + JvmMapper::Klass::class_loader_data)
                : 0;


            const uintptr_t dependencyLoaderOop = dependencyCld
                ? JvmApi::SafeRead<uintptr_t>(
                    dependencyCld + JvmMapper::ClassLoaderData::class_loader) : 0;
            if (dependencyCld && dependencyLoaderOop) {
                payloadOwnerCld = dependencyCld;
                Log("[ClassPlan] payload owner CLD=%p loaderOop=%p derived from external type %s klass=%p",
                    (void*)payloadOwnerCld, (void*)dependencyLoaderOop,
                    name.c_str(), (void*)dependency);
            }
        };
        for (size_t i = 0; i < jarClassNames.size() && !payloadOwnerCld; ++i) {
            considerExternalOwner(jarSuperNames[i]);
            for (const auto& interfaceName : jarInterfaceNames[i])
                considerExternalOwner(interfaceName);
        }
        if (!payloadOwnerCld) payloadOwnerCld = nullCld;
        Log("[ClassPlan] payload loader namespace: cld=%p%s",
            (void*)payloadOwnerCld,
            payloadOwnerCld == nullCld ? " (bootstrap)" : " (non-bootstrap)");

        uint32_t mirrorStaticBase = 0xFFFFFFFFu;
        uintptr_t systemKlass = JvmApi::FindClass("java/lang/System");
        if (systemKlass) {
            for (const auto& field : JvmApi::GetFields(systemKlass)) {
                if ((field.access_flags & 0x0008) != 0 && field.offset < mirrorStaticBase)
                    mirrorStaticBase = field.offset;
            }
        }
        if (mirrorStaticBase == 0xFFFFFFFFu) {
            Log("[-] Could not derive mirror static-field base from java/lang/System");
            return o_wglSwapBuffers(hdc);
        }
        Log("[FieldLayout] runtime mirror static base=%u", mirrorStaticBase);


        bool injectionFailed = false;
        for (auto& pc : parsedClasses) {
            Log("[JarLoader] Injecting: %s", pc.name.c_str());


            std::string actualClassName = "unknown";
            jcfp::u2 this_class_idx = pc.class_file.this_class;
            jcfp::ConstantPool cp_copy = pc.class_file.constant_pool;
            if (this_class_idx > 0 && this_class_idx < cp_copy.count()) {
                auto& class_info = cp_copy.get_entry(this_class_idx).get<jcfp::ConstantPoolEntry::ClassInfo>();
                if (class_info.name_index > 0 && class_info.name_index < cp_copy.count()) {
                    auto& utf8_info = cp_copy.get_entry(class_info.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                    actualClassName = utf8_info.bytes;
                }
            }

            const bool isMainClass = actualClassName == "Saori/evangelicy/bootstrap/Bootstrap";
            const std::string declaredSuperName = classNameOf(
                pc.class_file, pc.class_file.super_class);

            uintptr_t resolvedSuperKlass = 0;
            if (declaredSuperName.empty() || declaredSuperName == "java/lang/Object") {
                resolvedSuperKlass = templateKlass;
            } else {
                for (const auto& rec : injected) {
                    if (rec.name == declaredSuperName) {
                        resolvedSuperKlass = rec.klass;
                        break;
                    }
                }
                if (!resolvedSuperKlass)
                    resolvedSuperKlass = JvmApi::FindClass(declaredSuperName.c_str());
            }
            Log("[ClassPlan] hierarchy class=%s declared_super=%s resolved=%p",
                actualClassName.c_str(), declaredSuperName.c_str(),
                (void*)resolvedSuperKlass);
            if (!resolvedSuperKlass) {
                Log("[-] %s: superclass is not available: %s",
                    actualClassName.c_str(), declaredSuperName.c_str());
                injectionFailed = true;
                break;
            }

            uintptr_t resolvedInterfaces[64] = {};
            int32_t resolvedInterfaceCount = 0;
            bool interfacesReady = true;
            for (jcfp::u2 interfaceIndex : pc.class_file.interfaces) {
                if (resolvedInterfaceCount >= 64) {
                    Log("[-] %s: direct interface capacity exceeded", actualClassName.c_str());
                    interfacesReady = false;
                    break;
                }
                const std::string interfaceName = classNameOf(pc.class_file, interfaceIndex);
                uintptr_t interfaceKlass = 0;
                for (const auto& rec : injected) {
                    if (rec.name == interfaceName) {
                        interfaceKlass = rec.klass;
                        break;
                    }
                }
                if (!interfaceKlass)
                    interfaceKlass = JvmApi::FindClass(interfaceName.c_str());
                Log("[ClassPlan] interface class=%s name=%s resolved=%p",
                    actualClassName.c_str(), interfaceName.c_str(), (void*)interfaceKlass);
                if (!interfaceKlass) {
                    interfacesReady = false;
                    break;
                }
                resolvedInterfaces[resolvedInterfaceCount++] = interfaceKlass;
            }
            if (!interfacesReady) {
                Log("[-] %s: one or more interfaces are unavailable", actualClassName.c_str());
                injectionFailed = true;
                break;
            }

            RawInstanceFieldPlan fieldPlan = {};
            const size_t localFieldCount = pc.class_file.fields.size();
            std::vector<uintptr_t> fieldOffsets(localFieldCount, 0);
            uint32_t instanceCursor = JvmApi::SafeRead<uint32_t>(
                resolvedSuperKlass + JvmMapper::Klass::layout_helper) & ~1u;
            const uint32_t parentFieldWords = JvmApi::SafeRead<uint32_t>(
                resolvedSuperKlass + JvmMapper::InstanceKlass::nonstatic_field_size);
            uint32_t firstOopOffset = 0;
            uint32_t oopCount = 0;
            uint32_t staticCursor = mirrorStaticBase;
            uint16_t staticOopCount = 0;


            for (int pass = 0; pass < 4; ++pass) {
                for (size_t fi = 0; fi < localFieldCount; ++fi) {
                    auto& field = pc.class_file.fields[fi];
                    const uint32_t access = static_cast<uint32_t>(field.access_flags);
                    const bool isStatic = (access & 0x0008) != 0;
                    std::string descriptor;
                    if (field.descriptor_index > 0 && field.descriptor_index < pc.class_file.constant_pool.count())
                        descriptor = pc.class_file.constant_pool.get_entry(field.descriptor_index)
                            .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
                    const bool oop = !descriptor.empty() &&
                        (descriptor[0] == 'L' || descriptor[0] == '[');
                    if ((pass >= 2) != isStatic || ((pass & 1) == 0) != oop) continue;
                    uint32_t width = (!descriptor.empty() &&
                        (descriptor[0] == 'J' || descriptor[0] == 'D')) ? 8u : 4u;
                    uint32_t& cursor = isStatic ? staticCursor : instanceCursor;
                    cursor = (cursor + width - 1) & ~(width - 1);
                    fieldOffsets[fi] = cursor;
                    if (oop && isStatic) {
                        ++staticOopCount;
                    } else if (oop) {
                        if (!firstOopOffset) firstOopOffset = cursor;
                        ++oopCount;
                    }
                    cursor += width;
                }
            }
            if (localFieldCount) {
                const size_t u2Count = localFieldCount * JvmMapper::FieldInfo::entry_words;
                const size_t bytes = JvmMapper::CompactU2Array::data + u2Count * sizeof(uint16_t);
                fieldPlan.fieldsArray = reinterpret_cast<uintptr_t>(VirtualAlloc(
                    nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
                if (!fieldPlan.fieldsArray) {
                    Log("[-] %s: field metadata allocation failed",
                        actualClassName.c_str());
                    injectionFailed = true;
                    break;
                }
                memset(reinterpret_cast<void*>(fieldPlan.fieldsArray), 0, bytes);
                *reinterpret_cast<int32_t*>(fieldPlan.fieldsArray) = static_cast<int32_t>(u2Count);
                uint16_t* words = reinterpret_cast<uint16_t*>(
                    fieldPlan.fieldsArray + JvmMapper::CompactU2Array::data);
                for (size_t fi = 0; fi < localFieldCount; ++fi) {
                    auto& field = pc.class_file.fields[fi];
                    uint16_t* entry = words + fi * JvmMapper::FieldInfo::entry_words;
                    entry[JvmMapper::FieldInfo::initval_index_word] = 0;
                    entry[JvmMapper::FieldInfo::access_flags_word] =
                        static_cast<uint16_t>(field.access_flags);
                    entry[JvmMapper::FieldInfo::signature_index_word] = field.descriptor_index;
                    entry[JvmMapper::FieldInfo::name_index_word] = field.name_index;
                    const uint32_t packedOffset =
                        static_cast<uint32_t>(fieldOffsets[fi]) << JvmMapper::FieldInfo::offset_tag_bits | 1u;
                    entry[JvmMapper::FieldInfo::low_offset_word] = static_cast<uint16_t>(packedOffset);
                    entry[JvmMapper::FieldInfo::high_offset_word] = static_cast<uint16_t>(packedOffset >> 16);
                    Log("[FieldLayout] %s field=%zu offset=%llu access=0x%04X",
                        actualClassName.c_str(), fi,
                        static_cast<unsigned long long>(fieldOffsets[fi]),
                        static_cast<unsigned>(field.access_flags));
                }
            }
            fieldPlan.javaFieldCount = static_cast<uint16_t>(localFieldCount);
            fieldPlan.instanceSizeBytes = (instanceCursor + 7u) & ~7u;
            fieldPlan.nonstaticFieldWords = parentFieldWords +
                ((fieldPlan.instanceSizeBytes -
                  (JvmApi::SafeRead<uint32_t>(resolvedSuperKlass + JvmMapper::Klass::layout_helper) & ~1u) + 7u) / 8u);
            fieldPlan.oopOffsetBytes = firstOopOffset;
            fieldPlan.oopCount = oopCount;
            fieldPlan.staticFieldWords =
                ((staticCursor - mirrorStaticBase) + 7u) / 8u;
            fieldPlan.staticOopCount = staticOopCount;
            Log("[FieldLayout] %s instance_bytes=%u static_words=%u static_oops=%u",
                actualClassName.c_str(), fieldPlan.instanceSizeBytes,
                fieldPlan.staticFieldWords, fieldPlan.staticOopCount);


            {
                auto& planCp = pc.class_file.constant_pool;
                Log("[ClassPlan] class=%s methods=%zu fields=%zu interfaces=%zu",
                    actualClassName.c_str(), pc.class_file.methods.size(),
                    pc.class_file.fields.size(), pc.class_file.interfaces.size());
                for (auto& planned : pc.class_file.methods) {
                    std::string plannedName = "<invalid>";
                    std::string plannedDesc = "<invalid>";
                    if (planned.name_index > 0 && planned.name_index < planCp.count())
                        plannedName = planCp.get_entry(planned.name_index)
                            .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
                    if (planned.descriptor_index > 0 && planned.descriptor_index < planCp.count())
                        plannedDesc = planCp.get_entry(planned.descriptor_index)
                            .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
                    Log("[ClassPlan]   method=%s%s access=0x%04X",
                        plannedName.c_str(), plannedDesc.c_str(),
                        static_cast<unsigned>(planned.access_flags));
                }
            }

            if (isMainClass) {
                bool hasStaticMain = false;
                auto& mainCp = pc.class_file.constant_pool;
                for (auto& m : pc.class_file.methods) {
                    if (m.name_index > 0 && m.name_index < mainCp.count() &&
                        m.descriptor_index > 0 && m.descriptor_index < mainCp.count() &&
                        (m.access_flags & 0x0008) != 0 &&
                        mainCp.get_entry(m.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes == "main" &&
                        mainCp.get_entry(m.descriptor_index).get<jcfp::ConstantPoolEntry::Utf8Info>().bytes == "([Ljava/lang/String;)V")
                        hasStaticMain = true;
                }
                if (!hasStaticMain) {
                    Log("[-] Saori requires Saori.evangelicy.bootstrap.Bootstrap.main(String[]); rebuild saori.jar");
                    injectionFailed = true;
                    break;
                }
            }


            auto builtMethods = JCFPNativeBridge::BuildAllMethodsFromJCFP(
                hJvm, payloadOwnerCld, threadPtr, pc.class_file, g_env);
            if (builtMethods.empty()) {
                if (pc.class_file.methods.empty()) {
                    Log("[*] %s: empty synthetic/marker class skipped safely.",
                        actualClassName.c_str());
                    continue;
                }
                Log("[-] %s: method metadata build failed; aborting JAR.",
                    actualClassName.c_str());
                injectionFailed = true;
                break;
            }

            uintptr_t methodPtr = 0;
            uintptr_t clinitPtr = 0;
            for (const auto& built : builtMethods) {
                if (built.name == "<clinit>" && built.descriptor == "()V" &&
                    (built.access_flags & 0x0008) != 0)
                    clinitPtr = built.method;
                if (isMainClass && built.name == "main" &&
                    built.descriptor == "([Ljava/lang/String;)V" &&
                    (built.access_flags & 0x0008) != 0) {
                    methodPtr = built.method;
                    break;
                }
                if (!isMainClass && built.name == "run" &&
                    built.descriptor == "()V" &&
                    (built.access_flags & 0x0008) != 0) {
                    methodPtr = built.method;
                }
            }

            if (isMainClass && !methodPtr) {
                Log("[-] %s: built method set has no static main(String[])", actualClassName.c_str());
                injectionFailed = true;
                break;
            }


            const size_t methodArraySize =
                JvmMapper::Array::data + builtMethods.size() * sizeof(uintptr_t);
            uintptr_t methodArray = reinterpret_cast<uintptr_t>(
                VirtualAlloc(nullptr, methodArraySize,
                    MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
            if (methodArray) {
                *reinterpret_cast<int32_t*>(
                    methodArray + JvmMapper::Array::length) =
                    static_cast<int32_t>(builtMethods.size());
                for (size_t i = 0; i < builtMethods.size(); ++i) {
                    *reinterpret_cast<uintptr_t*>(
                        methodArray + JvmMapper::Array::data + i * sizeof(uintptr_t)) =
                        builtMethods[i].method;
                    Log("[MethodSet] %s[%zu]=%s%s method=%p",
                        actualClassName.c_str(), i,
                        builtMethods[i].name.c_str(),
                        builtMethods[i].descriptor.c_str(),
                        (void*)builtMethods[i].method);
                }
            } else {
                Log("[-] Method array allocation failed: %s", actualClassName.c_str());
                injectionFailed = true;
                break;
            }

            uintptr_t injectedKlass = KlassInjector::InjectClass(
                hJvm, actualClassName, templateKlass, methodArray, threadPtr,
                resolvedSuperKlass,
                static_cast<uint32_t>(pc.class_file.access_flags),
                resolvedInterfaces, resolvedInterfaceCount,
                &fieldPlan, payloadOwnerCld);

            if (!injectedKlass) {
                Log("[-] %s: InjectClass failed.", actualClassName.c_str());
                injectionFailed = true;
                break;
            }

            Log("[+] %s injected! Klass: %p, Methods: %zu, Entry: %p",
                actualClassName.c_str(), (void*)injectedKlass,
                builtMethods.size(), (void*)methodPtr);


            RegisterInDictionary(injectedKlass, threadPtr);

            injected.push_back({actualClassName, injectedKlass, methodPtr, clinitPtr});
        }

        if (injectionFailed) {
            Log("[-] JAR injection aborted after a class publication failure; initialization and main skipped");
            return o_wglSwapBuffers(hdc);
        }


        bool initializationFailed = false;
        for (auto& rec : injected) {
            uint8_t* initState = reinterpret_cast<uint8_t*>(
                rec.klass + JvmMapper::InstanceKlass::init_state);
            if (*initState == JvmMapper::State::klass_fully_initialized)
                continue;
            if (!rec.clinit) {
                *initState = JvmMapper::State::klass_fully_initialized;
                Log("[+] %s initialized (no <clinit>)", rec.name.c_str());
                continue;
            }
            *reinterpret_cast<uintptr_t*>(
                rec.klass + JvmMapper::InstanceKlass::init_thread) =
                reinterpret_cast<uintptr_t>(threadPtr);
            *initState = JvmMapper::State::klass_being_initialized;
            Log("[*] Invoking <clinit>: %s method=%p", rec.name.c_str(), (void*)rec.clinit);
            bool initialized = MethodInvoker::InvokeStaticVoid(rec.clinit);
            *reinterpret_cast<uintptr_t*>(
                rec.klass + JvmMapper::InstanceKlass::init_thread) = 0;
            *initState = initialized
                ? JvmMapper::State::klass_fully_initialized
                : JvmMapper::State::klass_initialization_error;
            Log("[%s] %s.<clinit> %s", initialized ? "+" : "-",
                rec.name.c_str(), initialized ? "completed" : "failed");
            if (!initialized) initializationFailed = true;
        }


        if (!initializationFailed) {
            size_t warmedArrayKlasses = 0;
            for (auto& rec : injected) {
                const uintptr_t metadataName = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::Klass::name);
                const uintptr_t metadataArrayName = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::InstanceKlass::array_name);
                const uintptr_t metadataCld = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::Klass::class_loader_data);
                const uintptr_t metadataSuper = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::Klass::super_klass);
                const uintptr_t metadataSecondary = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::Klass::secondary_supers);
                const int32_t secondaryCount = metadataSecondary
                    ? JvmApi::SafeRead<int32_t>(
                        metadataSecondary + JvmMapper::Array::length)
                    : -1;
                Log("[*] ArrayKlass warmup entering: %s klass=%p layout=0x%X "
                    "name=%p/%u array_name=%p/%u cld=%p super=%p secondary=%p/%d "
                    "vtable=%u itable=%u",
                    rec.name.c_str(), (void*)rec.klass,
                    JvmApi::SafeRead<uint32_t>(
                        rec.klass + JvmMapper::Klass::layout_helper),
                    (void*)metadataName,
                    static_cast<unsigned>(metadataName
                        ? JvmApi::SafeRead<uint16_t>(metadataName) : 0),
                    (void*)metadataArrayName,
                    static_cast<unsigned>(metadataArrayName
                        ? JvmApi::SafeRead<uint16_t>(metadataArrayName) : 0),
                    (void*)metadataCld, (void*)metadataSuper,
                    (void*)metadataSecondary, secondaryCount,
                    JvmApi::SafeRead<uint32_t>(
                        rec.klass + JvmMapper::InstanceKlass::vtable_len),
                    JvmApi::SafeRead<uint32_t>(
                        rec.klass + JvmMapper::InstanceKlass::itable_len));
                uintptr_t mirrorOop = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::Klass::java_mirror);
                if (!mirrorOop) {
                    Log("[-] ArrayKlass warmup: %s has no mirror",
                        rec.name.c_str());
                    initializationFailed = true;
                    break;
                }

                jclass componentHandle = reinterpret_cast<jclass>(&mirrorOop);
                jobjectArray emptyArray = g_env->NewObjectArray(
                    0, componentHandle, nullptr);
                if (!emptyArray || g_env->ExceptionCheck()) {
                    Log("[-] ArrayKlass warmup failed: %s",
                        rec.name.c_str());
                    if (g_env->ExceptionCheck()) {
                        DescribeExceptionIfLogging(g_env);
                        g_env->ExceptionClear();
                    }
                    if (emptyArray) g_env->DeleteLocalRef(emptyArray);
                    initializationFailed = true;
                    break;
                }

                const uintptr_t arrayKlass = JvmApi::SafeRead<uintptr_t>(
                    rec.klass + JvmMapper::InstanceKlass::array_klasses);
                g_env->DeleteLocalRef(emptyArray);
                if (!arrayKlass) {
                    Log("[-] ArrayKlass warmup produced no metadata: %s",
                        rec.name.c_str());
                    initializationFailed = true;
                    break;
                }
                ++warmedArrayKlasses;
            }
            Log("[%s] VM-owned ArrayKlass warmup: %zu/%zu",
                initializationFailed ? "-" : "+",
                warmedArrayKlasses, injected.size());
        }


        Log("[*] Pass 1 done. %zu class(es) registered.", injected.size());

        InjectedRecord* entry = nullptr;
        for (auto& rec : injected) {
            if (rec.name == "Saori/evangelicy/bootstrap/Bootstrap") {
                entry = &rec;
                break;
            }
        }

        if (entry && !initializationFailed) {
            Log("[*] Invoking entry point: %s (method=%p)",
                entry->name.c_str(), (void*)entry->method);
            jclass stringClass = g_env->FindClass("java/lang/String");
            jobjectArray args = stringClass ? g_env->NewObjectArray(0, stringClass, nullptr) : nullptr;
            if (!args || g_env->ExceptionCheck()) {
                Log("[-] Could not create main String[0]; invocation skipped");
                if (g_env->ExceptionCheck()) {
                    DescribeExceptionIfLogging(g_env);
                    g_env->ExceptionClear();
                }
            } else {
                bool ok = MethodInvoker::InvokeStaticVoid(entry->method, args, true);
                Log("[%s] Saori.main(String[0]) %s", ok ? "+" : "-", ok ? "completed" : "failed");
            }
            if (args) g_env->DeleteLocalRef(args);
            if (stringClass) g_env->DeleteLocalRef(stringClass);
        } else if (initializationFailed) {
            Log("[-] Saori.main skipped because a class initializer failed");
        } else {
            Log("[-] Saori.main(String[]) not available; no fallback invocation");
        }


        for (auto& rec : injected) {
            const bool isGui =
                rec.name == "Saori/evangelicy/ui/Overlay";
            const bool isEsp =
                rec.name == "Saori/evangelicy/module/impl/render/ESP";
            const bool isWings =
                rec.name == "Saori/evangelicy/module/impl/render/Wings";
            if (!isGui && !isEsp && !isWings) continue;
            uintptr_t mirrorOop = JvmApi::SafeRead<uintptr_t>(
                rec.klass + JvmMapper::Klass::java_mirror);
            if (!mirrorOop) continue;
            jclass temporaryHandle = reinterpret_cast<jclass>(&mirrorOop);
            jclass globalClass = reinterpret_cast<jclass>(
                g_env->NewGlobalRef(temporaryHandle));
            if (isGui) {
                g_watermarkClass = globalClass;
            } else if (isEsp) {
                g_espClass = globalClass;
            } else {
                g_wingsClass = globalClass;
            }
            if (isGui && g_watermarkClass) {


                g_watermarkMethod = g_env->GetStaticMethodID(
                    g_watermarkClass, "maintainInstallation", "()V");
            } else if (isEsp && g_espClass) {
                g_espRenderMethod = g_env->GetStaticMethodID(
                    g_espClass, "render3DAndCapture", "()V");
            } else if (isWings && g_wingsClass) {
                g_wingsRenderMethod = g_env->GetStaticMethodID(
                    g_wingsClass, "render3DWorld", "()V");
            }
            if (g_env->ExceptionCheck()) {
                DescribeExceptionIfLogging(g_env);
                g_env->ExceptionClear();
                if (isGui) g_watermarkMethod = nullptr;
                if (isEsp) g_espRenderMethod = nullptr;
                if (isWings) g_wingsRenderMethod = nullptr;
            }
            if (isGui) {
                Log("[%s] watermark callback cached: class=%p method=%p",
                    g_watermarkClass && g_watermarkMethod ? "+" : "-",
                    g_watermarkClass, g_watermarkMethod);
            } else if (isEsp) {
                Log("[%s] ESP callback cached: class=%p method=%p",
                    g_espClass && g_espRenderMethod ? "+" : "-",
                    g_espClass, g_espRenderMethod);
            } else {
                Log("[%s] Wings world callback cached: class=%p method=%p",
                    g_wingsClass && g_wingsRenderMethod ? "+" : "-",
                    g_wingsClass, g_wingsRenderMethod);
            }
        }

        Log("[+] Otonom JAR Injection tamamlandi");
        }
    }


    InterlockedExchange(&g_guiProjectionSeen, 0);
    if (g_watermarkClass && g_watermarkMethod) {
        g_env->CallStaticVoidMethod(g_watermarkClass, g_watermarkMethod);
        if (g_env->ExceptionCheck()) {
            static bool reported = false;
            if (!reported) {
                reported = true;
                Log("[-] watermark render callback threw an exception");
                DescribeExceptionIfLogging(g_env);
            }
            g_env->ExceptionClear();
        }
    }
    InterlockedExchange(&g_espBoundaryConsumed, 0);
    g_worldDepthPending = false;
    return o_wglSwapBuffers(hdc);
}


static void SetupHook()
{
    HMODULE hOgl = GetModuleHandleA("opengl32.dll");
    if (!hOgl) hOgl = LoadLibraryA("opengl32.dll");
    if (!hOgl) { Log("[-] opengl32.dll not found"); return; }
    void* pSwap = GetProcAddress(hOgl, "wglSwapBuffers");
    if (!pSwap) { Log("[-] wglSwapBuffers not found"); return; }
    HMODULE hLwjglOgl = GetModuleHandleA("lwjgl_opengl.dll");
    void* pOrtho = hLwjglOgl ? GetProcAddress(
        hLwjglOgl, "Java_org_lwjgl_opengl_GL11_glOrtho") : nullptr;
    void* pLoadIdentity = hLwjglOgl ? GetProcAddress(
        hLwjglOgl, "Java_org_lwjgl_opengl_GL11_glLoadIdentity") : nullptr;
    void* pClear = hLwjglOgl ? GetProcAddress(
        hLwjglOgl, "Java_org_lwjgl_opengl_GL11C_glClear") : nullptr;
    if (!pClear) Log("[-] LWJGL GL11C_glClear export not found; Wings world rendering unavailable");
    if (!pOrtho) { Log("[-] LWJGL GL11_glOrtho export not found"); return; }
    if (!pLoadIdentity) {
        Log("[-] LWJGL GL11_glLoadIdentity export not found");
        return;
    }
    g_glGetIntegerv = reinterpret_cast<glGetIntegerv_t>(
        GetProcAddress(hOgl, "glGetIntegerv"));
    g_glGetFloatv = reinterpret_cast<glGetFloatv_t>(
        GetProcAddress(hOgl, "glGetFloatv"));
    g_glMatrixMode = reinterpret_cast<glMatrixMode_t>(
        GetProcAddress(hOgl, "glMatrixMode"));
    g_glLoadIdentity = reinterpret_cast<glLoadIdentity_t>(
        GetProcAddress(hOgl, "glLoadIdentity"));
    g_glLoadMatrixf = reinterpret_cast<glLoadMatrixf_t>(
        GetProcAddress(hOgl, "glLoadMatrixf"));
    if (!g_glGetIntegerv || !g_glGetFloatv || !g_glMatrixMode ||
        !g_glLoadIdentity || !g_glLoadMatrixf) {
        Log("[-] Required OpenGL 1.1 matrix exports missing");
        return;
    }
    MH_Initialize();
    const MH_STATUS swapCreate = MH_CreateHook(
        pSwap, &hk_wglSwapBuffers, reinterpret_cast<void**>(&o_wglSwapBuffers));
    const MH_STATUS orthoCreate = MH_CreateHook(
        pOrtho, &hk_lwjglGlOrtho, reinterpret_cast<void**>(&o_lwjglGlOrtho));
    const MH_STATUS identityCreate = MH_CreateHook(
        pLoadIdentity, &hk_lwjglGlLoadIdentity,
        reinterpret_cast<void**>(&o_lwjglGlLoadIdentity));
    if (swapCreate == MH_OK && MH_EnableHook(pSwap) == MH_OK)
        Log("[+] wglSwapBuffers hooked @ %p", pSwap);
    else
        Log("[-] wglSwapBuffers hook failed: create=%d", static_cast<int>(swapCreate));
    if (orthoCreate == MH_OK && MH_EnableHook(pOrtho) == MH_OK)
        Log("[+] LWJGL GL11_glOrtho hooked @ %p", pOrtho);
    else
        Log("[-] glOrtho hook failed: create=%d", static_cast<int>(orthoCreate));
    if (identityCreate == MH_OK && MH_EnableHook(pLoadIdentity) == MH_OK)
        Log("[+] LWJGL GL11_glLoadIdentity hooked @ %p", pLoadIdentity);
    else
        Log("[-] glLoadIdentity hook failed: create=%d",
            static_cast<int>(identityCreate));
    if (pClear) {
        const MH_STATUS clearCreate = MH_CreateHook(
            pClear, &hk_lwjglGlClear, reinterpret_cast<void**>(&o_lwjglGlClear));
        const MH_STATUS clearEnable = clearCreate == MH_OK
            ? MH_EnableHook(pClear) : clearCreate;
        if (clearCreate == MH_OK && clearEnable == MH_OK)
            Log("[+] LWJGL GL11C_glClear hooked @ %p (Wings before world depth clear)", pClear);
        else
            Log("[-] glClear hook failed: create=%d enable=%d",
                static_cast<int>(clearCreate), static_cast<int>(clearEnable));
    }
}

static DWORD WINAPI MainThread(LPVOID)
{
    InitLog();
    Log("[*] ghostmasheen.dll loaded");
    SetupHook();
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
