

#include <jcfp/jcfp.hpp>
#include <jcfp/utils.hpp>
#include <format>

using namespace jcfp;

AttributeInfo AttributeInfo::parse(BufReader &reader)
{
	u2 attribute_name_index = reader.read_be<u2>();
	u4 attribute_length = reader.read_be<u4>();
	std::vector<u1> info = reader.read_bytes(attribute_length);
	return AttributeInfo(attribute_name_index, info);
}

AttributeInfo AttributeInfo::parse(const u1 *bytes, size_t max_length)
{
	BufReader reader = BufReader(bytes, max_length);
	return AttributeInfo::parse(reader);
}

std::vector<u1> AttributeInfo::encode()
{
	ByteStream stream = ByteStream();
	this->encode(stream);
	return stream.collect();
}

void AttributeInfo::encode(ByteStream &stream)
{
	stream.write_be(this->attribute_name_index);

	u4 attribute_length = static_cast<u4>(this->info.size());
	stream.write_be(attribute_length);
	stream.write_bytes(this->info);
}

void AttributeInfo::relocate(int diff, u2 from)
{
	JCFP_RELOCATE_INDEX(this->attribute_name_index, diff, from);
	// TODO: Add attribute-specific relocations
}
