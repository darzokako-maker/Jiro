#pragma once
#include <algorithm>
#include <Windows.h>
#include <string>
#include <utility>
#include <vector>
#include "jcfp/jcfp.hpp"
#include "jcfp/constant_pool.hpp"
#include "jcfp/attribute.hpp"
#include "Logging.hpp"
#include "NativeMethodBuilder.hpp"
#include "JvmApi.hpp"
#include "ClassScanner.hpp"

class JCFPNativeBridge {
public:
    struct BuiltMethod {
        std::string name;
        std::string descriptor;
        uint16_t access_flags = 0;
        uintptr_t method = 0;
    };

    static uintptr_t BuildMethodFromJCFP(HMODULE hJvm, uintptr_t cld, void* thread, jcfp::ClassFile& cf, const std::string& targetMethodName, const std::string& targetMethodDesc, JNIEnv* env, uintptr_t sharedClassCp = 0) {
        NativeMethodBuilder builder;

        auto& cp = cf.constant_pool;


        for (jcfp::u2 i = 1; i < cp.count(); ++i) {
            auto& jcfp_entry = cp.get_entry(i);
            NativeMethodBuilder::CPEntry nmb_entry;
            nmb_entry.str = "";
            nmb_entry.idx1 = 0;
            nmb_entry.idx2 = 0;

            if (std::holds_alternative<jcfp::ConstantPoolEntry::Utf8Info>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::Utf8Info>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Utf8;
                nmb_entry.str = info.bytes;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::ClassInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::ClassInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_UnresolvedClass;
                nmb_entry.idx1 = info.name_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::StringInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::StringInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_String;
                nmb_entry.idx1 = info.string_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::FieldrefInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::FieldrefInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Fieldref;
                nmb_entry.idx1 = info.class_index;
                nmb_entry.idx2 = info.name_and_type_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::MethodrefInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::MethodrefInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Methodref;
                nmb_entry.idx1 = info.class_index;
                nmb_entry.idx2 = info.name_and_type_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::InterfaceMethodrefInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::InterfaceMethodrefInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_InterfaceMethodref;
                nmb_entry.idx1 = info.class_index;
                nmb_entry.idx2 = info.name_and_type_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::NameAndTypeInfo>(jcfp_entry.info)) {
                auto& info = std::get<jcfp::ConstantPoolEntry::NameAndTypeInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_NameAndType;
                nmb_entry.idx1 = info.name_index;
                nmb_entry.idx2 = info.descriptor_index;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::IntegerInfo>(jcfp_entry.info)) {
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Integer;
                nmb_entry.value = std::get<jcfp::ConstantPoolEntry::IntegerInfo>(jcfp_entry.info).bytes;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::FloatInfo>(jcfp_entry.info)) {
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Float;
                nmb_entry.value = std::get<jcfp::ConstantPoolEntry::FloatInfo>(jcfp_entry.info).bytes;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::LongInfo>(jcfp_entry.info)) {
                const auto& info = std::get<jcfp::ConstantPoolEntry::LongInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Long;
                nmb_entry.value = (static_cast<uint64_t>(info.high_bytes) << 32) | info.low_bytes;
            }
            else if (std::holds_alternative<jcfp::ConstantPoolEntry::DoubleInfo>(jcfp_entry.info)) {
                const auto& info = std::get<jcfp::ConstantPoolEntry::DoubleInfo>(jcfp_entry.info);
                nmb_entry.tag = JVMCore::JVM_CONSTANT_Double;
                nmb_entry.value = (static_cast<uint64_t>(info.high_bytes) << 32) | info.low_bytes;
            }
			else if (std::holds_alternative<jcfp::ConstantPoolEntry::MethodHandleInfo>(jcfp_entry.info)) {
				const auto& info = std::get<jcfp::ConstantPoolEntry::MethodHandleInfo>(jcfp_entry.info);
				nmb_entry.tag = JVMCore::JVM_CONSTANT_MethodHandle;
				nmb_entry.idx1 = info.reference_kind;
				nmb_entry.idx2 = info.reference_index;
			}
			else if (std::holds_alternative<jcfp::ConstantPoolEntry::MethodTypeInfo>(jcfp_entry.info)) {
				const auto& info = std::get<jcfp::ConstantPoolEntry::MethodTypeInfo>(jcfp_entry.info);
				nmb_entry.tag = JVMCore::JVM_CONSTANT_MethodType;
				nmb_entry.idx1 = info.descriptor_index;
			}
			else if (std::holds_alternative<jcfp::ConstantPoolEntry::InvokeDynamicInfo>(jcfp_entry.info)) {
				const auto& info = std::get<jcfp::ConstantPoolEntry::InvokeDynamicInfo>(jcfp_entry.info);
				nmb_entry.tag = JVMCore::JVM_CONSTANT_InvokeDynamic;
				nmb_entry.idx1 = info.bootstrap_method_attr_index;
				nmb_entry.idx2 = info.name_and_type_index;
			}
            else {

                nmb_entry.tag = 0;
            }

            builder.cp_entries.push_back(nmb_entry);

            if (nmb_entry.tag == JVMCore::JVM_CONSTANT_Long || nmb_entry.tag == JVMCore::JVM_CONSTANT_Double) {
                builder.cp_entries.push_back({0, "", 0, 0});
                i++;
            }
        }


		for (const auto& attribute : cf.attributes) {
			if (attribute.attribute_name_index == 0 ||
				attribute.attribute_name_index >= cp.count())
				continue;
			const auto& nameEntry = cp.get_entry(attribute.attribute_name_index);
			if (!std::holds_alternative<jcfp::ConstantPoolEntry::Utf8Info>(nameEntry.info))
				continue;
			if (std::get<jcfp::ConstantPoolEntry::Utf8Info>(nameEntry.info).bytes !=
				"BootstrapMethods")
				continue;

			const auto& bytes = attribute.info;
			auto readU2 = [&](size_t& cursor, uint16_t& value) -> bool {
				if (cursor + 2 > bytes.size()) return false;
				value = static_cast<uint16_t>(
					(static_cast<uint16_t>(bytes[cursor]) << 8) |
					static_cast<uint16_t>(bytes[cursor + 1]));
				cursor += 2;
				return true;
			};

			size_t cursor = 0;
			uint16_t count = 0;
			if (!readU2(cursor, count)) {
				Log("[JCFP] ERROR: truncated BootstrapMethods header");
				return 0;
			}
			builder.bootstrap_operands.assign(static_cast<size_t>(count) * 2, 0);
			for (uint16_t bootstrap = 0; bootstrap < count; ++bootstrap) {
				const uint32_t tupleOffset =
					static_cast<uint32_t>(builder.bootstrap_operands.size());
				builder.bootstrap_operands[static_cast<size_t>(bootstrap) * 2] =
					static_cast<uint16_t>(tupleOffset & 0xFFFFu);
				builder.bootstrap_operands[static_cast<size_t>(bootstrap) * 2 + 1] =
					static_cast<uint16_t>(tupleOffset >> 16);

				uint16_t methodRef = 0;
				uint16_t argumentCount = 0;
				if (!readU2(cursor, methodRef) || !readU2(cursor, argumentCount)) {
					Log("[JCFP] ERROR: truncated BootstrapMethods tuple %u", bootstrap);
					return 0;
				}
				builder.bootstrap_operands.push_back(methodRef);
				builder.bootstrap_operands.push_back(argumentCount);
				for (uint16_t argument = 0; argument < argumentCount; ++argument) {
					uint16_t cpIndex = 0;
					if (!readU2(cursor, cpIndex)) {
						Log("[JCFP] ERROR: truncated BootstrapMethods arguments");
						return 0;
					}
					builder.bootstrap_operands.push_back(cpIndex);
				}
			}
			if (cursor != bytes.size()) {
				Log("[JCFP] ERROR: trailing bytes in BootstrapMethods: %zu",
					bytes.size() - cursor);
				return 0;
			}
			Log("[JCFP] BootstrapMethods flattened: methods=%u operands=%zu",
				static_cast<unsigned>(count), builder.bootstrap_operands.size());
			break;
		}

        int max_stack = 0;
        int max_locals = 0;
        int method_access_flags = 0;


        Log("[JCFP] Looking for method '%s' desc '%s' in %zu methods",
            targetMethodName.c_str(), targetMethodDesc.c_str(), cf.methods.size());
        bool methodFound = false;
        for (auto& method : cf.methods) {
            std::string methodName = "";
            std::string methodDesc = "";

            if (method.name_index > 0 && method.name_index < cp.count()) {
                auto& utf8_info = cp.get_entry(method.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                methodName = utf8_info.bytes;
            }
            if (method.descriptor_index > 0 && method.descriptor_index < cp.count()) {
                auto& utf8_info = cp.get_entry(method.descriptor_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                methodDesc = utf8_info.bytes;
            }

            if (methodName == targetMethodName && methodDesc == targetMethodDesc) {
                method_access_flags = method.access_flags;

                for (auto& attr : method.attributes) {
                    std::string attrName = "";
                    if (attr.attribute_name_index > 0 && attr.attribute_name_index < cp.count()) {
                        auto& utf8_info = cp.get_entry(attr.attribute_name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                        attrName = utf8_info.bytes;
                    }

                    if (attrName == "Code" && attr.info.size() >= 8) {


                        uint32_t code_length = (attr.info[4] << 24) | (attr.info[5] << 16) | (attr.info[6] << 8) | attr.info[7];

                        if (attr.info.size() >= 8 + code_length) {
                            builder.code.assign(attr.info.begin() + 8, attr.info.begin() + 8 + code_length);
                            max_stack = (attr.info[0] << 8) | attr.info[1];
                            max_locals = (attr.info[2] << 8) | attr.info[3];
                            Log("[JCFP] Found Code attr: code_length=%u max_stack=%d max_locals=%d",
                                code_length, max_stack, max_locals);


                            size_t et_offset = 8 + code_length;
                            if (attr.info.size() >= et_offset + 2) {
                                uint16_t et_length = (attr.info[et_offset] << 8) | attr.info[et_offset + 1];
                                et_offset += 2;
                                Log("[JCFP] Exception table: %d entries", (int)et_length);

                                for (uint16_t ei = 0; ei < et_length; ei++) {
                                    if (attr.info.size() >= et_offset + 8) {
                                        NativeMethodBuilder::ExceptionTableEntry ete;
                                        ete.start_pc    = (attr.info[et_offset + 0] << 8) | attr.info[et_offset + 1];
                                        ete.end_pc      = (attr.info[et_offset + 2] << 8) | attr.info[et_offset + 3];
                                        ete.handler_pc  = (attr.info[et_offset + 4] << 8) | attr.info[et_offset + 5];
                                        ete.catch_type  = (attr.info[et_offset + 6] << 8) | attr.info[et_offset + 7];
                                        builder.exception_table.push_back(ete);
                                        Log("[JCFP] ExceptionTable[%d]: start=%d end=%d handler=%d catch_type=%d",
                                            (int)ei, (int)ete.start_pc, (int)ete.end_pc, (int)ete.handler_pc, (int)ete.catch_type);
                                        et_offset += 8;
                                    }
                                }
                            }

                            methodFound = true;
                        }
                        break;
                    }
                }
                if (!methodFound &&
                    (method_access_flags & (0x0100 | 0x0400)) != 0) {


                    methodFound = true;
                    Log("[JCFP] Method has no Code by design: access=0x%X",
                        method_access_flags);
                }
                break;
            }
        }

        if (!methodFound) {
            Log("[-] Method %s%s not found in JCFP ClassFile or missing Code attribute", targetMethodName.c_str(), targetMethodDesc.c_str());
            return 0;
        }

        if (builder.code.empty() &&
            (method_access_flags & (0x0100 | 0x0400)) == 0) {
            Log("[-] Method bytecode is empty");
            return 0;
        }


        auto cpAlloc = reinterpret_cast<NativeMethodBuilder::fn_cp_alloc_t>(JvmApi::ConstantPoolAllocAddr());
        auto mAlloc = reinterpret_cast<NativeMethodBuilder::fn_m_alloc_t>(JvmApi::MethodAllocAddr());
        auto symAlloc = reinterpret_cast<NativeMethodBuilder::fn_new_symbol_t>(JvmApi::SymbolTableLookupAddr());

        if (!cpAlloc || !mAlloc || !symAlloc) {
            Log("[-] Missing JVM allocation functions");
            return 0;
        }


        uintptr_t objKlass = KlassInjector::FindObjectKlass(hJvm);
        uintptr_t templateMethod = 0;
        Log("[JCFP] objKlass=%p", (void*)objKlass);
        if (objKlass) {
            const uintptr_t methodsArr = JvmApi::SafeRead<uintptr_t>(
                objKlass + JvmMapper::InstanceKlass::methods);
            const int32_t len = methodsArr ? JvmApi::SafeRead<int32_t>(
                methodsArr + JvmMapper::Array::length) : 0;
            const uintptr_t m0 = (len > 0 && len < 200)
                ? JvmApi::SafeRead<uintptr_t>(methodsArr + JvmMapper::Array::data)
                : 0;
            if (m0) {
                const uintptr_t cm = JvmApi::SafeRead<uintptr_t>(
                    m0 + JvmMapper::Method::const_method);
                const uintptr_t cp = cm ? JvmApi::SafeRead<uintptr_t>(
                    cm + JvmMapper::ConstMethod::constants) : 0;
                const uint16_t name_idx = cm ? JvmApi::SafeRead<uint16_t>(
                    cm + JvmMapper::ConstMethod::name_index) : 0;
                if (cp && name_idx > 0 && name_idx < 2000) {
                    templateMethod = m0;
                    Log("[JCFP] template method from mapped InstanceKlass::_methods offset=0x%X len=%d m0=%p",
                        (int)JvmMapper::InstanceKlass::methods, len, (void*)m0);
                }
            }
        }


        Log("[JCFP] Calling NativeMethodBuilder::build()  cp_entries=%d bytecode_bytes=%d",
            (int)builder.cp_entries.size(), (int)builder.code.size());
        uintptr_t methodPtr = builder.build(cld, thread, cpAlloc, mAlloc, symAlloc,
            templateMethod, env, max_stack, max_locals, targetMethodName,
            targetMethodDesc, method_access_flags, sharedClassCp);

        return methodPtr;
    }

    static std::vector<BuiltMethod> BuildAllMethodsFromJCFP(HMODULE hJvm, uintptr_t cld, void* thread, jcfp::ClassFile& cf, JNIEnv* env) {
        std::vector<BuiltMethod> methods;
        uintptr_t sharedClassCp = 0;

        for (auto& method : cf.methods) {
            std::string methodName = "";
            std::string methodDesc = "";
            auto& cp = cf.constant_pool;

            if (method.name_index > 0 && method.name_index < cp.count()) {
                auto& utf8_info = cp.get_entry(method.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                methodName = utf8_info.bytes;
            }
            if (method.descriptor_index > 0 && method.descriptor_index < cp.count()) {
                auto& utf8_info = cp.get_entry(method.descriptor_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                methodDesc = utf8_info.bytes;
            }

            uintptr_t mPtr = BuildMethodFromJCFP(
                hJvm, cld, thread, cf, methodName, methodDesc, env, sharedClassCp);
            if (!mPtr) {
                Log("[JCFP] ERROR: class method build failed; rejecting partial class: %s%s",
                    methodName.c_str(), methodDesc.c_str());
                return {};
            }

            methods.push_back({methodName, methodDesc, method.access_flags, mPtr});
            if (!sharedClassCp) {
                uintptr_t cm = JvmApi::SafeRead<uintptr_t>(
                    mPtr + JvmMapper::Method::const_method);
                sharedClassCp = cm ? JvmApi::SafeRead<uintptr_t>(
                    cm + JvmMapper::ConstMethod::constants) : 0;
                if (!sharedClassCp) {
                    Log("[JCFP] ERROR: first Method has no class ConstantPool");
                    return {};
                }
                Log("[JCFP] class-wide ConstantPool selected: %p",
                    (void*)sharedClassCp);
            }
        }

        Log("[JCFP] class-wide ConstantPool ready: cp=%p methods=%zu",
            (void*)sharedClassCp, methods.size());


        auto symbolKeys = [](const BuiltMethod& built) {
            uintptr_t nameSymbol = 0;
            uintptr_t signatureSymbol = 0;
            uintptr_t cm = JvmApi::SafeRead<uintptr_t>(
                built.method + JvmMapper::Method::const_method);
            if (cm) {
                uintptr_t nativeCp = JvmApi::SafeRead<uintptr_t>(
                    cm + JvmMapper::ConstMethod::constants);
                uint16_t nameIndex = JvmApi::SafeRead<uint16_t>(
                    cm + JvmMapper::ConstMethod::name_index);
                uint16_t signatureIndex = JvmApi::SafeRead<uint16_t>(
                    cm + JvmMapper::ConstMethod::signature_index);
                if (nativeCp) {
                    uintptr_t cpBase = nativeCp + JvmMapper::ConstantPool::base;
                    nameSymbol = JvmApi::SafeRead<uintptr_t>(
                        cpBase + static_cast<uintptr_t>(nameIndex) * 8);
                    signatureSymbol = JvmApi::SafeRead<uintptr_t>(
                        cpBase + static_cast<uintptr_t>(signatureIndex) * 8);
                }
            }
            return std::pair<uintptr_t, uintptr_t>(nameSymbol, signatureSymbol);
        };

        std::sort(methods.begin(), methods.end(), [&](const BuiltMethod& a, const BuiltMethod& b) {
            const auto ka = symbolKeys(a);
            const auto kb = symbolKeys(b);
            if (ka.first != kb.first) return ka.first < kb.first;
            return ka.second < kb.second;
        });


        for (size_t i = 0; i < methods.size(); ++i) {
            uintptr_t idOwner = JvmApi::SafeRead<uintptr_t>(
                methods[i].method + JvmMapper::Method::id_owner);
            if (!idOwner) {
                Log("[-] Method id owner missing: %s%s method=%p",
                    methods[i].name.c_str(), methods[i].descriptor.c_str(),
                    (void*)methods[i].method);
                methods.clear();
                return methods;
            }
            *reinterpret_cast<uint16_t*>(idOwner + JvmMapper::MethodIdOwner::method_idnum) =
                static_cast<uint16_t>(i);

            uintptr_t cm = JvmApi::SafeRead<uintptr_t>(
                methods[i].method + JvmMapper::Method::const_method);
            uint16_t nameIndex = cm ? JvmApi::SafeRead<uint16_t>(
                cm + JvmMapper::ConstMethod::name_index) : 0;


            *reinterpret_cast<uint16_t*>(idOwner + JvmMapper::MethodIdOwner::original_idnum) =
                static_cast<uint16_t>(i);
            *reinterpret_cast<uint16_t*>(idOwner + JvmMapper::MethodIdOwner::name_index) = nameIndex;
            Log("[JCFP] method_idnum=%zu shadow_name_index=%u owner=%p %s%s",
                i, static_cast<unsigned>(nameIndex), (void*)idOwner,
                methods[i].name.c_str(),
                methods[i].descriptor.c_str());
        }

        for (const auto& built : methods) {
            const auto key = symbolKeys(built);
            Log("[JCFP] HotSpot method order: name_sym=%p sig_sym=%p %s%s",
                (void*)key.first, (void*)key.second,
                built.name.c_str(), built.descriptor.c_str());
        }
        return methods;
    }
};
