#pragma once
#include <Windows.h>
#include <cstdint>
#include <cstdio>
#include <intrin.h>
#include <jni.h>
#include "Logging.hpp"
#include "PatternScanner.hpp"
#include "JvmMapper.hpp"

class MethodInvoker {
public:
    static uintptr_t g_TlsIndexAddr;
    static uintptr_t g_CallStubPtrAddr;
    static uintptr_t g_SerializeMemAddr;
    static uintptr_t g_GetEnvAddr;


    static inline const std::ptrdiff_t& kActiveHandlesOffset = JvmMapper::JavaThread::active_handles;

    static inline const std::ptrdiff_t& kThreadStateOffset = JvmMapper::JavaThread::thread_state;
    static inline const std::ptrdiff_t& kLastJavaSpOffset = JvmMapper::JavaThread::last_java_sp;
    static inline const std::ptrdiff_t& kLastJavaPcOffset = JvmMapper::JavaThread::last_java_pc;
    static inline const std::ptrdiff_t& kLastJavaFpOffset = JvmMapper::JavaThread::last_java_fp;
    static inline const std::ptrdiff_t& kPendingExOffset = JvmMapper::JavaThread::pending_exception;


    static constexpr int kThreadInNative      = JvmMapper::State::thread_in_native;
    static constexpr int kThreadInNativeTrans = JvmMapper::State::thread_in_native_trans;
    static constexpr int kThreadInVM          = JvmMapper::State::thread_in_vm;
    static constexpr int kThreadInVMTrans     = JvmMapper::State::thread_in_vm_trans;
    static constexpr int kThreadInJava        = JvmMapper::State::thread_in_java;
    static constexpr int T_VOID               = JvmMapper::State::basic_type_void;
    static constexpr int T_OBJECT             = JvmMapper::State::basic_type_object;


    using fn_call_stub_t = void(__fastcall*)(
        void*     link,
        void*     result_val,
        int       result_type,
        void*     method,
        void*     entry_point,
        void*     parameters,
        int       size_params,
        void*     thread
    );

    using fn_serialize_t = void(__fastcall*)(uintptr_t thread);

    struct JCW {
        alignas(uintptr_t) unsigned char bytes[0x80]{};
        void Set(std::ptrdiff_t offset, uintptr_t value) {
            if (offset >= 0 && static_cast<size_t>(offset) + sizeof(value) <= sizeof(bytes))
                *reinterpret_cast<uintptr_t*>(bytes + offset) = value;
        }
        uintptr_t Get(std::ptrdiff_t offset) const {
            return offset >= 0 && static_cast<size_t>(offset) + sizeof(uintptr_t) <= sizeof(bytes)
                ? *reinterpret_cast<const uintptr_t*>(bytes + offset) : 0;
        }
    };

    struct JV {
        int      type;
        uint32_t _pad;
        uint64_t value;
    };

    static void DumpMethod(uintptr_t method_ptr, const char* prefix) {
        if constexpr (!kEnableLogging) return;
        if (!method_ptr) return;

        uintptr_t cm = *reinterpret_cast<uintptr_t*>(
            method_ptr + JvmMapper::Method::const_method);
        Log("[*] %s: --- Method Dump ---", prefix);
        Log("[*] %s: Method = %p", prefix, (void*)method_ptr);
        Log("[*] %s: ConstMethod = %p", prefix, (void*)cm);

        if (cm) {

            uint16_t code_size  = *reinterpret_cast<uint16_t*>(cm + Offsets::CM_code_size);
            uint16_t max_stack  = *reinterpret_cast<uint16_t*>(cm + Offsets::CM_max_stack);
            uint16_t max_locals = *reinterpret_cast<uint16_t*>(cm + Offsets::CM_max_locals);
            uint16_t size_params= *reinterpret_cast<uint16_t*>(cm + Offsets::CM_size_of_params);
            uintptr_t code_base = cm + Offsets::CM_bytecode;
            uintptr_t code_end  = code_base + code_size;

            Log("[*] %s: code_size = %u", prefix, code_size);
            Log("[*] %s: max_stack = %u", prefix, max_stack);
            Log("[*] %s: max_locals = %u", prefix, max_locals);
            Log("[*] %s: size_of_parameters = %u", prefix, size_params);
            Log("[*] %s: code_base = %p", prefix, (void*)code_base);
            Log("[*] %s: code_end = %p", prefix, (void*)code_end);

            char dumpBuf[256];
            int pos = 0;
            int limit = code_size > 100 ? 100 : code_size;
            for (int bi = 0; bi < limit; bi++) {
                pos += snprintf(dumpBuf + pos, sizeof(dumpBuf) - pos, "%02X ", *reinterpret_cast<uint8_t*>(code_base + bi));
                if (pos > 240) { Log("[*] %s: bytecode: %s", prefix, dumpBuf); pos = 0; }
            }
            if (pos > 0) Log("[*] %s: bytecode: %s", prefix, dumpBuf);

            Log("[*] %s: ConstMethod Trailer Hexdump (-32 to +128 from code_end):", prefix);
            for (int row = -32; row < 128; row += 16) {
                pos = snprintf(dumpBuf, sizeof(dumpBuf), "[*] %s:   %+03d: ", prefix, row);
                for (int col = 0; col < 16; col++) {
                    uint8_t b = 0;
                    __try { b = *reinterpret_cast<uint8_t*>(code_end + row + col); } __except(1) {}
                    pos += snprintf(dumpBuf + pos, sizeof(dumpBuf) - pos, "%02X ", b);
                }
                Log("%s", dumpBuf);
            }
        }
        Log("[*] %s: -------------------", prefix);
    }

    static bool Initialize(HMODULE hJvm) {
        if (!hJvm) return false;

        g_GetEnvAddr = PatternScanner::FindPattern(hJvm, "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 8B 05 ? ? ? ? 41 8B F0");
        if (!g_GetEnvAddr) { Log("[-] Pattern failed: GetEnv"); return false; }

        g_SerializeMemAddr = PatternScanner::FindPattern(hJvm, "48 83 EC ? 48 C1 E9");
        if (!g_SerializeMemAddr) { Log("[-] Pattern failed: SerializeMem"); return false; }

        uintptr_t tlsRef = PatternScanner::FindPattern(hJvm, "8B 0D ? ? ? ? FF 15 ? ? ? ? 48 8B F8 48 85 C0 0F 84");
        if (!tlsRef) { Log("[-] Pattern failed: TlsIndex reference"); return false; }
        g_TlsIndexAddr = (tlsRef + 6) + *reinterpret_cast<int32_t*>(tlsRef + 2);

        uintptr_t callStubRef = PatternScanner::FindPattern(hJvm, "48 8B 3D ? ? ? ? 48 8D 4D ? E8");
        if (!callStubRef) { Log("[-] Pattern failed: call_stub reference"); return false; }
        g_CallStubPtrAddr = (callStubRef + 7) + *reinterpret_cast<int32_t*>(callStubRef + 3);

        Log("[+] Dynamic Addresses Resolved:");
        Log("    GetEnv      : %p", (void*)g_GetEnvAddr);
        Log("    SerializeMem: %p", (void*)g_SerializeMemAddr);
        Log("    TlsIndex    : %p", (void*)g_TlsIndexAddr);
        Log("    CallStub    : %p", (void*)g_CallStubPtrAddr);
        return true;
    }


    static void TransitionToVM(uintptr_t thread)
    {
        *reinterpret_cast<int*>(thread + kThreadStateOffset) = kThreadInNativeTrans;
        _mm_mfence();
        reinterpret_cast<fn_serialize_t>(g_SerializeMemAddr)(thread);
        *reinterpret_cast<int*>(thread + kThreadStateOffset) = kThreadInVM;
        _mm_mfence();
    }


    static void TransitionToNative(uintptr_t thread)
    {
        *reinterpret_cast<int*>(thread + kThreadStateOffset) = kThreadInNativeTrans;
        _mm_mfence();
        reinterpret_cast<fn_serialize_t>(g_SerializeMemAddr)(thread);
        *reinterpret_cast<int*>(thread + kThreadStateOffset) = kThreadInNative;
        _mm_mfence();
    }


    static bool InvokeStaticVoid(uintptr_t method_ptr, jobject objectArgument = nullptr,
                                 bool withObjectArgument = false)
    {
        if (!method_ptr) return false;

        HMODULE hJvm = GetModuleHandleA("jvm.dll");
        if (!hJvm) return false;

        DWORD tlsIdx = *reinterpret_cast<DWORD*>(g_TlsIndexAddr);
        auto thread = reinterpret_cast<uintptr_t>(TlsGetValue(tlsIdx));
        if (!thread) { Log("[-] not on JavaThread\n"); return false; }

        int state = *reinterpret_cast<int*>(thread + kThreadStateOffset);
        Log("[*] IV: thread=%p state=%d method=%p", (void*)thread, state, (void*)method_ptr);

        auto callStub = *reinterpret_cast<fn_call_stub_t*>(g_CallStubPtrAddr);
        if (!callStub) { Log("[-] call_stub null\n"); return false; }


        void* entry = *reinterpret_cast<void**>(
            method_ptr + JvmMapper::Method::from_interpreted_entry);
        if (!entry) { Log("[-] entry null\n"); return false; }
        Log("[*] IV: call_stub=%p entry=%p", (void*)callStub, entry);


        Log("[*] IV: method dump:");
        Log("[*] IV: mapped vtable       = %p", (void*)*reinterpret_cast<uintptr_t*>(
            method_ptr + JvmMapper::Klass::vtable_ptr));
        Log("[*] IV: mapped constMethod   = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::const_method));
        Log("[*] IV: mapped i2i_entry     = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::i2i_entry));
        Log("[*] IV: mapped access_flags  = 0x%08X", *reinterpret_cast<uint32_t*>(method_ptr + JvmMapper::Method::access_flags));
        Log("[*] IV: mapped vtable_index  = %d", *reinterpret_cast<int32_t*>(method_ptr + JvmMapper::Method::vtable_index));
        Log("[*] IV: mapped method_size   = %u", *reinterpret_cast<uint16_t*>(method_ptr + JvmMapper::Method::method_size));
        Log("[*] IV: mapped flags(u1)     = 0x%02X", *reinterpret_cast<uint8_t*>(method_ptr + JvmMapper::Method::flags));
        Log("[*] IV: mapped from_interp   = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::from_interpreted_entry));
        Log("[*] IV: mapped adapter       = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::adapter));
        Log("[*] IV: mapped from_compiled = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::from_compiled_entry));
        Log("[*] IV: mapped code          = %p", (void*)*reinterpret_cast<uintptr_t*>(method_ptr + JvmMapper::Method::code));

        DumpMethod(method_ptr, "IV");

        uintptr_t saved_sp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset);
        uintptr_t saved_pc = *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset);
        uintptr_t saved_fp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset);

        uintptr_t current_rsp;
#ifdef _MSC_VER
        current_rsp = (uintptr_t)_AddressOfReturnAddress();
#else
        current_rsp = (uintptr_t)__builtin_frame_address(0);
#endif
        Log("[*] IV: Current RSP=%p", (void*)current_rsp);

        NT_TIB* tib = (NT_TIB*)NtCurrentTeb();
        uintptr_t real_stack_base   = (uintptr_t)tib->StackBase;
        uintptr_t real_stack_limit  = (uintptr_t)tib->StackLimit;
        uintptr_t real_stack_size   = real_stack_base - real_stack_limit;

        Log("[*] IV: TEB StackBase=%p StackLimit=%p Size=0x%X", (void*)real_stack_base, (void*)real_stack_limit, (uint32_t)real_stack_size);

        const auto kStackBaseOffset = JvmMapper::JavaThread::stack_base;
        const auto kStackSizeOffset = JvmMapper::JavaThread::stack_size;

        uintptr_t jvm_stack_base = *reinterpret_cast<uintptr_t*>(thread + kStackBaseOffset);
        uintptr_t jvm_stack_size = *reinterpret_cast<uintptr_t*>(thread + kStackSizeOffset);

        Log("[*] IV: JVM Thread StackBase=%p StackSize=0x%X", (void*)jvm_stack_base, (uint32_t)jvm_stack_size);

        Log("[*] IV: JVM Thread StackBase=%p StackSize=0x%X", (void*)jvm_stack_base, (uint32_t)jvm_stack_size);


        uint32_t* state_ptr = reinterpret_cast<uint32_t*>(thread + kThreadStateOffset);
        *state_ptr = kThreadInJava;
        _mm_mfence();

        JV result{};
        result.type = T_VOID;

        JCW jcw{};
        jcw.Set(JvmMapper::JavaCallWrapper::thread, thread);
        jcw.Set(JvmMapper::JavaCallWrapper::handles, *reinterpret_cast<uintptr_t*>(thread + kActiveHandlesOffset));
        jcw.Set(JvmMapper::JavaCallWrapper::callee_method, method_ptr);
        jcw.Set(JvmMapper::JavaCallWrapper::receiver, 0);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_sp, saved_sp);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_pc, saved_pc);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_fp, saved_fp);
        jcw.Set(JvmMapper::JavaCallWrapper::result, reinterpret_cast<uintptr_t>(&result));


        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = 0;
        _mm_mfence();


        intptr_t method_params[1] = { 0 };

        bool ok = false;
        Log("[*] IV: JCW thread=%p handles=%p callee=%p",
            (void*)jcw.Get(JvmMapper::JavaCallWrapper::thread),
            (void*)jcw.Get(JvmMapper::JavaCallWrapper::handles),
            (void*)jcw.Get(JvmMapper::JavaCallWrapper::callee_method));
        Log("[*] IV: firing call_stub...");
        __try {

            if (withObjectArgument && objectArgument)
                method_params[0] = *reinterpret_cast<intptr_t*>(objectArgument);
            callStub(
                &jcw,
                &result.value,
                T_VOID,
                reinterpret_cast<void*>(method_ptr),
                entry,
                method_params,
                withObjectArgument ? 1 : 0,
                reinterpret_cast<void*>(thread)
            );
            Log("[*] IV: call_stub returned");
            ok = true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Log("[-] IV SEH: 0x%08X", GetExceptionCode());
        }


        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = saved_sp;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = saved_pc;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = saved_fp;


        *reinterpret_cast<uintptr_t*>(thread + kStackSizeOffset) = jvm_stack_size;

        _mm_mfence();


        if (state_ptr) {
            *state_ptr = state;
            _mm_mfence();
        } else {
            *reinterpret_cast<int*>(thread + kThreadStateOffset) = state;
            _mm_mfence();
        }

        uintptr_t ex = *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset);
        if (ex) {
            Log("[-] Java exception oop: %p", (void*)ex);


            uintptr_t klass = 0;
            uintptr_t klassOffsetState = JvmMapper::Get(
                JvmMapper::Address::KlassFieldOffset);
            __try {
                if (klassOffsetState) {
                    int klassOffset = *reinterpret_cast<int*>(klassOffsetState);
                    if (klassOffset > 0 && klassOffset < 0x40)
                        klass = *reinterpret_cast<uintptr_t*>(ex + klassOffset);
                }
            } __except(1) {}

            if (klass) {
                uintptr_t nameSym = 0;
                __try {
                    nameSym = *reinterpret_cast<uintptr_t*>(
                        klass + JvmMapper::Klass::name);
                } __except(1) {}

                if (nameSym) {
                    uint16_t nameLen = 0;
                    __try {
                        nameLen = *reinterpret_cast<uint16_t*>(
                            nameSym + JvmMapper::Symbol::length);
                    } __except(1) {}

                    if (nameLen > 0 && nameLen < 512) {
                        char nameBuf[512] = {};
                        __try {
                            memcpy(nameBuf,
                                reinterpret_cast<void*>(nameSym + JvmMapper::Symbol::body),
                                nameLen);
                        } __except(1) {}
                        nameBuf[nameLen] = 0;
                        Log("[-] EXCEPTION CLASS: %s", nameBuf);
                    }
                }
            }

            *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset) = 0;
            return false;
        }

        if (ok) Log("[+] InvokeStaticVoid OK");
        return ok;
    }


    struct JCA {
        static constexpr int MAX_ARGS = 16;

        intptr_t  value_buffer[MAX_ARGS + 1]{};
        uint8_t   value_state_buffer[MAX_ARGS + 1]{};

        intptr_t* value       = nullptr;
        uint8_t*  value_state = nullptr;
        int       size        = 0;
        int       max_size    = MAX_ARGS;
        bool      start_at_zero = true;

        JCA() {
            value       = &value_buffer[1];
            value_state = &value_state_buffer[1];
        }


        inline void push_jobject(jobject h) {
            value_state[size] = 3;
            value[size]       = reinterpret_cast<intptr_t>(h);
            size++;
        }


        inline void push_int(int i) {
            value_state[size] = 0;
            value[size]       = static_cast<intptr_t>(i);
            size++;
        }
    };


    static uintptr_t InvokeDefineClass(
        uintptr_t defineClassMethod,
        jobject   classLoaderObj,
        jstring   nameObj,
        jbyteArray bytesObj,
        int        length)
    {
        if (!defineClassMethod) return 0;

        DWORD tlsIdx = *reinterpret_cast<DWORD*>(g_TlsIndexAddr);
        auto thread  = reinterpret_cast<uintptr_t>(TlsGetValue(tlsIdx));
        if (!thread) { Log("[-] IDC: not on JavaThread"); return 0; }

        int state = *reinterpret_cast<int*>(thread + kThreadStateOffset);
        Log("[*] IDC: thread=%p state=%d method=%p",
            (void*)thread, state, (void*)defineClassMethod);

        auto callStub = *reinterpret_cast<fn_call_stub_t*>(g_CallStubPtrAddr);
        if (!callStub) { Log("[-] IDC: call_stub null"); return 0; }

        void* entry = *reinterpret_cast<void**>(
            defineClassMethod + JvmMapper::Method::from_interpreted_entry);
        if (!entry) { Log("[-] IDC: entry null"); return 0; }
        Log("[*] IDC: call_stub=%p entry=%p", (void*)callStub, entry);

        uintptr_t saved_sp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset);
        uintptr_t saved_pc = *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset);
        uintptr_t saved_fp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset);

        if (state == kThreadInNative)
            TransitionToVM(thread);

        JV result{};
        result.type  = T_OBJECT;
        result.value = 0;

        JCW jcw{};
        jcw.Set(JvmMapper::JavaCallWrapper::thread, thread);
        jcw.Set(JvmMapper::JavaCallWrapper::handles, *reinterpret_cast<uintptr_t*>(thread + kActiveHandlesOffset));
        jcw.Set(JvmMapper::JavaCallWrapper::callee_method, defineClassMethod);
        jcw.Set(JvmMapper::JavaCallWrapper::receiver, reinterpret_cast<uintptr_t>(classLoaderObj));
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_sp, saved_sp);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_pc, saved_pc);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_fp, saved_fp);
        jcw.Set(JvmMapper::JavaCallWrapper::result, reinterpret_cast<uintptr_t>(&result));

        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = 0;
        _mm_mfence();


        JCA args;
        args.push_jobject(classLoaderObj);
        args.push_jobject(nameObj);
        args.push_jobject(bytesObj);
        args.push_int(0);
        args.push_int(length);

        Log("[*] IDC: args.size=%d", args.size);

        uintptr_t retval = 0;
        __try {
            callStub(
                &jcw,
                &result.value,
                T_OBJECT,
                reinterpret_cast<void*>(defineClassMethod),
                entry,
                args.value,
                args.size,
                reinterpret_cast<void*>(thread)
            );


            uintptr_t vm_result = *reinterpret_cast<uintptr_t*>(
                thread + JvmMapper::JavaThread::vm_result);
            if (vm_result != 0) {
                retval = vm_result;
                *reinterpret_cast<uintptr_t*>(
                    thread + JvmMapper::JavaThread::vm_result) = 0;
            } else {
                retval = static_cast<uintptr_t>(result.value);
            }
            Log("[*] IDC: call_stub returned, Class OOP=%p", (void*)retval);
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Log("[-] IDC SEH: 0x%08X", GetExceptionCode());
        }

        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = saved_sp;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = saved_pc;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = saved_fp;
        _mm_mfence();

        if (state == kThreadInNative) {
            TransitionToNative(thread);
        } else {
            *reinterpret_cast<int*>(thread + kThreadStateOffset) = state;
            _mm_mfence();
        }

        uintptr_t ex = *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset);
        if (ex) {
            Log("[-] IDC: Java exception: %p", (void*)ex);
            *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset) = 0;
            return 0;
        }

        if (retval) Log("[+] InvokeDefineClass OK, Class OOP=%p", (void*)retval);
        else        Log("[-] InvokeDefineClass returned null");
        return retval;
    }
    static uintptr_t InvokeStaticObject(uintptr_t method_ptr)
    {
        if (!method_ptr) return 0;

        HMODULE hJvm = GetModuleHandleA("jvm.dll");
        if (!hJvm) return 0;

        DWORD tlsIdx = *reinterpret_cast<DWORD*>(g_TlsIndexAddr);
        auto thread = reinterpret_cast<uintptr_t>(TlsGetValue(tlsIdx));
        if (!thread) { Log("[-] ISO: not on JavaThread"); return 0; }

        int state = *reinterpret_cast<int*>(thread + kThreadStateOffset);
        Log("[*] ISO: thread=%p state=%d method=%p", (void*)thread, state, (void*)method_ptr);

        auto callStub = *reinterpret_cast<fn_call_stub_t*>(g_CallStubPtrAddr);
        if (!callStub) { Log("[-] ISO: call_stub null"); return 0; }

        void* entry = *reinterpret_cast<void**>(
            method_ptr + JvmMapper::Method::from_interpreted_entry);
        if (!entry) { Log("[-] ISO: entry null"); return 0; }
        Log("[*] ISO: call_stub=%p entry=%p", (void*)callStub, entry);

        DumpMethod(method_ptr, "ISO");

        uintptr_t saved_sp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset);
        uintptr_t saved_pc = *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset);
        uintptr_t saved_fp = *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset);

        if (state == kThreadInNative)
            TransitionToVM(thread);

        JV result{};
        result.type  = T_OBJECT;
        result.value = 0;

        JCW jcw{};
        jcw.Set(JvmMapper::JavaCallWrapper::thread, thread);
        jcw.Set(JvmMapper::JavaCallWrapper::handles, *reinterpret_cast<uintptr_t*>(thread + kActiveHandlesOffset));
        jcw.Set(JvmMapper::JavaCallWrapper::callee_method, method_ptr);
        jcw.Set(JvmMapper::JavaCallWrapper::receiver, 0);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_sp, saved_sp);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_pc, saved_pc);
        jcw.Set(JvmMapper::JavaCallWrapper::anchor_fp, saved_fp);
        jcw.Set(JvmMapper::JavaCallWrapper::result, reinterpret_cast<uintptr_t>(&result));

        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = 0;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = 0;
        _mm_mfence();


        intptr_t method_params[1] = { 0 };

        uintptr_t retval = 0;
        __try {
            callStub(
                &jcw,
                &result.value,
                T_OBJECT,
                reinterpret_cast<void*>(method_ptr),
                entry,
                method_params,
                0,
                reinterpret_cast<void*>(thread)
            );


            uintptr_t thread_vm_result = *reinterpret_cast<uintptr_t*>(
                thread + JvmMapper::JavaThread::vm_result);

            if (thread_vm_result != 0) {
                 retval = thread_vm_result;

                 *reinterpret_cast<uintptr_t*>(
                    thread + JvmMapper::JavaThread::vm_result) = 0;
            } else {
                 retval = static_cast<uintptr_t>(result.value);
            }

            Log("[*] ISO: call_stub returned, OOP=%p", (void*)retval);
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Log("[-] ISO SEH: 0x%08X", GetExceptionCode());
        }

        *reinterpret_cast<uintptr_t*>(thread + kLastJavaSpOffset) = saved_sp;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaPcOffset) = saved_pc;
        *reinterpret_cast<uintptr_t*>(thread + kLastJavaFpOffset) = saved_fp;
        _mm_mfence();

        if (state == kThreadInNative) {
            TransitionToNative(thread);
        } else {
            *reinterpret_cast<int*>(thread + kThreadStateOffset) = state;
            _mm_mfence();
        }

        uintptr_t ex = *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset);
        if (ex) {
            Log("[-] ISO: Java exception: %p", (void*)ex);
            *reinterpret_cast<uintptr_t*>(thread + kPendingExOffset) = 0;
            return 0;
        }

        if (retval) Log("[+] InvokeStaticObject OK, OOP=%p", (void*)retval);
        else        Log("[-] InvokeStaticObject returned null");
        return retval;
    }
};
