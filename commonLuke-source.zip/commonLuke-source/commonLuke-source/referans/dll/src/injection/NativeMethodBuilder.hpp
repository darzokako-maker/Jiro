#pragma once


#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <limits>
#include <vector>
#include <string>
#include "Logging.hpp"
#include "JvmApi.hpp"
#include "MethodInvoker.hpp"


namespace JVMCore {
    constexpr int JVM_CONSTANT_Utf8                   = 1;
    constexpr int JVM_CONSTANT_Integer                = 3;
    constexpr int JVM_CONSTANT_Float                  = 4;
    constexpr int JVM_CONSTANT_Long                   = 5;
    constexpr int JVM_CONSTANT_Double                 = 6;
    constexpr int JVM_CONSTANT_Class                  = 7;
    constexpr int JVM_CONSTANT_String                 = 8;
    constexpr int JVM_CONSTANT_Fieldref               = 9;
    constexpr int JVM_CONSTANT_Methodref              = 10;
    constexpr int JVM_CONSTANT_InterfaceMethodref     = 11;
    constexpr int JVM_CONSTANT_NameAndType            = 12;
    constexpr int JVM_CONSTANT_MethodHandle           = 15;
    constexpr int JVM_CONSTANT_MethodType             = 16;
    constexpr int JVM_CONSTANT_InvokeDynamic          = 18;
    constexpr int JVM_CONSTANT_UnresolvedClass        = 100;
}


namespace Opcode {
    constexpr uint8_t _nop = 0;
    constexpr uint8_t _aload_0 = 42;
    constexpr uint8_t _getstatic = 178;
    constexpr uint8_t _ldc = 18;
    constexpr uint8_t _ldc_w = 19;
    constexpr uint8_t _invokevirtual = 182;
    constexpr uint8_t _invokespecial = 183;
    constexpr uint8_t _invokestatic = 184;
    constexpr uint8_t _return = 177;


    constexpr uint8_t _fast_linearswitch = 0xE4;
    constexpr uint8_t _fast_binaryswitch = 0xE5;
}

class NativeMethodBuilder {
public:

    struct InlineTableSizes {
        int localvariable_table_length  = 0;
        int compressed_linenumber_size  = 0;
        int exception_table_length      = 0;
        int checked_exceptions_length   = 0;
        int method_parameters_length    = 0;
        int generic_signature_index     = 0;
        int method_annotations_length   = 0;
        int parameter_annotations_length= 0;
        int type_annotations_length     = 0;
        int default_annotations_length  = 0;
    };


    using fn_m_alloc_t = uintptr_t(__fastcall*)(uintptr_t, int, int, void*, int, void*);


    using fn_cp_alloc_t = uintptr_t(__fastcall*)(uintptr_t, int, void*);


    using fn_new_symbol_t = uintptr_t(__fastcall*)(const char*, int, void*);


    std::vector<uint8_t> code;


    struct CPEntry {
        uint8_t tag;
        std::string str;
        int idx1;
        int idx2;
        uint64_t value = 0;
    };
    std::vector<CPEntry> cp_entries;

	std::vector<uint16_t> bootstrap_operands;


    struct ExceptionTableEntry {
        uint16_t start_pc;
        uint16_t end_pc;
        uint16_t handler_pc;
        uint16_t catch_type;
    };
    std::vector<ExceptionTableEntry> exception_table;

    NativeMethodBuilder() {

        cp_entries.push_back({0, "", 0, 0});
    }


    int add_utf8(const std::string& str) {
        cp_entries.push_back({JVMCore::JVM_CONSTANT_Utf8, str, 0, 0});
        return (int)cp_entries.size() - 1;
    }

    int add_unresolved_class(const std::string& className) {
        int name_idx = add_utf8(className);
        cp_entries.push_back({JVMCore::JVM_CONSTANT_UnresolvedClass, "", name_idx, 0});
        return (int)cp_entries.size() - 1;
    }

    int add_string(const std::string& str) {
        int utf8_idx = add_utf8(str);
        cp_entries.push_back({JVMCore::JVM_CONSTANT_String, "", utf8_idx, 0});
        return (int)cp_entries.size() - 1;
    }

    int add_name_and_type(const std::string& name, const std::string& sig) {
        int name_idx = add_utf8(name);
        int sig_idx = add_utf8(sig);
        cp_entries.push_back({JVMCore::JVM_CONSTANT_NameAndType, "", name_idx, sig_idx});
        return (int)cp_entries.size() - 1;
    }

    int add_methodref(const std::string& className, const std::string& methodName, const std::string& sig) {
        int class_idx = add_unresolved_class(className);
        int nat_idx = add_name_and_type(methodName, sig);
        cp_entries.push_back({JVMCore::JVM_CONSTANT_Methodref, "", class_idx, nat_idx});
        return (int)cp_entries.size() - 1;
    }

    int add_fieldref(const std::string& className, const std::string& fieldName, const std::string& sig) {
        int class_idx = add_unresolved_class(className);
        int nat_idx = add_name_and_type(fieldName, sig);
        cp_entries.push_back({JVMCore::JVM_CONSTANT_Fieldref, "", class_idx, nat_idx});
        return (int)cp_entries.size() - 1;
    }


    void append_u1(uint8_t u1) { code.push_back(u1); }

    void append_u2(uint16_t u2) {
        code.push_back((uint8_t)(u2 >> 8));
        code.push_back((uint8_t)(u2 & 0xFF));
    }

    void op_return() {
        append_u1(Opcode::_return);
    }

    void op_getstatic(int cp_index) {
        append_u1(Opcode::_getstatic);
        append_u2((uint16_t)cp_index);
    }

    void op_ldc(int cp_index) {
        if (cp_index < 256) {
            append_u1(Opcode::_ldc);
            append_u1((uint8_t)cp_index);
        } else {
            append_u1(Opcode::_ldc_w);
            append_u2((uint16_t)cp_index);
        }
    }

    void op_fast_aldc(uint8_t resolved_ref_idx) {
        append_u1(0xE6);
        append_u1(resolved_ref_idx);
    }

    void op_invokevirtual(int cp_index) {
        append_u1(Opcode::_invokevirtual);
        append_u2((uint16_t)cp_index);
    }

    void op_invokestatic(int cp_index) {
        append_u1(Opcode::_invokestatic);
        append_u2((uint16_t)cp_index);
    }

    void op_pop() {
        append_u1(87);
    }


    uintptr_t build(uintptr_t loader_data, void* thread, fn_cp_alloc_t cpAlloc, fn_m_alloc_t mAlloc, fn_new_symbol_t symAlloc, uintptr_t templateMethod, JNIEnv* env, int max_stack, int max_locals, const std::string& method_name, const std::string& method_sig, int method_access_flags, uintptr_t shared_class_cp = 0) {
        Log("[NMB] build() start: cp_entries=%d code_bytes=%d loader_data=%p thread=%p",
            (int)cp_entries.size(), (int)code.size(), (void*)loader_data, thread);


        struct ThreadStateScope {
            uintptr_t thread;
            int original;
            bool switched;

            explicit ThreadStateScope(void* value)
                : thread(reinterpret_cast<uintptr_t>(value)), original(0), switched(false) {
                if (thread)
                    original = *reinterpret_cast<int*>(
                        thread + JvmMapper::JavaThread::thread_state);
            }

            void enter_vm() {
                if (!thread || switched || original != JvmMapper::State::thread_in_native)
                    return;
                MethodInvoker::TransitionToVM(thread);
                switched = true;
            }

            void enter_native() {
                if (!thread || !switched)
                    return;
                MethodInvoker::TransitionToNative(thread);
                switched = false;
            }

            ~ThreadStateScope() { enter_native(); }
        } threadState(thread);


        if constexpr (kEnableLogging) {
            char buf[512]; int pos = 0;
            for (size_t bi = 0; bi < code.size() && pos < 480; bi++)
                pos += snprintf(buf + pos, sizeof(buf) - pos, "%02X ", code[bi]);
            Log("[NMB] bytecode: %s", buf);
        }


        int cp_len = (int)cp_entries.size();
        const bool owns_class_cp = shared_class_cp == 0;
		if (owns_class_cp) {
			bool hasInvokeDynamic = false;
			for (int i = 1; i < cp_len; ++i) {
				if (cp_entries[i].tag == JVMCore::JVM_CONSTANT_InvokeDynamic) {
					hasInvokeDynamic = true;
					break;
				}
			}
			if (hasInvokeDynamic && bootstrap_operands.empty()) {
				Log("[NMB] ERROR: InvokeDynamic exists but BootstrapMethods operands are missing");
				return 0;
			}
		}
        uintptr_t cp = shared_class_cp;
        if (owns_class_cp) {
            threadState.enter_vm();
            cp = cpAlloc(loader_data, cp_len, thread);
            if (!cp) { Log("[NMB] ERROR: cpAlloc returned null"); return 0; }
        } else {
            const int32_t sharedLength = JvmApi::SafeRead<int32_t>(
                cp + JvmMapper::ConstantPool::length);
            if (sharedLength != cp_len) {
                Log("[NMB] ERROR: shared ConstantPool length mismatch: native=%d classfile=%d",
                    sharedLength, cp_len);
                return 0;
            }
            Log("[NMB] reusing class ConstantPool=%p length=%d", (void*)cp, cp_len);
        }

        uintptr_t tags_ptr = JvmApi::SafeRead<uintptr_t>(
            cp + JvmMapper::ConstantPool::tags);
        if (!tags_ptr) { Log("[NMB] ERROR: _tags is null"); return 0; }
        uint8_t* tags_data = reinterpret_cast<uint8_t*>(
            tags_ptr + JvmMapper::CompactU2Array::data);

        uintptr_t cp_base = cp + JvmMapper::ConstantPool::base;

        if (owns_class_cp) {

            for (int i = 1; i < cp_len; i++) {
                auto& entry = cp_entries[i];
                tags_data[i] = entry.tag;
                if (entry.tag == JVMCore::JVM_CONSTANT_Utf8) {
                    uintptr_t sym = symAlloc(entry.str.c_str(), (int)entry.str.length(), thread);
                    *(uintptr_t*)(cp_base + i * 8) = sym;
                }
            }
            threadState.enter_native();


            for (int i = 1; i < cp_len; i++) {
                auto& entry = cp_entries[i];
                uintptr_t slot = cp_base + i * 8;
                switch (entry.tag) {
                    case JVMCore::JVM_CONSTANT_Integer:
                    case JVMCore::JVM_CONSTANT_Float:
                        *reinterpret_cast<uint32_t*>(slot) =
                            static_cast<uint32_t>(entry.value); break;
                    case JVMCore::JVM_CONSTANT_Long:
                    case JVMCore::JVM_CONSTANT_Double:
                        *reinterpret_cast<uint64_t*>(slot) = entry.value; break;
                    case JVMCore::JVM_CONSTANT_UnresolvedClass:
                        *(uintptr_t*)slot = (*(uintptr_t*)(cp_base + entry.idx1 * 8)) | 1; break;
                    case JVMCore::JVM_CONSTANT_String:
                        *(uintptr_t*)slot = *(uintptr_t*)(cp_base + entry.idx1 * 8); break;
                    case JVMCore::JVM_CONSTANT_NameAndType:
                        *(uint32_t*)slot = ((uint32_t)entry.idx2 << 16) | (uint32_t)entry.idx1; break;
					case JVMCore::JVM_CONSTANT_MethodHandle:
						*reinterpret_cast<uint32_t*>(slot) =
							(static_cast<uint32_t>(entry.idx2) << 16) |
							static_cast<uint32_t>(entry.idx1); break;
					case JVMCore::JVM_CONSTANT_MethodType:
						*reinterpret_cast<uint32_t*>(slot) =
							static_cast<uint32_t>(entry.idx1); break;
					case JVMCore::JVM_CONSTANT_InvokeDynamic:
						*reinterpret_cast<uint32_t*>(slot) =
							(static_cast<uint32_t>(entry.idx2) << 16) |
							static_cast<uint32_t>(entry.idx1); break;
                    case JVMCore::JVM_CONSTANT_Methodref:
                    case JVMCore::JVM_CONSTANT_Fieldref:
                    case JVMCore::JVM_CONSTANT_InterfaceMethodref:
                        *(uint32_t*)slot = ((uint32_t)entry.idx2 << 16) | (uint32_t)entry.idx1; break;
                }
            }

			if (!bootstrap_operands.empty()) {
				const size_t operandsSize =
					static_cast<size_t>(JvmMapper::CompactU2Array::data) +
					bootstrap_operands.size() * sizeof(uint16_t);
				const uintptr_t operands = reinterpret_cast<uintptr_t>(
					VirtualAlloc(nullptr, operandsSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
				if (!operands) {
					Log("[NMB] ERROR: BootstrapMethods operands allocation failed");
					return 0;
				}
				*reinterpret_cast<int32_t*>(
					operands + JvmMapper::CompactU2Array::length) =
					static_cast<int32_t>(bootstrap_operands.size());
				std::memcpy(reinterpret_cast<void*>(
					operands + JvmMapper::CompactU2Array::data),
					bootstrap_operands.data(),
					bootstrap_operands.size() * sizeof(uint16_t));
				*reinterpret_cast<uintptr_t*>(
					cp + JvmMapper::ConstantPool::operands) = operands;
				Log("[NMB] cp->_operands installed: %p u2=%zu",
					(void*)operands, bootstrap_operands.size());
			}
        }


        std::vector<int> cp_to_cpc_map;
        cp_to_cpc_map.reserve(cp_len);
        for (int i = 1; i < cp_len; ++i) {
            const uint8_t tag = cp_entries[i].tag;
            if (tag == JVMCore::JVM_CONSTANT_Fieldref ||
                tag == JVMCore::JVM_CONSTANT_Methodref ||
                tag == JVMCore::JVM_CONSTANT_InterfaceMethodref) {
                cp_to_cpc_map.push_back(i);
            }
        }

		for (int i = 1; i < cp_len; ++i) {
			if (cp_entries[i].tag == JVMCore::JVM_CONSTANT_InvokeDynamic)
				cp_to_cpc_map.push_back(i);
		}

        auto cpc_index_for_cp = [&](int cp_idx) -> int {
            for (size_t idx = 0; idx < cp_to_cpc_map.size(); ++idx) {
                if (cp_to_cpc_map[idx] == cp_idx) return static_cast<int>(idx);
            }
            return -1;
        };
        Log("[NMB] deterministic CPC map: entries=%d", (int)cp_to_cpc_map.size());


        std::vector<int> compact_ref_map(cp_len, -1);
		std::vector<int> resolved_ref_to_cp;
        for (int i = 1; i < cp_len; i++) {
            uint8_t tag = cp_entries[i].tag;
            if (tag == JVMCore::JVM_CONSTANT_String ||
                tag == JVMCore::JVM_CONSTANT_Class ||
                tag == JVMCore::JVM_CONSTANT_UnresolvedClass ||
                tag == JVMCore::JVM_CONSTANT_MethodType ||
                tag == JVMCore::JVM_CONSTANT_MethodHandle) {
				compact_ref_map[i] = static_cast<int>(resolved_ref_to_cp.size());
				resolved_ref_to_cp.push_back(i);
            }
        }


		std::vector<int> indy_ref_slot_by_cpc(cp_to_cpc_map.size(), -1);
		for (size_t cpc = 0; cpc < cp_to_cpc_map.size(); ++cpc) {
			const int cpIndex = cp_to_cpc_map[cpc];
			if (cp_entries[cpIndex].tag != JVMCore::JVM_CONSTANT_InvokeDynamic)
				continue;
			indy_ref_slot_by_cpc[cpc] = static_cast<int>(resolved_ref_to_cp.size());
			resolved_ref_to_cp.push_back(cpIndex);
			resolved_ref_to_cp.push_back(cpIndex);
		}
		const int total_ref_slots = static_cast<int>(resolved_ref_to_cp.size());
        Log("[NMB] compact_ref_map built: total_ref_slots=%d", total_ref_slots);
        size_t rewritten_lookup_switches = 0;
        auto read_be_s4 = [&](size_t offset, int32_t& value) -> bool {
            if (offset > code.size() || code.size() - offset < sizeof(uint32_t))
                return false;
            const uint32_t raw =
                (static_cast<uint32_t>(code[offset]) << 24) |
                (static_cast<uint32_t>(code[offset + 1]) << 16) |
                (static_cast<uint32_t>(code[offset + 2]) << 8) |
                static_cast<uint32_t>(code[offset + 3]);
            value = static_cast<int32_t>(raw);
            return true;
        };

        for (size_t bci = 0; bci < code.size(); ) {
            uint8_t op = code[bci];
            int len = 1;
            switch(op) {
                case 16: case 18: case 21: case 22: case 23: case 24: case 25:
                case 54: case 55: case 56: case 57: case 58: case 169: case 188:
                case 0xE6:
                    len = 2; break;
                case 17: case 19: case 20: case 132:
                case 153: case 154: case 155: case 156: case 157: case 158: case 159:
                case 160: case 161: case 162: case 163: case 164: case 165: case 166:
                case 167: case 168:
                case 178: case 179: case 180: case 181: case 182: case 183: case 184:
                case 187: case 189: case 192: case 193: case 198: case 199:
                case 0xE7:
                    len = 3; break;
                case 197:
                    len = 4; break;
                case 185:
                case 186:
                case 200:
                case 201:
                    len = 5; break;
                case 170: {
                    int pad = (4 - ((bci + 1) % 4)) % 4;
                    int32_t low = 0;
                    int32_t high = 0;
                    if (!read_be_s4(bci + pad + 5, low) ||
                        !read_be_s4(bci + pad + 9, high) || high < low) {
                        Log("[NMB] ERROR: malformed tableswitch at bci=%zu", bci);
                        return 0;
                    }
                    const uint64_t entries =
                        static_cast<uint64_t>(static_cast<int64_t>(high) -
                            static_cast<int64_t>(low)) + 1ULL;
                    const uint64_t switch_len =
                        static_cast<uint64_t>(pad) + 13ULL + entries * 4ULL;
                    if (switch_len > static_cast<uint64_t>(code.size() - bci) ||
                        switch_len > static_cast<uint64_t>(
                            (std::numeric_limits<int>::max)())) {
                        Log("[NMB] ERROR: truncated tableswitch at bci=%zu", bci);
                        return 0;
                    }
                    len = static_cast<int>(switch_len);
                    break;
                }
                case 171: {
                    int pad = (4 - ((bci + 1) % 4)) % 4;
                    int32_t npairs = 0;
                    if (!read_be_s4(bci + pad + 5, npairs) || npairs < 0) {
                        Log("[NMB] ERROR: malformed lookupswitch at bci=%zu", bci);
                        return 0;
                    }
                    const uint64_t switch_len =
                        static_cast<uint64_t>(pad) + 9ULL +
                        static_cast<uint64_t>(npairs) * 8ULL;
                    if (switch_len > static_cast<uint64_t>(code.size() - bci) ||
                        switch_len > static_cast<uint64_t>(
                            (std::numeric_limits<int>::max)())) {
                        Log("[NMB] ERROR: truncated lookupswitch at bci=%zu", bci);
                        return 0;
                    }
                    len = static_cast<int>(switch_len);


                    code[bci] = npairs < 5
                        ? Opcode::_fast_linearswitch
                        : Opcode::_fast_binaryswitch;
                    ++rewritten_lookup_switches;
                    break;
                }
                case 196:
                    if (bci + 1 >= code.size()) {
                        Log("[NMB] ERROR: truncated wide at bci=%zu", bci);
                        return 0;
                    }
                    if (code[bci+1] == 132) len = 6;
                    else len = 4;
                    break;
                default:
                    len = 1; break;
            }

            if (len <= 0 || static_cast<size_t>(len) > code.size() - bci) {
                Log("[NMB] ERROR: truncated opcode 0x%02X at bci=%zu len=%d remaining=%zu",
                    op, bci, len, code.size() - bci);
                return 0;
            }

            if (op >= 178 && op <= 184) {
                if (bci + 2 < code.size()) {
                    int cp_idx = (code[bci+1] << 8) | code[bci+2];
                    int cpc_idx = cpc_index_for_cp(cp_idx);
                    if (cpc_idx < 0) {
                        Log("[NMB] ERROR: bytecode 0x%02X at bci=%zu references CP[%d] without CPC entry",
                            op, bci, cp_idx);
                        return 0;
                    }
                    code[bci+1] = (uint8_t)(cpc_idx & 0xFF);
                    code[bci+2] = (uint8_t)(cpc_idx >> 8);
                }
            } else if (op == 185) {
                if (bci + 2 < code.size()) {
                    int cp_idx = (code[bci+1] << 8) | code[bci+2];
                    int cpc_idx = cpc_index_for_cp(cp_idx);
                    if (cpc_idx < 0) {
                        Log("[NMB] ERROR: invokeinterface at bci=%zu references CP[%d] without CPC entry",
                            bci, cp_idx);
                        return 0;
                    }
                    code[bci+1] = (uint8_t)(cpc_idx & 0xFF);
                    code[bci+2] = (uint8_t)(cpc_idx >> 8);
                }
			} else if (op == 186) {
				if (bci + 4 >= code.size()) {
					Log("[NMB] ERROR: truncated invokedynamic at bci=%zu", bci);
					return 0;
				}
				const int cp_idx =
					(static_cast<int>(code[bci + 1]) << 8) |
					static_cast<int>(code[bci + 2]);
				const int cpc_idx = cpc_index_for_cp(cp_idx);
				if (cpc_idx < 0) {
					Log("[NMB] ERROR: invokedynamic at bci=%zu references CP[%d] without CPC entry",
						bci, cp_idx);
					return 0;
				}


				const uint32_t encoded = ~static_cast<uint32_t>(cpc_idx);
				std::memcpy(code.data() + bci + 1, &encoded, sizeof(encoded));
				Log("[NMB] invokedynamic rewrite: bci=%zu cp=%d cpc=%d encoded=0x%08X",
					bci, cp_idx, cpc_idx, encoded);
            } else if (op == 18) {
                int cp_idx = (int)(uint8_t)code[bci+1];
                int tag = (cp_idx > 0 && cp_idx < cp_len) ? (int)cp_entries[cp_idx].tag : -1;


				if (tag == JVMCore::JVM_CONSTANT_String ||
					tag == JVMCore::JVM_CONSTANT_MethodType ||
					tag == JVMCore::JVM_CONSTANT_MethodHandle) {
                    int ref_slot = compact_ref_map[cp_idx];
                    if (ref_slot >= 0 && ref_slot <= 255) {
                        code[bci]   = 0xE6;
                        code[bci+1] = (uint8_t)ref_slot;
                    }
                }
            } else if (op == 19) {
                int cp_idx = (code[bci+1] << 8) | code[bci+2];
                int tag = (cp_idx > 0 && cp_idx < cp_len) ? (int)cp_entries[cp_idx].tag : -1;
				if (tag == JVMCore::JVM_CONSTANT_String ||
					tag == JVMCore::JVM_CONSTANT_MethodType ||
					tag == JVMCore::JVM_CONSTANT_MethodHandle) {
                    int ref_slot = compact_ref_map[cp_idx];
                    code[bci]   = 0xE7;

                    code[bci+1] = (uint8_t)(ref_slot & 0xFF);
                    code[bci+2] = (uint8_t)(ref_slot >> 8);
                }
            }
            bci += len;
        }
        if (rewritten_lookup_switches != 0) {
            Log("[NMB] HotSpot lookupswitch rewrite complete: count=%zu",
                rewritten_lookup_switches);
        }


        if (owns_class_cp && !cp_to_cpc_map.empty()) {
            int cache_len = (int)cp_to_cpc_map.size();
            size_t cache_size = static_cast<size_t>(JvmMapper::ConstantPoolCache::entries)
                + static_cast<size_t>(cache_len)
                    * static_cast<size_t>(JvmMapper::ConstantPoolCacheEntry::size);
            uintptr_t cache = (uintptr_t)VirtualAlloc(NULL, cache_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
            if (!cache) {
                Log("[NMB] ERROR: deterministic CPCache allocation failed: entries=%d bytes=%zu",
                    cache_len, cache_size);
                return 0;
            }
            {

                *reinterpret_cast<int32_t*>(
                    cache + JvmMapper::ConstantPoolCache::length) = cache_len;
                *reinterpret_cast<uintptr_t*>(
                    cache + JvmMapper::ConstantPoolCache::constant_pool) = cp;


                for (int i = 0; i < cache_len; i++) {
                    uintptr_t entry_addr = cache
                        + JvmMapper::ConstantPoolCache::entries
                        + (i * JvmMapper::ConstantPoolCacheEntry::size);
                    *reinterpret_cast<intptr_t*>(entry_addr
                        + JvmMapper::ConstantPoolCacheEntry::indices) = cp_to_cpc_map[i];
                    *reinterpret_cast<void**>(entry_addr
                        + JvmMapper::ConstantPoolCacheEntry::f1) = nullptr;
					const int indyRefSlot =
						indy_ref_slot_by_cpc[static_cast<size_t>(i)];
					*reinterpret_cast<intptr_t*>(entry_addr
						+ JvmMapper::ConstantPoolCacheEntry::f2) =
						indyRefSlot >= 0 ? indyRefSlot : 0;
                    *reinterpret_cast<intptr_t*>(entry_addr
                        + JvmMapper::ConstantPoolCacheEntry::flags) = 0;
                }

                *reinterpret_cast<void**>(cp + JvmMapper::ConstantPool::cache) = (void*)cache;
                Log("[NMB] CPCache @ %p written to CP+0x%02X",
                    (void*)cache, (int)JvmMapper::ConstantPool::cache);
            }
        } else if (!owns_class_cp && !cp_to_cpc_map.empty()) {
            const uintptr_t cache = JvmApi::SafeRead<uintptr_t>(
                cp + JvmMapper::ConstantPool::cache);
            if (!cache) {
                Log("[NMB] ERROR: shared ConstantPool has no CPCache");
                return 0;
            }

            const int32_t cache_len = JvmApi::SafeRead<int32_t>(
                cache + JvmMapper::ConstantPoolCache::length);
            if (cache_len != static_cast<int32_t>(cp_to_cpc_map.size())) {
                Log("[NMB] ERROR: shared CPCache length mismatch: native=%d expected=%d",
                    cache_len, (int)cp_to_cpc_map.size());
                return 0;
            }

            for (int i = 0; i < cache_len; ++i) {
                const uintptr_t entry_addr = cache
                    + JvmMapper::ConstantPoolCache::entries
                    + (i * JvmMapper::ConstantPoolCacheEntry::size);
                const intptr_t indices = JvmApi::SafeRead<intptr_t>(
                    entry_addr + JvmMapper::ConstantPoolCacheEntry::indices);
                const int native_cp_index = static_cast<int>(indices & 0xFFFF);
                if (native_cp_index != cp_to_cpc_map[i]) {
                    Log("[NMB] ERROR: shared CPCache[%d] mismatch: native_cp=%d expected_cp=%d",
                        i, native_cp_index, cp_to_cpc_map[i]);
                    return 0;
                }
            }
            Log("[NMB] shared CPCache validated: cache=%p entries=%d",
                (void*)cache, cache_len);
        }


        if (owns_class_cp && env && total_ref_slots > 0) {
            jclass objClass = env->FindClass("java/lang/Object");
            if (objClass) {
                jobjectArray refsArray = env->NewObjectArray(total_ref_slots, objClass, nullptr);
                if (refsArray) {
                    for (int i = 1; i < cp_len; i++) {
                        if (cp_entries[i].tag == JVMCore::JVM_CONSTANT_String) {
                            int ref_slot = compact_ref_map[i];
                            int utf8_idx = cp_entries[i].idx1;
                            if (utf8_idx > 0 && utf8_idx < cp_len
                                && cp_entries[utf8_idx].tag == JVMCore::JVM_CONSTANT_Utf8) {
                                jstring jstr = env->NewStringUTF(cp_entries[utf8_idx].str.c_str());
                                if (jstr) {
                                    env->SetObjectArrayElement(refsArray, ref_slot, jstr);
                                    env->DeleteLocalRef(jstr);
                                }
                            }
                        }
                    }
                    jobject globalRef = env->NewGlobalRef(refsArray);
                    *reinterpret_cast<jobject*>(
                        cp + JvmMapper::ConstantPool::resolved_references) = globalRef;
                    Log("[NMB] cp->_resolved_references (compact) set to globalRef=%p", (void*)globalRef);
                    env->DeleteLocalRef(refsArray);
                }
                env->DeleteLocalRef(objClass);
            }
        } else if (owns_class_cp && total_ref_slots == 0) {
            Log("[NMB] No resolved-reference constants; skipping resolved_references");
        } else if (!owns_class_cp && total_ref_slots > 0) {
            const uintptr_t refs = JvmApi::SafeRead<uintptr_t>(
                cp + JvmMapper::ConstantPool::resolved_references);
            if (!refs) {
                Log("[NMB] ERROR: shared ConstantPool has no resolved_references");
                return 0;
            }
            Log("[NMB] shared resolved_references reused: %p", (void*)refs);
        }
        if (owns_class_cp && total_ref_slots > 0) {
            const uintptr_t refs = JvmApi::SafeRead<uintptr_t>(
                cp + JvmMapper::ConstantPool::resolved_references);
            if (!refs) {
                Log("[NMB] ERROR: failed to install class resolved_references");
                return 0;
            }
        }


        if (owns_class_cp) {
            size_t ref_map_size = 4 + (size_t)total_ref_slots * 2;
            uintptr_t ref_map = reinterpret_cast<uintptr_t>(
                VirtualAlloc(NULL, ref_map_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
            Log("[NMB] reference_map=%p (size=%zu, slots=%d)",
                (void*)ref_map, ref_map_size, total_ref_slots);
            if (!ref_map) {
                Log("[NMB] ERROR: class reference_map allocation failed");
                return 0;
            }
            *reinterpret_cast<int32_t*>(
                ref_map + JvmMapper::CompactU2Array::length) = total_ref_slots;
            uint16_t* data = reinterpret_cast<uint16_t*>(
                ref_map + JvmMapper::CompactU2Array::data);
			for (int slot = 0; slot < total_ref_slots; ++slot) {
				data[slot] = static_cast<uint16_t>(resolved_ref_to_cp[slot]);
				Log("[NMB] reference_map[slot=%d]=cp[%d]",
					slot, resolved_ref_to_cp[slot]);
            }


            *reinterpret_cast<uintptr_t*>(
                cp + JvmMapper::ConstantPool::reference_map) = ref_map;
            Log("[NMB] cp->_reference_map set @ CP+0x%02X (compact)",
                (int)JvmMapper::ConstantPool::reference_map);
        } else {
            const uintptr_t ref_map = JvmApi::SafeRead<uintptr_t>(
                cp + JvmMapper::ConstantPool::reference_map);
            if (!ref_map) {
                Log("[NMB] ERROR: shared ConstantPool has no reference_map");
                return 0;
            }
            const int32_t ref_map_len = JvmApi::SafeRead<int32_t>(
                ref_map + JvmMapper::CompactU2Array::length);
            if (ref_map_len != total_ref_slots) {
                Log("[NMB] ERROR: shared reference_map length mismatch: native=%d expected=%d",
                    ref_map_len, total_ref_slots);
                return 0;
            }
            Log("[NMB] shared reference_map validated: map=%p slots=%d",
                (void*)ref_map, ref_map_len);
        }


        InlineTableSizes sizes;
        sizes.exception_table_length = (int)exception_table.size();
        int access_flags = method_access_flags;
        Log("[NMB] Method::allocate: loader_data=%p code_size=%d access_flags=0x%X exception_table=%d thread=%p",
            (void*)loader_data, (int)code.size(), access_flags, (int)exception_table.size(), thread);
        threadState.enter_vm();
        uintptr_t method = mAlloc(loader_data, (int)code.size(), access_flags, &sizes, 0, thread);
        threadState.enter_native();
        Log("[NMB] Method::allocate -> method=%p", (void*)method);
        if (!method) { Log("[NMB] ERROR: mAlloc returned null"); return 0; }


        Log("[NMB] Method entry linking deferred until pool holder is installed");


        uintptr_t constMethod = JvmApi::SafeRead<uintptr_t>(
            method + JvmMapper::Method::const_method);
        Log("[NMB] method->constMethod=%p", (void*)constMethod);
        if (constMethod) {

            if constexpr (kEnableLogging) {
              if (templateMethod) {
                uintptr_t tmpl_cm = JvmApi::SafeRead<uintptr_t>(
                    templateMethod + JvmMapper::Method::const_method);
                if (tmpl_cm) {
                    Log("[NMB] --- TEMPLATE CONSTMETHOD DUMP (Object.<init>) ---");
                    char dumpBuf[256];
                    for (int row = 0; row < 0x80; row += 16) {
                        int pos = snprintf(dumpBuf, sizeof(dumpBuf), "[NMB] +%02X: ", row);
                        for (int col = 0; col < 16; col++) {
                            uint8_t b = JvmApi::SafeRead<uint8_t>(tmpl_cm + row + col);
                            pos += snprintf(dumpBuf + pos, sizeof(dumpBuf) - pos, "%02X ", b);
                        }
                        Log("%s", dumpBuf);
                    }
                    Log("[NMB] ---------------------------------------------");
                }
              }
            }


            uint16_t name_cp_idx = 0;
            uint16_t sig_cp_idx  = 0;
            for (int i = 1; i < cp_len; i++) {
               if (cp_entries[i].tag == JVMCore::JVM_CONSTANT_Utf8) {
                   if (cp_entries[i].str == method_name && name_cp_idx == 0) name_cp_idx = (uint16_t)i;
                   if (cp_entries[i].str == method_sig  && sig_cp_idx  == 0) sig_cp_idx  = (uint16_t)i;
               }
            }


            int size_of_parameters = (access_flags & 0x0008) != 0 ? 0 : 1;
            for (size_t i = 1; i < method_sig.length() && method_sig[i] != ')'; i++) {
                char c = method_sig[i];
                if (c == '[') {

                    while (i + 1 < method_sig.length() && method_sig[i + 1] == '[') i++;
                    if (i + 1 >= method_sig.length() || method_sig[i + 1] == ')') {
                        Log("[NMB] ERROR: malformed array parameter descriptor: %s",
                            method_sig.c_str());
                        return 0;
                    }
                    i++;
                    if (method_sig[i] == 'L') {
                        while (i < method_sig.length() && method_sig[i] != ';') i++;
                        if (i >= method_sig.length()) {
                            Log("[NMB] ERROR: unterminated array object descriptor: %s",
                                method_sig.c_str());
                            return 0;
                        }
                    }
                    size_of_parameters++;
                    continue;
                }
                if (c == 'L') {
                    while (i < method_sig.length() && method_sig[i] != ';') i++;
                    if (i >= method_sig.length()) {
                        Log("[NMB] ERROR: unterminated object descriptor: %s",
                            method_sig.c_str());
                        return 0;
                    }
                    size_of_parameters++;
                    continue;
                }
                if (c == 'J' || c == 'D') size_of_parameters += 2;
                else size_of_parameters++;
            }


            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_size_of_params) = (uint16_t)size_of_parameters;
            *reinterpret_cast<uintptr_t*>(constMethod + Offsets::CM_constants) = cp;
            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_name_index) = name_cp_idx;
            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_max_stack) = (uint16_t)max_stack;
            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_max_locals) = (uint16_t)max_locals;
            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_code_size) = (uint16_t)code.size();
            *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_sig_index) = sig_cp_idx;
            const auto returnAt = method_sig.find(')');
            if (returnAt == std::string::npos || returnAt + 1 >= method_sig.size()) return 0;
            const char returnType = method_sig[returnAt + 1];
            const uint8_t basicType = returnType == 'Z' ? 4 : returnType == 'C' ? 5
                : returnType == 'F' ? 6 : returnType == 'D' ? 7 : returnType == 'B' ? 8
                : returnType == 'S' ? 9 : returnType == 'I' ? 10 : returnType == 'J' ? 11
                : (returnType == 'L' || returnType == '[') ? 12 : returnType == 'V' ? 14 : 0;
            if (!basicType) return 0;
            *reinterpret_cast<uint8_t*>(constMethod + JvmMapper::ConstMethod::result_type) = basicType;

            Log("[NMB] ConstMethod fields (IDA-verified custom JVM):");
            Log("[NMB]   +0x%02X size_of_params = %d", Offsets::CM_size_of_params, size_of_parameters);
            Log("[NMB]   +0x%02X _constants     = %p", Offsets::CM_constants, (void*)cp);
            Log("[NMB]   +0x%02X _name_index    = %d", Offsets::CM_name_index, name_cp_idx);
            Log("[NMB]   +0x%02X _max_stack     = %d", Offsets::CM_max_stack, max_stack);
            Log("[NMB]   +0x%02X _max_locals    = %d", Offsets::CM_max_locals, max_locals);
            Log("[NMB]   +0x%02X _code_size     = %d", Offsets::CM_code_size, (int)code.size());
            Log("[NMB]   +0x%02X _signature_idx = %d", Offsets::CM_sig_index, sig_cp_idx);


            uintptr_t code_base = constMethod + Offsets::CM_bytecode;
            if (!code.empty())
                memcpy((void*)code_base, code.data(), code.size());
            Log("[NMB] bytecode copied to +0x%02X (code_base=%p, size=%d)", Offsets::CM_bytecode, (void*)code_base, (int)code.size());


            if constexpr (kEnableLogging) {
                char buf[512] = {}; int pos = 0;
                for (size_t bi = 0; bi < code.size() && pos < 480; bi++)
                    pos += snprintf(buf + pos, sizeof(buf)-pos, "%02X ", ((uint8_t*)code_base)[bi]);
                Log("[NMB] constMethod bytecode (after copy): %s", buf);
            }


            if (!exception_table.empty()) {
                int32_t cm_size_words = JvmApi::SafeRead<int32_t>(constMethod + Offsets::CM_constMethod_size);
                uintptr_t cm_end = constMethod + (uintptr_t)cm_size_words * 8;
                Log("[NMB] constMethod size=%d words, end=%p", cm_size_words, (void*)cm_end);

                uint16_t flags = JvmApi::SafeRead<uint16_t>(constMethod + Offsets::CM_flags);
                flags |= JvmMapper::State::const_method_has_exception_table;
                *reinterpret_cast<uint16_t*>(constMethod + Offsets::CM_flags) = flags;
                Log("[NMB] constMethod._flags updated to 0x%04X (_has_exception_table set)", flags);

                uint16_t* et_length_addr = reinterpret_cast<uint16_t*>(cm_end - 2);
                *et_length_addr = (uint16_t)exception_table.size();
                Log("[NMB] exception_table_length @ %p = %d", (void*)et_length_addr, (int)*et_length_addr);

                uintptr_t et_base = (uintptr_t)et_length_addr - exception_table.size() * 8;
                for (size_t ei = 0; ei < exception_table.size(); ei++) {
                    auto& ete = exception_table[ei];
                    uint16_t* entry_ptr = reinterpret_cast<uint16_t*>(et_base + ei * 8);
                    entry_ptr[0] = ete.start_pc;
                    entry_ptr[1] = ete.end_pc;
                    entry_ptr[2] = ete.handler_pc;
                    entry_ptr[3] = ete.catch_type;
                    Log("[NMB] ExceptionTable[%zu]: start=%d end=%d handler=%d catch_type=%d",
                        ei, (int)ete.start_pc, (int)ete.end_pc, (int)ete.handler_pc, (int)ete.catch_type);
                }
                Log("[NMB] Exception table written: %zu entries @ %p", exception_table.size(), (void*)et_base);
            }
        } else {
            Log("[NMB] ERROR: constMethod is null at mapped Method offset +0x%02X",
                (int)JvmMapper::Method::const_method);
        }


        Log("[NMB] method dump: vtable=%p constMethod=%p access_flags=0x%X vtable_idx=%d",
            (void*)JvmApi::SafeRead<uintptr_t>(method),
            (void*)JvmApi::SafeRead<uintptr_t>(method + JvmMapper::Method::const_method),
            JvmApi::SafeRead<uint32_t>(method + JvmMapper::Method::access_flags),
            JvmApi::SafeRead<int32_t> (method + JvmMapper::Method::vtable_index));
        Log("[NMB] method dump: i2i=%p adapter=%p from_comp=%p from_interp=%p",
            (void*)JvmApi::SafeRead<uintptr_t>(method + JvmMapper::Method::i2i_entry),
            (void*)JvmApi::SafeRead<uintptr_t>(method + JvmMapper::Method::adapter),
            (void*)JvmApi::SafeRead<uintptr_t>(method + JvmMapper::Method::from_compiled_entry),
            (void*)JvmApi::SafeRead<uintptr_t>(method + JvmMapper::Method::from_interpreted_entry));
        Log("[NMB] build() done -> method=%p", (void*)method);

        return method;
    }
};
