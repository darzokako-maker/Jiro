#pragma once
#include <Windows.h>
#include <cstdint>
#include <string>
#include <vector>
#include "Logging.hpp"
#include "ClassScanner.hpp"
#include "MethodInvoker.hpp"
#include "JvmApi.hpp"


namespace CMOff {
    inline const std::ptrdiff_t& fingerprint = JvmMapper::ConstMethod::fingerprint;
    inline const std::ptrdiff_t& constants = JvmMapper::ConstMethod::constants;
    inline const std::ptrdiff_t& stackmap_data = JvmMapper::ConstMethod::stackmap_data;
    inline const std::ptrdiff_t& constMethod_size = JvmMapper::ConstMethod::const_method_size;
    inline const std::ptrdiff_t& flags = JvmMapper::ConstMethod::flags;
    inline const std::ptrdiff_t& result_type = JvmMapper::ConstMethod::result_type;
    inline const std::ptrdiff_t& code_size = JvmMapper::ConstMethod::code_size;
    inline const std::ptrdiff_t& name_index = JvmMapper::ConstMethod::name_index;
    inline const std::ptrdiff_t& sig_index = JvmMapper::ConstMethod::signature_index;
    inline const std::ptrdiff_t& method_idnum = JvmMapper::ConstMethod::method_idnum;
    inline const std::ptrdiff_t& max_stack = JvmMapper::ConstMethod::max_stack;
    inline const std::ptrdiff_t& max_locals = JvmMapper::ConstMethod::max_locals;
    inline const std::ptrdiff_t& size_of_params = JvmMapper::ConstMethod::size_of_parameters;

    inline const std::ptrdiff_t& orig_idnum = method_idnum;
    inline const std::ptrdiff_t& header_size = JvmMapper::ConstMethod::bytecode;

    constexpr uint64_t fingerprint_init = 0x8000000000000000ULL;
    constexpr uint8_t  T_VOID           = JvmMapper::State::basic_type_void;
}


namespace MOff {
    constexpr int vtable            = static_cast<int>(JvmMapper::Klass::vtable_ptr);
    inline const std::ptrdiff_t& method_counters = JvmMapper::Method::method_counters;
    inline const std::ptrdiff_t& method_data = JvmMapper::Method::method_data;
    inline const std::ptrdiff_t& constMethod = JvmMapper::Method::const_method;
    inline const std::ptrdiff_t& access_flags = JvmMapper::Method::access_flags;
    inline const std::ptrdiff_t& vtable_index = JvmMapper::Method::vtable_index;
    inline const std::ptrdiff_t& method_size = JvmMapper::Method::method_size;
    inline const std::ptrdiff_t& intrinsic_id = JvmMapper::Method::intrinsic_id;
    inline const std::ptrdiff_t& flags = JvmMapper::Method::flags;
    inline const std::ptrdiff_t& i2i_entry = JvmMapper::Method::i2i_entry;
    inline const std::ptrdiff_t& adapter = JvmMapper::Method::adapter;
    inline const std::ptrdiff_t& from_compiled = JvmMapper::Method::from_compiled_entry;
    inline const std::ptrdiff_t& code_ptr = JvmMapper::Method::code;
    inline const std::ptrdiff_t& from_interpreted = JvmMapper::Method::from_interpreted_entry;
    inline const std::ptrdiff_t& signature_handler = JvmMapper::Method::signature_handler;

    inline const std::ptrdiff_t& total_size = JvmMapper::Method::allocation_size;


    constexpr uint32_t ACC_PUBLIC_STATIC = JvmMapper::State::access_public_static;
    constexpr int32_t NONVIRTUAL_VTABLE =
        JvmMapper::State::nonvirtual_vtable_index;
}


class MethodBuilder {
public:


    struct InlineTableSizes {
        int localvariable_table_length  = 0;
        int compressed_linenumber_size  = 0;
        int exception_table_length      = 0;
        int checked_exceptions_length   = 0;
        int method_parameters_length    = 0;
        int generic_signature_index     = 0;
        int method_annotations_length   = 0;
        int parameter_annotations_length= 0;
        int type_annotations_length     = 0;
        int default_annotations_length  = 0;
    };


    using fn_cm_alloc_t = uintptr_t(__fastcall*)(
        uintptr_t   loader_data,
        int         code_size,
        void*       sizes,
        int         method_type,
        void*       thread
    );


    using fn_m_alloc_t = uintptr_t(__fastcall*)(
        uintptr_t   loader_data,
        int         code_size,
        int         access_flags,
        void*       sizes,
        int         method_type,
        void*       thread
    );


    struct ParsedMethod {
        std::vector<uint8_t> bytecode;
        uint16_t max_stack   = 0;
        uint16_t max_locals  = 1;
    };

    static ParsedMethod ParseRunBytecode()
    {
        ParsedMethod result;


        result.bytecode  = { 0xB1 };
        result.max_stack  = 1;
        result.max_locals = 0;

        Log("[MethodBuilder] Using stub bytecode: [B1 = return] (1 byte)");
        return result;
    }


    static uintptr_t BuildConstMethod(const ParsedMethod& pm, uintptr_t tmplConstMethod)
    {
        const uint16_t codeSize = static_cast<uint16_t>(pm.bytecode.size());
        const size_t   totalBytes = CMOff::header_size + codeSize + 8;

        uint8_t* mem = static_cast<uint8_t*>(VirtualAlloc(nullptr, totalBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!mem) return 0;
        memset(mem, 0, totalBytes);


        memcpy(mem, reinterpret_cast<void*>(tmplConstMethod), CMOff::header_size);


        const int32_t wordSize = static_cast<int32_t>((totalBytes + 7) / 8);
        *reinterpret_cast<int32_t*>(mem + CMOff::constMethod_size) = wordSize;
        *reinterpret_cast<uint16_t*>(mem + CMOff::code_size)       = codeSize;


        memcpy(mem + CMOff::header_size, pm.bytecode.data(), codeSize);

        return reinterpret_cast<uintptr_t>(mem);
    }


    static uintptr_t SafeReadPtr(uintptr_t addr)
    {
        uintptr_t val = 0;
        __try { val = *reinterpret_cast<const uintptr_t*>(addr); }
        __except(EXCEPTION_EXECUTE_HANDLER) {}
        return val;
    }


    static uintptr_t BuildMethod(uintptr_t constMethodPtr, uintptr_t templateMethod)
    {
        if (!constMethodPtr || !templateMethod) {
            Log("[MethodBuilder] BuildMethod: null arg");
            return 0;
        }

        uint8_t* mem = static_cast<uint8_t*>(
            VirtualAlloc(nullptr, MOff::total_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!mem) {
            Log("[MethodBuilder] Method VirtualAlloc failed");
            return 0;
        }
        memset(mem, 0, MOff::total_size);


        uintptr_t tmplVtable = SafeReadPtr(templateMethod + MOff::vtable);
        *reinterpret_cast<uintptr_t*>(mem + MOff::vtable)           = tmplVtable;


        *reinterpret_cast<uintptr_t*>(mem + MOff::constMethod)      = constMethodPtr;


        *reinterpret_cast<uintptr_t*>(mem + MOff::method_data)      = 0;
        *reinterpret_cast<uintptr_t*>(mem + MOff::method_counters)  = 0;


        *reinterpret_cast<uint32_t*>(mem + MOff::access_flags)      = MOff::ACC_PUBLIC_STATIC;


        *reinterpret_cast<int32_t*>(mem + MOff::vtable_index)       = MOff::NONVIRTUAL_VTABLE;


        *reinterpret_cast<uint16_t*>(mem + MOff::method_size)       = static_cast<uint16_t>(MOff::total_size / 8);


        *reinterpret_cast<uintptr_t*>(mem + MOff::i2i_entry)        = SafeReadPtr(templateMethod + MOff::i2i_entry);
        *reinterpret_cast<uintptr_t*>(mem + MOff::adapter)          = SafeReadPtr(templateMethod + MOff::adapter);
        *reinterpret_cast<uintptr_t*>(mem + MOff::from_compiled)    = SafeReadPtr(templateMethod + MOff::from_compiled);
        *reinterpret_cast<uintptr_t*>(mem + MOff::from_interpreted) = SafeReadPtr(templateMethod + MOff::from_interpreted);

        Log("[MethodBuilder] Method @ %p  constMethod=%p  from_interpreted=%p",
            (void*)mem,
            (void*)constMethodPtr,
            (void*)*reinterpret_cast<uintptr_t*>(mem + MOff::from_interpreted));
        return reinterpret_cast<uintptr_t>(mem);
    }


    static uintptr_t BuildMethodArray(uintptr_t methodPtr)
    {
        if (!methodPtr) return 0;

        const size_t arrSize = 16;
        uint8_t* mem = static_cast<uint8_t*>(
            VirtualAlloc(nullptr, arrSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!mem) {
            Log("[MethodBuilder] MethodArray VirtualAlloc failed");
            return 0;
        }
        memset(mem, 0, arrSize);

        *reinterpret_cast<int32_t*>(mem + JvmMapper::Array::length) = 1;
        *reinterpret_cast<uintptr_t*>(mem + JvmMapper::Array::data) = methodPtr;

        Log("[MethodBuilder] MethodArray @ %p  Method*[0]=%p", (void*)mem, (void*)methodPtr);
        return reinterpret_cast<uintptr_t>(mem);
    }


    static uintptr_t FindStaticVoidTemplate(HMODULE hJvm)
    {
        const uintptr_t base = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t cldHeadAddr = JvmApi::CLDGraphHeadAddr();
        if (!cldHeadAddr) {
            Log("[MethodBuilder] CLD head not resolved");
            return 0;
        }

        uintptr_t cld = SafeReadPtr(cldHeadAddr);
        int klassCount = 0;

        while (cld) {
            uintptr_t klass = SafeReadPtr(cld + JvmOffsets::kCLD_klasses);

            while (klass) {

                if (klass < base) {
                    klass = SafeReadPtr(klass + JvmOffsets::kKlass_next_link);
                    if (++klassCount > 10000) break;
                    continue;
                }

                uintptr_t found = FindStaticMethodInKlass(klass);
                if (found) return found;

                klass = SafeReadPtr(klass + JvmOffsets::kKlass_next_link);
                if (++klassCount > 10000) break;
            }

            if (klassCount > 10000) break;
            cld = SafeReadPtr(cld + JvmOffsets::kCLD_next);
        }

        Log("[MethodBuilder] No static template method found");
        return 0;
    }


    static uintptr_t Build(HMODULE hJvm, uintptr_t* outMethodPtr)
    {
        if (outMethodPtr) *outMethodPtr = 0;


        uintptr_t tmpl = FindStaticVoidTemplate(hJvm);
        if (!tmpl) {
            Log("[MethodBuilder] Build: no template method");
            return 0;
        }


        uintptr_t tmplConstMethod = SafeReadPtr(tmpl + MOff::constMethod);
        auto pm = ParseRunBytecode();
        if (pm.bytecode.empty()) return 0;

        uintptr_t cm = BuildConstMethod(pm, tmplConstMethod);
        if (!cm) return 0;


        uintptr_t method = BuildMethod(cm, tmpl);
        if (!method) return 0;


        uintptr_t arr = BuildMethodArray(method);
        if (!arr) return 0;

        if (outMethodPtr) *outMethodPtr = method;

        Log("[MethodBuilder] Build complete: Array=%p Method=%p ConstMethod=%p",
            (void*)arr, (void*)method, (void*)cm);
        return arr;
    }

private:

    static uint16_t SafeReadSizeOfParams(uintptr_t constMethod)
    {
        uint16_t size_of_params = 0;
        __try { size_of_params = *reinterpret_cast<const uint16_t*>(constMethod + CMOff::size_of_params); } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return size_of_params;
    }


    static uintptr_t CallConstMethodAlloc(
        fn_cm_alloc_t fn, uintptr_t cld, int codeSize, void* sizes, void* thread)
    {
        uintptr_t result = 0;
        __try {
            result = fn(cld, codeSize, sizes, 0 , thread);
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Log("[MB-MS] ConstMethod::allocate SEH: 0x%08X", GetExceptionCode());
        }
        return result;
    }

    static uintptr_t CallMethodAlloc(
        fn_m_alloc_t fn, uintptr_t cld, int codeSize, void* sizes, void* thread)
    {
        uintptr_t result = 0;
        __try {
            result = fn(cld, codeSize, MOff::ACC_PUBLIC_STATIC, sizes, 0 , thread);
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Log("[MB-MS] Method::allocate SEH: 0x%08X", GetExceptionCode());
        }
        return result;
    }


    static uintptr_t FindStaticMethodInKlass(uintptr_t klass)
    {
        auto methods = ReadMethods(klass);
        for (auto& m : methods) {
            if (!(m.access_flags & 0x8)) continue;

            if (m.signature != "()V") continue;

            uintptr_t constMethod = SafeReadPtr(m.method_ptr + MOff::constMethod);
            if (!constMethod) continue;

            if (SafeReadSizeOfParams(constMethod) != 0) continue;

            uintptr_t entry = SafeReadPtr(m.method_ptr + MOff::from_interpreted);
            if (!entry) continue;

            Log("[MethodBuilder] Template: %s%s  flags=0x%X  entry=%p",
                m.name.c_str(), m.signature.c_str(), m.access_flags, (void*)entry);
            return m.method_ptr;
        }
        return 0;
    }
};
