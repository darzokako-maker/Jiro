#pragma once


#include <Windows.h>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>
#include "Logging.hpp"
#include "ClassScanner.hpp"
#include "JvmApi.hpp"
#include "MethodInvoker.hpp"

inline int LogMirrorSEH(EXCEPTION_POINTERS* info)
{
    if (info && info->ExceptionRecord) {
        const auto* record = info->ExceptionRecord;
        const uintptr_t operation = record->NumberParameters > 0
            ? static_cast<uintptr_t>(record->ExceptionInformation[0]) : 0;
        const uintptr_t address = record->NumberParameters > 1
            ? static_cast<uintptr_t>(record->ExceptionInformation[1]) : 0;
        Log("[KlassInjector] mirror restore SEH: code=0x%08X ip=%p op=%llu address=%p",
            record->ExceptionCode, record->ExceptionAddress,
            static_cast<unsigned long long>(operation), (void*)address);
    }
    return EXCEPTION_EXECUTE_HANDLER;
}


namespace IKOff {

    constexpr int vtable_ptr           = static_cast<int>(JvmMapper::Klass::vtable_ptr);
    inline const std::ptrdiff_t& layout_helper = JvmMapper::Klass::layout_helper;
    inline const std::ptrdiff_t& super_check_offset = JvmMapper::Klass::super_check_offset;
    inline const std::ptrdiff_t& name = JvmMapper::Klass::name;
    inline const std::ptrdiff_t& secondary_super_cache = JvmMapper::Klass::secondary_super_cache;
    inline const std::ptrdiff_t& secondary_supers = JvmMapper::Klass::secondary_supers;
    inline const std::ptrdiff_t& primary_supers = JvmMapper::Klass::primary_supers;
    inline const std::ptrdiff_t& java_mirror = JvmMapper::Klass::java_mirror;
    inline const std::ptrdiff_t& super_klass = JvmMapper::Klass::super_klass;
    inline const std::ptrdiff_t& subklass = JvmMapper::Klass::subklass;
    inline const std::ptrdiff_t& next_sibling = JvmMapper::Klass::next_sibling;
    inline const std::ptrdiff_t& next_link = JvmMapper::Klass::next_link;
    inline const std::ptrdiff_t& class_loader_data = JvmMapper::Klass::class_loader_data;
    inline const std::ptrdiff_t& modifier_flags = JvmMapper::Klass::modifier_flags;
    inline const std::ptrdiff_t& access_flags = JvmMapper::Klass::access_flags;
    inline const std::ptrdiff_t& annotations = JvmMapper::InstanceKlass::annotations;
    inline const std::ptrdiff_t& array_klasses = JvmMapper::InstanceKlass::array_klasses;
    inline const std::ptrdiff_t& constants = JvmMapper::InstanceKlass::constants;
    inline const std::ptrdiff_t& inner_classes = JvmMapper::InstanceKlass::inner_classes;
    inline const std::ptrdiff_t& source_debug_ext = JvmMapper::InstanceKlass::source_debug_ext;
    inline const std::ptrdiff_t& array_name = JvmMapper::InstanceKlass::array_name;
    inline const std::ptrdiff_t& nonstatic_field_size = JvmMapper::InstanceKlass::nonstatic_field_size;
    inline const std::ptrdiff_t& static_field_size = JvmMapper::InstanceKlass::static_field_size;
    inline const std::ptrdiff_t& generic_sig_index = JvmMapper::InstanceKlass::generic_sig_index;
    inline const std::ptrdiff_t& source_file_index = JvmMapper::InstanceKlass::source_file_index;
    inline const std::ptrdiff_t& static_oop_count = JvmMapper::InstanceKlass::static_oop_count;
    inline const std::ptrdiff_t& java_fields_count = JvmMapper::InstanceKlass::java_fields_count;
    inline const std::ptrdiff_t& nonstatic_oop_size = JvmMapper::InstanceKlass::nonstatic_oop_size;
    inline const std::ptrdiff_t& is_marked_dep = JvmMapper::InstanceKlass::is_marked_dependent;
    inline const std::ptrdiff_t& is_being_redef = JvmMapper::InstanceKlass::is_being_redefined;
    inline const std::ptrdiff_t& has_unloaded_dep = JvmMapper::InstanceKlass::has_unloaded_dependent;

    inline const std::ptrdiff_t& misc_flags = JvmMapper::InstanceKlass::misc_flags;
    inline const std::ptrdiff_t& minor_version = JvmMapper::InstanceKlass::minor_version;
    inline const std::ptrdiff_t& major_version = JvmMapper::InstanceKlass::major_version;

    inline const std::ptrdiff_t& init_thread = JvmMapper::InstanceKlass::init_thread;
    inline const std::ptrdiff_t& vtable_len = JvmMapper::InstanceKlass::vtable_len;
    inline const std::ptrdiff_t& itable_len = JvmMapper::InstanceKlass::itable_len;
    inline const std::ptrdiff_t& oop_map_cache = JvmMapper::InstanceKlass::oop_map_cache;
    inline const std::ptrdiff_t& jni_ids = JvmMapper::InstanceKlass::jni_ids;
    inline const std::ptrdiff_t& methods_jmethod_ids = JvmMapper::InstanceKlass::methods_jmethod_ids;
    inline const std::ptrdiff_t& dependencies = JvmMapper::InstanceKlass::dependencies;
    inline const std::ptrdiff_t& osr_nmethods_head = JvmMapper::InstanceKlass::osr_nmethods_head;
    inline const std::ptrdiff_t& breakpoints = JvmMapper::InstanceKlass::breakpoints;
    inline const std::ptrdiff_t& previous_versions = JvmMapper::InstanceKlass::previous_versions;
    inline const std::ptrdiff_t& cached_class_file = JvmMapper::InstanceKlass::cached_class_file;
    inline const std::ptrdiff_t& idnum_allocated = JvmMapper::InstanceKlass::idnum_allocated;
    inline const std::ptrdiff_t& init_state = JvmMapper::InstanceKlass::init_state;
    inline const std::ptrdiff_t& reference_type = JvmMapper::InstanceKlass::reference_type;
    inline const std::ptrdiff_t& jvmti_field_map = JvmMapper::InstanceKlass::jvmti_field_map;

    inline const std::ptrdiff_t& methods = JvmMapper::InstanceKlass::methods;
    inline const std::ptrdiff_t& default_methods = JvmMapper::InstanceKlass::default_methods;
    inline const std::ptrdiff_t& local_interfaces = JvmMapper::InstanceKlass::local_interfaces;
    inline const std::ptrdiff_t& transitive_intf = JvmMapper::InstanceKlass::transitive_interfaces;
    inline const std::ptrdiff_t& method_ordering = JvmMapper::InstanceKlass::method_ordering;
    inline const std::ptrdiff_t& default_vtable_idx = JvmMapper::InstanceKlass::default_vtable_indices;
    inline const std::ptrdiff_t& fields = JvmMapper::InstanceKlass::fields;

    constexpr int kFullyInitialized   = JvmMapper::State::klass_fully_initialized;
    constexpr int kLinked             = JvmMapper::State::klass_linked;
}


struct RawInstanceFieldPlan {
    uintptr_t fieldsArray = 0;
    uint16_t javaFieldCount = 0;
    uint32_t instanceSizeBytes = 0;
    uint32_t nonstaticFieldWords = 0;
    uint32_t oopOffsetBytes = 0;
    uint32_t oopCount = 0;
    uint32_t staticFieldWords = 0;
    uint16_t staticOopCount = 0;
};

class KlassInjector {
public:


    static uintptr_t InjectClass(HMODULE hJvm,
                                 const std::string& internalName,
                                 uintptr_t templateKlass,
                                 uintptr_t methodArray = 0,
                                 void* threadPtr = nullptr,
                                 uintptr_t resolvedSuperKlass = 0,
                                 uint32_t classAccessFlags = 0x0021,
                                 const uintptr_t* resolvedInterfaces = nullptr,
                                 int32_t resolvedInterfaceCount = 0,
                                 const RawInstanceFieldPlan* fieldPlan = nullptr,
                                 uintptr_t ownerCldOverride = 0,
                                 bool prepareOnly = false)
    {
        if (!hJvm || !templateKlass || internalName.empty()) {
            Log("[KlassInjector] Invalid args");
            return 0;
        }


        uintptr_t emptyKlassArr  = JvmApi::SafeRead<uintptr_t>(JvmApi::EmptyKlassArray());
        uintptr_t emptyMethodArr = JvmApi::SafeRead<uintptr_t>(JvmApi::EmptyMethodArray());
        uintptr_t emptyIntArr    = JvmApi::SafeRead<uintptr_t>(JvmApi::EmptyIntArray());
        uintptr_t emptyShortArr  = JvmApi::SafeRead<uintptr_t>(JvmApi::EmptyShortArray());


        const uintptr_t derivedMethodArr = templateKlass
            ? DeriveEmptyMethodArray(templateKlass) : 0;
        const uintptr_t derivedKlassArr = templateKlass
            ? DeriveEmptyKlassArray(templateKlass) : 0;
        const uintptr_t derivedIntArr = templateKlass
            ? DeriveEmptyIntArray(templateKlass) : 0;
        const uintptr_t derivedShortArr = templateKlass
            ? DeriveEmptyShortArray(templateKlass) : 0;
        if (derivedMethodArr) emptyMethodArr = derivedMethodArr;
        else if (!IsEmptyArray(emptyMethodArr)) emptyMethodArr = 0;
        if (derivedKlassArr) emptyKlassArr = derivedKlassArr;
        else if (!IsEmptyArray(emptyKlassArr)) emptyKlassArr = 0;
        if (derivedIntArr) emptyIntArr = derivedIntArr;
        else if (!IsEmptyArray(emptyIntArr)) emptyIntArr = 0;
        if (derivedShortArr) emptyShortArr = derivedShortArr;
        else if (!IsEmptyArray(emptyShortArr)) emptyShortArr = 0;
        if (!emptyKlassArr || !emptyMethodArr || !emptyIntArr || !emptyShortArr) {
            Log("[KlassInjector] Universe empty arrays not initialized yet (JVM too early?)");
            Log("[KlassInjector]   klass=%p method=%p int=%p short=%p",
                (void*)emptyKlassArr, (void*)emptyMethodArr, (void*)emptyIntArr, (void*)emptyShortArr);
            return 0;
        }

        Log("[KlassInjector] empty_klass_arr=%p  empty_method_arr=%p",
            (void*)emptyKlassArr, (void*)emptyMethodArr);


        uintptr_t cldHeadAddr = JvmApi::BootstrapCLDPtrAddr();
        if (!cldHeadAddr) {
            Log("[KlassInjector] Bootstrap CLD pointer not found");
            return 0;
        }
        uintptr_t nullCld = JvmApi::SafeRead<uintptr_t>(cldHeadAddr);
        if (!nullCld) {
            Log("[KlassInjector] NULL CLD is null?");
            return 0;
        }
        Log("[KlassInjector] NULL CLD @ %p", (void*)nullCld);


        uintptr_t vtablePtr      = ReadPtr(templateKlass + IKOff::vtable_ptr);
        uintptr_t javaMirror     = ReadPtr(templateKlass + IKOff::java_mirror);
        uintptr_t objectKlass    = templateKlass;
        uintptr_t directSuper    = resolvedSuperKlass ? resolvedSuperKlass : objectKlass;


        uintptr_t ownerCld = ownerCldOverride ? ownerCldOverride :
            ReadPtr(directSuper + IKOff::class_loader_data);
        if (!ownerCld) ownerCld = nullCld;
        Log("[KlassInjector] owner CLD=%p source=%s super=%p%s",
            (void*)ownerCld, ownerCldOverride ? "jar" : "super",
            (void*)directSuper,
            ownerCld == nullCld ? " (bootstrap)" : " (non-bootstrap)");
        const bool isInterface   = (classAccessFlags & 0x0200) != 0;
        int32_t   layoutHelper   = ReadU32(directSuper + IKOff::layout_helper);
        if (fieldPlan && fieldPlan->instanceSizeBytes)
            layoutHelper = static_cast<int32_t>(fieldPlan->instanceSizeBytes);


        uintptr_t primarySupers[8] = {};
        for (int i = 0; i < 8; ++i)
            primarySupers[i] = ReadPtr(directSuper + IKOff::primary_supers + i * 8);

        int selfPrimaryIndex = -1;
        for (int i = 0; i < 8; ++i) {
            if (!primarySupers[i]) {
                selfPrimaryIndex = i;
                break;
            }
        }
        if (selfPrimaryIndex < 0) {
            Log("[KlassInjector] Super chain exceeds primary-super capacity: %s",
                internalName.c_str());
            return 0;
        }

        if (!vtablePtr || !javaMirror) {
            Log("[KlassInjector] Template klass missing vtable or mirror");
            return 0;
        }
        Log("[KlassInjector] Template vtable=%p mirror=%p", (void*)vtablePtr, (void*)javaMirror);


        uintptr_t nameSymbol = 0;
        uintptr_t arrayNameSymbol = 0;
        uintptr_t symLookupAddr = JvmApi::SymbolTableLookupAddr();
        if (internalName.size() > 1020) {
            Log("[KlassInjector] Class name too long for array signature: %s",
                internalName.c_str());
            return 0;
        }
        char arrayInternalName[1024] = {};
        arrayInternalName[0] = '[';
        arrayInternalName[1] = 'L';
        memcpy(arrayInternalName + 2, internalName.data(), internalName.size());
        arrayInternalName[internalName.size() + 2] = ';';
        const int arrayInternalNameLength =
            static_cast<int>(internalName.size() + 3);

        if (symLookupAddr && threadPtr) {

            using fn_sym_lookup_t = uintptr_t(__fastcall*)(const char*, int, void*);
            auto fnLookup = reinterpret_cast<fn_sym_lookup_t>(symLookupAddr);
            const uintptr_t symbolThread = reinterpret_cast<uintptr_t>(threadPtr);
            const int symbolOriginalState = *reinterpret_cast<int*>(
                symbolThread + JvmMapper::JavaThread::thread_state);
            const bool symbolSwitchState =
                symbolOriginalState == JvmMapper::State::thread_in_native;
            if (symbolSwitchState) MethodInvoker::TransitionToVM(symbolThread);
            __try {
                nameSymbol = fnLookup(internalName.c_str(), (int)internalName.size(), threadPtr);
                Log("[KlassInjector] SymbolTable::lookup('%s') -> %p",
                    internalName.c_str(), (void*)nameSymbol);


                arrayNameSymbol = fnLookup(arrayInternalName,
                    arrayInternalNameLength, threadPtr);
                Log("[KlassInjector] Array name SymbolTable::lookup('%s') -> %p",
                    arrayInternalName, (void*)arrayNameSymbol);
            } __except(EXCEPTION_EXECUTE_HANDLER) {
                Log("[KlassInjector] SymbolTable::lookup SEH: 0x%08X", GetExceptionCode());
                nameSymbol = 0;
                arrayNameSymbol = 0;
            }
            if (symbolSwitchState) MethodInvoker::TransitionToNative(symbolThread);
        }

        if (!nameSymbol || !arrayNameSymbol) {
            Log("[KlassInjector] class/array SymbolTable::lookup failed; unsafe manual Symbol fallback disabled");
            return 0;
        }
        const uint16_t nameSymbolLength = JvmApi::SafeRead<uint16_t>(nameSymbol);
        const uint16_t arrayNameSymbolLength =
            JvmApi::SafeRead<uint16_t>(arrayNameSymbol);
        if (nameSymbolLength != internalName.size() ||
            arrayNameSymbolLength != static_cast<uint16_t>(arrayInternalNameLength)) {
            Log("[KlassInjector] Symbol length mismatch: class=%u/%zu array=%u/%d",
                static_cast<unsigned>(nameSymbolLength), internalName.size(),
                static_cast<unsigned>(arrayNameSymbolLength), arrayInternalNameLength);
            return 0;
        }

        Log("[KlassInjector] Symbol @ %p name='%s'",
            (void*)nameSymbol, internalName.c_str());


        SYSTEM_INFO systemInfo{};
        GetSystemInfo(&systemInfo);
        const size_t totalSize = systemInfo.dwAllocationGranularity
            ? static_cast<size_t>(systemInfo.dwAllocationGranularity)
            : static_cast<size_t>(systemInfo.dwPageSize);
        if (!totalSize) {
            Log("[KlassInjector] Windows allocation geometry unavailable");
            return 0;
        }
        uintptr_t mem = reinterpret_cast<uintptr_t>(
            VirtualAlloc(nullptr, totalSize,
                         MEM_COMMIT | MEM_RESERVE,
                         PAGE_READWRITE));

        if (!mem) {
            Log("[KlassInjector] VirtualAlloc failed: %lu", GetLastError());
            return 0;
        }
        memset(reinterpret_cast<void*>(mem), 0, totalSize);
        Log("[KlassInjector] Allocated %zu bytes @ %p", totalSize, (void*)mem);


        auto W64 = [&](std::ptrdiff_t off, uintptr_t val) {
            if (off >= 0) *reinterpret_cast<uintptr_t*>(mem + off) = val;
        };
        auto W32 = [&](std::ptrdiff_t off, uint32_t val) {
            if (off >= 0) *reinterpret_cast<uint32_t*>(mem + off) = val;
        };
        auto W16 = [&](std::ptrdiff_t off, uint16_t val) {
            if (off >= 0) *reinterpret_cast<uint16_t*>(mem + off) = val;
        };
        auto W8 = [&](std::ptrdiff_t off, uint8_t val) {
            if (off >= 0) *reinterpret_cast<uint8_t*>(mem + off) = val;
        };


        uintptr_t cpPtr = 0;
        if (methodArray) {
            uintptr_t firstMethod = *reinterpret_cast<uintptr_t*>(
                methodArray + JvmMapper::Array::data);
            if (firstMethod) {
                uintptr_t constMethod = *reinterpret_cast<uintptr_t*>(
                    firstMethod + JvmMapper::Method::const_method);
                if (constMethod) {
                    cpPtr = *reinterpret_cast<uintptr_t*>(
                        constMethod + JvmMapper::ConstMethod::constants);
                }
            }
        }


        W64(IKOff::vtable_ptr,          vtablePtr);
        W32(IKOff::layout_helper,       static_cast<uint32_t>(layoutHelper));


        W32(IKOff::super_check_offset,
            static_cast<uint32_t>(isInterface
                ? IKOff::secondary_super_cache
                : IKOff::primary_supers + selfPrimaryIndex * 8));
        W64(IKOff::name,                nameSymbol);
        W64(IKOff::secondary_super_cache, 0);
        uintptr_t localInterfaceArray = emptyKlassArr;
        uintptr_t transitiveInterfaceArray = emptyKlassArr;
        uintptr_t transitiveInterfaces[128] = {};
        int32_t transitiveInterfaceCount = 0;
        if (resolvedInterfaces && resolvedInterfaceCount > 0) {
            if (resolvedInterfaceCount > 64) return 0;
            localInterfaceArray = AllocatePointerArray(resolvedInterfaces, resolvedInterfaceCount);
            if (!localInterfaceArray) return 0;
            for (int32_t i = 0; i < resolvedInterfaceCount; ++i) {
                AddUniquePointer(transitiveInterfaces, transitiveInterfaceCount, 128, resolvedInterfaces[i]);
                uintptr_t inherited = ReadPtr(resolvedInterfaces[i] + IKOff::transitive_intf);
                const int32_t inheritedCount = inherited ? JvmApi::SafeRead<int32_t>(inherited) : 0;
                for (int32_t j = 0; j < inheritedCount && j < 128; ++j)
                    AddUniquePointer(transitiveInterfaces, transitiveInterfaceCount, 128,
                        ReadPtr(inherited + JvmMapper::Array::data + j * 8ULL));
            }
        }
        if (!isInterface) {
            uintptr_t parentInterfaces = ReadPtr(directSuper + IKOff::transitive_intf);
            const int32_t parentCount = parentInterfaces ? JvmApi::SafeRead<int32_t>(parentInterfaces) : 0;
            for (int32_t i = 0; i < parentCount && i < 128; ++i)
                AddUniquePointer(transitiveInterfaces, transitiveInterfaceCount, 128,
                    ReadPtr(parentInterfaces + JvmMapper::Array::data + i * 8ULL));
        }
        if (transitiveInterfaceCount > 0) {
            transitiveInterfaceArray = AllocatePointerArray(transitiveInterfaces, transitiveInterfaceCount);
            if (!transitiveInterfaceArray) return 0;
        }
        W64(IKOff::secondary_supers,    transitiveInterfaceArray);

        for (int i = 0; i < 8; ++i)
            W64(IKOff::primary_supers + i * 8, primarySupers[i]);
        W64(IKOff::primary_supers + selfPrimaryIndex * 8, mem);


        W64(IKOff::java_mirror,          0);
        W64(IKOff::super_klass,          directSuper);
        W64(IKOff::subklass,             0);
        W64(IKOff::next_sibling,         0);
        W64(IKOff::next_link,            0);

        W64(IKOff::class_loader_data,    0);

        W32(IKOff::access_flags,         classAccessFlags);
        W32(IKOff::modifier_flags,       classAccessFlags & 0xFFFFu);


        W64(IKOff::annotations,          0);
        W64(IKOff::array_klasses,        0);
        W64(IKOff::constants,            cpPtr);
        W64(IKOff::inner_classes,        emptyShortArr);
        W64(IKOff::source_debug_ext,     0);
        W64(IKOff::array_name,           arrayNameSymbol);


        W8(IKOff::init_state,            IKOff::kLinked);

        W64(IKOff::methods,              methodArray ? methodArray : emptyMethodArr);
        W16(IKOff::idnum_allocated, methodArray
            ? static_cast<uint16_t>(ReadU32(methodArray + JvmMapper::Array::length)) : 0);
        W16(IKOff::major_version, 52);
        W16(IKOff::minor_version, 0);
        W64(IKOff::default_methods,      emptyMethodArr);

        W64(IKOff::local_interfaces,     localInterfaceArray);
        W64(IKOff::transitive_intf,      transitiveInterfaceArray);
        Log("[KlassInjector] interfaces: local=%d transitive=%d",
            resolvedInterfaceCount, transitiveInterfaceCount);

        W64(IKOff::method_ordering,      emptyIntArr);

        W64(IKOff::default_vtable_idx,   0);


        W64(IKOff::fields, fieldPlan && fieldPlan->fieldsArray
            ? fieldPlan->fieldsArray : emptyShortArr);
        if (fieldPlan) {
            W16(IKOff::java_fields_count, fieldPlan->javaFieldCount);
            W32(IKOff::nonstatic_field_size, fieldPlan->nonstaticFieldWords);
            W32(IKOff::static_field_size, fieldPlan->staticFieldWords);
            W16(IKOff::static_oop_count, fieldPlan->staticOopCount);
        }


        const std::ptrdiff_t embeddedVtableOffset =
            ResolveEmbeddedVtableOffset(objectKlass);
        const int32_t parentVtableLen = static_cast<int32_t>(
            ReadU32(directSuper + IKOff::vtable_len));
        uintptr_t javaVtable[512] = {};
        int32_t javaVtableLen = 0;
        if (embeddedVtableOffset > 0 && parentVtableLen >= 0 && parentVtableLen < 512) {
            for (int32_t i = 0; !isInterface && i < parentVtableLen; ++i) {
                javaVtable[javaVtableLen++] = ReadPtr(
                    directSuper + embeddedVtableOffset + i * sizeof(uintptr_t));
            }

            if (methodArray && !isInterface) {
                const int32_t methodCount = *reinterpret_cast<int32_t*>(methodArray);
                for (int32_t mi = 0; mi < methodCount; ++mi) {
                    uintptr_t method = ReadPtr(
                        methodArray + JvmMapper::Array::data + mi * sizeof(uintptr_t));
                    if (!method) continue;
                    const uint32_t flags = ReadU32(
                        method + JvmMapper::Method::access_flags);
                    const auto key = MethodSymbolKey(method);
                    const char firstNameByte = key.first
                        ? JvmApi::SafeRead<char>(key.first + JvmMapper::Symbol::body)
                        : 0;
                    if ((flags & 0x0008) || (flags & 0x0002) || firstNameByte == '<')
                        continue;

                    int32_t slot = -1;
                    for (int32_t vi = 0; vi < javaVtableLen; ++vi) {
                        if (MethodSymbolKey(javaVtable[vi]) == key) {
                            slot = vi;
                            javaVtable[vi] = method;
                            break;
                        }
                    }
                    if (slot < 0) {
                        if (javaVtableLen >= 512) {
                            Log("[KlassInjector] vtable entry capacity exceeded");
                            return 0;
                        }
                        slot = javaVtableLen;
                        javaVtable[javaVtableLen++] = method;
                    }
                    *reinterpret_cast<int32_t*>(
                        method + JvmMapper::Method::vtable_index) = slot;
                    Log("[KlassInjector] vtable method=%p slot=%d %s",
                        (void*)method, slot,
                        slot < parentVtableLen ? "override" : "append");
                }
            }

            const size_t vtableEnd = static_cast<size_t>(embeddedVtableOffset) +
                static_cast<size_t>(javaVtableLen) * sizeof(uintptr_t);
            if (vtableEnd > totalSize) {
                Log("[KlassInjector] vtable exceeds allocation: end=0x%zX", vtableEnd);
                return 0;
            }
            for (int32_t i = 0; i < javaVtableLen; ++i)
                W64(embeddedVtableOffset + i * sizeof(uintptr_t), javaVtable[i]);
            W32(IKOff::vtable_len, static_cast<uint32_t>(javaVtableLen));
            Log("[KlassInjector] vtable ready: offset=0x%zX parent=%d total=%d",
                static_cast<size_t>(embeddedVtableOffset), parentVtableLen,
                javaVtableLen);
        } else {
            Log("[KlassInjector] embedded vtable offset unresolved");
            return 0;
        }


        if (isInterface && methodArray) {
            const int32_t methodCount = JvmApi::SafeRead<int32_t>(methodArray);
            int32_t interfaceMethodIndex = 0;
            for (int32_t mi = 0; mi < methodCount; ++mi) {
                uintptr_t method = ReadPtr(
                    methodArray + JvmMapper::Array::data + mi * 8ULL);
                if (!method) continue;
                const uint32_t flags = ReadU32(method + JvmMapper::Method::access_flags);
                const auto key = MethodSymbolKey(method);
                const char firstNameByte = key.first
                    ? JvmApi::SafeRead<char>(key.first + JvmMapper::Symbol::body) : 0;
                if ((flags & 0x0008) || (flags & 0x0002) || firstNameByte == '<')
                    continue;
                *reinterpret_cast<int32_t*>(
                    method + JvmMapper::Method::vtable_index) = -10 - interfaceMethodIndex;
                Log("[KlassInjector] interface method=%p itable_index=%d encoded=%d",
                    (void*)method, interfaceMethodIndex, -10 - interfaceMethodIndex);
                ++interfaceMethodIndex;
            }
        }

        int32_t itableMethodCount = 0;
        for (int32_t ii = 0; !isInterface && ii < transitiveInterfaceCount; ++ii) {
            uintptr_t methods = ReadPtr(transitiveInterfaces[ii] + IKOff::methods);
            const int32_t count = methods ? JvmApi::SafeRead<int32_t>(methods) : 0;
            for (int32_t mi = 0; mi < count; ++mi) {
                uintptr_t method = ReadPtr(methods + JvmMapper::Array::data + mi * 8ULL);
                const uint32_t flags = method ? ReadU32(method + JvmMapper::Method::access_flags) : 0;
                if (method && !(flags & 0x0008) && !(flags & 0x0002)) ++itableMethodCount;
            }
        }
        const size_t itableStart = static_cast<size_t>(embeddedVtableOffset) +
            static_cast<size_t>(javaVtableLen) * sizeof(uintptr_t);
        const size_t offsetBytes = (!isInterface && transitiveInterfaceCount > 0)
            ? static_cast<size_t>(transitiveInterfaceCount + 1)
                * static_cast<size_t>(JvmMapper::ItableOffsetEntry::size) : 0;
        const size_t itableBytes = offsetBytes + static_cast<size_t>(itableMethodCount) * sizeof(uintptr_t);
        if (itableStart + itableBytes > totalSize) {
            Log("[KlassInjector] itable exceeds allocation: end=0x%zX", itableStart + itableBytes);
            return 0;
        }
        size_t cursor = itableStart + offsetBytes;
        for (int32_t ii = 0; !isInterface && ii < transitiveInterfaceCount; ++ii) {
            const size_t entry = itableStart + static_cast<size_t>(ii)
                * static_cast<size_t>(JvmMapper::ItableOffsetEntry::size);
            W64(static_cast<std::ptrdiff_t>(
                    entry + JvmMapper::ItableOffsetEntry::interface_klass),
                transitiveInterfaces[ii]);
            W32(static_cast<std::ptrdiff_t>(
                    entry + JvmMapper::ItableOffsetEntry::offset),
                static_cast<uint32_t>(cursor));
            uintptr_t methods = ReadPtr(transitiveInterfaces[ii] + IKOff::methods);
            const int32_t count = methods ? JvmApi::SafeRead<int32_t>(methods) : 0;
            int32_t emitted = 0;
            for (int32_t mi = 0; mi < count; ++mi) {
                uintptr_t source = ReadPtr(methods + JvmMapper::Array::data + mi * 8ULL);
                const uint32_t flags = source ? ReadU32(source + JvmMapper::Method::access_flags) : 0;
                if (!source || (flags & 0x0008) || (flags & 0x0002)) continue;
                uintptr_t implementation = FindMethodInHierarchy(mem, MethodSymbolKey(source));
                if (!implementation) {
                    Log("[KlassInjector] itable implementation missing: interface=%p method=%p",
                        (void*)transitiveInterfaces[ii], (void*)source);
                    return 0;
                }
                W64(static_cast<std::ptrdiff_t>(cursor), implementation);
                cursor += sizeof(uintptr_t);
                ++emitted;
                Log("[KlassInjector] itable method source=%p impl=%p",
                    (void*)source, (void*)implementation);
            }
            Log("[KlassInjector] itable interface=%p methods=%d",
                (void*)transitiveInterfaces[ii], emitted);
        }
        W32(IKOff::itable_len, static_cast<uint32_t>(
            (itableBytes + sizeof(uintptr_t) - 1) / sizeof(uintptr_t)));
        Log("[KlassInjector] itable ready: start=0x%zX words=%u", itableStart,
            static_cast<unsigned>((itableBytes + sizeof(uintptr_t) - 1) / sizeof(uintptr_t)));


        const uint32_t parentOopMapCount = isInterface ? 0 :
            ReadU32(directSuper + IKOff::nonstatic_oop_size);
        const uint32_t localOopMapCount = fieldPlan && fieldPlan->oopCount ? 1u : 0u;
        const uint32_t totalOopMapCount = parentOopMapCount + localOopMapCount;
        if (totalOopMapCount) {
            constexpr size_t oopMapAlignment = alignof(uintptr_t);
            const size_t oopMapStart = (itableStart + itableBytes + oopMapAlignment - 1)
                & ~(oopMapAlignment - 1);
            const size_t oopMapBlockSize = static_cast<size_t>(JvmMapper::OopMapBlock::size);
            if (oopMapStart + static_cast<size_t>(totalOopMapCount) * oopMapBlockSize > totalSize) {
                Log("[KlassInjector] oop-map exceeds allocation");
                return 0;
            }
            const uint32_t parentVtableWords = ReadU32(directSuper + IKOff::vtable_len);
            const uint32_t parentItableWords = ReadU32(directSuper + IKOff::itable_len);
            const uintptr_t parentMaps = directSuper + embeddedVtableOffset +
                static_cast<uintptr_t>(parentVtableWords + parentItableWords) * sizeof(uintptr_t);
            for (uint32_t i = 0; i < parentOopMapCount; ++i) {
                const size_t destination = oopMapStart + static_cast<size_t>(i) * oopMapBlockSize;
                const uintptr_t source = parentMaps + static_cast<uintptr_t>(i) * oopMapBlockSize;
                W32(static_cast<std::ptrdiff_t>(destination + JvmMapper::OopMapBlock::offset),
                    ReadU32(source + JvmMapper::OopMapBlock::offset));
                W32(static_cast<std::ptrdiff_t>(destination + JvmMapper::OopMapBlock::count),
                    ReadU32(source + JvmMapper::OopMapBlock::count));
            }
            if (localOopMapCount) {
                const size_t localMap = oopMapStart
                    + static_cast<size_t>(parentOopMapCount) * oopMapBlockSize;
                W32(static_cast<std::ptrdiff_t>(localMap + JvmMapper::OopMapBlock::offset),
                    fieldPlan->oopOffsetBytes);
                W32(static_cast<std::ptrdiff_t>(localMap + JvmMapper::OopMapBlock::count),
                    fieldPlan->oopCount);
                Log("[KlassInjector] oop-map local: offset_bytes=%u count=%u",
                    fieldPlan->oopOffsetBytes, fieldPlan->oopCount);
            }
            W32(IKOff::nonstatic_oop_size, totalOopMapCount);
            Log("[KlassInjector] oop-map ready: inherited=%u local=%u total=%u",
                parentOopMapCount, localOopMapCount, totalOopMapCount);
        } else {
            W32(IKOff::nonstatic_oop_size, 0);
        }

        Log("[KlassInjector] InstanceKlass struct filled @ %p", (void*)mem);


        if (prepareOnly) return mem;
        if (!LinkPreparedMethods(mem, methodArray, threadPtr)) return 0;
        if (!InstallPreparedMirror(mem, ownerCld, threadPtr, javaMirror)) return 0;
        PublishPreparedHierarchy(mem, directSuper);
        return mem;
    }

    // Split points preserve the reference implementation for manual staging.
    static bool LinkPreparedMethods(uintptr_t mem, uintptr_t methodArray, void* threadPtr) {
        if (methodArray) {
            int32_t numMethods = *reinterpret_cast<int32_t*>(methodArray);
            for (int32_t i = 0; i < numMethods; i++) {
                uintptr_t m = *reinterpret_cast<uintptr_t*>(
                    methodArray + JvmMapper::Array::data + (i * sizeof(uintptr_t)));
                if (m) {

                    uintptr_t constMethod = JvmApi::SafeRead<uintptr_t>(
                        m + JvmMapper::Method::const_method);
                    if (constMethod) {
                        uintptr_t cp = JvmApi::SafeRead<uintptr_t>(
                            constMethod + JvmMapper::ConstMethod::constants);
                        if (cp) {
                            *reinterpret_cast<uintptr_t*>(
                                cp + JvmMapper::ConstantPool::pool_holder) = mem;
                            Log("[KlassInjector] method[%d]: cp=%p, mapped _pool_holder = %p",
                                i, (void*)cp, (void*)mem);
                        } else {
                            Log("[KlassInjector] method[%d]: mapped ConstMethod CP is NULL!", i);
                        }
                    }
                }
            }
            Log("[KlassInjector] Set ConstantPool::_pool_holder for %d methods", numMethods);


            const uintptr_t linkAddr = JvmApi::MethodLinkAddr();
            const uintptr_t copyAddr = JvmApi::MetadataHandleCopyAddr();
            if (!threadPtr || !linkAddr || !copyAddr) {
                Log("[KlassInjector] method linking unavailable: thread=%p link=%p handleCopy=%p",
                    threadPtr, (void*)linkAddr, (void*)copyAddr);
                return 0;
            }

            struct RawMetadataHandle {
                uintptr_t value;
                uintptr_t thread;
            };
            static_assert(sizeof(RawMetadataHandle) == 16,
                "metadataHandle ABI mismatch");

            using fn_handle_copy_t = RawMetadataHandle*(__fastcall*)(
                RawMetadataHandle*, const RawMetadataHandle*);
            using fn_link_method_t = void(__fastcall*)(
                uintptr_t, RawMetadataHandle*, void*);
            auto copyHandle = reinterpret_cast<fn_handle_copy_t>(copyAddr);
            auto linkMethod = reinterpret_cast<fn_link_method_t>(linkAddr);

            const uintptr_t linkThread = reinterpret_cast<uintptr_t>(threadPtr);
            const int linkOriginalState = *reinterpret_cast<int*>(
                linkThread + JvmMapper::JavaThread::thread_state);
            const bool linkSwitchState =
                linkOriginalState == JvmMapper::State::thread_in_native;
            bool linkOk = true;
            if (linkSwitchState) MethodInvoker::TransitionToVM(linkThread);

            for (int32_t i = 0; i < numMethods; ++i) {
                const uintptr_t method = *reinterpret_cast<uintptr_t*>(
                    methodArray + JvmMapper::Array::data
                        + (i * sizeof(uintptr_t)));
                if (!method) continue;

                RawMetadataHandle source{ method, linkThread };
                RawMetadataHandle owned{};
                copyHandle(&owned, &source);

                linkMethod(method, &owned, threadPtr);

                const uintptr_t pendingException = JvmApi::SafeRead<uintptr_t>(
                    linkThread + JvmMapper::JavaThread::pending_exception);
                const uintptr_t adapter = JvmApi::SafeRead<uintptr_t>(
                    method + JvmMapper::Method::adapter);
                const uintptr_t fromCompiled = JvmApi::SafeRead<uintptr_t>(
                    method + JvmMapper::Method::from_compiled_entry);
                const uintptr_t fromInterpreted = JvmApi::SafeRead<uintptr_t>(
                    method + JvmMapper::Method::from_interpreted_entry);
                const uintptr_t i2i = JvmApi::SafeRead<uintptr_t>(
                    method + JvmMapper::Method::i2i_entry);
                Log("[KlassInjector] linked method[%d]: adapter=%p from_comp=%p from_interp=%p i2i=%p",
                    i, (void*)adapter, (void*)fromCompiled,
                    (void*)fromInterpreted, (void*)i2i);
                if (pendingException || !adapter || !fromCompiled ||
                    !fromInterpreted || !i2i) {
                    Log("[KlassInjector] method[%d] link verification FAILED pending=%p",
                        i, (void*)pendingException);
                    linkOk = false;
                    break;
                }
            }

            if (linkSwitchState) MethodInvoker::TransitionToNative(linkThread);
            if (!linkOk) return 0;
            Log("[KlassInjector] HotSpot method linking complete: %d methods", numMethods);
        }


        return true;
    }

    static bool InstallPreparedMirror(uintptr_t mem, uintptr_t ownerCld, void* threadPtr, uintptr_t javaMirror) {
        uintptr_t restoreFn = JvmApi::RestoreKlassMirrorAddr();
        if (!restoreFn || !JvmApi::CreateMirrorAddr() || !JvmApi::KlassOopStoreAddr()) {
            Log("[KlassInjector] GC-safe mirror path not resolved — cannot inject");
            return 0;
        }

        using fn_restore_mirror_t = void(__fastcall*)(
            uintptr_t klass, uintptr_t cld, uintptr_t protectionDomainHandle,
            void* thread);
        auto fnRestore = reinterpret_cast<fn_restore_mirror_t>(restoreFn);

        const uintptr_t thread = reinterpret_cast<uintptr_t>(threadPtr);
        const int originalState = *reinterpret_cast<int*>(
            thread + JvmMapper::JavaThread::thread_state);
        const bool switchState =
            originalState == JvmMapper::State::thread_in_native;
        bool mirrorCallSurvived = false;

        __try {
            if (switchState) MethodInvoker::TransitionToVM(thread);


            fnRestore(mem, ownerCld, 0, threadPtr);
            mirrorCallSurvived = true;
        } __except (LogMirrorSEH(GetExceptionInformation())) {
        }

        if (switchState) MethodInvoker::TransitionToNative(thread);


        const uintptr_t installedCld = ReadPtr(mem + IKOff::class_loader_data);
        const uintptr_t installedMirror = ReadPtr(mem + IKOff::java_mirror);
        if (!mirrorCallSurvived || installedCld != ownerCld ||
            !installedMirror || installedMirror == javaMirror) {
            Log("[KlassInjector] mirror verification failed: cld=%p mirror=%p template=%p",
                (void*)installedCld, (void*)installedMirror, (void*)javaMirror);
            return 0;
        }
        Log("[KlassInjector] Dedicated mirror installed: klass=%p mirror=%p",
            (void*)mem, (void*)installedMirror);


        return true;
    }

    static void PublishPreparedHierarchy(uintptr_t mem, uintptr_t directSuper) {
        auto parentSubklass = reinterpret_cast<PVOID volatile*>(
            directSuper + IKOff::subklass);
        PVOID observed = nullptr;
        do {
            observed = *parentSubklass;
            *reinterpret_cast<uintptr_t*>(mem + IKOff::next_sibling) = reinterpret_cast<uintptr_t>(observed);
        } while (InterlockedCompareExchangePointer(
                     parentSubklass, reinterpret_cast<PVOID>(mem), observed) != observed);

    }

    static uintptr_t FindObjectKlass(HMODULE hJvm)
    {
        return JvmApi::FindClass("java/lang/Object");
    }

private:

    static bool IsEmptyArray(uintptr_t array)
    {
        if (!array || JvmMapper::Array::length < 0) return false;
        MEMORY_BASIC_INFORMATION memoryInfo{};
        if (!VirtualQuery(reinterpret_cast<const void*>(array),
                          &memoryInfo, sizeof(memoryInfo)) ||
            memoryInfo.State != MEM_COMMIT ||
            (memoryInfo.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
            return false;
        const uintptr_t regionEnd = reinterpret_cast<uintptr_t>(
            memoryInfo.BaseAddress) + memoryInfo.RegionSize;
        const uintptr_t lengthAddress = array +
            static_cast<uintptr_t>(JvmMapper::Array::length);
        if (lengthAddress < array || lengthAddress + sizeof(int32_t) > regionEnd)
            return false;
        return *reinterpret_cast<const int32_t*>(lengthAddress) == 0;
    }

    static uintptr_t AllocatePointerArray(const uintptr_t* values, int32_t count)
    {
        if (!values || count <= 0) return 0;
        const size_t bytes = JvmMapper::Array::data + static_cast<size_t>(count) * 8ULL;
        uintptr_t array = reinterpret_cast<uintptr_t>(VirtualAlloc(
            nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
        if (!array) return 0;
        memset(reinterpret_cast<void*>(array), 0, bytes);
        *reinterpret_cast<int32_t*>(array + JvmMapper::Array::length) = count;
        for (int32_t i = 0; i < count; ++i)
            *reinterpret_cast<uintptr_t*>(array + JvmMapper::Array::data + i * 8ULL) = values[i];
        return array;
    }

    static void AddUniquePointer(uintptr_t* values, int32_t& count, int32_t capacity, uintptr_t value)
    {
        if (!values || !value || count >= capacity) return;
        for (int32_t i = 0; i < count; ++i) if (values[i] == value) return;
        values[count++] = value;
    }

    static uintptr_t FindMethodInHierarchy(
        uintptr_t klass, const std::pair<uintptr_t, uintptr_t>& key)
    {
        for (uintptr_t current = klass; current; current = ReadPtr(current + IKOff::super_klass)) {
            uintptr_t methods = ReadPtr(current + IKOff::methods);
            const int32_t count = methods ? JvmApi::SafeRead<int32_t>(methods) : 0;
            for (int32_t i = 0; i < count; ++i) {
                uintptr_t method = ReadPtr(methods + JvmMapper::Array::data + i * 8ULL);
                if (!method || MethodSymbolKey(method) != key) continue;
                if (!(ReadU32(method + JvmMapper::Method::access_flags) & 0x0400)) return method;
            }
        }
        return 0;
    }

    static std::pair<uintptr_t, uintptr_t> MethodSymbolKey(uintptr_t method)
    {
        if (!method) return {0, 0};
        uintptr_t cm = JvmApi::SafeRead<uintptr_t>(
            method + JvmMapper::Method::const_method);
        if (!cm) return {0, 0};
        uintptr_t cp = JvmApi::SafeRead<uintptr_t>(
            cm + JvmMapper::ConstMethod::constants);
        if (!cp) return {0, 0};
        uint16_t nameIndex = JvmApi::SafeRead<uint16_t>(
            cm + JvmMapper::ConstMethod::name_index);
        uint16_t sigIndex = JvmApi::SafeRead<uint16_t>(
            cm + JvmMapper::ConstMethod::signature_index);
        uintptr_t cpBase = cp + JvmMapper::ConstantPool::base;
        return {
            JvmApi::SafeRead<uintptr_t>(cpBase + nameIndex * 8ULL),
            JvmApi::SafeRead<uintptr_t>(cpBase + sigIndex * 8ULL)
        };
    }

    static std::ptrdiff_t ResolveEmbeddedVtableOffset(uintptr_t objectKlass)
    {
        static std::ptrdiff_t cached = 0;
        if (cached) return cached;

        uintptr_t methods = ReadPtr(objectKlass + IKOff::methods);
        int32_t methodCount = methods ? JvmApi::SafeRead<int32_t>(methods) : 0;
        int32_t vtableCount = static_cast<int32_t>(
            ReadU32(objectKlass + IKOff::vtable_len));
        if (!methods || methodCount <= 0 || methodCount > 256 ||
            vtableCount <= 0 || vtableCount > 256)
            return 0;


        MEMORY_BASIC_INFORMATION memoryInfo{};
        if (!VirtualQuery(reinterpret_cast<const void*>(objectKlass),
                          &memoryInfo, sizeof(memoryInfo)))
            return 0;
        const uintptr_t regionEnd = reinterpret_cast<uintptr_t>(
            memoryInfo.BaseAddress) + memoryInfo.RegionSize;
        if (regionEnd <= objectKlass) return 0;

        SYSTEM_INFO systemInfo{};
        GetSystemInfo(&systemInfo);
        size_t scanBytes = systemInfo.dwAllocationGranularity
            ? static_cast<size_t>(systemInfo.dwAllocationGranularity)
            : static_cast<size_t>(systemInfo.dwPageSize);
        const size_t regionBytes = static_cast<size_t>(regionEnd - objectKlass);
        if (!scanBytes || scanBytes > regionBytes) scanBytes = regionBytes;
        const size_t vtableBytes = static_cast<size_t>(vtableCount)
            * sizeof(uintptr_t);
        if (scanBytes < vtableBytes) return 0;

        for (std::ptrdiff_t off = 0;
             static_cast<size_t>(off) + vtableBytes <= scanBytes;
             off += sizeof(uintptr_t)) {
            bool allObjectMethods = true;
            for (int32_t vi = 0; vi < vtableCount; ++vi) {
                uintptr_t candidate = ReadPtr(
                    objectKlass + off + vi * sizeof(uintptr_t));
                bool found = false;
                for (int32_t mi = 0; mi < methodCount; ++mi) {
                    if (candidate == ReadPtr(
                            methods + JvmMapper::Array::data +
                            mi * sizeof(uintptr_t))) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    allObjectMethods = false;
                    break;
                }
            }
            if (allObjectMethods) {
                cached = off;
                Log("[KlassInjector] runtime embedded-vtable offset=0x%zX len=%d",
                    static_cast<size_t>(cached), vtableCount);
                return cached;
            }
        }
        return 0;
    }


    static uintptr_t DeriveEmptyMethodArray(uintptr_t objectKlass) {

        const char* names[] = { "java/lang/Cloneable", "java/io/Serializable", nullptr };
        for (int i = 0; names[i]; i++) {
            uintptr_t klass = JvmApi::FindClass(names[i]);
            if (!klass) continue;
            uintptr_t arr = JvmApi::SafeRead<uintptr_t>(klass + IKOff::methods);
            if (IsEmptyArray(arr)) {
                Log("[KlassInjector] empty_method_array derived from %s @ %p", names[i], (void*)arr);
                return arr;
            }
        }
        return 0;
    }

    static uintptr_t DeriveEmptyKlassArray(uintptr_t objectKlass) {

        uintptr_t arr = JvmApi::SafeRead<uintptr_t>(objectKlass + IKOff::local_interfaces);
        if (IsEmptyArray(arr)) {
            Log("[KlassInjector] empty_klass_array derived from Object._local_interfaces @ %p", (void*)arr);
            return arr;
        }
        return 0;
    }

    static uintptr_t DeriveEmptyIntArray(uintptr_t objectKlass) {

        uintptr_t arr = JvmApi::SafeRead<uintptr_t>(
            objectKlass + IKOff::method_ordering);
        if (IsEmptyArray(arr)) {
            Log("[KlassInjector] empty_int_array derived from Object._method_ordering @ %p",
                (void*)arr);
            return arr;
        }
        return 0;
    }

    static uintptr_t DeriveEmptyShortArray(uintptr_t objectKlass) {

        uintptr_t arr = JvmApi::SafeRead<uintptr_t>(
            objectKlass + IKOff::inner_classes);
        if (IsEmptyArray(arr)) {
            Log("[KlassInjector] empty_short_array derived from Object._inner_classes @ %p",
                (void*)arr);
            return arr;
        }
        return 0;
    }


    static uintptr_t ReadPtr(uintptr_t addr)
    {
        uintptr_t val = 0;
        __try { val = *reinterpret_cast<const uintptr_t*>(addr); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return val;
    }

    static uint32_t ReadU32(uintptr_t addr)
    {
        uint32_t val = 0;
        __try { val = *reinterpret_cast<const uint32_t*>(addr); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return val;
    }
};
