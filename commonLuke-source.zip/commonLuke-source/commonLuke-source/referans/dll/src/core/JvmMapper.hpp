#pragma once


#include <Windows.h>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <vector>
#include "Logging.hpp"
#include "hde64.h"

class JvmMapper {
public:

    static constexpr bool kEnableUnverifiedInjectionTest = true;
    static constexpr const char* kProfileName = "unpacked-jdk8u492-b09-x64-2026-09-01";
    static constexpr const char* kTargetSha256 =
        "D7A81519EB106DAC9E3AE0E399EA83A97746A215B56061EAC799AF5F4C12A2A4";

    struct Symbol {
        static inline std::ptrdiff_t length = -1;
        static inline std::ptrdiff_t body = -1;
    };

    struct Array {
        static inline std::ptrdiff_t length = -1;
        static inline std::ptrdiff_t data = -1;
    };

    struct CompactU2Array {
        static inline std::ptrdiff_t length = -1;
        static inline std::ptrdiff_t data = -1;
    };

    struct FieldInfo {
        static constexpr std::size_t entry_words = 6;


        static constexpr std::size_t initval_index_word = 0;
        static constexpr std::size_t access_flags_word = 1;
        static constexpr std::size_t signature_index_word = 2;
        static constexpr std::size_t name_index_word = 3;
        static constexpr std::size_t low_offset_word = 4;
        static constexpr std::size_t high_offset_word = 5;
        static constexpr unsigned offset_tag_bits = 2;
    };

    struct ClassLoaderData {
        static inline std::ptrdiff_t class_loader = -1;
        static inline std::ptrdiff_t klasses = -1;
        static inline std::ptrdiff_t next = -1;
    };

    struct Klass {
        static constexpr std::ptrdiff_t vtable_ptr       = 0x00;
        static inline std::ptrdiff_t layout_helper = -1;
        static inline std::ptrdiff_t super_check_offset = -1;
        static inline std::ptrdiff_t name = -1;
        static inline std::ptrdiff_t secondary_super_cache = -1;
        static inline std::ptrdiff_t secondary_supers = -1;
        static inline std::ptrdiff_t primary_supers = -1;
        static inline std::ptrdiff_t java_mirror = -1;
        static inline std::ptrdiff_t super_klass = -1;
        static inline std::ptrdiff_t subklass = -1;
        static inline std::ptrdiff_t next_sibling = -1;
        static inline std::ptrdiff_t next_link = -1;
        static inline std::ptrdiff_t class_loader_data = -1;
        static inline std::ptrdiff_t modifier_flags = -1;
        static inline std::ptrdiff_t access_flags = -1;
    };

    struct InstanceKlass {
        static inline std::ptrdiff_t annotations = -1;
        static inline std::ptrdiff_t array_klasses = -1;
        static inline std::ptrdiff_t constants = -1;
        static inline std::ptrdiff_t inner_classes = -1;
        static inline std::ptrdiff_t source_debug_ext = -1;
        static inline std::ptrdiff_t array_name = -1;
        static inline std::ptrdiff_t nonstatic_field_size = -1;
        static inline std::ptrdiff_t static_field_size = -1;
        static inline std::ptrdiff_t generic_sig_index = -1;
        static inline std::ptrdiff_t source_file_index = -1;
        static inline std::ptrdiff_t static_oop_count = -1;
        static inline std::ptrdiff_t java_fields_count = -1;
        static inline std::ptrdiff_t nonstatic_oop_size = -1;
        static inline std::ptrdiff_t is_marked_dependent = -1;
        static inline std::ptrdiff_t is_being_redefined = -1;
        static inline std::ptrdiff_t has_unloaded_dependent = -1;
        static inline std::ptrdiff_t misc_flags = -1;
        static inline std::ptrdiff_t minor_version = -1;
        static inline std::ptrdiff_t major_version = -1;
        static inline std::ptrdiff_t init_thread = -1;
        static inline std::ptrdiff_t vtable_len = -1;
        static inline std::ptrdiff_t itable_len = -1;
        static inline std::ptrdiff_t oop_map_cache = -1;
        static inline std::ptrdiff_t jni_ids = -1;
        static inline std::ptrdiff_t methods_jmethod_ids = -1;
        static inline std::ptrdiff_t dependencies = -1;
        static inline std::ptrdiff_t osr_nmethods_head = -1;
        static inline std::ptrdiff_t breakpoints = -1;
        static inline std::ptrdiff_t previous_versions = -1;
        static inline std::ptrdiff_t cached_class_file = -1;
        static inline std::ptrdiff_t idnum_allocated = -1;
        static inline std::ptrdiff_t init_state = -1;
        static inline std::ptrdiff_t reference_type = -1;
        static inline std::ptrdiff_t jvmti_field_map = -1;
        static inline std::ptrdiff_t methods = -1;
        static inline std::ptrdiff_t local_interfaces = -1;
        static inline std::ptrdiff_t fields = -1;
        static inline std::ptrdiff_t method_ordering = -1;
        static inline std::ptrdiff_t transitive_interfaces = -1;
        static inline std::ptrdiff_t default_methods = -1;
        static inline std::ptrdiff_t default_vtable_indices = -1;
    };

    struct Method {

        static inline std::ptrdiff_t const_method = -1;
        static inline std::ptrdiff_t method_counters = -1;
        static inline std::ptrdiff_t method_data = -1;
        static inline std::ptrdiff_t access_flags = -1;
        static inline std::ptrdiff_t vtable_index = -1;
        static inline std::ptrdiff_t method_size = -1;
        static inline std::ptrdiff_t intrinsic_id = -1;
        static inline std::ptrdiff_t flags = -1;
        static inline std::ptrdiff_t i2i_entry = -1;
        static inline std::ptrdiff_t adapter = -1;
        static inline std::ptrdiff_t from_compiled_entry = -1;
        static inline std::ptrdiff_t code = -1;
        static inline std::ptrdiff_t from_interpreted_entry = -1;
        static inline std::ptrdiff_t signature_handler = -1;
        static inline std::ptrdiff_t id_owner = -1;
        static inline const std::ptrdiff_t& call_stub_entry_arg = from_interpreted_entry;
        static inline std::ptrdiff_t allocation_size = -1;
    };

    struct MethodIdOwner {
        static inline std::ptrdiff_t method_idnum = -1;
        static inline std::ptrdiff_t original_idnum = -1;
        static inline std::ptrdiff_t name_index = -1;
    };

    struct ConstMethod {

        static inline std::ptrdiff_t max_stack = -1;
        static inline std::ptrdiff_t const_method_size = -1;
        static inline std::ptrdiff_t stackmap_data = -1;
        static inline std::ptrdiff_t fingerprint = -1;
        static inline std::ptrdiff_t size_of_parameters = -1;
        static inline std::ptrdiff_t code_size = -1;
        static inline std::ptrdiff_t method_idnum = -1;
        static inline std::ptrdiff_t max_locals = -1;
        static inline std::ptrdiff_t constants = -1;
        static inline std::ptrdiff_t name_index = -1;
        static inline std::ptrdiff_t flags = -1;
        static inline std::ptrdiff_t result_type = -1;
        static inline std::ptrdiff_t signature_index = -1;
        static inline std::ptrdiff_t bytecode = -1;
    };

    struct ConstantPool {


        static inline std::ptrdiff_t operands = -1;
        static inline std::ptrdiff_t cache = -1;
        static inline std::ptrdiff_t tags = -1;
        static inline std::ptrdiff_t length = -1;
        static inline std::ptrdiff_t reference_map = -1;
        static inline std::ptrdiff_t pool_holder = -1;
        static inline std::ptrdiff_t resolved_references = -1;
        static inline std::ptrdiff_t flags = -1;
        static inline std::ptrdiff_t lock = -1;
        static inline std::ptrdiff_t base = -1;
    };

    struct ConstantPoolCache {
        static inline std::ptrdiff_t length = -1;
        static inline std::ptrdiff_t constant_pool = -1;
        static inline std::ptrdiff_t entries = -1;
    };

    struct ConstantPoolCacheEntry {
        static inline std::ptrdiff_t indices = -1;
        static inline std::ptrdiff_t f1 = -1;
        static inline std::ptrdiff_t f2 = -1;
        static inline std::ptrdiff_t flags = -1;
        static inline std::ptrdiff_t size = -1;
    };

    struct ItableOffsetEntry {
        static inline std::ptrdiff_t interface_klass = -1;
        static inline std::ptrdiff_t offset = -1;
        static inline std::ptrdiff_t size = -1;
    };

    struct OopMapBlock {
        static inline std::ptrdiff_t offset = -1;
        static inline std::ptrdiff_t count = -1;
        static inline std::ptrdiff_t size = -1;
    };

    struct JavaThread {
        static inline std::ptrdiff_t pending_exception = -1;
        static inline std::ptrdiff_t active_handles = -1;
        static inline std::ptrdiff_t stack_base = -1;
        static inline std::ptrdiff_t stack_size = -1;
        static inline std::ptrdiff_t last_java_sp = -1;
        static inline std::ptrdiff_t last_java_pc = -1;
        static inline std::ptrdiff_t last_java_fp = -1;
        static inline std::ptrdiff_t jni_environment = -1;
        static inline std::ptrdiff_t vm_result = -1;
        static inline std::ptrdiff_t thread_state = -1;
    };

    struct Oop {
        static constexpr std::ptrdiff_t mark  = 0x00;


    };

    struct JavaCallWrapper {
        static inline std::ptrdiff_t thread = -1;
        static inline std::ptrdiff_t handles = -1;
        static inline std::ptrdiff_t callee_method = -1;
        static inline std::ptrdiff_t receiver = -1;
        static inline std::ptrdiff_t anchor_sp = -1;
        static inline std::ptrdiff_t anchor_pc = -1;
        static inline std::ptrdiff_t anchor_fp = -1;
        static inline std::ptrdiff_t result = -1;
        static inline std::ptrdiff_t size = -1;
    };

    struct State {
        static constexpr int thread_in_native       = 4;
        static constexpr int thread_in_native_trans = 5;
        static constexpr int thread_in_vm           = 6;
        static constexpr int thread_in_vm_trans     = 7;
        static constexpr int thread_in_java         = 8;
        static constexpr int basic_type_object      = 12;
        static constexpr int basic_type_void        = 14;
        static constexpr int klass_fully_initialized = 4;
        static constexpr int klass_allocated = 0;
        static constexpr int klass_loaded = 1;
        static constexpr int klass_linked = 2;
        static constexpr int klass_being_initialized = 3;
        static constexpr int klass_initialization_error = 5;
        static constexpr int method_type_normal     = 0;
        static constexpr int nonvirtual_vtable_index = -3;
        static constexpr int access_public_static   = 0x0009;
        static constexpr int const_method_has_exception_table = 0x0008;
    };

    enum class Address : std::size_t {
        CLDGraphHead,
        BootstrapCLD,
        EmptyIntArray,
        EmptyShortArray,
        EmptyKlassArray,
        EmptyMethodArray,
        AddClass,
        MetaspaceNonNull,
        ConstMethodAllocate,
        MethodAllocate,
        MethodLink,
        MetadataHandleCopy,
        ConstantPoolAllocate,
        SymbolTableLookup,
        UpdateDictionary,
        SystemDictionary,
        InterpreterEntryTable,
        KlassFieldOffset,
        Count
    };

    struct Signatures {
        static constexpr const char* add_class =
            "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B 59 ? 48 8B F2 48 8B F9 48 85 DB 74 ? 48 8B CB E8 ? ? ? ? 48 8B 47 ?";
        static constexpr const char* metaspace_non_null =
            "48 8B 41 10 48 85 C0 75 ? 48 8B 51 08 48 8B 42 20 48 39 42 40";
        static constexpr const char* const_method_allocate =
            "48 89 5C 24 10 48 89 6C 24 18 57 41 56 41 57 48 83 EC 30 41 8B 40 04";

        static constexpr const char* method_allocate =
            "48 89 5C 24 ? 55 57 41 57 48 83 EC ? 48 8B 7C 24 ? 49 8B C1 44 8B 4C 24 ?";


        static constexpr const char* method_link =
            "48 8B C4 48 89 68 18 48 89 70 20 41 56 48 83 EC 70 48 83 79 60 00";


        static constexpr const char* metadata_handle_copy =
            "40 53 48 83 EC 20 48 8B 02 48 8B D9 48 89 01 48 85 C0 74 ? 48 8B 4A 08 48 85 C9 75 ? E8 ? ? ? ? 84 C0";
        static constexpr const char* constant_pool_allocate =
            "48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 56 48 83 EC ? 48 63 DA 33 FF 8B C7 4C 89 44 24 ? 49 8B E8 4C 8B F1";
        static constexpr const char* symbol_table_lookup =
            "48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 48 63 F2";
        static constexpr const char* update_dictionary =
            "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 48 8B 7C 24 ? 44 8B FA";
        static constexpr const char* system_dictionary_from_update =
            "48 8B 0D ? ? ? ? 4D 8B CE 45 8B C7 48 89 6C 24 20 41 8B D4 E8 ? ? ? ? 48 85 C0";
        static constexpr const char* interpreter_entry_table =
            "48 63 C1 48 8D 0D ? ? ? ? 48 89 14 C1";
        static constexpr const char* oop_klass_field_offset =
            "48 63 05 ? ? ? ? 48 8B 04 08 C3";
    };

    static void Initialize(HMODULE module) {
        s_module = module;
        s_base = reinterpret_cast<std::uintptr_t>(module);
        s_addresses.fill(0);
        s_layoutResolved = false;
        for (const auto& rule : LayoutRules()) *rule.target = -1;
    }


    static bool ResolveCoreLayout() {
        s_layoutResolved = false;
        const auto& rules = LayoutRules();
        if (rules.empty()) {
            Log("[JvmMapper] Empty layout rules; initialization failed");
            return false;
        }
        for (const auto& rule : rules) *rule.target = -1;
        std::vector<std::ptrdiff_t> values;
        bool valid = true;
        for (const auto& rule : rules) {
            std::ptrdiff_t value = -1;
            const auto pattern = ParsePattern(rule.pattern);
            auto match = UniqueExportPattern(rule.exportName, pattern);
            if (match && rule.capture + rule.width <= pattern.size()) {
                value = rule.width == 1 ? static_cast<int8_t>(match[rule.capture])
                    : Displacement32(match + rule.capture);
                value += rule.bias;
            }
            if (!ValidMember(static_cast<int32_t>(value), rule.alignment)) {
                Log("[JvmMapper] UNRESOLVED %s from %s", rule.name, rule.exportName);
                valid = false;
            }
            for (size_t i = 0; i < values.size(); ++i)
                if (rules[i].target == rule.target && values[i] != value) {
                    Log("[JvmMapper] CONFLICT %s: independent accessors disagree", rule.name);
                    valid = false;
                }
            values.push_back(value);
        }
        if (!valid) return false;
        size_t unique = 0;
        for (size_t i = 0; i < rules.size(); ++i) {
            if (*rules[i].target == -1) {
                ++unique;
                Log("[JvmMapper] DERIVED %s = 0x%X", rules[i].name,
                    static_cast<unsigned>(values[i]));
            }
            *rules[i].target = values[i];
        }
        s_layoutResolved = true;
        Log("[JvmMapper] %zu fields resolved from runtime evidence; remaining layout is NOT write-verified",
            unique);
        return true;
    }

    static bool CoreLayoutResolved() { return s_layoutResolved; }

    static bool WriteLayoutVerified() { return false; }

    static bool CanAttemptInjection() {
        if (!CoreLayoutResolved()) return false;
        if (!WriteLayoutVerified() && !kEnableUnverifiedInjectionTest) return false;
        const Address required[] = {
            Address::CLDGraphHead, Address::BootstrapCLD, Address::AddClass,
            Address::ConstMethodAllocate, Address::MethodAllocate,
            Address::MethodLink, Address::MetadataHandleCopy,
            Address::ConstantPoolAllocate, Address::SymbolTableLookup,
            Address::UpdateDictionary, Address::SystemDictionary,
            Address::EmptyIntArray, Address::EmptyShortArray,
            Address::EmptyKlassArray, Address::EmptyMethodArray,
            Address::InterpreterEntryTable
        };
        for (const auto id : required) {
            if (!Has(id)) {
                Log("[JvmMapper] Injection blocked: required address id=%zu unresolved",
                    static_cast<size_t>(id));
                return false;
            }
        }
        return true;
    }

    static void Bind(Address id, std::uintptr_t value) {
        s_addresses[static_cast<std::size_t>(id)] = value;
    }

    static std::uintptr_t Get(Address id) {
        return s_addresses[static_cast<std::size_t>(id)];
    }

    static bool Has(Address id) { return Get(id) != 0; }
    static HMODULE Module() { return s_module; }
    static std::uintptr_t Base() { return s_base; }

private:
    struct LayoutRule {
        std::ptrdiff_t* target;
        const char* name;
        const char* exportName;
        const char* pattern;
        size_t capture;
        size_t width;
        int32_t alignment;
        int32_t bias;
    };
    static const std::vector<LayoutRule>& LayoutRules() {
        static const std::vector<LayoutRule> rules = {
#define JVM_LAYOUT_RULE(group, field, symbol, bytes, capture, width, alignment) \
            { &group::field, #group "." #field, symbol, bytes, capture, width, alignment, 0 },
#define JVM_LAYOUT_RULE_BIAS(group, field, symbol, bytes, capture, width, alignment, bias) \
            { &group::field, #group "." #field, symbol, bytes, capture, width, alignment, bias },
#include "JvmLayoutRules.inc"
#undef JVM_LAYOUT_RULE_BIAS
#undef JVM_LAYOUT_RULE
        };
        return rules;
    }
    static std::vector<int> ParsePattern(const char* p) {
        std::vector<int> result;
        auto hex = [](char c) -> int {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            return -1;
        };
        while (*p) {
            if (*p == ' ') { ++p; continue; }
            if (*p == '?') { result.push_back(-1); ++p; continue; }
            const int a = hex(*p++);
            if (!*p) return {};
            const int b = hex(*p++);
            if (a < 0 || b < 0) return {};
            result.push_back(a * 16 + b);
        }
        return result;
    }
    static bool ValidMember(int32_t value, int32_t alignment) {
        return value >= 0 && value < 0x1000 && value % alignment == 0;
    }
    static int32_t Displacement32(const unsigned char* p) {
        int32_t value;
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    struct CodeRange { DWORD begin; DWORD end; };
    static std::vector<CodeRange> ExportRanges(const char* name) {
        std::vector<CodeRange> ranges;
        const bool internal = name[0] == '@' || name[0] == '>' || name[0] == '!';
        auto entry = internal ? uintptr_t(0) : reinterpret_cast<uintptr_t>(GetProcAddress(s_module, name));
        if (!internal && (!entry || entry < s_base)) return ranges;
        auto dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(s_base);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE) return ranges;
        auto nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(s_base + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return ranges;
        const auto imageSize = nt->OptionalHeader.SizeOfImage;
        auto inside = [imageSize](size_t offset, size_t count) {
            return offset <= imageSize && count <= imageSize - offset;
        };


        if (name[0] == '!') {
            const auto anchor = ParsePattern(name + 1);
            if (anchor.empty()) return ranges;
            DWORD found = 0;
            DWORD foundSectionEnd = 0;
            const auto sections = IMAGE_FIRST_SECTION(nt);
            for (WORD sectionIndex = 0; sectionIndex < nt->FileHeader.NumberOfSections; ++sectionIndex) {
                const auto& section = sections[sectionIndex];
                if (!(section.Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
                const size_t begin = section.VirtualAddress;
                const size_t span = section.Misc.VirtualSize;
                if (!inside(begin, span) || anchor.size() > span) continue;
                const auto bytes = reinterpret_cast<const unsigned char*>(s_base + begin);
                for (size_t offset = 0; offset + anchor.size() <= span; ++offset) {
                    bool equal = true;
                    for (size_t j = 0; j < anchor.size(); ++j)
                        if (anchor[j] >= 0 && bytes[offset + j] != anchor[j]) {
                            equal = false;
                            break;
                        }
                    if (!equal) continue;
                    if (found) {
                        Log("[JvmMapper] Ambiguous internal leaf anchor");
                        return {};
                    }
                    found = static_cast<DWORD>(begin + offset);
                    foundSectionEnd = static_cast<DWORD>(begin + span);
                }
            }
            if (!found) return ranges;
            for (size_t decoded = 0; decoded < 0x800 && found + decoded < foundSectionEnd;) {
                const size_t available = foundSectionEnd - (found + decoded);
                unsigned char padded[16]{};
                const size_t copy = available < sizeof(padded) ? available : sizeof(padded);
                std::memcpy(padded, reinterpret_cast<const void*>(s_base + found + decoded), copy);
                hde64s instruction{};
                const auto length = hde64_disasm(padded, &instruction);
                if (!length || (instruction.flags & F_ERROR) || length > available) return {};
                decoded += length;
                if (instruction.opcode == 0xC3 || instruction.opcode == 0xC2)
                    return {{found, static_cast<DWORD>(found + decoded)}};
            }
            return {};
        }
        const auto directory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
        if (!inside(directory.VirtualAddress, directory.Size) ||
            directory.Size % sizeof(RUNTIME_FUNCTION)) return ranges;
        auto table = reinterpret_cast<const RUNTIME_FUNCTION*>(s_base + directory.VirtualAddress);
        const size_t count = directory.Size / sizeof(RUNTIME_FUNCTION);


        if (internal) {
            const auto anchor = ParsePattern(name + 1);
            if (anchor.empty()) return ranges;
            for (size_t i = 0; i < count; ++i) {
                const auto& fn = table[i];
                if (fn.EndAddress <= fn.BeginAddress ||
                    anchor.size() > fn.EndAddress - fn.BeginAddress ||
                    !inside(fn.BeginAddress, anchor.size())) continue;
                auto bytes = reinterpret_cast<const unsigned char*>(s_base + fn.BeginAddress);
                bool equal = true;
                for (size_t j = 0; j < anchor.size(); ++j)
                    if (anchor[j] >= 0 && bytes[j] != anchor[j]) { equal = false; break; }
                if (!equal) continue;
                if (entry) { Log("[JvmMapper] Ambiguous internal function anchor"); return {}; }
                entry = s_base + fn.BeginAddress;
            }
            if (!entry) return ranges;


            if (name[0] == '>') {
                if (anchor.size() < 5 || anchor[anchor.size()-5] != 0xE8) return {};
                auto call = reinterpret_cast<const unsigned char*>(entry + anchor.size() - 5);
                const auto target = entry + anchor.size() + static_cast<intptr_t>(Displacement32(call + 1));
                if (target < s_base || target - s_base >= imageSize) return {};
                const size_t begin = target - s_base;
                auto section = IMAGE_FIRST_SECTION(nt);
                bool executable = false;
                for (WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i)
                    if ((section[i].Characteristics & IMAGE_SCN_MEM_EXECUTE) &&
                        begin >= section[i].VirtualAddress &&
                        begin - section[i].VirtualAddress < section[i].Misc.VirtualSize)
                        executable = true;
                if (!executable) return {};
                for (size_t n = 0; n < 512;) {
                    if (!inside(begin + n, 16)) return {};
                    hde64s instruction{};
                    const auto length = hde64_disasm(reinterpret_cast<const void*>(target + n), &instruction);
                    if (!length || (instruction.flags & F_ERROR)) return {};
                    const auto op = instruction.opcode;
                    if (op == 0xC3) return {{static_cast<DWORD>(begin), static_cast<DWORD>(begin+n+length)}};
                    if (op != 0x89 && op != 0x8B && op != 0x8D && op != 0x33 && op != 0xC7) return {};
                    n += length;
                }
                return {};
            }
        }
        for (size_t i = 0; i < count; ++i) {
            RUNTIME_FUNCTION root = table[i];
            bool valid = false;
            for (unsigned depth = 0; depth < 32; ++depth) {
                if (!inside(root.UnwindData, 4)) break;
                auto unwind = reinterpret_cast<const unsigned char*>(s_base + root.UnwindData);
                const unsigned version = unwind[0] & 7;
                if (version != 1 && version != 2) break;
                if (!(unwind[0] & (UNW_FLAG_CHAININFO << 3))) { valid = true; break; }
                const size_t chain = root.UnwindData + 4 + ((size_t(unwind[2]) + 1) & ~size_t(1)) * 2;
                if (!inside(chain, sizeof(root))) break;
                std::memcpy(&root, reinterpret_cast<const void*>(s_base + chain), sizeof(root));
            }


            if (!valid || (s_base + root.BeginAddress != entry &&
                !(internal && s_base + table[i].BeginAddress == entry))) continue;
            const auto& fn = table[i];
            if (fn.EndAddress <= fn.BeginAddress ||
                !inside(fn.BeginAddress, fn.EndAddress - fn.BeginAddress)) return {};
            if (!ranges.empty() && ranges.back().end == fn.BeginAddress)
                ranges.back().end = fn.EndAddress;
            else ranges.push_back({fn.BeginAddress, fn.EndAddress});
        }
        size_t total = 0;
        for (const auto& range : ranges) total += range.end - range.begin;
        if (total > 0x10000) return {};
        return ranges;
    }
    static const unsigned char* UniqueExportPattern(const char* name, const std::vector<int>& pattern) {
        if (pattern.empty() || !s_module) return nullptr;
        const auto ranges = ExportRanges(name);
        if (ranges.empty()) {
            Log("[JvmMapper] Missing/unsupported export bounds: %s", name);
            return nullptr;
        }
        const unsigned char* match = nullptr;
        for (const auto& range : ranges) {
            auto start = reinterpret_cast<const unsigned char*>(s_base + range.begin);
            const size_t size = range.end - range.begin;


            if (name[0] == '@' || name[0] == '!') {
                for (size_t i = 0; i + pattern.size() <= size; ++i) {
                    bool equal = true;
                    for (size_t j = 0; j < pattern.size(); ++j)
                        if (pattern[j] >= 0 && start[i+j] != pattern[j]) {
                            equal = false;
                            break;
                        }
                    if (!equal) continue;
                    if (match) {
                        Log("[JvmMapper] Ambiguous layout signature: %s", name);
                        return nullptr;
                    }
                    match = start + i;
                }
                continue;
            }


            for (size_t i = 0; i + pattern.size() <= size;) {
                unsigned char padded[16]{};
                const size_t remaining = size - i;
                std::memcpy(padded, start + i, remaining < sizeof(padded) ? remaining : sizeof(padded));
                hde64s instruction{};
                const auto length = hde64_disasm(padded, &instruction);
                if (!length || (instruction.flags & F_ERROR) || length > remaining) {
                    Log("[JvmMapper] Unsupported instruction in %s", name);
                    return nullptr;
                }
                const size_t candidate = i;
                i += length;
                bool equal = true;
                for (size_t j = 0; j < pattern.size(); ++j)
                    if (pattern[j] >= 0 && start[candidate+j] != pattern[j]) { equal = false; break; }
                if (!equal) continue;
                if (match) {
                    Log("[JvmMapper] Ambiguous layout signature: %s", name);
                    return nullptr;
                }
                match = start + candidate;
            }
        }
        Log("[JvmMapper] %s layout evidence: %s", name, match ? "unique" : "missing");
        return match;
    }
    static inline bool s_layoutResolved = false;
    static inline HMODULE s_module = nullptr;
    static inline std::uintptr_t s_base = 0;
    static inline std::array<std::uintptr_t,
        static_cast<std::size_t>(Address::Count)> s_addresses{};
};
