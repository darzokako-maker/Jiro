#pragma once
#include <Windows.h>
#include <vector>
#include <string>

class PatternScanner {
public:
    static uintptr_t FindPattern(HMODULE hMod, const char* signature) {
        if (!hMod) return 0;

        auto dosHeader = reinterpret_cast<PIMAGE_DOS_HEADER>(hMod);
        auto ntHeaders = reinterpret_cast<PIMAGE_NT_HEADERS>(reinterpret_cast<uint8_t*>(hMod) + dosHeader->e_lfanew);
        
        auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
        auto scanBytes = reinterpret_cast<uint8_t*>(hMod);
        
        std::vector<int> patternBytes;
        auto* current = signature;
        while (*current) {
            if (*current == '?') {
                patternBytes.push_back(-1);
                ++current;
            } else if (*current == ' ') {
                ++current;
            } else {
                patternBytes.push_back(strtol(current, const_cast<char**>(&current), 16));
            }
        }
        
        auto s = patternBytes.size();
        auto d = patternBytes.data();
        
        for (auto i = 0ul; i < sizeOfImage - s; ++i) {
            bool found = true;
            for (auto j = 0ul; j < s; ++j) {
                if (scanBytes[i + j] != d[j] && d[j] != -1) {
                    found = false;
                    break;
                }
            }
            if (found) {
                return reinterpret_cast<uintptr_t>(&scanBytes[i]);
            }
        }
        
        return 0;
    }
};
