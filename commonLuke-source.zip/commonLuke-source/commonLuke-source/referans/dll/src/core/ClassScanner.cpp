

#include "ClassScanner.hpp"


static bool TryRead8(uintptr_t addr, uint8_t* out)
{
    __try { *out = *reinterpret_cast<const uint8_t*>(addr); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

static bool TryRead16(uintptr_t addr, uint16_t* out)
{
    __try { *out = *reinterpret_cast<const uint16_t*>(addr); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

static bool TryRead32(uintptr_t addr, uint32_t* out)
{
    __try { *out = *reinterpret_cast<const uint32_t*>(addr); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

static bool TryRead64(uintptr_t addr, uintptr_t* out)
{
    __try { *out = *reinterpret_cast<const uintptr_t*>(addr); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

static bool TryReadBuf(uintptr_t addr, void* out, size_t size)
{
    __try { memcpy(out, reinterpret_cast<const void*>(addr), size); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}


std::string ReadSymbol(uintptr_t symPtr)
{
    if (!symPtr) return {};

    uint16_t len = 0;
    if (!TryRead16(symPtr + Offsets::Sym_length, &len)) return {};
    if (len == 0 || len > 2048) return {};

    std::string buf(len, '\0');
    if (!TryReadBuf(symPtr + Offsets::Sym_body, &buf[0], len)) return {};
    return buf;
}


std::string ReadCpSymbol(uintptr_t cp, uint16_t idx)
{
    if (!cp || idx == 0) return {};

    uintptr_t slotAddr = cp + Offsets::CP_base + sizeof(uintptr_t) * idx;
    uintptr_t raw = 0;
    if (!TryRead64(slotAddr, &raw)) return {};
    if (!raw) return {};


    uintptr_t symPtr = raw & ~uintptr_t(1);
    if (!symPtr) return {};

    return ReadSymbol(symPtr);
}


std::vector<MethodInfo> ReadMethods(uintptr_t klassPtr)
{
    std::vector<MethodInfo> result;


    uintptr_t arrPtr = 0;
    if (!TryRead64(klassPtr + Offsets::IK_methods, &arrPtr) || !arrPtr) return result;


    uint32_t count = 0;
    if (!TryRead32(arrPtr + Offsets::Arr_length, &count)) return result;
    if (count == 0 || count > 65536) return result;

    result.reserve(count);


    for (uint32_t i = 0; i < count; ++i)
    {
        uintptr_t methodPtr = 0;
        if (!TryRead64(arrPtr + Offsets::Arr_data + sizeof(uintptr_t) * i, &methodPtr) || !methodPtr)
            continue;


        uintptr_t cmPtr = 0;
        if (!TryRead64(methodPtr + Offsets::M_constMethod, &cmPtr) || !cmPtr)
            continue;


        uintptr_t cp = 0;
        if (!TryRead64(cmPtr + Offsets::CM_constants, &cp) || !cp)
            continue;


        uint16_t nameIdx = 0, sigIdx = 0;
        if (!TryRead16(cmPtr + Offsets::CM_name_index, &nameIdx)) continue;
        if (!TryRead16(cmPtr + Offsets::CM_sig_index,  &sigIdx))  continue;

        auto name = ReadCpSymbol(cp, nameIdx);
        auto sig  = ReadCpSymbol(cp, sigIdx);
        if (name.empty()) continue;


        uint32_t aflags = 0;
        TryRead32(methodPtr + Offsets::M_access_flags, &aflags);


        result.push_back({ std::move(name), std::move(sig), methodPtr, aflags });
    }

    return result;
}


std::vector<FieldInfo> ReadFields(uintptr_t klassPtr)
{
    std::vector<FieldInfo> result;


    uintptr_t cp = 0;
    if (!TryRead64(klassPtr + Offsets::IK_constants, &cp) || !cp) return result;


    uintptr_t fieldsArr = 0;
    if (!TryRead64(klassPtr + Offsets::IK_fields, &fieldsArr) || !fieldsArr) return result;


    uint32_t u2count = 0;
    if (!TryRead32(fieldsArr + Offsets::Arr_length, &u2count)) return result;
    if (u2count > 65536) return result;

    uint16_t numFields = 0;
    if (!TryRead16(
            klassPtr + JvmMapper::InstanceKlass::java_fields_count,
            &numFields)) {
        return result;
    }

    if (u2count <
        static_cast<uint32_t>(numFields)
        * JvmMapper::FieldInfo::entry_words) {
        return result;
    }
    result.reserve(numFields);


    const uintptr_t base =
        fieldsArr + JvmMapper::CompactU2Array::data;

    for (uint32_t i = 0; i < numFields; ++i)
    {
        const uintptr_t fp = base
            + sizeof(uint16_t) * JvmMapper::FieldInfo::entry_words * i;

        uint16_t access = 0, nameIdx = 0, sigIdx = 0, low = 0, high = 0;
        if (!TryRead16(fp + sizeof(uint16_t) * JvmMapper::FieldInfo::access_flags_word,
                       &access)) continue;
        if (!TryRead16(fp + sizeof(uint16_t) * JvmMapper::FieldInfo::name_index_word,
                       &nameIdx)) continue;
        if (!TryRead16(fp + sizeof(uint16_t) * JvmMapper::FieldInfo::signature_index_word,
                       &sigIdx)) continue;
        if (!TryRead16(fp + sizeof(uint16_t) * JvmMapper::FieldInfo::low_offset_word,
                       &low)) continue;
        if (!TryRead16(fp + sizeof(uint16_t) * JvmMapper::FieldInfo::high_offset_word,
                       &high)) continue;


        if (nameIdx == 0) continue;

        auto name = ReadCpSymbol(cp, nameIdx);
        auto sig  = ReadCpSymbol(cp, sigIdx);
        if (name.empty()) continue;


        const uint32_t raw_off = (uint32_t(high) << 16) | uint32_t(low);
        const uint32_t offset  = raw_off >> JvmMapper::FieldInfo::offset_tag_bits;

        result.push_back({ std::move(name), std::move(sig), offset, access });
    }

    return result;
}
