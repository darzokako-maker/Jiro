#pragma once


#include <Windows.h>
#include <cstdint>
#include <string>
#include <vector>
#include <functional>
#include "Logging.hpp"
#include "ClassScanner.hpp"
#include "PatternScanner.hpp"


namespace JvmOffsets {


    static inline const std::ptrdiff_t& kCLD_klasses = JvmMapper::ClassLoaderData::klasses;
    static inline const std::ptrdiff_t& kCLD_next = JvmMapper::ClassLoaderData::next;


    static inline const std::ptrdiff_t& kKlass_layout_helper = JvmMapper::Klass::layout_helper;
    static inline const std::ptrdiff_t& kKlass_name = JvmMapper::Klass::name;
    static inline const std::ptrdiff_t& kKlass_next_link = JvmMapper::Klass::next_link;
}


class JvmApi {
public:
    struct FixedBindings {
        uintptr_t cldGraphHead, bootstrapCld;
        uintptr_t constMethodAllocate, methodAllocate, methodLink, metadataHandleCopy;
        uintptr_t constantPoolAllocate, symbolLookup, updateDictionary, dictionary;
        uintptr_t restoreMirror, createMirror, klassOopStore;
    };

    // The caller binds audited layout members separately. No runtime scans.
    static void BindFixed(HMODULE module, const FixedBindings& f) {
        s_hJvm = module; s_jvmBase = reinterpret_cast<uintptr_t>(module);
        s_cldGraphHeadAddr = f.cldGraphHead; s_bootstrapCLDPtrAddr = f.bootstrapCld;
        s_constMethodAllocAddr = f.constMethodAllocate; s_methodAllocAddr = f.methodAllocate;
        s_methodLinkAddr = f.methodLink; s_metadataHandleCopyAddr = f.metadataHandleCopy;
        s_constantPoolAllocAddr = f.constantPoolAllocate; s_symbolAllocAddr = f.symbolLookup;
        s_updateDictionaryAddr = f.updateDictionary; s_systemDictionaryAddr = f.dictionary;
        s_restoreKlassMirrorAddr = f.restoreMirror; s_createMirrorAddr = f.createMirror;
        s_klassOopStoreAddr = f.klassOopStore;
        s_initialized = true;
        BindMapperAddresses();
    }


    static bool Initialize(HMODULE hJvm)
    {
        if (s_initialized) return true;
        if (!hJvm) return false;

        s_hJvm    = hJvm;
        s_jvmBase = reinterpret_cast<uintptr_t>(hJvm);
        JvmMapper::Initialize(hJvm);
        if (!JvmMapper::ResolveCoreLayout()) {
            Log("[JvmApi] Core layout resolution failed; initialization stopped");
            return false;
        }


        s_cldGraphHeadAddr = FindCLDGraphHead(hJvm);
        if (s_cldGraphHeadAddr)
            Log("[JvmApi] ClassLoaderDataGraph::_head @ %p (RVA 0x%llX)",
                (void*)s_cldGraphHeadAddr, s_cldGraphHeadAddr - s_jvmBase);
        else
            Log("[JvmApi] WARNING: _head not found — GetLoadedClasses will return empty");


        ResolveBootstrapCLD(hJvm);


        ResolveEmptyArrays(hJvm);


        ResolveFunctions(hJvm);
        ResolveMirrorFunctions(hJvm);

        ResolveSystemDictionary(hJvm);

        ResolveKlassFieldOffset(hJvm);


        ResolveInterpreterEntry(hJvm);

        BindMapperAddresses();

        s_initialized = true;
        return true;
    }


    static std::vector<ClassInfo> GetLoadedClasses(bool withDetails = false)
    {
        std::vector<ClassInfo> result;
        if (!s_cldGraphHeadAddr) return result;

        result.reserve(8192);

        uintptr_t cld      = SafeRead<uintptr_t>(s_cldGraphHeadAddr);
        int       cldCount = 0;

        while (cld) {
            if (++cldCount > 32768) break;

            uintptr_t klass      = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_klasses);
            int       klassCount = 0;

            while (klass) {
                if (++klassCount > 131072) break;

                uintptr_t symPtr = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_name);
                if (symPtr) {
                    auto name = ::ReadSymbol(symPtr);
                    if (!name.empty()) {
                        result.push_back({ std::move(name), klass, {}, {} });
                    }
                }

                klass = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_next_link);
            }

            cld = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_next);
        }

        Log("[JvmApi] GetLoadedClasses: %zu classes", result.size());
        return result;
    }


    static uintptr_t FindClass(const std::string& internalName)
    {
        return WalkCLD([&](uintptr_t klass) -> bool {
            uintptr_t symPtr = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_name);
            if (!symPtr) return false;
            return ::ReadSymbol(symPtr) == internalName;
        });
    }


    using ClassCallback = std::function<bool(uintptr_t)>;
    static void ForEachClass(ClassCallback cb)
    {
        WalkCLD([&](uintptr_t klass) -> bool { return cb(klass); });
    }


    static std::string GetClassName(uintptr_t klassPtr)
    {
        uintptr_t symPtr = SafeRead<uintptr_t>(klassPtr + JvmOffsets::kKlass_name);
        return ::ReadSymbol(symPtr);
    }


    static std::vector<MethodInfo> GetMethods(uintptr_t klassPtr)
    {
        return ::ReadMethods(klassPtr);
    }


    static std::vector<FieldInfo> GetFields(uintptr_t klassPtr)
    {
        return ::ReadFields(klassPtr);
    }


    static uintptr_t FindMethod(const std::string& className,
                                const std::string& methodName,
                                const std::string& signature = "")
    {
        uintptr_t klass = FindClass(className);
        if (!klass) return 0;

        uintptr_t firstNameMatch = 0;

        for (auto& m : ::ReadMethods(klass)) {
            if (m.name != methodName) continue;

            if (signature.empty()) {
                return m.method_ptr;
            }

            if (m.signature == signature) {
                return m.method_ptr;
            }

            if (m.signature.empty() && firstNameMatch == 0) {
                firstNameMatch = m.method_ptr;
            }
        }

        if (firstNameMatch) {
            Log("[JvmApi] FindMethod: sig match failed for '%s::%s %s', using name-only fallback",
                className.c_str(), methodName.c_str(), signature.c_str());
        }
        return firstNameMatch;
    }


    static std::vector<std::pair<std::string, uintptr_t>>
    FindMethodAllOverloads(const std::string& className, const std::string& methodName)
    {
        std::vector<std::pair<std::string, uintptr_t>> result;
        uintptr_t klass = FindClass(className);
        if (!klass) return result;
        for (auto& m : ::ReadMethods(klass)) {
            if (m.name == methodName)
                result.push_back({ m.signature, m.method_ptr });
        }
        return result;
    }


    static FieldInfo FindField(const std::string& className,
                               const std::string& fieldName)
    {
        uintptr_t klass = FindClass(className);
        if (!klass) return {};
        for (auto& f : ::ReadFields(klass))
            if (f.name == fieldName) return f;
        return {};
    }


    static bool IsInstanceKlass(uintptr_t klassPtr)
    {
        return SafeRead<int>(klassPtr + JvmOffsets::kKlass_layout_helper) > 0;
    }


    static void DumpToFile(const char* path, bool withDetails = false)
    {
        FILE* f = nullptr;
        if (fopen_s(&f, path, "w") != 0 || !f) {
            Log("[JvmApi] DumpToFile: cannot open %s", path);
            return;
        }

        size_t count = 0;
        uintptr_t cld      = SafeRead<uintptr_t>(s_cldGraphHeadAddr);
        int       cldCount = 0;

        while (cld) {
            if (++cldCount > 32768) break;

            uintptr_t klass      = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_klasses);
            int       klassCount = 0;

            while (klass) {
                if (++klassCount > 131072) break;

                uintptr_t symPtr = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_name);
                if (symPtr) {
                    auto name = ::ReadSymbol(symPtr);
                    if (!name.empty()) {
                        fprintf(f, "[CLASS] %s  klass=%p\n", name.c_str(), (void*)klass);
                        ++count;

                        if (withDetails) {
                            for (auto& m : ::ReadMethods(klass))
                                fprintf(f, "  [METHOD] %s %s  flags=0x%04X  ptr=%p\n",
                                    m.name.c_str(), m.signature.c_str(),
                                    m.access_flags, (void*)m.method_ptr);
                            for (auto& field : ::ReadFields(klass))
                                fprintf(f, "  [FIELD]  %s %s  offset=+0x%X  flags=0x%04X\n",
                                    field.signature.c_str(), field.name.c_str(),
                                    field.offset, field.access_flags);
                        }
                    }
                }

                klass = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_next_link);
            }

            cld = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_next);
        }

        fclose(f);
        Log("[JvmApi] Dumped %zu classes to %s", count, path);
    }


    static bool      IsInitialized()        { return s_initialized; }
    static bool      HasCLDGraph()          { return s_cldGraphHeadAddr != 0; }
    static HMODULE   GetHJvm()              { return s_hJvm; }
    static uintptr_t GetJvmBase()           { return s_jvmBase; }
    static uintptr_t CLDGraphHeadAddr()     { return s_cldGraphHeadAddr; }


    static uintptr_t EmptyKlassArray()      { return s_emptyKlassArray; }
    static uintptr_t EmptyMethodArray()     { return s_emptyMethodArray; }
    static uintptr_t EmptyIntArray()        { return s_emptyIntArray; }
    static uintptr_t EmptyShortArray()      { return s_emptyShortArray; }


    static uintptr_t AddClassAddr()         { return s_addClassAddr; }
    static uintptr_t MetaspaceNonNullAddr() { return s_metaspaceNonNullAddr; }
    static uintptr_t ConstMethodAllocAddr()  { return s_constMethodAllocAddr; }
    static uintptr_t MethodAllocAddr()       { return s_methodAllocAddr; }
    static uintptr_t MethodLinkAddr()        { return s_methodLinkAddr; }
    static uintptr_t MetadataHandleCopyAddr(){ return s_metadataHandleCopyAddr; }
    static uintptr_t ConstantPoolAllocAddr() { return s_constantPoolAllocAddr; }
    static uintptr_t SymbolTableLookupAddr() { return s_symbolAllocAddr; }
    static uintptr_t SymbolAllocAddr()       { return s_symbolAllocAddr; }
    static uintptr_t UpdateDictionaryAddr()  { return s_updateDictionaryAddr; }
    static uintptr_t SystemDictionaryAddr()  { return s_systemDictionaryAddr; }
    static uintptr_t KlassFieldOffsetAddr()  { return s_klassFieldOffsetAddr; }
    static uintptr_t RestoreKlassMirrorAddr(){ return s_restoreKlassMirrorAddr; }
    static uintptr_t CreateMirrorAddr()      { return s_createMirrorAddr; }
    static uintptr_t KlassOopStoreAddr()     { return s_klassOopStoreAddr; }


    static uintptr_t BootstrapCLDPtrAddr()  { return s_bootstrapCLDPtrAddr; }


    static uintptr_t InterpreterEntryZeroLocals() {
        if (!s_interpreterEntryTable) return 0;
        return SafeRead<uintptr_t>(s_interpreterEntryTable);
    }


    template<typename T>
    static T SafeRead(uintptr_t addr)
    {
        T val{};
        __try { val = *reinterpret_cast<const T*>(addr); }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return val;
    }

private:
    static void BindMapperAddresses()
    {
        JvmMapper::Bind(JvmMapper::Address::CLDGraphHead,          s_cldGraphHeadAddr);
        JvmMapper::Bind(JvmMapper::Address::BootstrapCLD,          s_bootstrapCLDPtrAddr);
        JvmMapper::Bind(JvmMapper::Address::EmptyIntArray,         s_emptyIntArray);
        JvmMapper::Bind(JvmMapper::Address::EmptyShortArray,       s_emptyShortArray);
        JvmMapper::Bind(JvmMapper::Address::EmptyKlassArray,       s_emptyKlassArray);
        JvmMapper::Bind(JvmMapper::Address::EmptyMethodArray,      s_emptyMethodArray);
        JvmMapper::Bind(JvmMapper::Address::AddClass,              s_addClassAddr);
        JvmMapper::Bind(JvmMapper::Address::MetaspaceNonNull,      s_metaspaceNonNullAddr);
        JvmMapper::Bind(JvmMapper::Address::ConstMethodAllocate,   s_constMethodAllocAddr);
        JvmMapper::Bind(JvmMapper::Address::MethodAllocate,        s_methodAllocAddr);
        JvmMapper::Bind(JvmMapper::Address::MethodLink,            s_methodLinkAddr);
        JvmMapper::Bind(JvmMapper::Address::MetadataHandleCopy,    s_metadataHandleCopyAddr);
        JvmMapper::Bind(JvmMapper::Address::ConstantPoolAllocate,  s_constantPoolAllocAddr);
        JvmMapper::Bind(JvmMapper::Address::SymbolTableLookup,     s_symbolAllocAddr);
        JvmMapper::Bind(JvmMapper::Address::UpdateDictionary,      s_updateDictionaryAddr);
        JvmMapper::Bind(JvmMapper::Address::SystemDictionary,      s_systemDictionaryAddr);
        JvmMapper::Bind(JvmMapper::Address::KlassFieldOffset,      s_klassFieldOffsetAddr);
        JvmMapper::Bind(JvmMapper::Address::InterpreterEntryTable, s_interpreterEntryTable);
    }

    static bool      s_initialized;
    static HMODULE   s_hJvm;
    static uintptr_t s_jvmBase;
    static uintptr_t s_cldGraphHeadAddr;


    static uintptr_t s_emptyKlassArray;
    static uintptr_t s_emptyMethodArray;
    static uintptr_t s_emptyIntArray;
    static uintptr_t s_emptyShortArray;


    static uintptr_t s_addClassAddr;
    static uintptr_t s_metaspaceNonNullAddr;
    static uintptr_t s_constMethodAllocAddr;
    static uintptr_t s_methodAllocAddr;
    static uintptr_t s_methodLinkAddr;
    static uintptr_t s_metadataHandleCopyAddr;
    static uintptr_t s_constantPoolAllocAddr;
    static uintptr_t s_symbolAllocAddr;
    static uintptr_t s_updateDictionaryAddr;
    static uintptr_t s_systemDictionaryAddr;
    static uintptr_t s_klassFieldOffsetAddr;
    static uintptr_t s_restoreKlassMirrorAddr;
    static uintptr_t s_createMirrorAddr;
    static uintptr_t s_klassOopStoreAddr;


    static uintptr_t s_bootstrapCLDPtrAddr;
    static uintptr_t s_bootstrapCLDValue;


    static uintptr_t s_interpreterEntryTable;


    static uintptr_t DecodeRipRel(uintptr_t disp_addr, int insn_len = 7)
    {
        int32_t disp = *reinterpret_cast<const int32_t*>(disp_addr);


        uintptr_t insn_start = disp_addr - (insn_len - 4);
        return (insn_start + insn_len) + disp;
    }

    static bool CheckAddr(uintptr_t addr, uintptr_t base, uintptr_t imgEnd)
    {
        return addr > base && addr < imgEnd;
    }

    static uintptr_t GetImageEnd(HMODULE hJvm)
    {
        auto base    = reinterpret_cast<uintptr_t>(hJvm);
        auto* dosHdr = reinterpret_cast<PIMAGE_DOS_HEADER>(hJvm);
        auto* ntHdr  = reinterpret_cast<PIMAGE_NT_HEADERS>(base + dosHdr->e_lfanew);
        return base + ntHdr->OptionalHeader.SizeOfImage;
    }


    using KlassPredicate = std::function<bool(uintptr_t)>;
    static uintptr_t WalkCLD(KlassPredicate pred)
    {
        if (!s_cldGraphHeadAddr) return 0;

        uintptr_t cld      = SafeRead<uintptr_t>(s_cldGraphHeadAddr);
        int       cldCount = 0;

        while (cld) {
            if (++cldCount > 32768) break;

            uintptr_t klass      = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_klasses);
            int       klassCount = 0;

            while (klass) {
                if (++klassCount > 131072) break;


                if (pred(klass)) return klass;
                klass = SafeRead<uintptr_t>(klass + JvmOffsets::kKlass_next_link);
            }

            cld = SafeRead<uintptr_t>(cld + JvmOffsets::kCLD_next);
        }

        return 0;
    }


    static uintptr_t FindCLDGraphHead(HMODULE hJvm)
    {
        const uintptr_t base   = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t imgEnd = GetImageEnd(hJvm);

        auto check = [&](uintptr_t addr) -> bool {
            return CheckAddr(addr, base, imgEnd);
        };


        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 8B 05 ? ? ? ? 45 32 F6 48 89 74 24 38 33 F6 48 89 7C 24 30 ? ? 48 8B 3D ? ? ? ?");
            if (m) {
                uintptr_t addr = DecodeRipRel(m + 26);
                if (check(addr)) {
                    Log("[JvmApi] CLD head found via pattern1 (do_unloading) @ RVA 0x%llX", addr - base);
                    return addr;
                }
            }
        }


        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 8B 1D ? ? ? ? 48 8D 15 ? ? ? ?");
            if (m) {
                uintptr_t addr = DecodeRipRel(m + 3);
                if (check(addr)) {
                    Log("[JvmApi] CLD head found via pattern2 (CLD ctor CAS) @ RVA 0x%llX", addr - base);
                    return addr;
                }
            }
        }


        {
            uintptr_t m = PatternScanner::FindPattern(hJvm, "48 8B 3D ? ? ? ? 48 85 FF 74");
            if (m) {
                uintptr_t addr = DecodeRipRel(m + 3);
                if (check(addr)) {
                    Log("[JvmApi] CLD head found via pattern3 (classes_do) @ RVA 0x%llX", addr - base);
                    return addr;
                }
            }
        }


        {
            uintptr_t m = PatternScanner::FindPattern(hJvm, "48 8B 0D ? ? ? ? 48 85 C9 74");
            if (m) {
                uintptr_t addr = DecodeRipRel(m + 3);
                if (check(addr)) {
                    Log("[JvmApi] CLD head found via pattern4 (rcx variant) @ RVA 0x%llX", addr - base);
                    return addr;
                }
            }
        }

        Log("[JvmApi] CLD head not found");
        return 0;
    }


    static void ResolveEmptyArrays(HMODULE hJvm)
    {
        const uintptr_t base   = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t imgEnd = GetImageEnd(hJvm);


        const uintptr_t initializer = PatternScanner::FindPattern(hJvm,
            "B9 10 00 00 00 E8 ? ? ? ? 48 C7 C7 FF FF FF FF 48 85 C0 74 ? "
            "48 89 18 89 78 08 EB ? 48 8B C3 B9 10 00 00 00 48 89 05 ? ? ? ?");
        const uintptr_t terminal = PatternScanner::FindPattern(hJvm,
            "80 3D ? ? ? ? 00 48 89 74 24 ? 48 89 05 ? ? ? ?");
        if (initializer && terminal >= initializer && terminal - initializer < 0x1000) {
            const uintptr_t scanEnd = terminal + 19;
            uintptr_t globals[4]{};
            size_t count = 0;
            for (uintptr_t addr = initializer; addr + 7 <= scanEnd; ++addr) {
                const auto* p = reinterpret_cast<const uint8_t*>(addr);
                if (p[0] != 0x48 || p[1] != 0x89 || p[2] != 0x05) continue;
                const uintptr_t global = DecodeRipRel(addr + 3, 7);
                if (CheckAddr(global, base, imgEnd) && count < 4)
                    globals[count++] = global;
            }
            if (count == 4) {
                s_emptyIntArray = globals[0];
                s_emptyShortArray = globals[1];
                s_emptyKlassArray = globals[2];
                s_emptyMethodArray = globals[3];
            }
        }

        if (s_emptyIntArray && s_emptyShortArray &&
            s_emptyKlassArray && s_emptyMethodArray) {
            Log("[JvmApi] Empty arrays (resolved from allocation sequence):");
            Log("[JvmApi]   int_array   @ %p (RVA 0x%llX)", (void*)s_emptyIntArray,    s_emptyIntArray - base);
            Log("[JvmApi]   short_array @ %p (RVA 0x%llX)", (void*)s_emptyShortArray,  s_emptyShortArray - base);
            Log("[JvmApi]   klass_array @ %p (RVA 0x%llX)", (void*)s_emptyKlassArray,  s_emptyKlassArray - base);
            Log("[JvmApi]   method_array@ %p (RVA 0x%llX)", (void*)s_emptyMethodArray, s_emptyMethodArray - base);
        } else {
            Log("[JvmApi] WARNING: empty-array allocation sequence incomplete");
        }
    }


    static void ResolveFunctions(HMODULE hJvm)
    {
        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 48 8B 59 18 48 8B F2 48 8B F9 48 85 DB 74 ? 48 8B CB E8 ? ? ? ? 48 8B 47 28 48 8B CB 48 89 86 88 00 00 00 48 89 77 28");
            if (m) {
                s_addClassAddr = m;
                Log("[JvmApi] add_class @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: add_class not found");
            }
        }

        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 8B 41 10 48 85 C0 75 ? 48 8B 51 08 48 8B 42 20 48 39 42 40 77 ? 48 3B 42 58 73 ? 48 8B 00 C3");
            if (m) {
                s_metaspaceNonNullAddr = m;
                Log("[JvmApi] metaspace_non_null @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: metaspace_non_null not found");
            }
        }

        {

            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 41 8B 40 04");
            if (!m) {
                m = PatternScanner::FindPattern(hJvm,
                    "48 89 74 24 18 48 89 7C 24 20 41 54 41 56 41 57 48 83 EC 30 41 8B 40 04 45 8B ? 85 C0 49 8B");
            }
            if (!m) {

                m = PatternScanner::FindPattern(hJvm,
                    "48 89 5C 24 10 48 89 6C 24 18 56 41 56 41 57 48 83 EC 30 41 8B 40 04 45 8B F9 85 C0 49 8B");
            }
            if (!m) {

                m = PatternScanner::FindPattern(hJvm,
                    "48 89 5C 24 10 48 89 6C 24 18 57 41 56 41 57 48 83 EC 30 41 8B 40 04 45 8B F9 85 C0 49 8B");
            }
            if (m) {
                s_constMethodAllocAddr = m;
                Log("[JvmApi] ConstMethod::allocate @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: ConstMethod::allocate not found (will try caller scan)");
            }
        }

        {
            uintptr_t m = PatternScanner::FindPattern(hJvm, JvmMapper::Signatures::method_allocate);
            if (!m) {
                m = PatternScanner::FindPattern(hJvm,
                    "48 89 5C 24 18 55 57 41 56 48 83 EC 30 48 8B 7C 24 78 49 8B C1 44 8B 4C");
            }
            if (!m) {
                m = PatternScanner::FindPattern(hJvm,
                    "48 89 5C 24 20 55 57 41 54 48 83 EC 30 48 8B 7C 24 78 49 8B C1 44 8B 4C 24 70 41 8B D8");
            }
            if (m) {
                s_methodAllocAddr = m;
                Log("[JvmApi] Method::allocate @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: Method::allocate not found (will try caller scan)");
            }
        }

        {
            uintptr_t m = PatternScanner::FindPattern(
                hJvm, JvmMapper::Signatures::method_link);
            if (m) {
                s_methodLinkAddr = m;
                Log("[JvmApi] Method::link_method @ %p (RVA 0x%llX)",
                    (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: Method::link_method not found");
            }
        }

        {
            uintptr_t m = PatternScanner::FindPattern(
                hJvm, JvmMapper::Signatures::metadata_handle_copy);
            if (m) {
                s_metadataHandleCopyAddr = m;
                Log("[JvmApi] metadataHandle copy ctor @ %p (RVA 0x%llX)",
                    (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: metadataHandle copy ctor not found");
            }
        }


        if (!s_methodAllocAddr || !s_constMethodAllocAddr) {
            CallerScanForMethodAlloc(hJvm);
        }


        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                JvmMapper::Signatures::constant_pool_allocate);
            if (m) {
                s_constantPoolAllocAddr = m;
                Log("[JvmApi] ConstantPool::allocate @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: ConstantPool::allocate not found");
            }
        }
        {
            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 48 63 F2");
            if (m) {
                s_symbolAllocAddr = m;
                Log("[JvmApi] SymbolTable::lookup @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: SymbolTable::lookup not found");
            }
        }

        {


            uintptr_t m = PatternScanner::FindPattern(hJvm,
                "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC ? 48 8B 7C 24 ? 44 8B FA");
            if (m) {
                s_updateDictionaryAddr = m;
                Log("[JvmApi] SystemDictionary::update_dictionary @ %p (RVA 0x%llX)", (void*)m, m - s_jvmBase);
            } else {
                Log("[JvmApi] WARNING: SystemDictionary::update_dictionary not found");
            }
        }
    }

    static void ResolveMirrorFunctions(HMODULE hJvm)
    {
        const uintptr_t base = reinterpret_cast<uintptr_t>(hJvm);


        uintptr_t wrapper = PatternScanner::FindPattern(hJvm,
            "48 89 5C 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 83 B9 ? ? ? ? 00 4D 8B F1 49 8B D8 48 8B C2 48 8B F9 75 ? 48 89 91 ? ? ? ? 48 8B D1 48 8B C8 E8 ? ? ? ? 48 83 7F ? 00");

        if (wrapper) {
            const int32_t cldCmp = *reinterpret_cast<const int32_t*>(wrapper + 19);
            const int32_t cldSet = *reinterpret_cast<const int32_t*>(wrapper + 41);

            const uint8_t mirror = *reinterpret_cast<const uint8_t*>(wrapper + 59);
            if (cldCmp != JvmMapper::Klass::class_loader_data ||
                cldSet != JvmMapper::Klass::class_loader_data ||
                mirror != JvmMapper::Klass::java_mirror) {
                Log("[JvmApi] Mirror wrapper rejected: layout mismatch cld=%X/%X mirror=%X",
                    static_cast<unsigned>(cldCmp),
                    static_cast<unsigned>(cldSet),
                    static_cast<unsigned>(mirror));
                wrapper = 0;
            }
        }

        if (wrapper) {
            s_restoreKlassMirrorAddr = wrapper;
        }

        s_createMirrorAddr = PatternScanner::FindPattern(hJvm,
            "48 89 74 24 ? 57 41 56 41 57 48 83 EC ? 48 8B 01 4C 8B F2 49 8B D1 4D 8B F9 49 8B F0 48 8B F9 FF 90 ? ? ? ? 49 83 7F ? 00");


        s_klassOopStoreAddr = PatternScanner::FindPattern(hJvm,
            "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 80 3D ? ? ? ? 00 49 8B F8 48 8B DA 48 8B F1 74 ? 48 8B 0A 48 85 C9 74 ? E8 ? ? ? ? 48 89 3B C6 86 ? ? ? ? 01");

        if (s_restoreKlassMirrorAddr && s_createMirrorAddr && s_klassOopStoreAddr) {
            Log("[JvmApi] Klass mirror restore wrapper @ %p (RVA 0x%llX)",
                (void*)s_restoreKlassMirrorAddr, s_restoreKlassMirrorAddr - base);
            Log("[JvmApi] java_lang_Class::create_mirror @ %p (RVA 0x%llX)",
                (void*)s_createMirrorAddr, s_createMirrorAddr - base);
            Log("[JvmApi] Klass::klass_oop_store @ %p (RVA 0x%llX)",
                (void*)s_klassOopStoreAddr, s_klassOopStoreAddr - base);
        } else {
            Log("[JvmApi] WARNING: complete GC-safe mirror path not resolved");
            s_restoreKlassMirrorAddr = 0;
        }
    }

    static void ResolveSystemDictionary(HMODULE hJvm)
    {
        const uintptr_t base = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t end  = GetImageEnd(hJvm);
        uintptr_t m = PatternScanner::FindPattern(
            hJvm, JvmMapper::Signatures::system_dictionary_from_update);
        if (!m) {
            Log("[JvmApi] WARNING: SystemDictionary::_dictionary not found");
            return;
        }

        uintptr_t address = DecodeRipRel(m + 3, 7);
        if (!CheckAddr(address, base, end)) {
            Log("[JvmApi] WARNING: SystemDictionary::_dictionary candidate invalid");
            return;
        }

        s_systemDictionaryAddr = address;
        Log("[JvmApi] SystemDictionary::_dictionary @ %p (RVA 0x%llX)",
            (void*)address, address - base);
    }

    static void ResolveKlassFieldOffset(HMODULE hJvm)
    {
        const uintptr_t base = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t end  = GetImageEnd(hJvm);
        uintptr_t m = PatternScanner::FindPattern(
            hJvm, JvmMapper::Signatures::oop_klass_field_offset);
        if (!m) {
            Log("[JvmApi] WARNING: oop klass-field offset state not found");
            return;
        }

        uintptr_t address = DecodeRipRel(m + 3, 7);
        if (!CheckAddr(address, base, end)) return;
        s_klassFieldOffsetAddr = address;
        Log("[JvmApi] oop klass-field offset state @ %p (RVA 0x%llX)",
            (void*)address, address - base);
    }


    static void CallerScanForMethodAlloc(HMODULE hJvm)
    {
        const uintptr_t base   = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t imgEnd = GetImageEnd(hJvm);


        if (!s_constMethodAllocAddr && s_constantPoolAllocAddr) {


            const uintptr_t scanStart = base;
            const uintptr_t scanEnd = imgEnd;


            for (uintptr_t addr = scanStart; addr < scanEnd - 30; addr++) {
                uint8_t* p = reinterpret_cast<uint8_t*>(addr);

                if (p[0] == 0x41 && p[1] == 0x54 &&
                    p[2] == 0x41 && p[3] == 0x56 &&
                    p[4] == 0x41 && p[5] == 0x57 &&
                    p[6] == 0x48 && p[7] == 0x83 && p[8] == 0xEC && p[9] == 0x30 &&
                    p[10] == 0x41 && p[11] == 0x8B && p[12] == 0x40 && p[13] == 0x04)
                {

                    uintptr_t funcStart = 0;
                    for (int back = 0; back < 16; back++) {
                        uint8_t* q = reinterpret_cast<uint8_t*>(addr - back);

                        if (q[0] == 0x48 && q[1] == 0x89 && q[3] == 0x24) {
                            funcStart = (uintptr_t)q;
                            break;
                        }
                    }
                    if (!funcStart) funcStart = addr;

                    s_constMethodAllocAddr = funcStart;
                    Log("[JvmApi] ConstMethod::allocate (caller scan) @ %p (RVA 0x%llX)",
                        (void*)funcStart, funcStart - base);
                    break;
                }
            }
        }

        if (!s_constMethodAllocAddr) {
            Log("[JvmApi] CallerScan: ConstMethod::allocate still not found, aborting");
            return;
        }


        if (!s_methodAllocAddr) {

            uintptr_t textStart = base;
            uintptr_t textEnd   = imgEnd;

            for (uintptr_t addr = textStart; addr < textEnd - 5; addr++) {
                uint8_t* p = reinterpret_cast<uint8_t*>(addr);
                if (p[0] != 0xE8) continue;

                int32_t rel = *reinterpret_cast<int32_t*>(addr + 1);
                uintptr_t target = addr + 5 + rel;
                if (target != s_constMethodAllocAddr) continue;


                uintptr_t funcStart = 0;
                for (int back = 0; back < 64; back++) {
                    uint8_t* q = reinterpret_cast<uint8_t*>(addr - back);


                    if (q[0] == 0x48 && q[1] == 0x89 && q[2] == 0x5C && q[3] == 0x24 &&
                        (q[4] == 0x18 || q[4] == 0x20) &&
                        q[5] == 0x55) {
                        funcStart = (uintptr_t)q;
                        break;
                    }
                }

                if (funcStart) {
                    s_methodAllocAddr = funcStart;
                    Log("[JvmApi] Method::allocate (caller scan) @ %p (RVA 0x%llX)",
                        (void*)funcStart, funcStart - base);
                    break;
                }
            }

            if (!s_methodAllocAddr)
                Log("[JvmApi] CallerScan: Method::allocate not found");
        }
    }


    static void ResolveInterpreterEntry(HMODULE hJvm)
    {
        const uintptr_t base   = reinterpret_cast<uintptr_t>(hJvm);
        const uintptr_t imgEnd = GetImageEnd(hJvm);


        uintptr_t m = PatternScanner::FindPattern(hJvm, "48 63 C1 48 8D 0D ? ? ? ? 48 89 14 C1");
        if (m) {
            uintptr_t addr = DecodeRipRel(m + 6, 7);
            if (CheckAddr(addr, base, imgEnd)) {
                s_interpreterEntryTable = addr;
                Log("[JvmApi] AbstractInterpreter::_entry_table @ %p (RVA 0x%llX)", (void*)addr, addr - base);
            }
        }

        if (!s_interpreterEntryTable) {
            Log("[JvmApi] WARNING: AbstractInterpreter::_entry_table not found");
        }
    }


    static void ResolveBootstrapCLD(HMODULE hJvm)
    {
        (void)hJvm;


        s_bootstrapCLDValue = 0;
        if (s_cldGraphHeadAddr) {
            uintptr_t cld = SafeRead<uintptr_t>(s_cldGraphHeadAddr);
            for (size_t count = 0; cld && count < 32768; ++count) {
                const uintptr_t classLoader = SafeRead<uintptr_t>(
                    cld + JvmMapper::ClassLoaderData::class_loader);
                if (classLoader == 0) {
                    s_bootstrapCLDValue = cld;
                    s_bootstrapCLDPtrAddr = reinterpret_cast<uintptr_t>(
                        &s_bootstrapCLDValue);
                    Log("[JvmApi] bootstrap CLD discovered from graph @ %p",
                        (void*)cld);
                    break;
                }
                cld = SafeRead<uintptr_t>(
                    cld + JvmMapper::ClassLoaderData::next);
            }
        }

        if (!s_bootstrapCLDPtrAddr)
            Log("[JvmApi] WARNING: bootstrap CLD ptr not found");
    }
};


inline bool      JvmApi::s_initialized      = false;
inline HMODULE   JvmApi::s_hJvm             = nullptr;
inline uintptr_t JvmApi::s_jvmBase          = 0;
inline uintptr_t JvmApi::s_cldGraphHeadAddr = 0;

inline uintptr_t JvmApi::s_emptyKlassArray  = 0;
inline uintptr_t JvmApi::s_emptyMethodArray = 0;
inline uintptr_t JvmApi::s_emptyIntArray    = 0;
inline uintptr_t JvmApi::s_emptyShortArray  = 0;

inline uintptr_t JvmApi::s_addClassAddr         = 0;
inline uintptr_t JvmApi::s_metaspaceNonNullAddr  = 0;
inline uintptr_t JvmApi::s_constMethodAllocAddr  = 0;
inline uintptr_t JvmApi::s_methodAllocAddr       = 0;
inline uintptr_t JvmApi::s_methodLinkAddr        = 0;
inline uintptr_t JvmApi::s_metadataHandleCopyAddr = 0;
inline uintptr_t JvmApi::s_constantPoolAllocAddr = 0;
inline uintptr_t JvmApi::s_symbolAllocAddr       = 0;
inline uintptr_t JvmApi::s_updateDictionaryAddr  = 0;
inline uintptr_t JvmApi::s_systemDictionaryAddr  = 0;
inline uintptr_t JvmApi::s_klassFieldOffsetAddr  = 0;
inline uintptr_t JvmApi::s_restoreKlassMirrorAddr = 0;
inline uintptr_t JvmApi::s_createMirrorAddr       = 0;
inline uintptr_t JvmApi::s_klassOopStoreAddr      = 0;

inline uintptr_t JvmApi::s_bootstrapCLDPtrAddr   = 0;
inline uintptr_t JvmApi::s_bootstrapCLDValue     = 0;
inline uintptr_t JvmApi::s_interpreterEntryTable = 0;
