#pragma once


#include <Windows.h>
#include <cstdint>
#include <string>
#include <vector>
#include "JvmMapper.hpp"


struct MethodInfo {
    std::string name;
    std::string signature;
    uintptr_t   method_ptr;
    uint32_t    access_flags;
};

struct FieldInfo {
    std::string name;
    std::string signature;
    uint32_t    offset;
    uint16_t    access_flags;
};

struct ClassInfo {
    std::string              name;
    uintptr_t                klass_ptr;
    std::vector<MethodInfo>  methods;
    std::vector<FieldInfo>   fields;
};


namespace Offsets {

    inline const std::ptrdiff_t& Sym_length = JvmMapper::Symbol::length;
    inline const std::ptrdiff_t& Sym_body = JvmMapper::Symbol::body;


    inline const std::ptrdiff_t& CP_base = JvmMapper::ConstantPool::base;


    inline const std::ptrdiff_t& CM_constants = JvmMapper::ConstMethod::constants;
    inline const std::ptrdiff_t& CM_sig_index = JvmMapper::ConstMethod::signature_index;
    inline const std::ptrdiff_t& CM_max_locals = JvmMapper::ConstMethod::max_locals;
    inline const std::ptrdiff_t& CM_constMethod_size = JvmMapper::ConstMethod::const_method_size;
    inline const std::ptrdiff_t& CM_size_of_params = JvmMapper::ConstMethod::size_of_parameters;
    inline const std::ptrdiff_t& CM_name_index = JvmMapper::ConstMethod::name_index;
    inline const std::ptrdiff_t& CM_flags = JvmMapper::ConstMethod::flags;
    inline const std::ptrdiff_t& CM_max_stack = JvmMapper::ConstMethod::max_stack;
    inline const std::ptrdiff_t& CM_code_size = JvmMapper::ConstMethod::code_size;
    inline const std::ptrdiff_t& CM_bytecode = JvmMapper::ConstMethod::bytecode;


    inline const std::ptrdiff_t& M_constMethod = JvmMapper::Method::const_method;
    inline const std::ptrdiff_t& M_access_flags = JvmMapper::Method::access_flags;


    inline const std::ptrdiff_t& IK_constants = JvmMapper::InstanceKlass::constants;
    inline std::ptrdiff_t& IK_methods = JvmMapper::InstanceKlass::methods;
    inline const std::ptrdiff_t& IK_fields = JvmMapper::InstanceKlass::fields;


    inline const std::ptrdiff_t& Arr_length = JvmMapper::Array::length;
    inline const std::ptrdiff_t& Arr_data = JvmMapper::Array::data;
}


std::string  ReadSymbol(uintptr_t symPtr);
std::string  ReadCpSymbol(uintptr_t cp, uint16_t idx);

std::vector<MethodInfo> ReadMethods(uintptr_t klassPtr);
std::vector<FieldInfo>  ReadFields(uintptr_t klassPtr);
