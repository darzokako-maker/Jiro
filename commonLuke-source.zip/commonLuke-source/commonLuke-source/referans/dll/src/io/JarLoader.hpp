#pragma once
#include <Windows.h>
#include <string>
#include <unordered_set>
#include <vector>
#include <iostream>
#include "miniz/miniz.h"
#include "jcfp/jcfp.hpp"
#include "Logging.hpp"
#include <cstring>

class JarLoader {
private:
    static bool HasBytes(const std::vector<jcfp::u1>& bytes,
                         size_t offset, size_t count) {
        return offset <= bytes.size() && count <= bytes.size() - offset;
    }

    static uint16_t ReadU2BE(const std::vector<jcfp::u1>& bytes, size_t offset) {
        return static_cast<uint16_t>(
            (static_cast<uint16_t>(bytes[offset]) << 8) |
             static_cast<uint16_t>(bytes[offset + 1]));
    }


    static bool ValidateJava8Envelope(const std::vector<jcfp::u1>& bytes,
                                      std::string& reason) {
        if (!HasBytes(bytes, 0, 10)) {
            reason = "truncated class header";
            return false;
        }

        const uint32_t magic =
            (static_cast<uint32_t>(bytes[0]) << 24) |
            (static_cast<uint32_t>(bytes[1]) << 16) |
            (static_cast<uint32_t>(bytes[2]) << 8) |
             static_cast<uint32_t>(bytes[3]);
        if (magic != JCFP_CLASSFILE_MAGIC) {
            reason = "bad class magic";
            return false;
        }

        const uint16_t major = ReadU2BE(bytes, 6);
        if (major != static_cast<uint16_t>(jcfp::MajorVersion::JAVA_SE_8)) {
            reason = "unsupported class version " + std::to_string(major) +
                " (expected Java 8 / 52)";
            return false;
        }

        const uint16_t cpCount = ReadU2BE(bytes, 8);
        if (cpCount == 0) {
            reason = "invalid constant-pool count";
            return false;
        }

        size_t cursor = 10;
        for (uint16_t index = 1; index < cpCount; ++index) {
            if (!HasBytes(bytes, cursor, 1)) {
                reason = "truncated constant pool";
                return false;
            }
            const uint8_t tag = bytes[cursor++];
            size_t payloadSize = 0;
            switch (tag) {
                case 1:
                    if (!HasBytes(bytes, cursor, 2)) {
                        reason = "truncated Utf8 constant";
                        return false;
                    }
                    payloadSize = 2u + ReadU2BE(bytes, cursor);
                    break;
                case 3: case 4:
                case 9: case 10: case 11: case 12: case 18:
                    payloadSize = 4;
                    break;
                case 5: case 6:
                    payloadSize = 8;
                    if (++index >= cpCount) {
                        reason = "wide constant missing reserved slot";
                        return false;
                    }
                    break;
                case 7: case 8: case 16:
                    payloadSize = 2;
                    break;
                case 15:
                    payloadSize = 3;
                    break;
                default:
                    reason = "unsupported constant-pool tag " +
                        std::to_string(static_cast<unsigned>(tag));
                    return false;
            }
            if (!HasBytes(bytes, cursor, payloadSize)) {
                reason = "truncated constant-pool payload";
                return false;
            }
            cursor += payloadSize;
        }
        return true;
    }

    static bool GetClassName(const jcfp::ClassFile& cf, jcfp::u2 classIndex,
                             std::string& name) {
        const auto& cp = cf.constant_pool;
        if (!classIndex || classIndex >= cp.count() ||
            cp.get_tag(classIndex) != jcfp::ConstantPoolEntry::Tag::Class)
            return false;
        const auto& classInfo = cp.get_entry(classIndex)
            .get<jcfp::ConstantPoolEntry::ClassInfo>();
        if (!classInfo.name_index || classInfo.name_index >= cp.count() ||
            cp.get_tag(classInfo.name_index) != jcfp::ConstantPoolEntry::Tag::Utf8)
            return false;
        name = cp.get_entry(classInfo.name_index)
            .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
        return !name.empty();
    }

    static bool ValidateParsedClass(const jcfp::ClassFile& cf,
                                    std::string& className,
                                    std::string& reason, bool allowNativeMethods = false) {
        if (!GetClassName(cf, cf.this_class, className)) {
            reason = "invalid this_class entry";
            return false;
        }

        if (cf.super_class) {
            std::string ignored;
            if (!GetClassName(cf, cf.super_class, ignored)) {
                reason = "invalid super_class entry";
                return false;
            }
        }
        for (jcfp::u2 interfaceIndex : cf.interfaces) {
            std::string ignored;
            if (!GetClassName(cf, interfaceIndex, ignored)) {
                reason = "invalid interface entry";
                return false;
            }
        }

        const auto& cp = cf.constant_pool;
        const bool isInterface =
            (static_cast<uint16_t>(cf.access_flags) & jcfp::ACC_INTERFACE) != 0;
        for (const auto& method : cf.methods) {
            if (!method.name_index || method.name_index >= cp.count() ||
                cp.get_tag(method.name_index) != jcfp::ConstantPoolEntry::Tag::Utf8 ||
                !method.descriptor_index || method.descriptor_index >= cp.count() ||
                cp.get_tag(method.descriptor_index) != jcfp::ConstantPoolEntry::Tag::Utf8) {
                reason = "invalid method name/descriptor entry";
                return false;
            }
            const auto flags = static_cast<uint16_t>(method.access_flags);
            const std::string& methodName = cp.get_entry(method.name_index)
                .get<jcfp::ConstantPoolEntry::Utf8Info>().bytes;
            if ((flags & jcfp::ACC_NATIVE) != 0 && !allowNativeMethods) {
                reason = "native method is unsupported: " + methodName;
                return false;
            }
            if (isInterface && methodName != "<clinit>" &&
                (flags & (jcfp::ACC_ABSTRACT | jcfp::ACC_STATIC)) == 0) {
                reason = "interface default method is unsupported: " + methodName;
                return false;
            }
        }
        return true;
    }

public:

    struct ParsedClass {
        std::string name;
        std::vector<jcfp::u1> bytecode;
        jcfp::ClassFile class_file;
    };

    static std::vector<ParsedClass> LoadClasses(mz_zip_archive& zip_archive, bool allowNativeMethods) {
        std::vector<ParsedClass> loadedClasses;
        int numFiles = (int)mz_zip_reader_get_num_files(&zip_archive);
        Log("[JarLoader] Opened JAR with %d files.", numFiles);
        bool invalidJar = false;
        std::unordered_set<std::string> classNames;

        for (int i = 0; i < numFiles; i++) {
            mz_zip_archive_file_stat file_stat;
            if (!mz_zip_reader_file_stat(&zip_archive, i, &file_stat)) {
                Log("[JarLoader] Failed to read JAR entry metadata at index %d", i);
                invalidJar = true;
                break;
            }

            std::string filename = file_stat.m_filename;

            if (filename.length() > 6 && filename.substr(filename.length() - 6) == ".class") {
                size_t uncomp_size;
                void* p = mz_zip_reader_extract_file_to_heap(&zip_archive, file_stat.m_filename, &uncomp_size, 0);
                if (!p) {
                    Log("[JarLoader] Failed to extract file: %s", filename.c_str());
                    invalidJar = true;
                    break;
                }

                std::vector<jcfp::u1> bytecode((jcfp::u1*)p, (jcfp::u1*)p + uncomp_size);
                mz_free(p);

                std::string validationReason;
                if (!ValidateJava8Envelope(bytecode, validationReason)) {
                    Log("[JarLoader] Rejected %s: %s", filename.c_str(),
                        validationReason.c_str());
                    invalidJar = true;
                    break;
                }

                try {

                    auto result = jcfp::ClassFile::parse(bytecode);
                    if (!result) {
                        Log("[JarLoader] jcfp parsing failed for: %s", filename.c_str());
                        invalidJar = true;
                        break;
                    }

                    std::string validatedClassName;
                    if (!ValidateParsedClass(result.value(), validatedClassName,
                                             validationReason, allowNativeMethods)) {
                        Log("[JarLoader] Rejected %s: %s", filename.c_str(),
                            validationReason.c_str());
                        invalidJar = true;
                        break;
                    }
                    if (!classNames.insert(validatedClassName).second) {
                        Log("[JarLoader] Rejected duplicate class: %s",
                            validatedClassName.c_str());
                        invalidJar = true;
                        break;
                    }

                    ParsedClass pc{filename, std::move(bytecode), std::move(result.value())};

                Log("[JarLoader] ----------------------------------------");
                Log("[JarLoader] Found Class File: %s", filename.c_str());
                Log("[JarLoader] Extracted Size: %zu bytes", pc.bytecode.size());


                jcfp::u2 this_class_idx = pc.class_file.this_class;
                auto& cp = pc.class_file.constant_pool;

                std::string actualClassName = "unknown";
                if (this_class_idx > 0 && this_class_idx < cp.count()) {
                    auto& class_info = cp.get_entry(this_class_idx).get<jcfp::ConstantPoolEntry::ClassInfo>();
                    if (class_info.name_index > 0 && class_info.name_index < cp.count()) {
                        auto& utf8_info = cp.get_entry(class_info.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                        actualClassName = utf8_info.bytes;
                    }
                }

                std::string superClassName = "none";
                jcfp::u2 super_class_idx = pc.class_file.super_class;
                if (super_class_idx > 0 && super_class_idx < cp.count()) {
                    auto& super_class_info = cp.get_entry(super_class_idx).get<jcfp::ConstantPoolEntry::ClassInfo>();
                    if (super_class_info.name_index > 0 && super_class_info.name_index < cp.count()) {
                        auto& utf8_info = cp.get_entry(super_class_info.name_index).get<jcfp::ConstantPoolEntry::Utf8Info>();
                        superClassName = utf8_info.bytes;
                    }
                }

                Log("[JarLoader] Parsed Class: %s", actualClassName.c_str());
                Log("[JarLoader] Super Class : %s", superClassName.c_str());
                Log("[JarLoader] Interfaces  : %zu", pc.class_file.interfaces.size());
                Log("[JarLoader] Fields      : %zu", pc.class_file.fields.size());
                Log("[JarLoader] Methods     : %zu", pc.class_file.methods.size());
                Log("[JarLoader] Attributes  : %zu", pc.class_file.attributes.size());
                Log("[JarLoader] ----------------------------------------");

                    loadedClasses.push_back(std::move(pc));
                } catch (const std::exception& error) {
                    Log("[JarLoader] Parser exception for %s: %s",
                        filename.c_str(), error.what());
                    invalidJar = true;
                    break;
                } catch (...) {
                    Log("[JarLoader] Unknown parser exception for %s", filename.c_str());
                    invalidJar = true;
                    break;
                }
            }
        }

        mz_zip_reader_end(&zip_archive);
        if (invalidJar) {
            Log("[JarLoader] JAR rejected; no classes will be injected");
            loadedClasses.clear();
            return loadedClasses;
        }
        Log("[JarLoader] Finished loading %zu classes from JAR.", loadedClasses.size());
        return loadedClasses;
    }
    static std::vector<ParsedClass> LoadClassesFromJar(const std::string& jarPath, bool allowNativeMethods = false) {
        mz_zip_archive zip_archive{};
        if (!mz_zip_reader_init_file(&zip_archive, jarPath.c_str(), 0)) {
            Log("[JarLoader] Failed to open jar: %s", jarPath.c_str());
            return {};
        }
        return LoadClasses(zip_archive,allowNativeMethods);
    }
    static std::vector<ParsedClass> LoadClassesFromMemory(const void* bytes,size_t size,bool allowNativeMethods=false) {
        if(!bytes||!size)return {};
        mz_zip_archive zip_archive{};
        if(!mz_zip_reader_init_mem(&zip_archive,bytes,size,0))return {};
        return LoadClasses(zip_archive,allowNativeMethods);
    }
};
